#include "nm_peripherals.h"

#ifdef __AVR__
#include <avr/interrupt.h>
#include <avr/io.h>

/* [БИНАРНИК] 0x0CBE..0x0CE8 и 0x0D8A..0x0D92.
 * [РУКОВОДСТВО] 1-Wire DS18B20. PD7 отпускается через DDR.
 * Исходник прекращает ожидание присутствия после 255 итераций.
 * Задержки C близки по числу циклов, осциллограммы пока не проверены. */
bool nm_atmega32_onewire_reset(void)
{
    PORTD &= (uint8_t)~_BV(PD7);
    DDRD |= _BV(PD7);
    __builtin_avr_delay_cycles(510);
    cli();
    DDRD &= (uint8_t)~_BV(PD7);
    uint8_t remaining = 255;
    do {
        remaining--;
    } while (remaining && (PIND & _BV(PD7)));
    sei();
    __builtin_avr_delay_cycles(510);
    return remaining != 0;
}

/* [БИНАРНИК] 0x0CEA..0x0D00. Для единицы PD7 освобождается
 * сразу, для нуля остаётся выходом до конца слота. */
static void write_bit(bool value)
{
    cli();
    DDRD |= _BV(PD7);
    if (value)
        DDRD &= (uint8_t)~_BV(PD7);
    __builtin_avr_delay_cycles(99);
    DDRD &= (uint8_t)~_BV(PD7);
    sei();
}

/* [БИНАРНИК] 0x0D02..0x0D2A. Считывание вскоре после отпускания
 * линии. Оригинал явно включает прерывания после выборки. */
static bool read_bit(void)
{
    cli();
    DDRD |= _BV(PD7);
    DDRD &= (uint8_t)~_BV(PD7);
    __builtin_avr_delay_cycles(22);
    bool value = (PIND & _BV(PD7)) != 0;
    sei();
    __builtin_avr_delay_cycles(85);
    return value;
}

/* [БИНАРНИК] 0x0D2C..0x0D88. На шине первым идёт младший бит. */
void nm_atmega32_onewire_write(uint8_t byte)
{
    for (uint8_t bit = 1; bit != 0; bit <<= 1)
        write_bit((byte & bit) != 0);
}

uint8_t nm_atmega32_onewire_read(void)
{
    uint8_t value = 0;
    for (uint8_t bit = 1; bit != 0; bit <<= 1)
        if (read_bit())
            value |= bit;
    return value;
}

void nm_atmega32_onewire_send(const uint8_t *bytes, uint8_t count)
{
    while (count--)
        nm_atmega32_onewire_write(*bytes++);
}
/* [БИНАРНИК] 0x12C4..0x12D2, 0x13D8..0x13E2, 0x1432..0x1462.
 * Работа с ранее выбранным ROM. Цикл ожидания измерения и поиск ROM
 * относятся к вызывающему коду; эта операция читает один scratchpad. */
bool nm_atmega32_dallas_read(const uint8_t rom[8], int16_t *temperature)
{
    uint8_t bytes[9];
    (void)nm_atmega32_onewire_reset();
    nm_atmega32_onewire_write(0x55);
    nm_atmega32_onewire_send(rom, 8);
    nm_atmega32_onewire_write(0xbe);
    for (uint8_t i = 0; i < sizeof bytes; i++)
        bytes[i] = nm_atmega32_onewire_read();
    if (!nm_dallas_scratchpad_valid(bytes))
        return false;
    *temperature = nm_dallas_temperature(rom[0], bytes);
    return true;
}

#endif
