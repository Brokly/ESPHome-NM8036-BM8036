/* Оригинал запускается в simavr только для независимой проверки. */
#include "nm_peripherals.h"
#include "fixture.h"
#include <simavr/sim_avr.h>
#include <simavr/avr_eeprom.h>
#include <simavr/avr_uart.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint8_t flash[28668];

static void capture(struct avr_irq_t *irq, uint32_t value, void *param)
{
    (void)irq;
    send(param, (uint8_t)value);
}

static void step(avr_t *avr)
{
    int status = avr_run(avr);
    assert(status != cpu_Crashed && status != cpu_Done);
}

static void check(uint8_t command, unsigned seed, unsigned input_count)
{
    Fixture original = {0};
    uint32_t random = seed;
    for (unsigned i = 0; i < sizeof original.ee; i++) {
        random = random * 1664525u + 1013904223u;
        original.ee[i] = (uint8_t)(random >> 24);
    }
    for (unsigned i = 0; i < sizeof original.ram; i++)
        original.ram[i] = original.ee[i % 1024];
    for (unsigned i = 0; i < sizeof original.rx; i++)
        original.rx[i] = original.ee[i + 99];
    if (command == 'W')
        original.rx[0] = (uint8_t)seed;
    Fixture translated = original;
    NM8036 m = fixture_device(&translated);
    m.output_reply_seed = translated.ram[0x0321 - 0x60];
    assert(nm_command(&m, command));
    assert(translated.rx_count == input_count);

    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr->frequency = 1000000;
    avr_loadcode(avr, flash, sizeof flash, 0);
    avr->log = LOG_NONE;
    memcpy(avr->data + 0x60, original.ram, sizeof original.ram);
    avr_eeprom_desc_t ee = {original.ee, 0, sizeof original.ee};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
    uint32_t flags = 0;
    avr_ioctl(avr, AVR_IOCTL_UART_SET_FLAGS('0'), &flags);
    avr_irq_t *out = avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'), UART_IRQ_OUTPUT);
    avr_irq_t *in = avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'), UART_IRQ_INPUT);
    assert(out && in);
    avr_irq_register_notify(out, capture, &original);

    /* Выполняем оригинальную настройку UART до RET, затем входим
       в диспетчер после приёма команды. Y — программный стек компилятора. */
    avr->pc = 0x2bf6;
    for (unsigned i = 0; i < 8; i++)
        step(avr);
    assert(avr->pc == 0x2c06);
    /* Модель simavr 1.6 трактует запись UCSRC как старший делитель.
       Исправляем только моделируемое значение делителя перед обменом. */
    avr_core_watch_write(avr, 0x40, 0);
    avr->data[0x5d] = 0x5f;
    avr->data[0x5e] = 0x06;
    avr->data[28] = 0x20;
    avr->data[29] = 0x03;
    avr->data[0x0320] = command;
    avr->pc = 0x54cc;
    for (unsigned i = 0; i < input_count; i++)
        avr_raise_irq(in, original.rx[i]);

    while (avr->pc != 0x5848 && avr->cycle < 400000000)
        step(avr);
    if (avr->pc != 0x5848) fprintf(stderr, "timeout %c at %04x, sent %u, SP %02x%02x\n", command, avr->pc, original.tx_count, avr->data[0x5e], avr->data[0x5d]);
    assert(avr->pc == 0x5848);
    avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
    if (original.tx_count != translated.tx_count ||
        memcmp(original.tx, translated.tx, translated.tx_count) ||
        memcmp(original.ee, translated.ee, sizeof original.ee)) {
        fprintf(stderr, "%c seed=%u UART AVR=%u C=%u\n", command, seed,
                original.tx_count, translated.tx_count);
        for (unsigned i = 0; i < translated.tx_count; i++)
            if (original.tx[i] != translated.tx[i]) {
                fprintf(stderr, "TX[%u] AVR=%02x C=%02x\n", i, original.tx[i], translated.tx[i]);
                break;
            }
        for (unsigned i = 0; i < sizeof original.ee; i++)
            if (original.ee[i] != translated.ee[i]) {
                fprintf(stderr, "EEPROM[%03x] AVR=%02x C=%02x\n", i, original.ee[i], translated.ee[i]);
            }
        abort();
    }
    assert(avr->data[0x068e] == *nm_ram(&m, 0x068e));
    assert(avr->data[0x0739] == *nm_ram(&m, 0x0739));
    avr_terminate(avr);
    free(avr);
}

static void check_calendar(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (unsigned year = 0; year < 100; year += 3)
        for (unsigned month = 0; month <= 12; month++) {
            avr->data[28] = 0x20;
            avr->data[29] = 0x03;
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[16] = 19;
            avr->data[17] = 32;
            avr->data[18] = 43;
            avr->data[19] = 29;
            avr->data[20] = (uint8_t)month;
            avr->data[21] = (uint8_t)year;
            avr->pc = 0x3af4;
            unsigned budget = 5000;
            while (avr->pc != 0x3b94 && budget--)
                step(avr);
            assert(avr->pc == 0x3b94);
            uint32_t actual = 0;
            for (unsigned i = 0; i < 4; i++)
                actual |= (uint32_t)avr->data[16 + i] << (8 * i);
            assert(actual == nm_calendar_seconds(year, month, 29, 19, 32, 43));
        }
    avr_terminate(avr);
    free(avr);
}

static void check_schedule(void)
{
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (unsigned period = 0; period < 4; period++)
        for (unsigned pattern = 0; pattern < 3; pattern++) {
            uint8_t record[27] = {0};
            record[0] = pattern == 0 ? 7 : 17;
            record[1] = record[4] = 17;
            record[2] = record[5] = 15;
            record[3] = pattern == 1 ? 7 : 17;
            record[6] = record[7] = 18;
            record[8] = record[9] = 11;
            record[10] = record[11] = 26;
            record[19] = (uint8_t)period;
            record[25] = 1;
            uint8_t mask_bit = period == 1 ? 2 : period == 2 ? 17 : 10;
            record[20 + mask_bit / 8] = (uint8_t)(1u << (mask_bit % 8));
            nm_program_write(&m, 31, record);
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            for (unsigned hour = 0; hour < 24; hour++)
                for (unsigned offset = 0; offset < 3; offset++) {
                    uint8_t rtc[8] = {0x14 + offset,0x17,0,3,0x18,0x11,0x26,0x90};
                    rtc[2] = (uint8_t)((hour / 10) * 16 + hour % 10);
                    memcpy(avr->data + 0x0727, rtc, sizeof rtc);
                    avr->data[0x06b9] = 31;
                    avr->data[28] = 0x20;
                    avr->data[29] = 0x03;
                    avr->data[0x5d] = 0x5f;
                    avr->data[0x5e] = 0x06;
                    avr->pc = 0x3bc0;
                    unsigned budget = 10000;
                    while (avr->pc != 0x3ccc && avr->pc != 0x3d40 && budget--)
                        step(avr);
                    assert(avr->pc == 0x3ccc || avr->pc == 0x3d40);
                    bool actual = avr->pc == 0x3ccc;
                    bool translated = nm_schedule_window(&m, 31, rtc);
                    if (actual != translated)
                        fprintf(stderr, "period=%u pattern=%u hour=%u offset=%u AVR=%d C=%d\n",
                            period, pattern, hour, offset, actual, translated);
                    assert(actual == translated);
                }
        }
    avr_terminate(avr);
    free(avr);
}

static uint8_t unused_key(const NM8036 *m)
{
    (void)m;
    assert(!"Отключённый будильник не должен опрашивать АЦП");
    return 0xff;
}

static void check_control(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);

    for (uint8_t mode = 0; mode < 4; mode++)
        for (uint8_t config = 0; config < 8; config++)
            for (int16_t value = -70; value <= 70; value += 10) {
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                volatile uint8_t *rtc = nm_ram(&m, 0x0727);
                rtc[2] = 0x13;
                rtc[3] = rtc[4] = rtc[5] = 1;
                uint8_t record[27] = {0};
                record[0] = 6;
                record[3] = (config & 4) ? 12 : 18;
                record[13] = 0;
                record[14] = 0xc4;
                record[15] = 0xff;
                record[16] = 60;
                record[18] = mode;
                record[19] = 2;
                record[20] = 1;
                record[25] = 1;
                record[26] = (config & 2) ? 2 : 0;
                nm_program_write(&m, 31, record);
                if (mode == 2)
                    f.ee[0x4c + 21 * 31 + 5] |= 0x80;
                f.ee[0x02ed] = 1;
                *nm_ram(&m, 0x0707) = 1;
                nm_ram(&m, 0x06c7)[0] = (uint8_t)value;
                nm_ram(&m, 0x06c7)[1] = (uint8_t)((uint16_t)value >> 8);
                *nm_ram(&m, 0x06b9) = 31;
                *nm_ram(&m, 0x06ba) = config & 1;
                *nm_ram(&m, 0x0747 + 37) = config & 1;
                memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
                avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                nm_schedule_step(&m, unused_key);

                avr->data[28] = 0x20;
                avr->data[29] = 0x03;
                avr->data[0x5d] = 0x5f;
                avr->data[0x5e] = 0x06;
                avr->pc = 0x3bc0;
                unsigned budget = 15000;
                while (avr->pc != 0x3eba && budget--)
                    step(avr);
                assert(avr->pc == 0x3eba);
                if (memcmp(avr->data + 0x06b9, (const void *)nm_ram(&m, 0x06b9), 13) ||
                    memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 49)) {
                    fprintf(stderr, "control mode=%u config=%u val=%d AVR=%u C=%u\n",
                            mode, config, value, avr->data[0x076c], *nm_ram(&m, 0x076c));
                    abort();
                }
            }
    avr_terminate(avr);
    free(avr);
}

static void check_startup_and_sensors(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    memset(avr->data + 0x660, 0x5a, 0x124);
    memset((void *)nm_ram(&m, 0x660), 0x5a, 0x124);
    avr->data[0x5d] = 0x5f;
    avr->data[0x5e] = 0x06;
    avr->pc = 0x6b1a;
    while (avr->pc != 0x6b4c && avr->cycle < 9000)
        step(avr);
    assert(avr->pc == 0x6b4c);
    nm_startup_memory(&m);
    assert(!memcmp(avr->data + 0x660, (const void *)nm_ram(&m, 0x660), 0x124));

    for (unsigned seed = 0; seed < 64; seed++) {
        uint8_t bytes[9];
        for (unsigned i = 0; i < sizeof bytes; i++)
            bytes[i] = (uint8_t)(seed * 17u + i * 73u);
        memcpy(avr->data + 0x0600, bytes, sizeof bytes);
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[16] = 0;
        avr->data[17] = 6;
        avr->data[18] = sizeof bytes;
        avr->pc = 0x411a;
        unsigned budget = 4000;
        while (avr->pc != 0x4158 && budget--)
            step(avr);
        assert(avr->pc == 0x4158);
        assert(avr->data[16] == nm_dallas_crc(bytes, sizeof bytes));
    }

    for (int raw = -880; raw <= 2000; raw += 13)
        for (unsigned family = 0; family < 2; family++) {
            uint8_t bytes[9] = {(uint8_t)raw, (uint8_t)((uint16_t)raw >> 8)};
            bytes[6] = (uint8_t)((uint16_t)raw % 20);
            bytes[7] = (uint8_t)((uint16_t)raw % 18);
            memcpy(avr->data + 0x0600, bytes, sizeof bytes);
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[26] = 0;
            avr->data[27] = 6;
            avr->data[4] = bytes[7];
            avr->data[6] = bytes[6];
            avr->pc = family ? 0x14a2 : 0x14ba;
            unsigned budget = 5000;
            while (avr->pc != 0x14d6 && budget--)
                step(avr);
            assert(avr->pc == 0x14d6);
            int16_t actual = (int16_t)(avr->data[24] | (unsigned)avr->data[25] << 8);
            int16_t translated = nm_dallas_temperature(family ? 0x10 : 0x28, bytes);
            if (actual != translated)
                fprintf(stderr, "sensor family=%u raw=%d count=%u/%u AVR=%d C=%d\n",
                        family, raw, bytes[6], bytes[7], actual, translated);
            assert(actual == translated);
        }
    avr_terminate(avr);
    free(avr);
}

static void check_pulse_outputs(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    for (uint8_t channel = 0; channel < 12; channel++) {
        f.ee[0x15 + 2 * channel] = channel;
        f.ee[0x2d + 2 * channel] = channel % 5;
    }
    nm_outputs_init(&m);
    for (uint8_t channel = 0; channel < 12; channel++)
        *nm_ram(&m, 0x0747 + 37 + channel) = channel % 3 != 2;
    memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
    avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);

    for (unsigned tick = 0; tick < 32; tick++) {
        avr->data[28] = 0x20;
        avr->data[29] = 0x03;
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[16] = 0x47;
        avr->data[17] = 0x07;
        avr->pc = 0x2508;
        unsigned budget = 15000;
        while (avr->pc != 0x259c && budget--)
            step(avr);
        assert(avr->pc == 0x259c);
        nm_outputs_tick(&m);
        assert(!memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 49));
        assert(avr->data[0x3b] == f.porta);
        assert(avr->data[0x35] == f.portc);
        assert(avr->data[0x32] == f.portd);
    }
    avr_terminate(avr);
    free(avr);
}

int main(int argc, char **argv)
{
    assert(argc == 2);
    FILE *file = fopen(argv[1], "rb");
    assert(file && fread(flash, 1, sizeof flash, file) == sizeof flash);
    assert(fgetc(file) == EOF);
    fclose(file);
    check_startup_and_sensors();
    check_calendar();
    check_schedule();
    check_control();
    check_pulse_outputs();
    const char commands[] = "VDdtsvbiaclz";
    for (unsigned i = 0; commands[i]; i++)
        check((uint8_t)commands[i], 1, 0);
    check('K', 3, 1);
    check('A', 9, 48);
    check('I', 11, 27);
    check('L', 0, 0);
    check('L', 17, 0);
    for (unsigned i = 0; i < 32; i++)
        check('W', i, 28);
    check('W', 255, 28);
    puts("simavr: UART, EEPROM, пусковые данные, датчики, календарь, расписания и запросы выходов совпали");
}
