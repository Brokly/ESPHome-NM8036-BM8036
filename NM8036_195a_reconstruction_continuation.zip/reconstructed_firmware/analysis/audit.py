#!/usr/bin/env python3
"""Декодирование .cod, статический обход AVR, реестр перевода и пробелов."""
import collections
import csv
import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
cod = (ROOT / "original.cod").read_bytes()
image = (ROOT / "original.bin").read_bytes()
assert len(cod) == 28924 and len(image) == 28668
assert bytes((byte - cod[i % 256]) & 255 for i, byte in enumerate(cod[256:])) == image
assert image[:4] == bytes.fromhex("0c 94 5c 31")

def word(address):
    return int.from_bytes(image[address:address + 2], "little")

def size(address):
    opcode = word(address)
    if opcode & 0xfe0e in (0x940c, 0x940e) or opcode & 0xfe0f in (0x9000, 0x9200):
        return 4
    return 2

def signed(value, bits):
    sign = 1 << (bits - 1)
    return (value ^ sign) - sign

def switch_table(base):
    """0x6926: 8-битный selector, пары адресов и приращений либо плотная таблица."""
    first, flags = image[base:base + 2]
    assert flags in (0, 1)
    default = 2 * word(base + 2)
    pos = base + 4
    if flags == 0:
        count = word(pos)
        return default, {first + i: 2 * word(pos + 2 + 2 * i) for i in range(count)}, pos + 2 + 2 * count
    targets = {}
    while True:
        targets[first] = 2 * word(pos)
        pos += 2
        delta = image[pos]
        pos += 1
        if delta == 0xfb:
            return default, targets, pos
        assert 0 < delta < 0xfb
        first += delta
        assert first < 256

switches = {
    0x3040: 0x0bf0, 0x49d2: 0x0c0a, 0x4a5a: 0x0c26,
    0x54d2: 0x0c42, 0x5e4c: 0x0c88,
}
tables = {site: switch_table(base) for site, base in switches.items()}
listing = subprocess.check_output(
    ["avr-objdump", "-D", "-z", "-b", "binary", "-m", "avr:5", "original.bin"],
    cwd=ROOT, text=True)
(ROOT / "original.lst").write_text(listing)
decoded = {}
for line in listing.splitlines():
    match = re.match(r"^\s*([0-9a-f]+):\s+((?:[a-f0-9]{2}\s+)+)(\S.*)$", line)
    if match:
        address = int(match[1], 16)
        decoded[address] = (len(bytes.fromhex(match[2])), match[3])

# Таблицы/строки в flash между векторами и первой функцией,
# таблица startup и конец образа после последнего RET.
data_regions = [(0x0054, 0x0cbe), (0x6fd2, len(image))]
# Вторые слова четырёхбайтовых слотов с однословным RETI.
vector_padding = [(a + 2, a + 4) for a in range(0, 0x54, 4) if word(a) == 0x9518]
assert all(word(a) == 0x9518 for a, _ in vector_padding)
data_regions += vector_padding

# 0x185A помещает указатель структуры в X+20, 0x2746..0x274E
# помещают другой указатель в X+14, 0x62D0..0x62D8 задают
# полный диапазон таблицы вызовов при запуске.
indirect_tables = {
    0x1996: range(0x0180, 0x0186, 2),
    0x298a: range(0x03d8, 0x03e0, 2),
    0x622c: range(0x0cbc, 0x0cbe, 2),
}
def is_data(address):
    return any(start <= address < stop for start, stop in data_regions)

vectors = set(range(0, 0x54, 4))
pending = collections.deque(sorted(vectors))
edges = set()
seen = set()
entries = set(vectors)
indirect = set()
external = set()
bad = set()
def edge(source, target, kind):
    edges.add((source, target, kind))
    if not 0 <= target < len(image):
        external.add((source, target))
    elif target & 1 or is_data(target):
        bad.add((source, target))
    else:
        pending.append(target)

while pending:
    address = pending.popleft()
    if address in seen:
        continue
    seen.add(address)
    opcode = word(address)
    nxt = address + size(address)
    parsed = decoded.get(address)
    if parsed is None or parsed[0] != size(address) or parsed[1].startswith(".word"):
        bad.add((address, address))
        continue
    if address in tables:
        default, targets, _ = tables[address]
        for target in set(targets.values()) | {default}:
            edge(address, target, "switch")
        edge(address, 0x6926, "switch_helper")
    elif opcode & 0xfe0e in (0x940c, 0x940e) or opcode >> 12 in (0xc, 0xd):
        if opcode >> 12 in (0xc, 0xd):
            target = nxt + 2 * signed(opcode & 0xfff, 12)
            call = opcode >> 12 == 0xd
        else:
            target = 2 * ((((opcode & 0x1f0) >> 3 | opcode & 1) << 16) + word(address + 2))
            call = bool(opcode & 2)
        edge(address, target, "call" if call else "jump")
        if call or address in vectors:
            entries.add(target)
        if call:
            edge(address, nxt, "return_site")
    elif opcode & 0xf800 == 0xf000:
        edge(address, nxt + 2 * signed(opcode >> 3 & 127, 7), "branch")
        edge(address, nxt, "fallthrough")
    elif (opcode & 0xfc00 == 0x1000 or opcode & 0xfe08 in (0xfc00, 0xfe00)
          or opcode & 0xfd00 == 0x9900):
        edge(address, nxt, "skip_fallthrough")
        edge(address, nxt + size(nxt), "skip_taken")
    elif opcode in (0x9409, 0x9509):
        if address in indirect_tables:
            for slot in indirect_tables[address]:
                target = 2 * word(slot)
                edge(address, target, "flash_pointer")
                entries.add(target)
        if address != 0x622c:
            indirect.add(address)
        if opcode == 0x9509:
            edge(address, nxt, "return_site")
    elif opcode not in (0x9508, 0x9518, 0x9598):
        edge(address, nxt, "fallthrough")

# Во входной таблице покрытия интервалы полуоткрытые.
coverage = []
for line in (ROOT / "translated.tsv").read_text().splitlines():
    if line and not line.startswith("#"):
        start, stop, name, level = line.split("\t")
        coverage.append((int(start, 16), int(stop, 16), name, level))

def label(address):
    for start, stop, name, level in coverage:
        if start <= address < stop:
            return name, level
    return "", ""

def hex_address(address):
    return f"0x{address:04X}"

def write_csv(filename, headers, rows):
    with (ROOT / filename).open("w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(rows)

def code_size(addresses):
    return sum(size(a) for a in addresses)

write_csv("edges.csv", ("from", "to", "kind"),
          ((hex_address(a), hex_address(b), k) for a, b, k in sorted(edges)))
write_csv("switches.csv", ("site", "table", "selector", "target"),
          ((hex_address(site), hex_address(switches[site]), selector, hex_address(target))
           for site, (default, targets, _) in tables.items()
           for selector, target in [("default", default), *sorted(targets.items())]))
write_csv("entries.csv", ("entry", "module", "verification"),
          ((hex_address(a), *label(a)) for a in sorted(entries)))
write_csv("instructions.csv", ("address", "size", "instruction", "module", "verification"),
          ((hex_address(a), size(a), decoded.get(a, (0, "?"))[1], *label(a)) for a in sorted(seen)))

def coalesce(addresses, instruction_sizes):
    for address in sorted(addresses):
        stop = address + instruction_sizes(address)
        if ranges and ranges[-1][1] == address:
            ranges[-1] = (ranges[-1][0], stop)
        else:
            ranges.append((address, stop))

covered = {a for a in seen if label(a)[0]}
identified = {i for a in seen for i in range(a, a + size(a))}
ranges = []
coalesce(seen - covered, size)
write_csv("untranslated_reachable.csv", ("start", "end_exclusive", "bytes"),
          ((hex_address(a), hex_address(b), b - a) for a, b in ranges))
ranges = []
unclassified = {a for a in range(len(image)) if a not in identified and not is_data(a)}
coalesce(unclassified, lambda _: 1)
write_csv("unclassified.csv", ("start", "end_exclusive", "bytes"),
          ((hex_address(a), hex_address(b), b - a) for a, b in ranges))
levels = collections.Counter()
for address in covered:
    levels[label(address)[1]] += size(address)
summary = {
    "cod_sha256": hashlib.sha256(cod).hexdigest(),
    "bin_sha256": hashlib.sha256(image).hexdigest(),
    "image_bytes": len(image),
    "reachable_instructions": len(seen),
    "reachable_bytes": code_size(seen),
    "entry_points": len(entries),
    "entry_points_in_translated_ranges": sum(bool(label(a)[0]) for a in entries),
    "direct_callsites": sum(kind == "call" for _, _, kind in edges),
    "translated_bytes_by_verification": dict(sorted(levels.items())),
    "reachable_untranslated_bytes": code_size(seen - covered),
    "declared_flash_data_bytes": sum(b - a for a, b in data_regions),
    "unclassified_bytes": len(unclassified),
    "indirect_sites": list(map(hex_address, sorted(indirect))),
    "external_edges": [[hex_address(a), hex_address(b)] for a, b in sorted(external)],
    "invalid_edges_or_instructions": [[hex_address(a), hex_address(b)] for a, b in sorted(bad)],
}
(ROOT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(summary, ensure_ascii=False, indent=2))
