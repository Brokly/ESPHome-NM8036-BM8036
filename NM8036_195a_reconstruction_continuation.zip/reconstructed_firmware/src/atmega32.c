#include "nm_peripherals.h"

#ifdef __AVR__
#include <avr/interrupt.h>
#include <avr/io.h>
#include <avr/pgmspace.h>

/* [БИНАРНИК] 0x2BDC..0x2C06, 0x2C90..0x2CB6.
 * [РУКОВОДСТВО] Прил. 5, UART с двумя стоповыми битами. */
static void uart_send(void *ctx, uint8_t value)
{
    (void)ctx;
    while (!(UCSRA & _BV(UDRE))) {}
    UDR = value;
}

static uint8_t uart_receive(void *ctx)
{
    (void)ctx;
    while (!(UCSRA & _BV(RXC))) {}
    return UDR;
}

bool nm_atmega32_poll(NM8036 *m)
{
    if (!(UCSRA & _BV(RXC)))
        return false;
    return nm_command(m, UDR);
}

static uint8_t lock_irq(void *ctx)
{
    (void)ctx;
    uint8_t saved = SREG;
    cli();
    return saved;
}

static void restore_irq(void *ctx, uint8_t saved)
{
    (void)ctx;
    SREG = saved;
}

/* [БИНАРНИК] 0x62F8..0x636E. Адрес первого доступа уже готов.
 * Последовательность SBI в одном блоке удерживает интервал записи
 * в пределах аппаратного окна EEMWE/EEWE. */
static uint8_t ee_read(void *ctx, uint16_t address)
{
    (void)ctx;
    while (EECR & _BV(EEWE)) {}
    EEAR = address;
    EECR |= _BV(EERE);
    return EEDR;
}

static void ee_write(void *ctx, uint16_t address, uint8_t value)
{
    (void)ctx;
    uint8_t saved = SREG;
    while (EECR & _BV(EEWE)) {}
    EEDR = value;
    EEAR = address;
    cli();
    __asm__ volatile ("sbi %0,%1\n\tsbi %0,%2"
        : : "I" (_SFR_IO_ADDR(EECR)), "I" (EEMWE), "I" (EEWE) : "memory");
    SREG = saved;
}

/* [БИНАРНИК] 0x11AC..0x11D0. PC1 освобождается через DDR,
 * PC0 управляет тактированием. AVR-реализация сохраняет порядок
 * переходов, длительность фаз зависит от сборки. */
static bool rtc_data(bool high)
{
    PORTC &= (uint8_t)~_BV(PC1);
    if (high)
        DDRC &= (uint8_t)~_BV(PC1);
    else
        DDRC |= _BV(PC1);
    return (PINC & _BV(PC1)) != 0;
}

static void rtc_clock(bool high)
{
    DDRC |= _BV(PC0);
    if (high)
        PORTC |= _BV(PC0);
    else
        PORTC &= (uint8_t)~_BV(PC0);
}

static bool rtc_sample(void)
{
    rtc_clock(true);
    return rtc_data(true);
}

static void rtc_start(void)
{
    rtc_data(false);
    rtc_clock(false);
}

static void rtc_stop(void)
{
    rtc_clock(true);
    rtc_data(true);
}

/* [БИНАРНИК] 0x122A..0x1262. Биты идут от старшего к младшему.
 * Оригинальные вызывающие подпрограммы продолжают обмен после ACK/NACK. */
static void rtc_send(uint8_t byte)
{
    for (uint8_t bit = 0x80; bit != 0; bit >>= 1) {
        rtc_data((byte & bit) != 0);
        rtc_clock(true);
        rtc_clock(false);
    }
    rtc_data(true);
    (void)rtc_sample();
    rtc_clock(false);
}

/* [БИНАРНИК] 0x1264..0x1294. После последнего байта выдаётся NACK. */
static uint8_t rtc_receive(bool more)
{
    uint8_t value = 0;
    rtc_data(true);
    for (uint8_t i = 0; i < 8; i++) {
        value = (uint8_t)((value << 1) | rtc_sample());
        rtc_clock(false);
    }
    rtc_data(!more);
    rtc_clock(true);
    rtc_clock(false);
    return value;
}

/* [БИНАРНИК] 0x11D2..0x1228, 0x12A6..0x12B0.
 * [РУКОВОДСТВО] DS1307, адрес 0x68, время и SRAM приветствия. */
static void rtc_read(void *ctx, uint8_t address, uint8_t *buffer, uint8_t size)
{
    (void)ctx;
    rtc_start();
    rtc_send(0xd0);
    rtc_send(address);
    rtc_stop();
    rtc_start();
    rtc_send(0xd1);
    while (size != 0) {
        size--;
        *buffer++ = rtc_receive(size != 0);
    }
    rtc_stop();
}

static void rtc_write(void *ctx, uint8_t address, const uint8_t *buffer, uint8_t size)
{
    (void)ctx;
    if (size == 0)
        return;
    rtc_start();
    rtc_send(0xd0);
    rtc_send(address);
    while (size--)
        rtc_send(*buffer++);
    rtc_stop();
}

/* [БИНАРНИК] 0x1DEC..0x1E50. LCD на PB4..PB7,
 * PB0 = E, PB1 = R/W, PB2 = RS. */
static void lcd_pulse(void)
{
    PORTB |= _BV(PB0);
    __builtin_avr_delay_cycles(9);
    PORTB &= (uint8_t)~_BV(PB0);
}

static uint8_t lcd_read_byte(void)
{
    DDRB &= 0x0f;
    PORTB |= 0xf0;
    PORTB |= _BV(PB1);
    PORTB |= _BV(PB0);
    __builtin_avr_delay_cycles(1);
    uint8_t high = PINB & 0xf0;
    PORTB &= (uint8_t)~_BV(PB0);
    PORTB |= _BV(PB0);
    __builtin_avr_delay_cycles(1);
    uint8_t low = PINB >> 4;
    PORTB &= (uint8_t)~_BV(PB0);
    return high | low;
}

static void lcd_write_raw(const NM8036 *m, uint8_t value, bool data)
{
    *nm_ram(m, 0x068e) = 1;
    if (data)
        PORTB |= _BV(PB2);
    else
        PORTB &= (uint8_t)~_BV(PB2);
    DDRB = 0xff;
    PORTB &= (uint8_t)~_BV(PB1);
    PORTB = (PORTB & 0x0f) | (value & 0xf0);
    PORTB |= _BV(PB0);
    PORTB &= (uint8_t)~_BV(PB0);
    PORTB = (PORTB & 0x0f) | (uint8_t)(value << 4);
    PORTB |= _BV(PB0);
    PORTB &= (uint8_t)~_BV(PB0);
    PORTB &= (uint8_t)~_BV(PB2);
    while (lcd_read_byte() & 0x80) {}
}

static void lcd_command(const NM8036 *m, uint8_t value)
{
    lcd_write_raw(m, value, false);
}

/* [БИНАРНИК] 0x1EE0..0x1F10; таблица кодов символов 0x01BF..0x0216. */
static const uint8_t lcd_extended_chars[] PROGMEM = {
    0xa2, 0xed, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
    0x20, 0x20, 0x20, 0x20, 0x20, 0xb5, 0x20, 0x20, 0x20, 0x20, 0x20,
    0x20, 0x20, 0x41, 0xa0, 0x42, 0xa1, 0xe0, 0x45, 0xa3, 0xa4, 0xa5,
    0xa6, 0x4b, 0xa7, 0x4d, 0x48, 0x4f, 0xa8, 0x50, 0x43, 0x54, 0xa9,
    0xaa, 0x58, 0xe1, 0xab, 0xac, 0xe2, 0xad, 0xae, 0x62, 0xaf, 0xb0,
    0xb1, 0x61, 0xb2, 0xb3, 0xb4, 0xe3, 0x65, 0xb6, 0xb7, 0xb8, 0xb9,
    0xba, 0xbb, 0xbc, 0xbd, 0x6f, 0xbe, 0x70, 0x63, 0xbf, 0x79, 0xe4,
    0x78, 0xe5, 0xc0, 0xc1, 0xe6, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7,
};

void nm_atmega32_lcd_text(const NM8036 *m, uint8_t row, uint8_t column,
                         const uint8_t *text, uint8_t length)
{
    if (row > 1)
        return;
    lcd_command(m, (row ? 0xc0 : 0x80) + column);
    while (length--) {
        uint8_t value = *text++;
        if (value >= 0xa8)
            value = pgm_read_byte(lcd_extended_chars + value - 0xa8);
        lcd_write_raw(m, value, true);
    }
}

/* [БИНАРНИК] 0x1EC0..0x1EE0. В CGRAM отправляются восемь
 * строк глифа без перекодировки. */
void nm_atmega32_lcd_glyph(const NM8036 *m, uint8_t index, const uint8_t rows[8])
{
    lcd_command(m, (uint8_t)(0x40u | ((index & 7u) << 3)));
    for (uint8_t row = 0; row < 8; row++)
        lcd_write_raw(m, rows[row], true);
}

/* [БИНАРНИК] 0x1F4E..0x1F66. Формат соответствует снимку S.
 * Буфером владеет вызывающий код, его освобождение определяется API C. */
void nm_atmega32_lcd_restore(const NM8036 *m, const uint8_t buffer[96])
{
    lcd_command(m, 0x40);
    for (uint8_t i = 0; i < 96; i++) {
        if (i == 64)
            lcd_command(m, 0x80);
        if (i == 80)
            lcd_command(m, 0xc0);
        lcd_write_raw(m, buffer[i], true);
    }
}

/* [БИНАРНИК] 0x1F26..0x1F48, 0x1F6A..0x1F86. Чтение через
 * контроллер LCD, включая побочный эффект флага после установки адреса. */
static void lcd_snapshot(const NM8036 *m, uint8_t buffer[96])
{
    lcd_command(m, 0x40);
    for (uint8_t i = 0; i < 96; i++) {
        if (i == 64)
            lcd_command(m, 0x80);
        if (i == 80)
            lcd_command(m, 0xc0);
        PORTB |= _BV(PB2);
        buffer[i] = lcd_read_byte();
        PORTB &= (uint8_t)~_BV(PB2);
    }
}

/* [БИНАРНИК] 0x1D8C..0x1DF8, 0x1E86..0x1E9A.
 * Короткие выдержки сохранены в циклах; на плате их ещё надо измерить. */
void nm_atmega32_lcd_init(const NM8036 *m)
{
    PORTB &= (uint8_t)~(_BV(PB1) | _BV(PB2));
    DDRB = 0xff;
    PORTB &= 0x0f;
    __builtin_avr_delay_cycles(15000);
    PORTB |= 0x30;
    lcd_pulse();
    __builtin_avr_delay_cycles(5000);
    lcd_pulse();
    __builtin_avr_delay_cycles(200);
    lcd_pulse();
    __builtin_avr_delay_cycles(200);
    PORTB = (PORTB & 0x0f) | 0x20;
    lcd_pulse();
    __builtin_avr_delay_cycles(200);
    lcd_command(m, 0x2a);
    lcd_command(m, 0x0c);
    lcd_command(m, 0x06);
    lcd_command(m, 0x01);
    __builtin_avr_delay_cycles(3000);
}

/* [БИНАРНИК] 0x0D94..0x0DCA. Чтение ADCL до ADCH, затем
 * оба байта в общий массив измерений 0x0673. */
uint16_t nm_atmega32_adc(const NM8036 *m, uint8_t channel)
{
    uint8_t saved = SREG;
    cli();
    ADMUX = (uint8_t)(channel + 0x40u);
    ADCSRA |= _BV(ADSC);
    while (!(ADCSRA & _BV(ADIF))) {}
    uint8_t low = ADCL;
    uint8_t high = ADCH;
    volatile uint8_t *buffer = nm_ram(m, 0x0673 + 2u * channel);
    buffer[0] = low;
    buffer[1] = high;
    SREG = saved;
    return low | ((uint16_t)high << 8);
}

void nm_atmega32_adc_init(const NM8036 *m)
{
    DDRA &= (uint8_t)~_BV(PA1);
    ADCSRA = 0x8f;
    MCUCR |= 0x10;
    (void)nm_atmega32_adc(m, 1);
}

/* [БИНАРНИК] 0x203E, 0x20D4..0x20D8. Порядок выборок важен. */
uint8_t nm_atmega32_read_key(const NM8036 *m)
{
    uint16_t first = nm_atmega32_adc(m, 1);
    uint16_t second = nm_atmega32_adc(m, 1);
    return nm_key_decode(first, second);
}

/* [БИНАРНИК] 0x4910..0x4914, назначения 0x4DDE..0x4DE6. */
void nm_atmega32_refresh_clock(const NM8036 *m)
{
    uint8_t buffer[8];
    m->rtc_read(m->context, 0, buffer, sizeof buffer);
    for (uint8_t i = 0; i < sizeof buffer; i++)
        nm_ram(m, 0x0727)[i] = buffer[i];
}

/* [БИНАРНИК] Вектор ADC 0x0040 → 0x0DCC, тело RETI. */
ISR(ADC_vect, ISR_NAKED)
{
    reti();
}

/* [БИНАРНИК] 0x417A..0x41BA. Инициализация GPIO и таймеров
 * до включения глобальных прерываний вызывающей программой. */
void nm_atmega32_gpio_timer_init(void)
{
    DDRD |= 0x48;
    DDRC |= 0xfc;
    DDRA |= 0xf0;
    TCCR0 = 0x69;
    DDRB |= _BV(PB3);
    TCCR1A |= 0xf1;
    TCCR1B |= 1;
    OCR1AL = 0x80;
    TCCR2 |= 4;
    TIMSK |= 0x40;
    MCUCR |= 0x11;
    GICR |= 0x40;
}

/* [БИНАРНИК] 0x5532..0x5557. Команда E выключает IRQ,
 * очищает LCD, передаёт эхо, затем оставляет PA1 выходом и
 * выводит две строки из flash 0x0AE4/0x0AED. Последняя инструкция
 * передаёт управление уже прошитому загрузчику за границей образа. */
static void enter_loader(const NM8036 *m)
{
    static const uint8_t row0[] = "firmware";
    static const uint8_t row1[] = "update";
    cli();
    nm_atmega32_lcd_clear(m);
    m->send(m->context, 'E');
    DDRA = 2;
    nm_atmega32_lcd_text(m, 0, 4, row0, sizeof row0 - 1);
    nm_atmega32_lcd_text(m, 1, 5, row1, sizeof row1 - 1);
    __asm__ volatile ("jmp 0x7000" ::: "memory");
    __builtin_unreachable();
}

/* [БИНАРНИК] 0x1E86..0x1E9A. Интерфейс для экранов startup. */
void nm_atmega32_lcd_clear(const NM8036 *m)
{
    lcd_command(m, 1);
    __builtin_avr_delay_cycles(3000);
}

/* [БИНАРНИК] 0x2BF6..0x2C06. Адаптер использует исходные адреса SRAM. */
void nm_atmega32_uart_init(void)
{
    UBRRL = 12;
    UCSRA = 2;
    UCSRB = 0x18;
    UCSRC = 0x8e;
}

NM8036 nm_atmega32_device(void)
{
    return (NM8036){
        .sram = (volatile uint8_t *)0x0060,
        .porta = &PORTA, .portc = &PORTC, .portd = &PORTD,
        .receive = uart_receive, .send = uart_send, .ee_read = ee_read,
        .ee_write = ee_write, .irq_disable = lock_irq, .irq_restore = restore_irq,
        .rtc_read = rtc_read, .rtc_write = rtc_write, .lcd_read = lcd_snapshot,
        .boot_enter = enter_loader,
    };
}
NM8036 nm_atmega32(void)
{
    nm_atmega32_uart_init();
    return nm_atmega32_device();
}
#endif
