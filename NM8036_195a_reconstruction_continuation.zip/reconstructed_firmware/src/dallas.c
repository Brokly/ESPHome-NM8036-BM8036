#include "nm_dallas.h"
#include "nm_peripherals.h"

/* [БИНАРНИК] 0x0D2C..0x0D88. Младший бит передаётся первым. */
static void send_byte(const NMOneWire *bus, uint8_t byte)
{
    for (uint8_t bit = 1; bit; bit <<= 1)
        bus->write_bit(bus->context, (byte & bit) != 0);
}

static uint8_t read_byte(const NMOneWire *bus)
{
    uint8_t byte = 0;
    for (uint8_t bit = 1; bit; bit <<= 1)
        if (bus->read_bit(bus->context))
            byte |= bit;
    return byte;
}

/* [БИНАРНИК] 0x154C..0x1640. При конфликте на новой позиции
 * исходник заново запускает Search ROM для обеих ветвей. Счётчик
 * попыток и ROM общие для всех уровней. Сравнение позиции со старой
 * позицией знаковое: -1 в первом вызове предшествует биту 0.
 * Стек C хранит адреса возврата и параметры, как стек оригинала. */
static void search_pass(const NMOneWire *bus, volatile uint8_t *sram,
                        int8_t last_discrepancy, bool direction)
{
    if (last_discrepancy != -1 && sram[12] >= 21)
        return;
    sram[12]++;
    if (!bus->reset(bus->context))
        return;
    send_byte(bus, 0xf0);
    sram[14] = 0;
    while (sram[14] < 64) {
        bool bit = bus->read_bit(bus->context);
        sram[13] = bit;
        bool inverse = bus->read_bit(bus->context);
        uint8_t position = sram[14];
        volatile uint8_t *rom_byte = &sram[2 + (position >> 3)];
        uint8_t mask = (uint8_t)(1u << (position & 7));
        if (bit == inverse) {
            if ((int16_t)position > last_discrepancy) {
                search_pass(bus, sram, (int8_t)position, false);
                search_pass(bus, sram, (int8_t)position, true);
                return;
            }
            bit = (int16_t)position == last_discrepancy ? direction : (*rom_byte & mask) != 0;
        }
        sram[13] = bit;
        if (bit)
            *rom_byte |= mask;
        else
            *rom_byte &= (uint8_t)~mask;
        bus->write_bit(bus->context, bit);
        sram[14]++;
    }
    if (sram[11] == sram[1])
        sram[12] = 61;
    sram[12]--;
    sram[11]++;
}

uint8_t nm_dallas_search(const NM8036 *m, const NMOneWire *bus)
{
    volatile uint8_t *sram = nm_ram(m, 0x067f);
    sram[11] = 0;
    sram[12] = 0;
    search_pass(bus, sram, -1, false);
    return sram[11];
}

/* [БИНАРНИК] 0x4346..0x435C, 0x4878..0x4893 и 0x493A..0x495F.
 * ROM нумеруются с нуля. Незаписанный слот сравнивается с восемью
 * байтами из 0x0667, установленными startup. */
bool nm_dallas_load_rom(const NM8036 *m, uint8_t index)
{
    volatile uint8_t *rom = nm_ram(m, 0x0681);
    uint16_t start = 0x02f0u + 8u * index;
    bool differs = false;
    for (uint8_t i = 0; i < 8; i++) {
        uint8_t state = m->irq_disable(m->context);
        rom[i] = nm_ee_read(m, start + i);
        m->irq_restore(m->context, state);
        differs |= rom[i] != *nm_ram(m, 0x0667 + i);
    }
    return differs;
}

static void select_rom(const NM8036 *m, const NMOneWire *bus)
{
    (void)bus->reset(bus->context);
    send_byte(bus, 0x55);
    volatile uint8_t *rom = nm_ram(m, 0x0681);
    for (uint8_t i = 0; i < 8; i++)
        send_byte(bus, rom[i]);
}

/* [БИНАРНИК] 0x12D4..0x135A. Сначала считываются TH, TL и
 * конфигурация. Запись и Copy Scratchpad выполняются при изменении
 * конфигурации. Тайминг выдержки задаётся драйвером слотов. */
void nm_dallas_configure_selected(const NM8036 *m, const NMOneWire *bus)
{
    select_rom(m, bus);
    send_byte(bus, 0xb4);
    uint8_t desired = bus->read_bit(bus->context) ? 0x7f : 0x3f;
    select_rom(m, bus);
    send_byte(bus, 0xbe);
    (void)read_byte(bus);
    (void)read_byte(bus);
    uint8_t high = read_byte(bus);
    uint8_t low = read_byte(bus);
    uint8_t old = read_byte(bus);
    (void)bus->reset(bus->context);
    if (old == desired)
        return;
    select_rom(m, bus);
    send_byte(bus, 0x4e);
    send_byte(bus, high);
    send_byte(bus, low);
    send_byte(bus, desired);
    select_rom(m, bus);
    send_byte(bus, 0x48);
    bus->copy_delay(bus->context);
}

/* [БИНАРНИК] 0x1524..0x154B. Запрос источника питания,
 * затем отдельный сеанс Match ROM / Convert T. */
static bool begin_conversion(const NM8036 *m, const NMOneWire *bus)
{
    select_rom(m, bus);
    send_byte(bus, 0xb4);
    bool parasite = !bus->read_bit(bus->context);
    *nm_ram(m, 0x067f) = parasite;
    select_rom(m, bus);
    send_byte(bus, 0x44);
    return parasite;
}

static void read_scratchpad(const NM8036 *m, const NMOneWire *bus,
                            uint8_t *bytes, uint8_t count)
{
    select_rom(m, bus);
    send_byte(bus, 0xbe);
    for (uint8_t i = 0; i < count; i++)
        bytes[i] = read_byte(bus);
}

/* [БИНАРНИК] 0x135A..0x13CD. Блокирующее первое измерение.
 * Кадр заканчивается на COUNT_PER_C; CRC проверяет только обычный опрос. */
int16_t nm_dallas_sample_selected_sync(const NM8036 *m, const NMOneWire *bus)
{
    if (begin_conversion(m, bus)) {
        bus->strong_pullup(bus->context, true);
        bus->conversion_delay(bus->context);
        bus->strong_pullup(bus->context, false);
    }
    while (!bus->read_bit(bus->context)) {}
    uint8_t bytes[9] = {0};
    read_scratchpad(m, bus, bytes, 8);
    return nm_dallas_temperature(*nm_ram(m, 0x0681), bytes);
}

/* [БИНАРНИК] 0x150C..0x154B. Паразитное питание использует PD7
 * как выход высокого уровня. Счётчик привязан к фазе сигнала RTC. */
void nm_dallas_start_conversion(const NM8036 *m, const NMOneWire *bus)
{
    if (begin_conversion(m, bus)) {
        bus->strong_pullup(bus->context, true);
        *nm_ram(m, 0x0689) = bus->clock_high(bus->context);
    }
}

/* [БИНАРНИК] 0x13E4..0x14E3. Ожидание возвращает 0, готовый кадр
 * с CRC — 1, ошибка — 2. Сырые два байта записываются до проверки CRC. */
uint8_t nm_dallas_poll(const NM8036 *m, const NMOneWire *bus)
{
    if (!bus->line_high(bus->context))
        return NM_DALLAS_ERROR;
    if (*nm_ram(m, 0x067f)) {
        volatile uint8_t *phase = nm_ram(m, 0x0689);
        if (bus->clock_high(bus->context) && !*phase)
            *phase = 1;
        if (!bus->clock_high(bus->context)) {
            if (!*phase)
                return NM_DALLAS_PENDING;
            (*phase)++;
        }
        if (*phase < 5)
            return NM_DALLAS_PENDING;
        bus->strong_pullup(bus->context, false);
    } else if (!bus->read_bit(bus->context)) {
        return NM_DALLAS_PENDING;
    }

    uint8_t scratchpad[9];
    read_scratchpad(m, bus, scratchpad, sizeof scratchpad);
    volatile uint8_t *result = nm_ram(m, 0x06c7 + 2u * *nm_ram(m, 0x073e));
    result[0] = scratchpad[0];
    result[1] = scratchpad[1];
    if (!nm_dallas_scratchpad_valid(scratchpad))
        return NM_DALLAS_ERROR;
    int16_t value = nm_dallas_temperature(*nm_ram(m, 0x0681), scratchpad);
    result[0] = (uint8_t)value;
    result[1] = (uint8_t)((uint16_t)value >> 8);
    return NM_DALLAS_SAMPLE;
}

/* [БИНАРНИК] 0x448A..0x44F1, 0x48A8..0x48CF. Цикл пропускает
 * выключенный опрос и пустые ROM, ограничивая просмотр 32 слотами. */
void nm_dallas_poll_registered(const NM8036 *m, const NMOneWire *bus)
{
    if (*nm_ram(m, 0x0738))
        return;
    uint8_t outcome = nm_dallas_poll(m, bus);
    if (outcome == NM_DALLAS_PENDING)
        return;
    volatile uint8_t *index = nm_ram(m, 0x073e);
    *nm_ram(m, 0x0707 + *index) = outcome == NM_DALLAS_SAMPLE ? 0xff : 0;
    for (uint8_t remaining = 32; remaining; remaining--) {
        uint8_t next = (uint8_t)(*index + 1);
        *index = next < 32 ? next : 0;
        if (nm_dallas_load_rom(m, *index)) {
            nm_dallas_start_conversion(m, bus);
            return;
        }
        *nm_ram(m, 0x0707 + *index) = 0;
    }
}
