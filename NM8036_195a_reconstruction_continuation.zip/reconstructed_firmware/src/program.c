#include "nm8036.h"

/* [БИНАРНИК] 0x5924 → 0x4DD4, 0x55A0, 0x5656. EEPROM от 0x4C,
 * по 21 байту на запись. Число 32 задаёт цикл чтения (0x5642). */
static uint16_t record_address(uint8_t index)
{
    return 0x4cu + 21u * index;
}

/* [БИНАРНИК] 0x2C08..0x2C34. При пакетной передаче EEPROM
 * исходный код удерживает прерывания выключенными на всём диапазоне. */
static void send_field(const NM8036 *m, uint16_t address, uint8_t count)
{
    uint8_t state = m->irq_disable(m->context);
    while (count--)
        m->send(m->context, nm_ee_read(m, address++));
    m->irq_restore(m->context, state);
}

/* [БИНАРНИК] 0x5596..0x5648, маски в 0x58EC..0x590C и 0x591A.
 * [РУКОВОДСТВО] Прил. 5, команда L. Для каждой из 32 записей
 * часы, минуты, календарные поля и параметры выходят в порядке протокола. */
void nm_program_send(const NM8036 *m)
{
    m->send(m->context, 'L');
    for (uint8_t index = 0; index < NM_RECORDS; index++) {
        uint16_t base = record_address(index);
        static const uint8_t offsets[] = {6, 0, 1, 5, 7, 8, 9, 10};
        static const uint8_t masks[] = {31, 63, 63, 31, 63, 63, 31, 31};
        for (uint8_t i = 0; i < sizeof offsets; i++)
            m->send(m->context, nm_ee_read(m, base + offsets[i]) & masks[i]);

        m->send(m->context, nm_ee_read(m, base + 4) & 15);
        m->send(m->context, nm_ee_read(m, base + 4) >> 4);
        m->send(m->context, nm_ee_read(m, base + 3) & 127);
        m->send(m->context, nm_ee_read(m, base + 2) & 127);
        m->send(m->context, nm_ee_read(m, base + 12) & 127);
        m->send(m->context, nm_ee_read(m, base + 11));
        send_field(m, base + 13, 2);
        send_field(m, base + 15, 2);
        m->send(m->context, nm_ee_read(m, base) >> 6);
        m->send(m->context, nm_ee_read(m, base + 1) >> 6);
        send_field(m, base + 17, 4);
        m->send(m->context, nm_ee_read(m, base + 2) >> 7);
        m->send(m->context, nm_ee_read(m, base + 3) >> 7);
        uint8_t flags = (nm_ee_read(m, base + 6) & 0x20u) >> 3;
        flags |= (nm_ee_read(m, base + 12) & 0x80u) >> 6;
        flags |= (nm_ee_read(m, base + 5) & 0x20u) >> 5;
        m->send(m->context, flags);
    }
}

static void merge(const NM8036 *m, uint16_t address, uint8_t mask, uint8_t data)
{
    nm_ee_write(m, address, (nm_ee_read(m, address) & (uint8_t)~mask) | (data & mask));
}

/* [БИНАРНИК] 0x5652..0x5796, 0x5932..0x5952.
 * Сохраняются не затронутые масками разряды и порядок физических записей.
 * Запись интервала начинается с младшего байта, затем идёт старший.
 * [РУКОВОДСТВО] Прил. 5, W. Документированный индекс 0..31. */
void nm_program_write(const NM8036 *m, uint8_t index, const uint8_t w[NM_WIRE_RECORD])
{
    uint16_t base = record_address(index);
    merge(m, base + 6, 31, w[0]);
    merge(m, base, 63, w[1]);
    merge(m, base + 1, 63, w[2]);
    merge(m, base + 5, 31, w[3]);
    merge(m, base + 7, 63, w[4]);
    merge(m, base + 8, 63, w[5]);
    merge(m, base + 9, 31, w[6]);
    merge(m, base + 10, 31, w[7]);
    nm_ee_write(m, base + 4, (w[8] & 15) | ((w[9] & 15) << 4));
    merge(m, base + 3, 127, w[10]);
    merge(m, base + 2, 127, w[11]);
    merge(m, base + 12, 127, w[12]);
    nm_ee_write(m, base + 11, w[13]);
    for (uint8_t i = 0; i < 4; i++)
        nm_ee_write(m, base + 13 + i, w[14 + i]);
    merge(m, base, 0xc0, (uint8_t)(w[18] << 6));
    merge(m, base + 1, 0xc0, (uint8_t)(w[19] << 6));
    for (uint8_t i = 0; i < 4; i++)
        nm_ee_write(m, base + 17 + i, w[20 + i]);
    merge(m, base + 2, 0x80, (uint8_t)(w[24] << 7));
    merge(m, base + 3, 0x80, (uint8_t)(w[25] << 7));
    merge(m, base + 5, 0x20, (uint8_t)((w[26] & 1u) << 5));
    merge(m, base + 12, 0x80, (uint8_t)((w[26] & 2u) << 6));
    merge(m, base + 6, 0x20, (uint8_t)((w[26] & 4u) << 3));
}

/* [БИНАРНИК] 0x3FEA..0x4107. Конечное состояние 32 записей после
 * заводского сброса. Режим 3, начало/конец в полночь, 1 января;
 * служебные старшие биты часов и отдельных полей сохраняются.
 * Промежуточные повторные записи одного адреса свёрнуты. */
void nm_factory_program_defaults(const NM8036 *m)
{
    static const uint8_t preserve[21] = {
        0, 0, 0, 0, 0, 0, 0xc0, 0xc0, 0, 0, 0xe0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    static const uint8_t defaults[21] = {
        0xc0, 0, 0x80, 0, 0x11, 0x80, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    uint8_t saved = m->irq_disable(m->context);
    for (uint8_t i = 0; i < NM_RECORDS; i++) {
        uint16_t base = record_address(i);
        for (uint8_t field = 0; field < sizeof defaults; field++) {
            uint8_t data = defaults[field];
            if (preserve[field])
                data |= nm_ee_read(m, base + field) & preserve[field];
            nm_ee_write(m, base + field, data);
        }
    }
    m->irq_restore(m->context, saved);
}
