/* Только проверка компоновки. Образ не предназначен для прошивки прибора. */
#include "nm_runtime.h"

int main(void)
{
    static NM8036 device;
    nm_atmega32_initialize(&device);
    for (;;)
        (void)nm_atmega32_main_iteration(&device);
}
