#ifndef NM_NUMERIC_DISPLAY_H
#define NM_NUMERIC_DISPLAY_H
#include <stdint.h>

typedef struct {
    void *context;
    void (*position)(void *, uint8_t column, uint8_t row);
    void (*write)(void *, uint8_t byte, uint8_t data);
} NMNumericDisplay;

void nm_avr_editor_redraw_word(const NMNumericDisplay *lcd, const uint8_t field[22],
                               const uint8_t *flash);
void nm_avr_editor_redraw_digit(const NMNumericDisplay *lcd, const uint8_t field[22]);
void nm_avr_editor_redraw_scientific(const NMNumericDisplay *lcd, const uint8_t field[20],
                                     const uint8_t *flash);

typedef void (*NMAdcFormat)(void *context, uint16_t flash_format,
                            uint16_t channel_number, uint32_t binary32);
uint16_t nm_avr_adc_position(const NMNumericDisplay *lcd, uint16_t channel);
void nm_avr_adc_scientific_draw(uint16_t channel_number, uint32_t binary32,
                                NMAdcFormat format, void *context);

void nm_avr_lcd_format_ram(const NMNumericDisplay *lcd, const uint8_t *sram,
                           const uint8_t *format, uint16_t argument);

#endif
