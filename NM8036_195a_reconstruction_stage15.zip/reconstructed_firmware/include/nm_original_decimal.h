#ifndef NM_ORIGINAL_DECIMAL_H
#define NM_ORIGINAL_DECIMAL_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint32_t magnitude;
    int16_t exponent;
} NMDecimalScale;

NMDecimalScale nm_avr_decimal_scale(uint32_t magnitude);
bool nm_avr_decimal_carry(uint8_t *digits, size_t length);
size_t nm_avr_decimal_trim(const uint8_t *digits, size_t length);
size_t nm_avr_decimal_exponent(uint8_t *output, uint8_t marker, int16_t exponent);
uint16_t nm_avr_decimal_padding(uint16_t width, uint16_t length, uint16_t offset, bool sign);

typedef uint16_t (*NMFormatEmit)(void *context, uint16_t state, uint8_t byte);
uint16_t nm_avr_format_ram(const uint8_t *sram, const uint8_t *format,
                           uint16_t *argument, uint16_t state,
                           NMFormatEmit emit, void *context);

#endif
