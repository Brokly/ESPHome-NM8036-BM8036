#include "nm_stage14.h"
#include "nm_original_numeric.h"

/* 0x64D0–0x64F8. Входы в r16–r19/r20–r23. Для каждого
 * числа скрытая единица возвращается в старшем бите мантиссы,
 * знак — в r0/r1 и порядок — в r19/r23. У денормала порядок 1. */
NMFloatParts nm_avr_unpack_binary32(uint32_t word)
{
    uint8_t exponent = (uint8_t)(word >> 23);
    return (NMFloatParts){
        .mantissa = (word & UINT32_C(0x7fffff)) | (exponent ? UINT32_C(0x800000) : 0),
        .exponent = exponent ? exponent : 1,
        .negative = (word >> 31) != 0
    };
}

/* 0x64FA–0x654F. Расширенная мантисса r18:r17:r16:r30,
 * порядок r19, знак r0. T участвует только на точной половине.
 * Результат r16–r19. r30 и промежуточные флаги не являются API C. */
uint32_t nm_avr_pack_binary32(uint32_t extended, uint8_t exponent, bool negative, bool sticky)
{
    if (!(extended >> 31)) {
        do {
            extended <<= 1;
            --exponent;
        } while (exponent >= 2 && !(extended >> 31));
        exponent = exponent <= 1 ? (uint8_t)(extended >> 31) : exponent;
    }
    uint8_t tail = (uint8_t)extended;
    uint32_t mantissa = extended >> 8;
    if (tail > 128 || (tail == 128 && (sticky || (mantissa & 1u)))) {
        ++mantissa;
        exponent += (uint8_t)(mantissa >> 24);
        mantissa &= UINT32_C(0xffffff);
    }
    if (exponent <= 1)
        exponent = (mantissa >> 23) != 0;
    uint32_t sign = negative ? UINT32_C(0x80000000) : 0;
    if (exponent == 255)
        return sign | UINT32_C(0x7f800000);
    return sign | (uint32_t)exponent << 23 | (mantissa & UINT32_C(0x7fffff));
}

/* 0x198A–0x1996. Запись +20 содержит байтовый адрес
 * Flash, а таблица — адрес в словах для IJMP. Сам callback
 * получает исходную запись, здесь возвращается его байтовый адрес. */
uint16_t nm_avr_redraw_callback(const uint8_t *flash, uint16_t table)
{
    uint16_t word = flash[table] | ((uint16_t)flash[table + 1u] << 8);
    return (uint16_t)(word << 1);
}

/* 0x1BDE–0x1C2F. Верх/низ выбирают цифру либо меняют
 * знак на позициях 0 и 6. true обозначает вызов LCD 0x1D7E.
 * На пропущенных колонках исходный r24 остаётся без изменения. */
bool nm_avr_digit_selection(uint8_t field[20], uint8_t key, uint8_t *digit)
{
    if (key != 1 && key != 4)
        return false;
    switch (field[9]) {
    case 0:
    case 6: {
        uint8_t offset = field[9] == 0 ? 2 : 3;
        field[offset] = (field[offset] + 1u) & 1u;
        return true;
    }
    case 1: *digit = field[4]; break;
    case 3: *digit = field[5]; break;
    case 4: *digit = field[6]; break;
    case 7: *digit = field[7]; break;
    case 8: *digit = field[8]; break;
    }
    return false;
}

/* 0x457E–0x45B1. SRAM 0x073C выбирает исходный вход
 * экрана, а 0x073F/0x0735 проходят в r16/r17. */
uint16_t nm_avr_display_entry(uint8_t page)
{
    static const uint16_t entries[] = {0x45b2,0x45bc,0x4628,0x469c,0x46d4,0x46f6,0x4728};
    return page < sizeof entries / sizeof *entries ? entries[page] : 0x43e6;
}

/* 0x4792–0x47D3. Код из EEPROM выбирает адрес заголовка
 * в Flash (r24:r25). Все незаданные коды используют 0x0846. */
uint16_t nm_avr_adc_template(uint8_t format)
{
    if (format > 6)
        format = 2;
    return (uint16_t)(0x0830u + 11u * format);
}

/* 0x47DC–0x481F. Предикаты оригинала, включая NaN.
 * Интервал асимметричен. Положительный предел включён
 * в научную форму, отрицательный предел остаётся обычным. */
bool nm_avr_adc_scientific(uint32_t value)
{
    return nm_avr_binary32_ge(value, UINT32_C(0x4cbebc20)) ||
           nm_avr_binary32_less(value, UINT32_C(0xcb18967f)) ||
           (nm_avr_binary32_less(value, UINT32_C(0x38d1b717)) &&
            nm_avr_binary32_ge(value, 0)) ||
           (nm_avr_binary32_ge(value, UINT32_C(0xb8d1b716)) &&
            nm_avr_binary32_less(value, 0));
}

/* 0x1C52–0x1CA3. Верхняя/нижняя границы вложенного
 * десятичного поля зависят от курсора и набранного порядка.
 * child соответствует указателю, записанному в parent+12. */
void nm_avr_digit_limits(const uint8_t parent[20], uint8_t child[22])
{
    uint8_t cursor = parent[9];
    if (cursor == 1)
        nm_avr_editor_set_limits(child, 1, 9);
    if (cursor == 7)
        nm_avr_editor_set_limits(child, 0, 3);
    if (parent[7] != 3)
        return;
    if (cursor == 8)
        nm_avr_editor_set_limits(child, 0, 8);
    if (parent[8] != 8)
        return;
    if (cursor == 1)
        nm_avr_editor_set_limits(child, 1, 3);
    if (cursor == 3)
        nm_avr_editor_set_limits(child, 0, 4);
}

/* 0x19F0–0x1A0D, затем разбор с 0x1A0E. r16:r17
 * указывает на запись редактора, r20–r23 — аргумент binary32.
 * Исходный формат живёт во Flash 0x01A7. Форматтер передаётся
 * отдельно, поскольку его округление — самостоятельный контракт. */
void nm_avr_scientific_load(uint8_t field[20], uint32_t binary32,
                            NMEditorFormat format, void *context)
{
    uint8_t buffer[20];
    format(context, 0x01a7, binary32, buffer);
    nm_avr_scientific_digits(field, buffer);
}

/* Транзакции EEPROM под редакторами. index приходит в r17
 * при вызове экрана, вычисляемый адрес — r24:r25.
 * 0x10E0–0x10E8 читает четыре байта коэффициента. */
uint32_t nm_avr_calibration_read(const NM8036 *m, uint8_t index)
{
    uint32_t word = 0;
    uint16_t address = (uint16_t)index * 4u;
    for (uint8_t i = 0; i < 4; ++i)
        word |= (uint32_t)nm_ee_read(m, address + i) << (8u*i);
    return word;
}

/* 0x1106–0x110B. Вызывается после подтверждения и
 * вычисления binary32. Запись младшим байтом вперёд. */
void nm_avr_calibration_commit(const NM8036 *m, uint8_t index, uint32_t word)
{
    uint16_t address = (uint16_t)index * 4u;
    for (uint8_t i = 0; i < 4; ++i)
        nm_ee_write(m, address + i, (uint8_t)(word >> (8u*i)));
}

/* 0x117A–0x117F. Редактор условного обозначения
 * канала сохраняет только младший байт числа. */
void nm_avr_calibration_unit_commit(const NM8036 *m, uint8_t index, uint32_t word)
{
    nm_ee_write(m, 0x12u + index, (uint8_t)word);
}
