#include "nm_numeric_display.h"
#include "nm_original_decimal.h"

static uint16_t text_address(const uint8_t *bytes)
{
    return bytes[0] | (uint16_t)bytes[1] << 8;
}

static void text(const NMNumericDisplay *lcd, const uint8_t *bytes)
{
    while (*bytes)
        lcd->write(lcd->context, *bytes++, 1);
}

static void decimal(const NMNumericDisplay *lcd, uint32_t value)
{
    uint8_t reverse[10];
    uint8_t count = 0;
    do {
        reverse[count++] = '0' + value % 10u;
        value /= 10u;
    } while (value);
    while (count)
        lcd->write(lcd->context, reverse[--count], 1);
}

static void title(const NMNumericDisplay *lcd, const uint8_t *flash, uint16_t address)
{
    lcd->position(lcd->context, address ? 0 : 1, 0);
    text(lcd, flash + (address ? address : 0x018a));
}

/* 0x16EA–0x1725. Значение r16–r19 читается из +10,
 * выводится как %ld по Flash 0x0186. Заголовок из +18. */
void nm_avr_editor_redraw_word(const NMNumericDisplay *lcd, const uint8_t field[22],
                               const uint8_t *flash)
{
    uint32_t value = (uint32_t)field[10] | (uint32_t)field[11] << 8 |
                     (uint32_t)field[12] << 16 | (uint32_t)field[13] << 24;
    lcd->write(lcd->context, 1, 0);
    lcd->position(lcd->context, 7, 1);
    if (value >> 31) {
        lcd->write(lcd->context, '-', 1);
        value = 0u - value;
    }
    decimal(lcd, value);
    title(lcd, flash, text_address(field + 18));
}

/* 0x18D4–0x18ED. Колонка и строка в +18/+19,
 * код курсора 0x0F и младший байт значения с прибавлением '0'. */
void nm_avr_editor_redraw_digit(const NMNumericDisplay *lcd, const uint8_t field[22])
{
    lcd->position(lcd->context, field[18], field[19]);
    lcd->write(lcd->context, 0x0f, 0);
    lcd->write(lcd->context, (uint8_t)(field[10] + '0'), 1);
    lcd->position(lcd->context, field[18], field[19]);
}

/* 0x1AFE–0x1B55. Вывод отдельных знаков и полей
 * %d.%d%de %d%d, возврат курсора в base+offset. */
void nm_avr_editor_redraw_scientific(const NMNumericDisplay *lcd, const uint8_t field[20],
                                     const uint8_t *flash)
{
    uint8_t base = field[10];
    lcd->position(lcd->context, base, field[11]);
    lcd->write(lcd->context, field[2] ? '-' : '+', 1);
    decimal(lcd, field[4]);
    lcd->write(lcd->context, '.', 1);
    decimal(lcd, field[5]);
    decimal(lcd, field[6]);
    lcd->write(lcd->context, 'e', 1);
    lcd->write(lcd->context, ' ', 1);
    decimal(lcd, field[7]);
    decimal(lcd, field[8]);
    lcd->position(lcd->context, (uint8_t)(base + 6u), 1);
    lcd->write(lcd->context, field[3] ? '-' : '+', 1);
    title(lcd, flash, text_address(field + 15));
    lcd->position(lcd->context, (uint8_t)(base + field[9]), 1);
}

/* 0x47D4–0x47DB. Номер канала в r8:r9, строка — его
 * младший байт, передаваемый в 0x52EA. Печатаемый номер с единицы. */
uint16_t nm_avr_adc_position(const NMNumericDisplay *lcd, uint16_t channel)
{
    lcd->position(lcd->context, 0, (uint8_t)channel);
    return (uint16_t)(channel + 1u);
}

/* 0x4820–0x4829 и 0x4854–0x4861. r26:r27 — номер
 * канала, r4–r7 — binary32. Передача аргументов в формате
 * 0x087D. Управление главной страницей после вывода остаётся
 * за вызывающим кодом (переход 0x43D2). */
void nm_avr_adc_scientific_draw(uint16_t channel_number, uint32_t binary32,
                                NMAdcFormat format, void *context)
{
    format(context, 0x087d, channel_number, binary32);
}

/* 0x6D88–0x6DAB. Оригинальный 0x4168 передаёт один байт
 * через LCD и возвращает тот же байт r24, сохранённый в стеке.
 * Поэтому счётчик callback остаётся прежним. */
static uint16_t lcd_format_emit(void *context, uint16_t state, uint8_t byte)
{
    const NMNumericDisplay *lcd = context;
    lcd->write(lcd->context, byte, 1);
    return state;
}

/* 0x6ABA–0x6AD9. Формат из SRAM, указатель аргументов
 * из Y исходного ABI. Начальное состояние LCD равно 1. */
void nm_avr_lcd_format_ram(const NMNumericDisplay *lcd, const uint8_t *sram,
                           const uint8_t *format, uint16_t argument)
{
    (void)nm_avr_format_ram(sram, format, &argument, 1, lcd_format_emit, (void *)lcd);
}

/* 0x1CA4–0x1CC5. Дочернее поле уже выделено. Сначала
 * отрисовка с новой позицией, затем с цифрой и её резервной копией. */
void nm_avr_scientific_open_digit(const NMNumericDisplay *lcd, uint8_t parent[20],
                                   uint8_t child[22], uint8_t value)
{
    child[18] = (uint8_t)(parent[10] + parent[9]);
    child[19] = parent[11];
    nm_avr_editor_redraw_digit(lcd, child);
    for (uint8_t i = 10; i < 18; ++i)
        child[i] = 0;
    child[10] = child[14] = value;
    nm_avr_editor_redraw_digit(lcd, child);
    parent[14] = 1;
}

/* 0x482E–0x483B. Только результат 1 сбрасывает флаг
 * меню в 0x073A до общего продолжения диспетчера 0x441E. */
bool nm_avr_adc_finish_menu(volatile uint8_t *active, uint8_t result)
{
    if (result == 1)
        *active = 0;
    return *active != 0;
}
