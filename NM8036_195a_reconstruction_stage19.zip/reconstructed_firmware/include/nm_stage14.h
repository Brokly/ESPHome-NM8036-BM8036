#ifndef NM_STAGE14_H
#define NM_STAGE14_H
#include "nm8036.h"
#include <stdbool.h>

typedef struct {
    uint32_t mantissa;
    uint8_t exponent;
    bool negative;
} NMFloatParts;

NMFloatParts nm_avr_unpack_binary32(uint32_t word);
uint32_t nm_avr_pack_binary32(uint32_t extended, uint8_t exponent, bool negative, bool sticky);
uint16_t nm_avr_redraw_callback(const uint8_t *flash, uint16_t table);
bool nm_avr_digit_selection(uint8_t field[20], uint8_t key, uint8_t *digit);
uint16_t nm_avr_display_entry(uint8_t page);
uint16_t nm_avr_adc_template(uint8_t format);
bool nm_avr_adc_scientific(uint32_t word);

void nm_avr_digit_limits(const uint8_t parent[20], uint8_t child[22]);
typedef void (*NMEditorFormat)(void *context, uint16_t flash_format,
                               uint32_t binary32, uint8_t buffer[20]);
void nm_avr_scientific_load(uint8_t field[20], uint32_t binary32,
                            NMEditorFormat format, void *context);
uint32_t nm_avr_calibration_read(const NM8036 *m, uint8_t index);
void nm_avr_calibration_commit(const NM8036 *m, uint8_t index, uint32_t word);
void nm_avr_calibration_unit_commit(const NM8036 *m, uint8_t index, uint32_t word);

bool nm_avr_calibration_finish(const NM8036 *m, uint8_t index, uint8_t editor_result,
                               const uint8_t field[20]);
#endif
