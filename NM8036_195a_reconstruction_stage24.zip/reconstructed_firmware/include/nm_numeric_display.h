#ifndef NM_NUMERIC_DISPLAY_H
#define NM_NUMERIC_DISPLAY_H
#include <stdint.h>
#include <stdbool.h>

typedef struct {
    void *context;
    void (*position)(void *, uint8_t column, uint8_t row);
    void (*write)(void *, uint8_t byte, uint8_t data);
} NMNumericDisplay;

void nm_avr_editor_redraw_word(const NMNumericDisplay *lcd, const uint8_t field[22],
                               const uint8_t *flash);
void nm_avr_editor_redraw_digit(const NMNumericDisplay *lcd, const uint8_t field[22]);
void nm_avr_editor_redraw_scientific(const NMNumericDisplay *lcd, const uint8_t field[20],
                                     const uint8_t *flash);

typedef void (*NMAdcFormat)(void *context, uint16_t flash_format,
                            uint16_t channel_number, uint32_t binary32);
uint16_t nm_avr_adc_position(const NMNumericDisplay *lcd, uint16_t channel);
void nm_avr_adc_scientific_draw(uint16_t channel_number, uint32_t binary32,
                                NMAdcFormat format, void *context);

void nm_avr_lcd_format_ram(const NMNumericDisplay *lcd, const uint8_t *sram,
                           const uint8_t *format, uint16_t argument);

void nm_avr_scientific_open_digit(const NMNumericDisplay *lcd, uint8_t parent[20],
                                   uint8_t child[22], uint8_t value);
typedef uint16_t (*NMNumericAlloc)(void *context, uint16_t size);
typedef uint16_t (*NMNumericSnapshot)(void *context);
bool nm_avr_scientific_begin_digit(const NMNumericDisplay *lcd, uint8_t *sram,
                                  uint8_t parent[20], const uint8_t *flash, uint8_t value,
                                  NMNumericAlloc allocate, NMNumericSnapshot snapshot);
typedef void (*NMNumericRestore)(void *context, uint16_t snapshot_address);
void nm_avr_scientific_end_digit(const NMNumericDisplay *lcd, uint8_t *sram,
                                const uint8_t parent[20], const uint8_t *flash,
                                NMNumericRestore restore);
void nm_avr_scientific_init_digit(uint8_t child[22]);
uint8_t nm_avr_scientific_idle_result(uint8_t key);
bool nm_avr_adc_next_channel(uint8_t *channel);
bool nm_avr_adc_finish_menu(volatile uint8_t *active, uint8_t result);

void nm_avr_scientific_commit_digit(uint8_t parent[20], const uint8_t child[22]);
bool nm_avr_scientific_step_digit(const NMNumericDisplay *lcd, uint8_t parent[20],
                                 uint8_t child[22], uint8_t key);
uint8_t nm_avr_scientific_step(const NMNumericDisplay *lcd, uint8_t *sram,
                              uint8_t parent[20], const uint8_t *flash,
                              uint8_t key, uint8_t digit,
                              NMNumericAlloc allocate, NMNumericSnapshot snapshot,
                              NMNumericRestore restore);
#endif
