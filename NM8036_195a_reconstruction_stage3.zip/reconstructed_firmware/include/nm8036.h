#ifndef NM8036_H
#define NM8036_H
#include <stdbool.h>
#include <stdint.h>

enum { NM_RECORDS = 32, NM_WIRE_RECORD = 27, NM_EEPROM_SIZE = 1024 };

/* Адреса EEPROM в интерфейсе физические, SRAM индексируется от 0x0060. */
typedef struct nm8036 {
    void *context;
    volatile uint8_t *sram;
    volatile uint8_t *porta, *portc, *portd;
    volatile uint8_t *backlight_pwm, *contrast_pwm;
    uint16_t output_reply_seed;
    uint8_t (*receive)(void *);
    void (*send)(void *, uint8_t);
    uint8_t (*ee_read)(void *, uint16_t);
    void (*ee_write)(void *, uint16_t, uint8_t);
    uint8_t (*irq_disable)(void *);
    void (*irq_restore)(void *, uint8_t);
    void (*rtc_read)(void *, uint8_t, uint8_t *, uint8_t);
    void (*rtc_write)(void *, uint8_t, const uint8_t *, uint8_t);
    void (*lcd_read)(const struct nm8036 *, uint8_t [96]);
    void (*boot_enter)(const struct nm8036 *);
} NM8036;

static inline volatile uint8_t *nm_ram(const NM8036 *m, uint16_t address)
{
    return m->sram + (address - 0x60);
}

static inline uint8_t nm_ee_read(const NM8036 *m, uint16_t address)
{
    return m->ee_read(m->context, address & (NM_EEPROM_SIZE - 1));
}

static inline void nm_ee_write(const NM8036 *m, uint16_t address, uint8_t byte)
{
    m->ee_write(m->context, address & (NM_EEPROM_SIZE - 1), byte);
}

void nm_program_send(const NM8036 *m);
void nm_factory_program_defaults(const NM8036 *m);
void nm_program_write(const NM8036 *m, uint8_t index, const uint8_t wire[NM_WIRE_RECORD]);
bool nm_command(const NM8036 *m, uint8_t command);
#endif
