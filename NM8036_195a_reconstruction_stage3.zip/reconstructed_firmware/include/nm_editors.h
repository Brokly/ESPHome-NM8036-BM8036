#ifndef NM_EDITORS_H
#define NM_EDITORS_H
#include "nm8036.h"

typedef enum { NM_EDIT_BACKLIGHT, NM_EDIT_CONTRAST } NMPwmSetting;
typedef enum { NM_EDIT_ACTIVE, NM_EDIT_SAVED, NM_EDIT_CANCELLED } NMEditResult;

void nm_pwm_editor_open(const NM8036 *m, NMPwmSetting setting);
NMEditResult nm_pwm_editor_key(const NM8036 *m, NMPwmSetting setting, uint8_t key);
bool nm_sound_editor_key(const NM8036 *m, uint8_t key);
bool nm_clock_editor_key(const NM8036 *m, uint8_t key);
void nm_pwm_editor_screen(const NM8036 *m, NMPwmSetting setting, uint8_t screen[32]);
void nm_sound_editor_screen(const NM8036 *m, uint8_t screen[32]);
#endif
