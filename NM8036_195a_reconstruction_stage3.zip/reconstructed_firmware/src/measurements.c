#include "nm_runtime.h"
#include <string.h>

static uint16_t sample(const NM8036 *m, uint8_t channel)
{
    volatile uint8_t *p = nm_ram(m, 0x0677u + 2u * channel);
    uint8_t low = p[0];
    return low | ((uint16_t)p[1] << 8);
}

static void right_decimal(uint8_t *end, uint16_t number, uint8_t width)
{
    do {
        *--end = '0' + number % 10u;
        number /= 10u;
        width--;
    } while (number && width);
}

/* [БИНАРНИК] 0x46D4..0x4727; форматы 0x0808/0x0819.
 * Берутся два внешних входа: результаты АЦП лежат в 0x0677
 * и 0x0679. Вольты = отсчёт × 5/1024, с округлением до мВ.
 * Заполнение строк LCD соответствует формату для 10-битных отсчётов. */
void nm_home_adc_screen(const NM8036 *m, bool volts, uint8_t screen[32])
{
    static const uint8_t prefix[] = {0xc4,0xe0,0xf2,0xf7,'.'};
    memset(screen, ' ', 32);
    for (uint8_t channel = 0; channel < 2; channel++) {
        uint8_t *row = screen + 16u * channel;
        memcpy(row, prefix, sizeof prefix);
        row[5] = '1' + channel;
        row[6] = ':';
        uint16_t count = sample(m, channel);
        if (!volts) {
            right_decimal(row + 11, count, 4);
            memcpy(row + 11, "(bin)", 5);
        } else {
            uint16_t mv = (uint16_t)(((uint32_t)count * 5000 + 512u) / 1024u);
            row[10] = '0' + (mv / 1000u) % 10u;
            row[11] = '.';
            row[12] = '0' + (mv / 100u) % 10u;
            row[13] = '0' + (mv / 10u) % 10u;
            row[14] = '0' + mv % 10u;
            row[15] = 'V';
        }
    }
}

/* [БИНАРНИК] 0x4732..0x4784. Коэффициенты сохранены как
 * два 32-битных IEEE-754 числа на канал, младший байт первым.
 * При вычислении порядок операций совпадает с AVR. */
float nm_adc_calibrated(const NM8036 *m, uint8_t channel)
{
    float range[2];
    for (uint8_t i = 0; i < 2; i++) {
        uint32_t word = 0;
        for (uint8_t j = 0; j < 4; j++)
            word |= (uint32_t)nm_ee_read(m, 8u * channel + 4u * i + j) << (8u * j);
        memcpy(&range[i], &word, sizeof word);
    }
    return range[0] + ((range[1] - range[0]) * (1.0f / 1024.0f)) * sample(m, channel);
}


/* [БИНАРНИК] 0x45B2..0x469B, 0x502A..0x5036. Четыре
 * канала на страницу, один глиф выхода и семь знаков измерения.
 * Глифы загружаются отдельно по таблице в области 0x08B3..0x0972. */
void nm_home_temperature_screen(const NM8036 *m, uint8_t group, bool sqw,
                                uint8_t screen[32])
{
    for (uint8_t i = 0; i < 4; i++) {
        uint8_t channel = 4u * group + i;
        volatile uint8_t *p = nm_ram(m, 0x06c7u + 2u * channel);
        uint8_t *cell = screen + 8u * i;
        cell[0] = (uint8_t)(i + (sqw && *nm_ram(m, 0x076c + channel) ? 4 : 0));
        if (!*nm_ram(m, 0x0707u + channel)) {
            memcpy(cell + 1, " ----- ", 7);
            continue;
        }
        memset(cell + 1, ' ', 7);
        uint8_t low = p[0];
        int16_t signed_sample = (int16_t)(low | ((uint16_t)p[1] << 8));
        uint16_t magnitude = signed_sample < 0 ? (uint16_t)(0u - (uint16_t)signed_sample)
                                               : (uint16_t)signed_sample;
        uint16_t tenths = (magnitude + 5u) / 10u;
        cell[6] = 'C';
        cell[5] = '0' + tenths % 10u;
        cell[4] = '.';
        unsigned units = tenths / 10u;
        right_decimal(cell + 4, (uint16_t)units, 3);
        if (signed_sample < 0 && units < 100)
            cell[units < 10 ? 2 : 1] = '-';
    }
}

#ifdef __AVR__
#include "nm_peripherals.h"

/* [БИНАРНИК] 0x45B2..0x45C5, 0x4632..0x4637; штатные 8×8
 * знаков CGRAM таблицы каждой группы. */
void nm_atmega32_home_temperature_glyphs(const NM8036 *m, uint8_t group)
{
    static const uint8_t glyphs[3][64] = {
        {
            0x1f, 0x1b, 0x13, 0x1b, 0x1b, 0x11, 0x1f, 0x00,
            0x1f, 0x11, 0x1d, 0x11, 0x17, 0x11, 0x1f, 0x00,
            0x1f, 0x11, 0x1d, 0x11, 0x1d, 0x11, 0x1f, 0x00,
            0x1f, 0x15, 0x15, 0x11, 0x1d, 0x1d, 0x1f, 0x00,
            0x00, 0x04, 0x0c, 0x04, 0x04, 0x0e, 0x00, 0x00,
            0x00, 0x0e, 0x02, 0x0e, 0x08, 0x0e, 0x00, 0x00,
            0x00, 0x0e, 0x02, 0x0e, 0x02, 0x0e, 0x00, 0x00,
            0x00, 0x0a, 0x0a, 0x0e, 0x02, 0x02, 0x00, 0x00,
        },
        {
            0x1f, 0x11, 0x17, 0x11, 0x1d, 0x11, 0x1f, 0x00,
            0x1f, 0x11, 0x17, 0x11, 0x15, 0x11, 0x1f, 0x00,
            0x1f, 0x11, 0x1d, 0x1d, 0x1d, 0x1d, 0x1f, 0x00,
            0x1f, 0x11, 0x15, 0x11, 0x15, 0x11, 0x1f, 0x00,
            0x00, 0x0e, 0x08, 0x0e, 0x02, 0x0e, 0x00, 0x00,
            0x00, 0x0e, 0x08, 0x0e, 0x0a, 0x0e, 0x00, 0x00,
            0x00, 0x0e, 0x02, 0x02, 0x02, 0x02, 0x00, 0x00,
            0x00, 0x0e, 0x0a, 0x0e, 0x0a, 0x0e, 0x00, 0x00,
        },
        {
            0x1f, 0x11, 0x15, 0x11, 0x1d, 0x11, 0x1f, 0x00,
            0x00, 0x0e, 0x0a, 0x0a, 0x0a, 0x0e, 0x00, 0x00,
            0x00, 0x04, 0x0c, 0x04, 0x04, 0x0e, 0x00, 0x00,
            0x00, 0x0e, 0x02, 0x0e, 0x08, 0x0e, 0x00, 0x00,
            0x00, 0x0e, 0x0a, 0x0e, 0x02, 0x0e, 0x00, 0x00,
            0x1f, 0x11, 0x15, 0x15, 0x15, 0x11, 0x1f, 0x00,
            0x1f, 0x1b, 0x13, 0x1b, 0x1b, 0x11, 0x1f, 0x00,
            0x1f, 0x11, 0x1d, 0x11, 0x17, 0x11, 0x1f, 0x00,
        },
    };
    for (uint8_t i = 0; i < 8; i++)
        nm_atmega32_lcd_glyph(m, i, glyphs[group] + 8u * i);
}
#endif
