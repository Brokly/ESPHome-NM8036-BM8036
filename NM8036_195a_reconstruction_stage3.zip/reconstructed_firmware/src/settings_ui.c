#include "nm_menu.h"
#include "nm_editors.h"
#include "nm_dallas.h"
#include "nm_peripherals.h"
#include "nm_runtime.h"

#ifdef __AVR__
#include <avr/io.h>
#include <string.h>

/* Собственная C-обвязка для списка и восстановленных экранов.
 * Идентификаторы пунктов берутся из таблиц flash 0x0C0A/0x0C26. */
enum { SETTINGS_LIST, SETTINGS_PWM, SETTINGS_SOUND, SETTINGS_CLOCK, SETTINGS_DALLAS };
static NMSettingsMenu list;
static uint8_t view;
static NMPwmSetting setting;
static uint8_t rom[8], ordinal, slot, found;
static NMDallasRegistration registration;

static void draw(const NM8036 *m, const uint8_t screen[32])
{
    for (uint8_t row = 0; row < 2; row++)
        nm_atmega32_lcd_text(m, row, 0, screen + 16u * row, 16);
}

/* Порядковый поиск с проверкой наличия требуемого результата.
 * Исходник 0x5070..0x50BE кеширует результаты и измеряет температуру.
 * Пока интерфейс пересчитывает выбранный ROM по требованию. */
static void select_sensor(const NM8036 *m)
{
    *nm_ram(m, 0x0680) = ordinal;
    found = nm_dallas_search(m, &nm_atmega32_onewire);
    for (uint8_t i = 0; i < 8; i++)
        rom[i] = *nm_ram(m, 0x0681 + i);
    if (found <= ordinal)
        *nm_ram(m, 0x0680) = 0;
}

static void sensor_screen(const NM8036 *m)
{
    static const uint8_t assign[] = {0xcd,0xe0,0xe7,0xed,0xe0,0xf7,0xe8,0xf2,0xfc,' ','N','o',' '};
    uint8_t screen[32];
    memset(screen, ' ', sizeof screen);
    memcpy(screen + 16, assign, sizeof assign);
    uint8_t number = slot + 1;
    screen[29] = number < 10 ? ' ' : '0' + number / 10;
    screen[30] = '0' + number % 10;
    if (found > ordinal) {
        static const uint8_t hex[] = "0123456789ABCDEF";
        for (uint8_t i = 0; i < 8; i++) {
            screen[2u * i] = hex[rom[i] >> 4];
            screen[2u * i + 1] = hex[rom[i] & 15u];
        }
        if (registration == NM_DALLAS_REGISTERED)
            screen[31] = 'M';
        else if (registration == NM_DALLAS_UNREGISTERED)
            screen[31] = '-';
        else if (nm_dallas_crc(rom, 8))
            screen[31] = '!';
    } else {
        memcpy(screen, "No ROM", 6);
    }
    draw(m, screen);
}

/* [БИНАРНИК] 0x5104..0x5157: клавиши 1/4 меняют индекс ROM,
 * 2/3 циклически меняют номер назначения. Путь записи — 0x5158. */
static void sensor_key(const NM8036 *m, uint8_t key)
{
    if (key == 1 && ordinal < 31) {
        uint8_t prior = ordinal++;
        select_sensor(m);
        if (found <= ordinal) {
            ordinal = prior;
            select_sensor(m);
        }
        registration = NM_DALLAS_BAD_ROM;
    } else if (key == 4 && ordinal) {
        ordinal--;
        select_sensor(m);
        registration = NM_DALLAS_BAD_ROM;
    } else if (key == 2 || key == 3) {
        slot = (uint8_t)((slot + (key == 2 ? 31u : 1u)) & 31u);
        registration = NM_DALLAS_BAD_ROM;
    } else if (key == 0 && found > ordinal) {
        registration = nm_dallas_register_rom(m, slot, rom);
    }
}

/* Возвращает false для ещё не восстановленного редактора.
 * Список остаётся на выбранной строке для следующей клавиши. */
bool nm_atmega32_settings_step(NM8036 *m)
{
    volatile uint8_t *visible = nm_ram(m, 0x073a);
    uint8_t key = *nm_ram(m, 0x0739);
    if (!*visible) {
        if ((key & 15u) != 5)
            return false;
        *visible = 1;
        list = (NMSettingsMenu){0};
        view = SETTINGS_LIST;
        nm_atmega32_settings_menu_glyphs(m);
        nm_atmega32_settings_menu_draw(m, &list);
        return true;
    }
    bool opening = view == SETTINGS_LIST;
    if (view == SETTINGS_LIST) {
        switch (key & 15u) {
        case 5:
            *visible = 0;
            *nm_ram(m, 0x073f) = 0;
            return true;
        case 1: case 4:
            nm_settings_menu_move(&list, (key & 15u) == 1 ? -1 : 1);
            nm_atmega32_settings_menu_draw(m, &list);
            return true;
        case 0: {
            uint8_t selected = nm_settings_menu_selection(&list);
            if (selected == 7 || selected == 8) {
                setting = selected == 7 ? NM_EDIT_BACKLIGHT : NM_EDIT_CONTRAST;
                nm_pwm_editor_open(m, setting);
                view = SETTINGS_PWM;
            } else if (selected == 9) {
                view = SETTINGS_SOUND;
            } else if (selected == 0) {
                view = SETTINGS_CLOCK;
                nm_atmega32_refresh_clock(m);
            } else if (selected == 2) {
                view = SETTINGS_DALLAS;
                ordinal = slot = 0;
                registration = NM_DALLAS_BAD_ROM;
                select_sensor(m);
            } else {
                return false;
            }
            key = 0xff;
            break;
        }
        default:
            return true;
        }
    }

    if (!opening && key == 0xff &&
        (view != SETTINGS_CLOCK || !*nm_ram(m, 0x0735)))
        return true;
    uint8_t screen[32];
    bool done = false;
    if (view == SETTINGS_PWM) {
        done = nm_pwm_editor_key(m, setting, key) != NM_EDIT_ACTIVE;
        nm_pwm_editor_screen(m, setting, screen);
    } else if (view == SETTINGS_SOUND) {
        done = nm_sound_editor_key(m, key);
        nm_sound_editor_screen(m, screen);
    } else if (view == SETTINGS_CLOCK) {
        done = nm_clock_editor_key(m, key);
        nm_home_clock_screen(m, screen);
        /* [БИНАРНИК] 0x4CAC..0x4D0B. Гашение выбранного поля
         * на низкой фазе SQW, кроме непосредственного изменения. */
        if (!done && !(PIND & _BV(PD2)) && (key & 15u) != 1 && (key & 15u) != 4) {
            static const uint8_t start[] = {0,3,6,9,16,19,28};
            static const uint8_t width[] = {2,2,2,7,2,8,4};
            uint8_t field = *nm_ram(m, 0x0740);
            memset(screen + start[field], ' ', width[field]);
        }
        *nm_ram(m, 0x0735) = 0;
    } else {
        if (key != 5) {
            sensor_key(m, key);
            sensor_screen(m);
            return true;
        }
        done = true;
    }
    if (done) {
        view = SETTINGS_LIST;
        nm_atmega32_settings_menu_draw(m, &list);
    } else {
        draw(m, screen);
    }
    return true;
}
#endif
