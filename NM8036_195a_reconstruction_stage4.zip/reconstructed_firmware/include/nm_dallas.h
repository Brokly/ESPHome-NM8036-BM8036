#ifndef NM_DALLAS_H
#define NM_DALLAS_H
#include "nm8036.h"

typedef struct {
    void *context;
    bool (*reset)(void *);
    bool (*read_bit)(void *);
    void (*write_bit)(void *, bool);
    bool (*line_high)(void *);
    bool (*clock_high)(void *);
    void (*strong_pullup)(void *, bool);
    void (*copy_delay)(void *);
    void (*conversion_delay)(void *);
} NMOneWire;

enum {
    NM_DALLAS_PENDING = 0,
    NM_DALLAS_SAMPLE = 1,
    NM_DALLAS_ERROR = 2
};

typedef enum { NM_DALLAS_BAD_ROM, NM_DALLAS_REGISTERED, NM_DALLAS_UNREGISTERED } NMDallasRegistration;
bool nm_dallas_store_rom_raw(const NM8036 *m, uint8_t slot, const uint8_t rom[8]);
NMDallasRegistration nm_dallas_register_rom(const NM8036 *m, uint8_t slot, const uint8_t rom[8]);
uint8_t nm_dallas_search(const NM8036 *m, const NMOneWire *bus);
bool nm_dallas_load_rom(const NM8036 *m, uint8_t index);
void nm_dallas_configure_selected(const NM8036 *m, const NMOneWire *bus);
void nm_dallas_start_conversion(const NM8036 *m, const NMOneWire *bus);
int16_t nm_dallas_sample_selected_sync(const NM8036 *m, const NMOneWire *bus);
uint8_t nm_dallas_discovery_count(const NM8036 *m, const NMOneWire *bus);
bool nm_dallas_discovery_rom(const NM8036 *m, const NMOneWire *bus,
                             uint8_t ordinal, uint8_t rom[8]);
uint8_t nm_dallas_poll_sample(const NM8036 *m, const NMOneWire *bus,
                             volatile uint8_t result[2]);
uint8_t nm_dallas_poll(const NM8036 *m, const NMOneWire *bus);
void nm_dallas_poll_registered(const NM8036 *m, const NMOneWire *bus);

#ifdef __AVR__
extern const NMOneWire nm_atmega32_onewire;
#endif
#endif
