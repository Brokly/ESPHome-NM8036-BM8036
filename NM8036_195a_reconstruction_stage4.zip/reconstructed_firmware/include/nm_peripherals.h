#ifndef NM_PERIPHERALS_H
#define NM_PERIPHERALS_H
#include "nm8036.h"

uint8_t nm_key_decode(uint16_t first, uint16_t second);
void nm_startup_memory(const NM8036 *m);
uint8_t nm_key_event(const NM8036 *m, uint8_t key);
void nm_timer2_tick(const NM8036 *m, volatile uint8_t *ddrd);
void nm_tone(const NM8036 *m, uint8_t duration);
void nm_key_timing_init(const NM8036 *m);
uint16_t nm_outputs_report(const NM8036 *m, uint16_t seed, bool physical);
void nm_output_set(const NM8036 *m, uint8_t channel, bool active);
void nm_outputs_init(const NM8036 *m);
uint16_t nm_output_duration(const NM8036 *m, uint8_t row);
void nm_output_save_duration(const NM8036 *m, uint8_t row, uint16_t seconds);
void nm_outputs_force(const NM8036 *m, uint8_t mode);
void nm_outputs_tick(const NM8036 *m);
void nm_output_request(const NM8036 *m, uint8_t channel, bool active);
uint8_t nm_dallas_crc(const uint8_t *data, uint8_t count);
int16_t nm_dallas_temperature(uint8_t family, const uint8_t scratchpad[9]);
bool nm_dallas_scratchpad_valid(const uint8_t scratchpad[9]);
uint32_t nm_calendar_seconds(uint8_t year, uint8_t month, uint8_t day,
                             uint8_t hour, uint8_t minute, uint8_t second);
bool nm_schedule_window(const NM8036 *m, uint8_t index, const uint8_t rtc[8]);
void nm_schedule_step(const NM8036 *m, uint8_t (*read_key)(const NM8036 *));
void nm_rtc_edge(const NM8036 *m, volatile uint8_t *ddrd, const volatile uint8_t *pind);

#ifdef __AVR__
NM8036 nm_atmega32(void);
NM8036 nm_atmega32_device(void);
void nm_atmega32_uart_init(void);
void nm_atmega32_attach_interrupts(const NM8036 *m);
bool nm_atmega32_poll(NM8036 *m);
void nm_atmega32_gpio_timer_init(void);
void nm_atmega32_adc_init(const NM8036 *m);
uint16_t nm_atmega32_adc(const NM8036 *m, uint8_t channel);
void nm_atmega32_lcd_init(const NM8036 *m);
void nm_atmega32_lcd_clear(const NM8036 *m);
void nm_atmega32_lcd_glyph(const NM8036 *m, uint8_t index, const uint8_t rows[8]);
void nm_atmega32_lcd_text(const NM8036 *m, uint8_t row, uint8_t column,
                         const uint8_t *text, uint8_t length);
void nm_atmega32_lcd_restore(const NM8036 *m, const uint8_t buffer[96]);
uint8_t nm_atmega32_read_key(const NM8036 *m);
void nm_atmega32_refresh_clock(const NM8036 *m);
bool nm_atmega32_onewire_reset(void);
uint8_t nm_atmega32_onewire_read(void);
void nm_atmega32_onewire_write(uint8_t byte);
void nm_atmega32_onewire_send(const uint8_t *bytes, uint8_t count);
bool nm_atmega32_dallas_read(const uint8_t rom[8], int16_t *temperature);
#endif
#endif
