#include "nm_runtime.h"
#include "nm_menu.h"
#include "nm_peripherals.h"
#include "nm_dallas.h"

/* [БИНАРНИК] 0x426A..0x4299.
 * CH=0, формирование 1 Гц на SQW включено и формат часов — 24 ч.
 * Перезапись всей восьмибайтовой группы выполняется только при
 * обнаружении отклонения. Сохраняются остальные биты RTC. */
bool nm_rtc_fix_startup(const NM8036 *m)
{
    volatile uint8_t *state = nm_ram(m, 0x0727);
    if (!(state[0] & 0x80) && (state[7] & 0x13) == 0x10 && !(state[2] & 0x40))
        return false;
    state[0] &= 0x7f;
    state[7] = (state[7] & 0xfc) | 0x10;
    state[2] &= 0xbf;
    uint8_t bytes[8];
    for (uint8_t i = 0; i < sizeof bytes; i++)
        bytes[i] = state[i];
    m->rtc_write(m->context, 0, bytes, sizeof bytes);
    return true;
}

/* [БИНАРНИК] 0x0DCE..0x0E15, 0x2A88..0x2ABB, 0x24DA..0x2507.
 * Заводские коэффициенты ADC в IEEE-754 little-endian и времена
 * индикации в EEPROM, затем 12 пар импульсных длительностей. */
void nm_factory_analog_display_defaults(const NM8036 *m)
{
    static const uint8_t scale[] = {
        0, 0, 0x80, 0x3f, 0, 0, 0x80, 0x3f, 0, 0, 0x80, 0x3f, 0, 0, 0x80, 0x3f,
        '%', 'P', 1, 1, 0
    };
    static const uint8_t intervals[] = {5, 0, 0, 5, 0, 0, 0};
    for (uint8_t i = 0; i < sizeof scale; i++)
        nm_ee_write(m, i, scale[i]);
    for (uint8_t i = 0; i < sizeof intervals; i++)
        nm_ee_write(m, 0x45 + i, intervals[i]);
    uint8_t saved = m->irq_disable(m->context);
    for (uint8_t i = 0; i < 12; i++) {
        nm_ee_write(m, 0x15 + 2u * i, 10);
        nm_ee_write(m, 0x16 + 2u * i, 0);
        nm_ee_write(m, 0x2d + 2u * i, 0);
        nm_ee_write(m, 0x2e + 2u * i, 0);
    }
    m->irq_restore(m->context, saved);
}

/* [БИНАРНИК] 0x4960..0x49A3, 0x4464..0x446D, формат flash 0x07CE.
 * Три поля BCD × два знака. Часы без ведущего нуля, минуты и
 * секунды отображаются с нулём. Выход содержит восемь знаков. */
void nm_clock_text(const NM8036 *m, uint8_t display[8])
{
    volatile uint8_t *rtc = nm_ram(m, 0x0727);
    uint8_t fields[] = {rtc[2] & 0x3f, rtc[1] & 0x7f, rtc[0] & 0x7f};
    for (uint8_t i = 0; i < sizeof fields; i++) {
        uint8_t decimal = 10u * (fields[i] >> 4) + (fields[i] & 15u);
        display[3u * i] = (uint8_t)('0' + decimal / 10u);
        display[3u * i + 1] = (uint8_t)('0' + decimal % 10u);
    }
    if (display[0] == '0')
        display[0] = ' ';
    display[2] = display[5] = ':';
}

/* [БИНАРНИК] 0x469C..0x46D3. Страница часов и календаря.
 * Метки недели и месяцев — текстовые таблицы flash 0x0B58/0x0AEB.
 * При неверном индексе оставляем пробелы вместо чтения за таблицей.
 * Буфер содержит две строки ровно по шестнадцать символов. */
void nm_home_clock_screen(const NM8036 *m, uint8_t screen[32])
{
    static const uint8_t months[][8] = {
        {0xff,0xed,0xe2,0xe0,0xf0,0xff,0x20,0x20},
        {0xf4,0xe5,0xe2,0xf0,0xe0,0xeb,0xff,0x20},
        {0xec,0xe0,0xf0,0xf2,0xe0,0x20,0x20,0x20},
        {0xe0,0xef,0xf0,0xe5,0xeb,0xff,0x20,0x20},
        {0xec,0xe0,0xff,0x20,0x20,0x20,0x20,0x20},
        {0xe8,0xfe,0xed,0xff,0x20,0x20,0x20,0x20},
        {0xe8,0xfe,0xeb,0xff,0x20,0x20,0x20,0x20},
        {0xe0,0xe2,0xe3,0xf3,0xf1,0xf2,0xe0,0x20},
        {0xf1,0xe5,0xed,0xf2,0xff,0xe1,0xf0,0xff},
        {0xee,0xea,0xf2,0xff,0xe1,0xf0,0xff,0x20},
        {0xed,0xee,0xff,0xe1,0xf0,0xff,0x20,0x20},
        {0xe4,0xe5,0xea,0xe0,0xe1,0xf0,0xff,0x20},
    };
    static const uint8_t weekdays[][7] = {
        {0xcf,0xce,0xcd,0xc5,0xc4,0xc5,0xcb},
        {0xc2,0xd2,0xce,0xd0,0xcd,0xc8,0xca},
        {0xd1,0xd0,0xc5,0xc4,0xc0,0x20,0x20},
        {0xd7,0xc5,0xd2,0xc2,0xc5,0xd0,0xc3},
        {0xcf,0xdf,0xd2,0xcd,0xc8,0xd6,0xc0},
        {0xd1,0xd3,0xc1,0xc1,0xce,0xd2,0xc0},
        {0xc2,0xce,0xd1,0xca,0xd0,0xc5,0xd1},
    };
    volatile uint8_t *rtc = nm_ram(m, 0x0727);
    nm_clock_text(m, screen);
    for (uint8_t i = 8; i < 32; i++)
        screen[i] = ' ';
    uint8_t weekday = rtc[3] & 7u;
    if (weekday)
        for (uint8_t i = 0; i < 7; i++)
            screen[9 + i] = weekdays[weekday - 1][i];
    uint8_t date = rtc[4] & 0x3fu;
    uint8_t day = 10u * (date >> 4) + (date & 15u);
    screen[16] = day >= 10 ? (uint8_t)('0' + day / 10) : ' ';
    screen[17] = (uint8_t)('0' + day % 10);
    uint8_t month = (rtc[5] & 15u) + ((rtc[5] & 0x10u) ? 10u : 0u);
    if (month >= 1 && month <= 12)
        for (uint8_t i = 0; i < 8; i++)
            screen[19 + i] = months[month - 1][i];
    uint8_t year = 10u * (rtc[6] >> 4) + (rtc[6] & 15u);
    screen[28] = '2';
    screen[29] = '0';
    screen[30] = (uint8_t)('0' + year / 10);
    screen[31] = (uint8_t)('0' + year % 10);
}

/* [БИНАРНИК] 0x450C..0x457D. В полностью ручном режиме
 * клавиши 1 и 4 циклически перелистывают семь страниц. В
 * автоматическом режиме нулевой интервал пропускает страницу. */
bool nm_home_page(const NM8036 *m, uint8_t *interval, bool *manual)
{
    uint8_t saved = m->irq_disable(m->context);
    volatile uint8_t *page = nm_ram(m, 0x073c);
    *interval = nm_ee_read(m, 0x45 + *page);
    *manual = true;
    for (uint8_t i = 0; i < 7; i++)
        if (nm_ee_read(m, 0x45 + i))
            *manual = false;
    m->irq_restore(m->context, saved);

    if (*manual) {
        uint8_t key = *nm_ram(m, 0x0739) & 15u;
        if (key == 4 || key == 1) {
            *nm_ram(m, 0x073f) = 0;
            *page = key == 4 ? (uint8_t)((*page + 1u) % 7u)
                              : (uint8_t)(*page == 0 ? 6 : *page - 1);
        }
        *nm_ram(m, 0x073b) = 0;
    }
    return *manual || *interval != 0;
}

#ifdef __AVR__
#include <avr/interrupt.h>
#include <avr/io.h>
#include <string.h>

/* [БИНАРНИК] 0x62B8..0x62DF, 0x41BC..0x41EA.
 * CRT компилятора обслуживает аппаратный стек. Явная привязка ISR
 * завершается перед первой штатной инструкцией SEI. */
uint8_t nm_atmega32_startup_prefix(NM8036 *m)
{
    cli();
    *m = nm_atmega32_device();
    nm_startup_memory(m);
    /* 0x62D0 → 0x61EC → 0x415A → 0x2308. */
    *nm_ram(m, 0x0747 + 36) = 0;
    nm_atmega32_attach_interrupts(m);
    nm_atmega32_gpio_timer_init();
    nm_atmega32_lcd_init(m);
    nm_atmega32_uart_init();
    nm_atmega32_adc_init(m);
    nm_key_timing_init(m);
    nm_atmega32_refresh_clock(m);
    nm_outputs_init(m);
    return nm_atmega32_read_key(m);
}

/* [БИНАРНИК] 0x41EC..0x4269. Старт при удержании клавиши 5.
 * При сбросе удаляется регистрация Dallas, RTC-время не обнуляется. */
static void factory_initialize(NM8036 *m)
{
    static const uint8_t message0[] = {0xcd, 0xe0, 0xf7, 0xe0, 0xeb, 0xfc, 0xed, 0xe0, 0xff};
    static const uint8_t message1[] = {0xe8, 0xed, 0xe8, 0xf6, 0xe8, 0xe0, 0xeb, 0xe8, 0xe7, 0xe0, 0xf6, 0xe8, 0xff};
    nm_ee_write(m, 0x02ec, 1);
    nm_ee_write(m, 0x02ed, 1);
    nm_ee_write(m, 0x02ee, 150);
    nm_ee_write(m, 0x02ef, 150);
    OCR1BL = 0x69;
    OCR0 = 0x69;
    DDRD |= _BV(PD4);
    nm_atmega32_lcd_text(m, 0, 3, message0, sizeof message0);
    nm_atmega32_lcd_text(m, 1, 0, message1, sizeof message1);
    const uint8_t zero = 0;
    for (uint8_t address = 8; address < 42; address++)
        m->rtc_write(m->context, address, &zero, 1);
    nm_factory_program_defaults(m);
    nm_factory_analog_display_defaults(m);
    for (uint16_t address = 0x02f0; address < 0x03f0; address++)
        nm_ee_write(m, address, 0);
    DDRD &= (uint8_t)~_BV(PD4);
}

void nm_atmega32_initialize(NM8036 *m)
{
    if (nm_atmega32_startup_prefix(m) == 5)
        factory_initialize(m);
    nm_atmega32_startup_normal(m);
}

/* [БИНАРНИК] 0x429A..0x431F. Два 17-байтовых блока приветствия.
 * При пустой строке берутся две строки из flash 0x0B98 и 0x0BA9. */
static void startup_message(NM8036 *m)
{
    static const uint8_t defaults[2][16] = {
        {0x20,0x20,0x20,0xcc,0xc0,0xd1,0xd2,0xc5,0xd0,0xca,0xc8,0xd2,0,0,0,0},
        "www.masterkit.ru"
    };
    for (uint8_t row = 0; row < 2; row++) {
        uint8_t line[17];
        m->rtc_read(m->context, 8u + 17u * row, line, sizeof line);
        if (!line[0])
            memcpy(line, defaults[row], sizeof defaults[row]);
        uint8_t count = 0;
        while (count < 16 && line[count])
            count++;
        nm_atmega32_lcd_text(m, row, 0, line, count);
    }
    OCR0 = (uint8_t)~nm_ee_read(m, 0x02ef);
    DDRD &= (uint8_t)~_BV(PD4);
    if (nm_ee_read(m, 0x02ed)) {
        DDRD |= _BV(PD4);
        bool invert = true;
        for (uint8_t i = 1; i != 0xff; i++) {
            if ((i & 63u) == 0)
                invert = !invert;
            uint8_t ramp = (uint8_t)(i << 2);
            OCR1BL = invert ? (uint8_t)~ramp : ramp;
            __builtin_avr_delay_cycles(10001);
        }
        OCR1BL = (uint8_t)~nm_ee_read(m, 0x02ee);
    }
}

/* [БИНАРНИК] 0x426A..0x431F, 0x4342..0x4380, 0x4392..0x43B6.
 * Нормальная ветвь старта. Представление хода регистрации
 * (0x4322..0x4341 и 0x4368..0x4391) вынесено из текущего покрытия. */
void nm_atmega32_startup_normal(NM8036 *m)
{
    if (nm_rtc_fix_startup(m)) {
        const uint8_t zero = 0;
        for (uint8_t address = 8; address < 42; address++)
            m->rtc_write(m->context, address, &zero, 1);
    }
    startup_message(m);
    for (uint8_t i = 0; i < 32; i++) {
        if (nm_dallas_load_rom(m, i)) {
            nm_dallas_configure_selected(m, &nm_atmega32_onewire);
            int16_t temperature = nm_dallas_sample_selected_sync(m, &nm_atmega32_onewire);
            volatile uint8_t *sample = nm_ram(m, 0x06c7 + 2u * i);
            sample[0] = (uint8_t)temperature;
            sample[1] = (uint8_t)((uint16_t)temperature >> 8);
        }
    }
    for (uint8_t i = 0; i < 3; i++) {
        nm_tone(m, 1);
        __builtin_avr_delay_cycles(200001);
    }
    *nm_ram(m, 0x073b) = 0;
    *nm_ram(m, 0x073c) = 0;
    sei();
}

/* [БИНАРНИК] 0x441E..0x4431. Обход ADC в порядке (index+1)&3,
 * фиксация кода после авторепита и затем обработка команды UART. */
void nm_atmega32_front_scan(NM8036 *m)
{
    volatile uint8_t *channel = nm_ram(m, 0x073d);
    (*channel)++;
    (void)nm_atmega32_adc(m, *channel & 3u);
    *nm_ram(m, 0x0739) = nm_key_event(m, nm_atmega32_read_key(m));
    (void)nm_atmega32_poll(m);
}

/* [БИНАРНИК] 0x448A..0x44FB.
 * Вызов сам по себе не выполняет навигацию экранов 0x450C. */
void nm_atmega32_control_service(const NM8036 *m)
{
    nm_dallas_poll_registered(m, &nm_atmega32_onewire);
    if (*nm_ram(m, 0x0735))
        nm_atmega32_refresh_clock(m);
    nm_schedule_step(m, nm_atmega32_read_key);
}

/* [БИНАРНИК] 0x4432..0x4488. Во время ожидания работает
 * планировщик, выход по клавише 6 восстанавливает снимок LCD. */
void nm_atmega32_standby(NM8036 *m)
{
    cli();
    if (*nm_ram(m, 0x0739) != 6 && nm_ee_read(m, 0x02ed)) {
        sei();
        return;
    }
    uint8_t screen[96];
    m->lcd_read(m, screen);
    nm_atmega32_lcd_clear(m);
    static const uint8_t off[] = {0x20,0x20,0x20,0x20,0xc2,0xfb,0xea,0xeb,0xfe,0xf7,0xe5,0xed,0x20,0x20,0x20,0x20};
    nm_atmega32_lcd_text(m, 0, 0, off, sizeof off);
    DDRD |= _BV(PD4);
    OCR1BL = 0xe6;
    nm_ee_write(m, 0x02ed, 0);
    sei();
    do {
        *nm_ram(m, 0x0739) = nm_key_event(m, nm_atmega32_read_key(m));
        if (*nm_ram(m, 0x0739) == 6)
            break;
        if (*nm_ram(m, 0x0735)) {
            uint8_t time[8];
            nm_atmega32_refresh_clock(m);
            nm_clock_text(m, time);
            nm_atmega32_lcd_text(m, 1, 4, time, sizeof time);
            *nm_ram(m, 0x0735) = 0;
        }
        nm_schedule_step(m, nm_atmega32_read_key);
    } while (true);
    cli();
    nm_ee_write(m, 0x02ed, 1);
    OCR1BL = (uint8_t)~nm_ee_read(m, 0x02ee);
    nm_atmega32_lcd_restore(m, screen);
    sei();
}
/* Обвязка переведённого общего прохода. Вызывающий код различает
 * обработанную страницу и ещё не перенесённый диспетчер меню.
 * Состояние такой страницы не сбрасывается при выходе. */
bool nm_atmega32_main_iteration(NM8036 *m)
{
    nm_atmega32_front_scan(m);
    nm_atmega32_standby(m);
    nm_atmega32_control_service(m);
    if (*nm_ram(m, 0x073a) || (*nm_ram(m, 0x0739) & 15u) == 5)
        return nm_atmega32_settings_step(m);

    uint8_t interval;
    bool manual;
    if (!nm_home_page(m, &interval, &manual) ||
        (!manual && *nm_ram(m, 0x073b) >= interval)) {
        *nm_ram(m, 0x073b) = 0;
        *nm_ram(m, 0x073f) = 0;
        *nm_ram(m, 0x073c) = (uint8_t)((*nm_ram(m, 0x073c) + 1u) % 7u);
        return true;
    }
    uint8_t page = *nm_ram(m, 0x073c);
    if (page > 5)
        return false;
    if (*nm_ram(m, 0x0735) || !*nm_ram(m, 0x073f)) {
        uint8_t screen[32];
        if (page < 3) {
            if (!*nm_ram(m, 0x073f))
                nm_atmega32_home_temperature_glyphs(m, page);
            nm_home_temperature_screen(m, page, (PIND & _BV(PD2)) != 0, screen);
        } else if (page == 3)
            nm_home_clock_screen(m, screen);
        else
            nm_home_adc_screen(m, page == 5, screen);
        nm_atmega32_lcd_text(m, 0, 0, screen, 16);
        nm_atmega32_lcd_text(m, 1, 0, screen + 16, 16);
        *nm_ram(m, 0x073f) = 1;
        *nm_ram(m, 0x0735) = 0;
    }
    return true;
}
#endif
