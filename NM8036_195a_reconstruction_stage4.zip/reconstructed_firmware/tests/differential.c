/* Оригинал запускается в simavr только для независимой проверки. */
#include "nm_peripherals.h"
#include "nm_runtime.h"
#include "nm_menu.h"
#include "nm_editors.h"
#include "fixture.h"
#include "dallas_bus.h"
#include <simavr/sim_avr.h>
#include <simavr/sim_core.h>
#include <simavr/avr_eeprom.h>
#include <simavr/avr_uart.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint8_t flash[28668];

static void capture(struct avr_irq_t *irq, uint32_t value, void *param)
{
    (void)irq;
    send(param, (uint8_t)value);
}

static void step(avr_t *avr)
{
    int status = avr_run(avr);
    assert(status != cpu_Crashed && status != cpu_Done);
}

static void check(uint8_t command, unsigned seed, unsigned input_count)
{
    Fixture original = {0};
    uint32_t random = seed;
    for (unsigned i = 0; i < sizeof original.ee; i++) {
        random = random * 1664525u + 1013904223u;
        original.ee[i] = (uint8_t)(random >> 24);
    }
    for (unsigned i = 0; i < sizeof original.ram; i++)
        original.ram[i] = original.ee[i % 1024];
    for (unsigned i = 0; i < sizeof original.rx; i++)
        original.rx[i] = original.ee[i + 99];
    if (command == 'W')
        original.rx[0] = (uint8_t)seed;
    Fixture translated = original;
    NM8036 m = fixture_device(&translated);
    m.output_reply_seed = translated.ram[0x0321 - 0x60];
    assert(nm_command(&m, command));
    assert(translated.rx_count == input_count);

    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr->frequency = 1000000;
    avr_loadcode(avr, flash, sizeof flash, 0);
    avr->log = LOG_NONE;
    memcpy(avr->data + 0x60, original.ram, sizeof original.ram);
    avr_eeprom_desc_t ee = {original.ee, 0, sizeof original.ee};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
    uint32_t flags = 0;
    avr_ioctl(avr, AVR_IOCTL_UART_SET_FLAGS('0'), &flags);
    avr_irq_t *out = avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'), UART_IRQ_OUTPUT);
    avr_irq_t *in = avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'), UART_IRQ_INPUT);
    assert(out && in);
    avr_irq_register_notify(out, capture, &original);

    /* Выполняем оригинальную настройку UART до RET, затем входим
       в диспетчер после приёма команды. Y — программный стек компилятора. */
    avr->pc = 0x2bf6;
    for (unsigned i = 0; i < 8; i++)
        step(avr);
    assert(avr->pc == 0x2c06);
    /* Модель simavr 1.6 трактует запись UCSRC как старший делитель.
       Исправляем только моделируемое значение делителя перед обменом. */
    avr_core_watch_write(avr, 0x40, 0);
    avr->data[0x5d] = 0x5f;
    avr->data[0x5e] = 0x06;
    avr->data[28] = 0x20;
    avr->data[29] = 0x03;
    avr->data[0x0320] = command;
    avr->pc = 0x54cc;
    for (unsigned i = 0; i < input_count; i++)
        avr_raise_irq(in, original.rx[i]);

    while (avr->pc != 0x5848 && avr->cycle < 400000000)
        step(avr);
    if (avr->pc != 0x5848) fprintf(stderr, "timeout %c at %04x, sent %u, SP %02x%02x\n", command, avr->pc, original.tx_count, avr->data[0x5e], avr->data[0x5d]);
    assert(avr->pc == 0x5848);
    avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
    if (original.tx_count != translated.tx_count ||
        memcmp(original.tx, translated.tx, translated.tx_count) ||
        memcmp(original.ee, translated.ee, sizeof original.ee)) {
        fprintf(stderr, "%c seed=%u UART AVR=%u C=%u\n", command, seed,
                original.tx_count, translated.tx_count);
        for (unsigned i = 0; i < translated.tx_count; i++)
            if (original.tx[i] != translated.tx[i]) {
                fprintf(stderr, "TX[%u] AVR=%02x C=%02x\n", i, original.tx[i], translated.tx[i]);
                break;
            }
        for (unsigned i = 0; i < sizeof original.ee; i++)
            if (original.ee[i] != translated.ee[i]) {
                fprintf(stderr, "EEPROM[%03x] AVR=%02x C=%02x\n", i, original.ee[i], translated.ee[i]);
            }
        abort();
    }
    assert(avr->data[0x068e] == *nm_ram(&m, 0x068e));
    assert(avr->data[0x0739] == *nm_ram(&m, 0x0739));
    avr_terminate(avr);
    free(avr);
}

static void check_calendar(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (unsigned year = 0; year < 100; year += 3)
        for (unsigned month = 0; month <= 12; month++) {
            avr->data[28] = 0x20;
            avr->data[29] = 0x03;
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[16] = 19;
            avr->data[17] = 32;
            avr->data[18] = 43;
            avr->data[19] = 29;
            avr->data[20] = (uint8_t)month;
            avr->data[21] = (uint8_t)year;
            avr->pc = 0x3af4;
            unsigned budget = 5000;
            while (avr->pc != 0x3b94 && budget--)
                step(avr);
            assert(avr->pc == 0x3b94);
            uint32_t actual = 0;
            for (unsigned i = 0; i < 4; i++)
                actual |= (uint32_t)avr->data[16 + i] << (8 * i);
            assert(actual == nm_calendar_seconds(year, month, 29, 19, 32, 43));
        }
    avr_terminate(avr);
    free(avr);
}

static void check_schedule(void)
{
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (unsigned period = 0; period < 4; period++)
        for (unsigned pattern = 0; pattern < 3; pattern++) {
            uint8_t record[27] = {0};
            record[0] = pattern == 0 ? 7 : 17;
            record[1] = record[4] = 17;
            record[2] = record[5] = 15;
            record[3] = pattern == 1 ? 7 : 17;
            record[6] = record[7] = 18;
            record[8] = record[9] = 11;
            record[10] = record[11] = 26;
            record[19] = (uint8_t)period;
            record[25] = 1;
            uint8_t mask_bit = period == 1 ? 2 : period == 2 ? 17 : 10;
            record[20 + mask_bit / 8] = (uint8_t)(1u << (mask_bit % 8));
            nm_program_write(&m, 31, record);
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            for (unsigned hour = 0; hour < 24; hour++)
                for (unsigned offset = 0; offset < 3; offset++) {
                    uint8_t rtc[8] = {0x14 + offset,0x17,0,3,0x18,0x11,0x26,0x90};
                    rtc[2] = (uint8_t)((hour / 10) * 16 + hour % 10);
                    memcpy(avr->data + 0x0727, rtc, sizeof rtc);
                    avr->data[0x06b9] = 31;
                    avr->data[28] = 0x20;
                    avr->data[29] = 0x03;
                    avr->data[0x5d] = 0x5f;
                    avr->data[0x5e] = 0x06;
                    avr->pc = 0x3bc0;
                    unsigned budget = 10000;
                    while (avr->pc != 0x3ccc && avr->pc != 0x3d40 && budget--)
                        step(avr);
                    assert(avr->pc == 0x3ccc || avr->pc == 0x3d40);
                    bool actual = avr->pc == 0x3ccc;
                    bool translated = nm_schedule_window(&m, 31, rtc);
                    if (actual != translated)
                        fprintf(stderr, "period=%u pattern=%u hour=%u offset=%u AVR=%d C=%d\n",
                            period, pattern, hour, offset, actual, translated);
                    assert(actual == translated);
                }
        }
    avr_terminate(avr);
    free(avr);
}

static uint8_t unused_key(const NM8036 *m)
{
    (void)m;
    assert(!"Отключённый будильник не должен опрашивать АЦП");
    return 0xff;
}

static void check_control(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);

    for (uint8_t mode = 0; mode < 4; mode++)
        for (uint8_t config = 0; config < 8; config++)
            for (int16_t value = -70; value <= 70; value += 10) {
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                volatile uint8_t *rtc = nm_ram(&m, 0x0727);
                rtc[2] = 0x13;
                rtc[3] = rtc[4] = rtc[5] = 1;
                uint8_t record[27] = {0};
                record[0] = 6;
                record[3] = (config & 4) ? 12 : 18;
                record[13] = 0;
                record[14] = 0xc4;
                record[15] = 0xff;
                record[16] = 60;
                record[18] = mode;
                record[19] = 2;
                record[20] = 1;
                record[25] = 1;
                record[26] = (config & 2) ? 2 : 0;
                nm_program_write(&m, 31, record);
                if (mode == 2)
                    f.ee[0x4c + 21 * 31 + 5] |= 0x80;
                f.ee[0x02ed] = 1;
                *nm_ram(&m, 0x0707) = 1;
                nm_ram(&m, 0x06c7)[0] = (uint8_t)value;
                nm_ram(&m, 0x06c7)[1] = (uint8_t)((uint16_t)value >> 8);
                *nm_ram(&m, 0x06b9) = 31;
                *nm_ram(&m, 0x06ba) = config & 1;
                *nm_ram(&m, 0x0747 + 37) = config & 1;
                memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
                avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                nm_schedule_step(&m, unused_key);

                avr->data[28] = 0x20;
                avr->data[29] = 0x03;
                avr->data[0x5d] = 0x5f;
                avr->data[0x5e] = 0x06;
                avr->pc = 0x3bc0;
                unsigned budget = 15000;
                while (avr->pc != 0x3eba && budget--)
                    step(avr);
                assert(avr->pc == 0x3eba);
                if (memcmp(avr->data + 0x06b9, (const void *)nm_ram(&m, 0x06b9), 13) ||
                    memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 49)) {
                    fprintf(stderr, "control mode=%u config=%u val=%d AVR=%u C=%u\n",
                            mode, config, value, avr->data[0x076c], *nm_ram(&m, 0x076c));
                    abort();
                }
            }
    avr_terminate(avr);
    free(avr);
}

static void check_startup_and_sensors(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    memset(avr->data + 0x660, 0x5a, 0x124);
    memset((void *)nm_ram(&m, 0x660), 0x5a, 0x124);
    avr->data[0x5d] = 0x5f;
    avr->data[0x5e] = 0x06;
    avr->pc = 0x6b1a;
    while (avr->pc != 0x6b4c && avr->cycle < 9000)
        step(avr);
    assert(avr->pc == 0x6b4c);
    nm_startup_memory(&m);
    assert(!memcmp(avr->data + 0x660, (const void *)nm_ram(&m, 0x660), 0x124));

    for (unsigned seed = 0; seed < 64; seed++) {
        uint8_t bytes[9];
        for (unsigned i = 0; i < sizeof bytes; i++)
            bytes[i] = (uint8_t)(seed * 17u + i * 73u);
        memcpy(avr->data + 0x0600, bytes, sizeof bytes);
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[16] = 0;
        avr->data[17] = 6;
        avr->data[18] = sizeof bytes;
        avr->pc = 0x411a;
        unsigned budget = 4000;
        while (avr->pc != 0x4158 && budget--)
            step(avr);
        assert(avr->pc == 0x4158);
        assert(avr->data[16] == nm_dallas_crc(bytes, sizeof bytes));
    }

    for (int raw = -880; raw <= 2000; raw += 13)
        for (unsigned family = 0; family < 2; family++) {
            uint8_t bytes[9] = {(uint8_t)raw, (uint8_t)((uint16_t)raw >> 8)};
            bytes[6] = (uint8_t)((uint16_t)raw % 20);
            bytes[7] = (uint8_t)((uint16_t)raw % 18);
            memcpy(avr->data + 0x0600, bytes, sizeof bytes);
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[26] = 0;
            avr->data[27] = 6;
            avr->data[4] = bytes[7];
            avr->data[6] = bytes[6];
            avr->pc = family ? 0x14a2 : 0x14ba;
            unsigned budget = 5000;
            while (avr->pc != 0x14d6 && budget--)
                step(avr);
            assert(avr->pc == 0x14d6);
            int16_t actual = (int16_t)(avr->data[24] | (unsigned)avr->data[25] << 8);
            int16_t translated = nm_dallas_temperature(family ? 0x10 : 0x28, bytes);
            if (actual != translated)
                fprintf(stderr, "sensor family=%u raw=%d count=%u/%u AVR=%d C=%d\n",
                        family, raw, bytes[6], bytes[7], actual, translated);
            assert(actual == translated);
        }
    avr_terminate(avr);
    free(avr);
}

static void check_pulse_outputs(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    for (uint8_t channel = 0; channel < 12; channel++) {
        f.ee[0x15 + 2 * channel] = channel;
        f.ee[0x2d + 2 * channel] = channel % 5;
    }
    nm_outputs_init(&m);
    for (uint8_t channel = 0; channel < 12; channel++)
        *nm_ram(&m, 0x0747 + 37 + channel) = channel % 3 != 2;
    memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
    avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);

    for (unsigned tick = 0; tick < 32; tick++) {
        avr->data[28] = 0x20;
        avr->data[29] = 0x03;
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[16] = 0x47;
        avr->data[17] = 0x07;
        avr->pc = 0x2508;
        unsigned budget = 15000;
        while (avr->pc != 0x259c && budget--)
            step(avr);
        assert(avr->pc == 0x259c);
        nm_outputs_tick(&m);
        assert(!memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 49));
        assert(avr->data[0x3b] == f.porta);
        assert(avr->data[0x35] == f.portc);
        assert(avr->data[0x32] == f.portd);
    }
    avr_terminate(avr);
    free(avr);
}

/* Подставляем уровни PD7 только в момент выборки IN/SBIC, поэтому
 * реально исполняются поиск, рекурсия и драйвер слотов оригинального AVR. */
static void check_dallas_search(void)
{
    for (uint8_t devices = 0; devices <= 3; devices++)
        for (uint8_t scenario = 0; scenario < 6; scenario++) {
            uint8_t desired = scenario == 5 ? 100 : scenario;
            DallasBus original = {
                .rom = {{0x28, 0x12, 0x33, 0xb4, 0x35, 0x36, 0x37, 0x38},
                        {0x28, 0x13, 0x33, 0xb4, 0x35, 0x36, 0x37, 0x38},
                        {0x28, 0x13, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38}},
                .devices = devices
            };
            DallasBus translated = original;
            NMOneWire bus = {.context = &translated, .reset = search_reset,
                .read_bit = search_read, .write_bit = search_write};
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            *nm_ram(&m, 0x0680) = desired;
            uint8_t rom[8];
            uint8_t count;
            if (desired == 100) {
                count = nm_dallas_discovery_count(&m, &bus);
                assert(*nm_ram(&m, 0x0744) == count);
                assert(*nm_ram(&m, 0x0680) == 0);
                /* Для сравнения снимка восстанавливаем входной индекс. */
                *nm_ram(&m, 0x0680) = desired;
            } else {
                bool present = nm_dallas_discovery_rom(&m, &bus, desired, rom);
                count = *nm_ram(&m, 0x068a);
                assert(present == (count > desired));
                if (present)
                    assert(!memcmp(rom, (const void *)nm_ram(&m, 0x0681), 8));
            }
            avr_t *avr = avr_make_mcu_by_name("atmega32");
            assert(avr && avr_init(avr) == 0);
            avr_loadcode(avr, flash, sizeof flash, 0);
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[28] = 0x20;
            avr->data[29] = 0x03;
            avr->data[0x0680] = desired;
            avr->data[16] = 0xff;
            avr->data[17] = 0;
            _avr_push_addr(avr, 0x7000);
            avr->pc = 0x154c;
            bool presence = false;
            unsigned budget = 2500000;
            while (avr->pc != 0x7000 && budget--) {
                if (avr->pc == 0x0cbe)
                    presence = search_reset(&original);
                else if (avr->pc == 0x0cd0)
                    avr->data[0x30] = presence ? 0 : 0x80;
                else if (avr->pc == 0x0d0e)
                    avr->data[0x30] = search_read(&original) ? 0x80 : 0;
                else if (avr->pc == 0x0cea)
                    search_write(&original, avr->data[16] != 0);
                step(avr);
            }
            assert(avr->pc == 0x7000);
            assert(avr->data[16] == count);
            assert(!memcmp(avr->data + 0x067f, (const void *)nm_ram(&m, 0x067f), 15));
            assert(original.reads == translated.reads &&
                   original.writes == translated.writes &&
                   original.resets == translated.resets);
            avr_terminate(avr);
            free(avr);
        }
}

static void save_rtc(void *context, uint8_t address, const uint8_t *data, uint8_t size)
{
    Fixture *f = context;
    assert(address == 0 && size == 8);
    f->tx_count++;
    memcpy(f->tx, data, size);
}

static void check_runtime(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    m.rtc_write = save_rtc;
    uint8_t original_ee[1024];
    for (unsigned i = 0; i < sizeof f.ee; i++)
        f.ee[i] = (uint8_t)(i * 73u + (i >> 2));
    memcpy(original_ee, f.ee, sizeof f.ee);
    avr_eeprom_desc_t ee = {original_ee, 0, sizeof original_ee};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
    const unsigned entries[] = {0x0dce, 0x2a88, 0x24da, 0x3fea};
    for (unsigned i = 0; i < sizeof entries / sizeof entries[0]; i++) {
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[28] = 0x20;
        avr->data[29] = 0x03;
        avr->data[16] = 0x47;
        avr->data[17] = 0x07;
        _avr_push_addr(avr, 0x7000);
        avr->pc = entries[i];
        unsigned budget = 20000000;
        while (avr->pc != 0x7000 && budget--)
            step(avr);
        assert(avr->pc == 0x7000);
    }
    avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
    nm_factory_analog_display_defaults(&m);
    nm_factory_program_defaults(&m);
    for (unsigned i = 0; i < sizeof f.ee; i++) {
        if (f.ee[i] != original_ee[i])
            fprintf(stderr, "factory EEPROM[%03x] AVR=%02x C=%02x\n", i, original_ee[i], f.ee[i]);
    }
    assert(!memcmp(f.ee, original_ee, sizeof f.ee));

    for (unsigned condition = 0; condition < 16; condition++) {
        uint8_t clock[8] = {0x15, 0x21, 0x20, 4, 0x18, 0x11, 0x26, 0x90};
        clock[0] |= (condition & 1) ? 0x80 : 0;
        clock[2] |= (condition & 2) ? 0x40 : 0;
        clock[7] ^= (condition & 4) ? 0x10 : 0;
        clock[7] |= (condition & 8) ? 2 : 0;
        memcpy(avr->data + 0x0727, clock, sizeof clock);
        memcpy((void *)nm_ram(&m, 0x0727), clock, sizeof clock);
        avr->data[10] = avr->data[11] = 7;
        avr->pc = 0x426a;
        unsigned budget = 100;
        while (avr->pc != 0x4296 && avr->pc != 0x429a && budget--)
            step(avr);
        assert(avr->pc == 0x4296 || avr->pc == 0x429a);
        unsigned calls = f.tx_count;
        bool adjusted = nm_rtc_fix_startup(&m);
        assert(adjusted == (avr->pc == 0x4296));
        assert(f.tx_count == calls + adjusted);
        assert(!memcmp(avr->data + 0x0727, (const void *)nm_ram(&m, 0x0727), 8));
        if (adjusted)
            assert(!memcmp(avr->data + 0x0727, f.tx, 8));
    }
    avr_terminate(avr);
    free(avr);
}

static void check_settings_menu(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t row = 0; row <= 10; row++)
        for (uint8_t cursor = 0; cursor <= 1; cursor++)
            for (int8_t delta = -1; delta <= 1; delta++) {
                NMSettingsMenu menu = {row, cursor};
                avr->data[0x5d] = 0x5f;
                avr->data[0x5e] = 0x06;
                avr->data[28] = 0x20;
                avr->data[29] = 0x03;
                avr->data[16] = 0;
                avr->data[17] = 6;
                avr->data[18] = (uint8_t)delta;
                avr->data[0x0605] = 12;
                avr->data[0x0606] = row;
                avr->data[0x0607] = cursor | 0xa0;
                avr->pc = 0x21f4;
                unsigned budget = 200;
                while (avr->pc != 0x2226 && budget--)
                    step(avr);
                assert(avr->pc == 0x2226);
                nm_settings_menu_move(&menu, delta);
                assert(avr->data[0x0606] == menu.first_row);
                assert(avr->data[0x0607] == (menu.cursor | 0xa0));
            }
    avr_terminate(avr);
    free(avr);
}

typedef struct {
    bool parasite, line_high, clock_high, ready, released;
    uint8_t frame[9];
    unsigned reads, writes, resets;
} PollBus;

static bool poll_reset(void *context)
{
    ((PollBus *)context)->resets++;
    return true;
}

static bool poll_read(void *context)
{
    PollBus *bus = context;
    unsigned slot = bus->reads++;
    if (!bus->parasite) {
        if (slot == 0)
            return bus->ready;
        slot--;
    }
    assert(slot < 72);
    return (bus->frame[slot / 8] >> (slot % 8)) & 1u;
}

static void poll_write(void *context, bool bit)
{
    (void)bit;
    ((PollBus *)context)->writes++;
}

static bool poll_line(void *context)
{
    return ((PollBus *)context)->line_high;
}

static bool poll_clock(void *context)
{
    return ((PollBus *)context)->clock_high;
}

static void poll_power(void *context, bool active)
{
    assert(!active);
    ((PollBus *)context)->released = true;
}

static void check_dallas_poll(void)
{
    for (unsigned condition = 0; condition < 64; condition++) {
        PollBus original = {.parasite = (condition & 1) != 0,
            .ready = (condition & 2) != 0, .line_high = (condition & 4) != 0,
            .clock_high = (condition & 8) != 0,
            .frame = {0x91, 1, 0x4b, 0x46, 0x7f, 0xff, 0x0c, 0x10, 0}};
        original.frame[8] = nm_dallas_crc(original.frame, 8) ^ ((condition >> 4) & 1u);
        PollBus translated = original;
        NMOneWire bus = {.context = &translated, .reset = poll_reset, .read_bit = poll_read,
            .write_bit = poll_write, .line_high = poll_line,
            .clock_high = poll_clock, .strong_pullup = poll_power};
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        *nm_ram(&m, 0x067f) = original.parasite;
        *nm_ram(&m, 0x0681) = 0x28;
        *nm_ram(&m, 0x0689) = (condition & 32) ? 4 : 0;
        *nm_ram(&m, 0x073e) = 5;
        *nm_ram(&m, 0x06d1) = 0x5a;
        *nm_ram(&m, 0x06d2) = 0xa5;

        avr_t *avr = avr_make_mcu_by_name("atmega32");
        assert(avr && avr_init(avr) == 0);
        avr_loadcode(avr, flash, sizeof flash, 0);
        memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[28] = 0x20;
        avr->data[29] = 0x03;
        avr->data[16] = 0xd1;
        avr->data[17] = 0x06;
        _avr_push_addr(avr, 0x7000);
        avr->pc = 0x13e4;
        unsigned budget = 40000;
        while (avr->pc != 0x7000 && budget--) {
            if (avr->pc == 0x13ec)
                avr->data[0x30] = original.line_high ? 0x80 : 0;
            else if (avr->pc == 0x13f8 || avr->pc == 0x140a)
                avr->data[0x30] = original.clock_high ? 4 : 0;
            else if (avr->pc == 0x1428)
                poll_power(&original, false);
            else if (avr->pc == 0x0cbe)
                (void)poll_reset(&original);
            else if (avr->pc == 0x0cd0)
                avr->data[0x30] = 0;
            else if (avr->pc == 0x0d0e)
                avr->data[0x30] = poll_read(&original) ? 0x80 : 0;
            else if (avr->pc == 0x0cea)
                poll_write(&original, avr->data[16] != 0);
            step(avr);
        }
        assert(avr->pc == 0x7000);
        uint8_t outcome = nm_dallas_poll(&m, &bus);
        assert(avr->data[16] == outcome);
        assert(!memcmp(avr->data + 0x06d1, (const void *)nm_ram(&m, 0x06d1), 2));
        assert(avr->data[0x0689] == *nm_ram(&m, 0x0689));
        assert(original.resets == translated.resets &&
               original.reads == translated.reads &&
               original.writes == translated.writes &&
               original.released == translated.released);
        /* Передаём прямо результат оригинального scratchpad и C
           в один и тот же шаг термостата из двух реализаций. */
        if (outcome != NM_DALLAS_PENDING) {
            uint8_t wire[27] = {0};
            wire[3] = 23;
            wire[13] = 5;
            wire[14] = 0xb8;
            wire[15] = 0x0b;
            wire[16] = 0xa0;
            wire[17] = 0x0f;
            wire[19] = 2;
            wire[20] = 1;
            wire[25] = 1;
            nm_program_write(&m, 31, wire);
            f.ee[0x02ed] = 1;
            avr_eeprom_desc_t ee = { .ee = f.ee, .offset = 0, .size = sizeof f.ee };
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            uint8_t recorded = outcome == NM_DALLAS_SAMPLE ? 0xff : 0;
            *nm_ram(&m, 0x070c) = recorded;
            avr->data[0x070c] = avr->data[16] == NM_DALLAS_SAMPLE ? 0xff : 0;
            *nm_ram(&m, 0x072a) = 1;
            *nm_ram(&m, 0x072b) = 1;
            *nm_ram(&m, 0x072c) = 1;
            avr->data[0x072a] = avr->data[0x072b] = avr->data[0x072c] = 1;
            *nm_ram(&m, 0x06b9) = 31;
            avr->data[0x06b9] = 31;
            nm_schedule_step(&m, unused_key);
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[28] = 0x20;
            avr->data[29] = 0x03;
            avr->pc = 0x3bc0;
            budget = 15000;
            while (avr->pc != 0x3eba && budget--)
                step(avr);
            assert(avr->pc == 0x3eba);
            assert(avr->data[0x076c] == *nm_ram(&m, 0x076c));
            assert(avr->data[0x076c] == (recorded != 0));
        }
        avr_terminate(avr);
        free(avr);
    }
}

static void check_home_page(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t index = 0; index < 7; index++)
        for (uint8_t key = 0; key < 7; key++)
            for (unsigned settings = 0; settings < 3; settings++) {
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                if (settings)
                    f.ee[0x45 + (settings == 1 ? index : (index + 1) % 7)] = 5;
                *nm_ram(&m, 0x0739) = key;
                *nm_ram(&m, 0x073b) = 7;
                *nm_ram(&m, 0x073c) = index;
                *nm_ram(&m, 0x073f) = 1;
                memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
                avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                avr->data[10] = avr->data[11] = 7;
                avr->data[0x5d] = 0x5f;
                avr->data[0x5e] = 0x06;
                avr->data[28] = 0x20;
                avr->data[29] = 0x03;
                avr->pc = 0x450c;
                unsigned budget = 1000;
                while (avr->pc != 0x457e && avr->pc != 0x43f2 && budget--)
                    step(avr);
                assert(avr->pc == 0x457e || avr->pc == 0x43f2);
                uint8_t interval;
                bool manual;
                bool render = nm_home_page(&m, &interval, &manual);
                assert(render == (avr->pc == 0x457e));
                assert(interval == avr->data[12] && manual == (avr->data[13] != 0));
                assert(!memcmp(avr->data + 0x073b, (const void *)nm_ram(&m, 0x073b), 5));
            }
    avr_terminate(avr);
    free(avr);
}

static void enter_fragment(avr_t *avr, unsigned pc)
{
    avr->data[0x5d] = 0x5f;
    avr->data[0x5e] = 0x06;
    avr->data[28] = 0x20;
    avr->data[29] = 0x03;
    avr->data[26] = avr->data[27] = 7;
    avr->pc = pc;
}

static void check_editors(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    static const uint8_t keys[] = {0, 2, 3, 5, 0x82, 0x83, 0xff};
    static const uint8_t values[] = {0, 3, 96, 100, 101, 123, 247, 254, 255};
    for (uint8_t setting = 0; setting <= 1; setting++)
        for (unsigned i = 0; i < sizeof values; i++)
            for (unsigned j = 0; j < sizeof keys; j++) {
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                uint8_t duty = (uint8_t)~values[i];
                m.backlight_pwm = m.contrast_pwm = &duty;
                uint8_t key = keys[j];
                uint16_t ee_address = 0x02ee + setting;
                f.ee[ee_address] = 169;
                nm_pwm_editor_open(&m, (NMPwmSetting)setting);
                avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                avr->data[0x0745 + setting] = values[i];
                avr->data[0x0739] = key;
                avr->data[0x0733] = 0;
                avr->data[0x0734] = 6;
                memset(avr->data + 0x0600, 0, 16);
                avr->data[0x0602] = setting ? 100 : 0;
                avr->data[0x0606] = 255;
                enter_fragment(avr, setting ? 0x5414 : 0x5356);
                unsigned budget = 15000;
                while (avr->pc != 0x53aa && avr->pc != 0x548e && budget--) {
                    /* 0x297E — отдельный полиморфный вызов рендера LCD.
                       В этом тесте сравниваются редактор и EEPROM. */
                    if (avr->pc == 0x297e)
                        avr->pc = 0x296c;
                    step(avr);
                }
                assert(avr->pc == 0x53aa || avr->pc == 0x548e);
                NMEditResult result = nm_pwm_editor_key(&m, (NMPwmSetting)setting, key);
                assert((result == NM_EDIT_ACTIVE) == (avr->pc == 0x53aa));
                assert(avr->data[0x0745 + setting] == *nm_ram(&m, 0x0745 + setting));
                assert(avr->data[setting ? 0x5c : 0x48] == duty);
                uint8_t original_ee[1024];
                ee.ee = original_ee;
                avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
                assert(!memcmp(original_ee, f.ee, sizeof f.ee));
            }

    static const uint8_t sound_keys[] = {0, 1, 4, 5, 0x81, 0x84, 0xff, 9};
    for (unsigned value = 0; value < 4; value++)
        for (unsigned j = 0; j < sizeof sound_keys; j++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            f.ee[0x02ec] = (uint8_t)value;
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            avr->data[0x0739] = sound_keys[j];
            enter_fragment(avr, 0x4ec6);
            unsigned budget = 500;
            while (avr->pc != 0x4ee8 && avr->pc != 0x5494 &&
                   avr->pc != 0x4f02 && budget--)
                step(avr);
            assert(budget);
            bool done = nm_sound_editor_key(&m, sound_keys[j]);
            assert(done == (avr->pc == 0x5494));
            uint8_t ee_byte;
            avr_eeprom_desc_t get = {&ee_byte, 0x02ec, 1};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &get);
            assert(ee_byte == f.ee[0x02ec]);
        }
    avr_terminate(avr);
    free(avr);
}

static void check_rom_registration(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t slot = 0; slot < 32; slot++)
        for (uint8_t changed = 0; changed < 2; changed++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            uint8_t rom[8] = {0x28, 3, 55, 67, 39, 80, slot, 0};
            rom[7] = nm_dallas_crc(rom, 7);
            memcpy(f.ee + 0x02f0 + 8u * slot, rom, 8);
            if (changed)
                f.ee[0x02f0 + 8u * slot + 3] ^= 1;
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            avr->data[0x0743] = slot;
            avr->data[0x0680] = 1;
            memcpy(avr->data + 0x0608, rom, 8);
            avr->data[2] = 0;
            avr->data[3] = 6;
            enter_fragment(avr, 0x5158);
            unsigned budget = 40000;
            while (avr->pc != 0x51a6 && budget--)
                step(avr);
            assert(avr->pc == 0x51a6);
            NMDallasRegistration actual = nm_dallas_register_rom(&m, slot, rom);
            assert(actual == (changed ? NM_DALLAS_REGISTERED : NM_DALLAS_UNREGISTERED));
            uint8_t original_ee[1024];
            ee.ee = original_ee;
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
            assert(!memcmp(original_ee, f.ee, sizeof f.ee));
            rom[7] ^= 1;
            assert(nm_dallas_register_rom(&m, slot, rom) == NM_DALLAS_BAD_ROM);
            assert(!memcmp(original_ee, f.ee, sizeof f.ee));
        }
    avr_terminate(avr);
    free(avr);
}

static void check_clock_editor(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    const uint8_t clocks[][8] = {
        {0x59,0x59,0x23,7,0x31,0x12,0x99,0x90},
        {0x80,0x80,0x40,0xa1,0xc1,0xe1,0,0x90},
        {0x12,0x37,0x09,4,0x18,0x11,0x26,0x90}
    };
    for (uint8_t field = 0; field < 7; field++)
        for (uint8_t clock = 0; clock < 3; clock++)
            for (uint8_t direction = 0; direction <= 1; direction++) {
                uint8_t key = direction ? 1 : 4;
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                m.rtc_write = save_rtc;
                *nm_ram(&m, 0x0740) = field;
                memcpy((void *)nm_ram(&m, 0x0727), clocks[clock], 8);
                memcpy(avr->data + 0x0727, clocks[clock], 8);
                avr->data[0x0740] = field;
                avr->data[25] = key;
                enter_fragment(avr, 0x4b0a);
                unsigned budget = 500;
                while (avr->pc != 0x4c6a && budget--)
                    step(avr);
                assert(avr->pc == 0x4c6a);
                assert(!nm_clock_editor_key(&m, key));
                assert(f.tx_count == 1);
                assert(!memcmp(avr->data + 0x0727, f.tx, 8));
            }
    avr_terminate(avr);
    free(avr);
}

static void check_timer_interrupts(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t on = 0; on < 2; on++)
        for (uint8_t tick = 0; tick < 6; tick++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            f.ee[0x02ec] = on;
            *nm_ram(&m, 0x0697) = tick == 5 ? 255 : tick;
            *nm_ram(&m, 0x069b) = 4;
            memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            avr->data[0x31] = 0x71;
            avr->data[0x32] = 0;
            enter_fragment(avr, 0x1f88);
            _avr_push_addr(avr, 0x7000);
            unsigned budget = 500;
            while (avr->pc != 0x7000 && budget--)
                step(avr);
            assert(avr->pc == 0x7000);
            uint8_t direction = 0x71;
            nm_timer2_tick(&m, &direction);
            assert(avr->data[0x31] == direction && avr->data[0x32] == 0);
            assert(!memcmp(avr->data + 0x0697, (const void *)nm_ram(&m, 0x0697), 8));
        }

    for (uint8_t condition = 0; condition < 8; condition++) {
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        uint8_t pin = condition & 4u;
        uint8_t direction = 0x10;
        f.ee[0x02ed] = condition & 1u;
        *nm_ram(&m, 0x0737) = (condition & 2u) != 0;
        *nm_ram(&m, 0x073b) = 0xff;
        memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
        avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
        avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
        avr->data[0x31] = direction;
        avr->data[0x32] = 0;
        enter_fragment(avr, 0x5968);
        _avr_push_addr(avr, 0x7000);
        unsigned budget = 3000;
        while (avr->pc != 0x7000 && budget--) {
            if (avr->pc == 0x5988 || avr->pc == 0x59a8)
                avr->data[0x30] = pin;
            step(avr);
        }
        assert(avr->pc == 0x7000);
        nm_rtc_edge(&m, &direction, &pin);
        assert(avr->data[0x31] == direction);
        assert(!memcmp(avr->data + 0x069b, (const void *)nm_ram(&m, 0x069b), 4));
        assert(!memcmp(avr->data + 0x0735, (const void *)nm_ram(&m, 0x0735), 7));
        assert(!memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 49));
    }
    avr_terminate(avr);
    free(avr);
}

static void check_adc_calibration(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    const float coefficients[] = {-20.0f, 50.0f, 80.0f, 8.5f};
    const uint16_t inputs[] = {0, 1, 124, 512, 1023};
    for (uint8_t channel = 0; channel < 2; channel++)
        for (unsigned i = 0; i < sizeof inputs / sizeof inputs[0]; i++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            memcpy(f.ee, coefficients, sizeof coefficients);
            *nm_ram(&m, 0x0677 + 2u * channel) = (uint8_t)inputs[i];
            *nm_ram(&m, 0x0678 + 2u * channel) = (uint8_t)(inputs[i] >> 8);
            memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            avr->data[8] = channel;
            avr->data[9] = 0;
            enter_fragment(avr, 0x4732);
            unsigned budget = 4000;
            while (avr->pc != 0x4784 && budget--)
                step(avr);
            assert(avr->pc == 0x4784);
            float translated = nm_adc_calibrated(&m, channel);
            if (memcmp(avr->data + 16, &translated, sizeof translated)) {
                float expected;
                memcpy(&expected, avr->data + 16, sizeof expected);
                fprintf(stderr, "ADC %u input=%u AVR=%g C=%g\n",
                        channel, inputs[i], (double)expected, (double)translated);
            }
            assert(!memcmp(avr->data + 16, &translated, sizeof translated));
        }
    avr_terminate(avr);
    free(avr);
}

static void check_menu_lcd_stream(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t outputs = 0; outputs < 2; outputs++)
        for (uint8_t first = 0; first < (outputs ? 23 : 11); first++)
            for (uint8_t cursor = 0; cursor < 2; cursor++) {
                NMSettingsMenu menu = {first, cursor};
                uint8_t expected[32], actual[32];
                memset(actual, ' ', sizeof actual);
                if (outputs)
                    nm_output_menu_screen(&menu, expected);
                else
                    nm_settings_menu_screen(&menu, expected);
                enter_fragment(avr, 0x2282);
                _avr_push_addr(avr, 0x7000);
                avr->data[16] = 0;
                avr->data[17] = 6;
                avr->data[0x0603] = outputs ? 0x40 : 0x18;
                avr->data[0x0604] = outputs ? 0x02 : 0x0a;
                avr->data[0x0606] = first;
                avr->data[0x0607] = cursor;
                uint8_t row = 0, column = 0;
                unsigned budget = 18000;
                while (avr->pc != 0x7000 && budget--) {
                    /* Уровень до перекодировки HD44780. В оригинале
                       исполняется форматтер с чтением строк flash. */
                    if (avr->pc == 0x1e52) {
                        row = avr->data[17];
                        column = avr->data[16];
                        avr->pc = 0x2190;
                    } else if (avr->pc == 0x1ee0) {
                        if (row < 2 && column < 16)
                            actual[16u * row + column] = avr->data[16];
                        column++;
                        avr->pc = 0x2190;
                    } else if (avr->pc == 0x1e86) {
                        avr->pc = 0x2190;
                    }
                    step(avr);
                }
                assert(avr->pc == 0x7000);
                if (memcmp(actual, expected, sizeof actual)) {
                    fprintf(stderr, "LCD outputs=%u first=%u cursor=%u\n", outputs, first, cursor);
                    for (unsigned i = 0; i < sizeof actual; i++)
                        if (actual[i] != expected[i])
                            fprintf(stderr, "%u: AVR=%02x C=%02x\n", i, actual[i], expected[i]);
                    assert(0);
                }
            }
    avr_terminate(avr);
    free(avr);
}

static void check_output_and_program_editors(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    static const uint8_t keys[] = {0,1,2,3,4,5,0x80,0x81,0x82,0x83,0x84,0x85,0xff};
    static const uint16_t values[] = {0,1,2,9,10,11,99,100,101,999,1000,1001,
                                      64534,64535,65435,65525,65534,65535};
    const unsigned editor = 0x0600;
    for (uint8_t wait = 0; wait < 2; wait++)
        for (unsigned i = 0; i < sizeof values / sizeof *values; i++)
            for (unsigned j = 0; j < sizeof keys; j++) {
                uint16_t value = values[i];
                enter_fragment(avr, 0x172a);
                _avr_push_addr(avr, 0x7000);
                memset(avr->data + editor, 0, 20);
                avr->data[16] = 0;
                avr->data[17] = 6;
                avr->data[18] = keys[j];
                avr->data[editor + 2] = !wait;
                avr->data[editor + 6] = avr->data[editor + 7] = 255;
                avr->data[editor + 10] = value;
                avr->data[editor + 11] = value >> 8;
                avr->data[editor + 14] = avr->data[editor + 15] = 255;
                unsigned budget = 500;
                while (avr->pc != 0x7000 && budget--) {
                    if (avr->pc == 0x17ea)
                        avr->pc = 0x17f0; /* Рендер LCD после изменения. */
                    step(avr);
                }
                assert(avr->pc == 0x7000);
                bool done = nm_output_editor_key(wait * 12, &value, keys[j]);
                assert(done == (avr->data[16] == 1));
                assert(value == (avr->data[editor + 10] | (avr->data[editor + 11] << 8)));
            }

    for (uint8_t cursor = 0; cursor < 6; cursor++)
        for (unsigned i = 0; i < sizeof keys; i++)
            for (uint8_t input = 0; input < 4; input++) {
                NMProgramTime time = {{0,0,0,0,0,0},cursor};
                static const uint8_t sample[][6] = {
                    {0,0,0,0,0,0}, {23,59,59,31,12,99},
                    {255,255,255,255,255,255}, {9,10,11,3,4,5}
                };
                memcpy(time.field, sample[input], 6);
                memcpy(avr->data + editor + 3, time.field, 6);
                avr->data[editor + 9] = cursor;
                enter_fragment(avr, 0x2df2);
                avr->data[16] = 0;
                avr->data[17] = 6;
                avr->data[18] = keys[i];
                unsigned budget = 500;
                while (avr->pc != 0x2f76 && budget--)
                    step(avr);
                assert(avr->pc == 0x2f76);
                nm_program_time_key(&time, keys[i]);
                assert(!memcmp(avr->data + editor + 3, time.field, 6));
                assert(time.cursor == avr->data[editor + 9]);
            }
    avr_terminate(avr);
    free(avr);
}

static void check_editor_eeprom(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t row = 0; row < 24; row++) {
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        for (unsigned i = 0; i < sizeof f.ee; i++)
            f.ee[i] = (uint8_t)(91u * i + row);
        avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
        avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
        uint16_t value = 1024u * row + 313u;
        enter_fragment(avr, row < 12 ? 0x236e : 0x2378);
        _avr_push_addr(avr, 0x7000);
        avr->data[18] = row % 12u;
        unsigned budget = 15000;
        while (avr->pc != 0x7000 && budget--)
            step(avr);
        assert(avr->pc == 0x7000);
        assert(nm_output_duration(&m, row) == (avr->data[16] | (avr->data[17] << 8)));

        enter_fragment(avr, row < 12 ? 0x2390 : 0x23b0);
        avr->data[18] = row % 12u;
        avr->data[20] = value;
        avr->data[21] = value >> 8;
        _avr_push_addr(avr, 0x7000);
        budget = 30000;
        while (avr->pc != 0x7000 && budget--)
            step(avr);
        assert(avr->pc == 0x7000);
        enter_fragment(avr, 0x23fa);
        _avr_push_addr(avr, 0x7000);
        avr->data[16] = 0x47;
        avr->data[17] = 7;
        budget = 55000;
        while (avr->pc != 0x7000 && budget--)
            step(avr);
        assert(avr->pc == 0x7000);
        nm_output_save_duration(&m, row, value);
        uint8_t original[1024];
        ee.ee = original;
        avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
        assert(!memcmp(f.ee, original, sizeof original));
        assert(!memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 36));
    }

    for (uint8_t index = 0; index < 32; index++)
        for (uint8_t stop = 0; stop < 2; stop++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            for (unsigned i = 0; i < sizeof f.ee; i++)
                f.ee[i] = (uint8_t)(67u * i + (stop ? 0x17u : 0xaau));
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            NMProgramTime time = {{23, 57, 58, 30, 11, 42}, 5};
            const unsigned editor = 0x0600;
            memcpy(avr->data + editor + 3, time.field, 6);
            avr->data[0x06b4] = index;
            /* X содержит адрес рабочего окна из AVR-редактора. */
            enter_fragment(avr, stop ? 0x31a4 : 0x3140);
            avr->data[0x0707] = 0;
            avr->data[0x0708] = 6;
            unsigned target = stop ? 0x31e0 : 0x3174;
            unsigned budget = 75000;
            while (avr->pc != target && budget--)
                step(avr);
            if (avr->pc != target) fprintf(stderr, "stage4 %u %u pc %04x target %04x\n", index, stop, avr->pc, target);
            assert(avr->pc == target);
            nm_program_time_save(&m, index, stop, &time);
            uint8_t original[1024];
            ee.ee = original;
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
            if (memcmp(f.ee, original, sizeof original)) {
                for (unsigned i = 0; i < sizeof original; i++)
                    if (f.ee[i] != original[i])
                        fprintf(stderr, "program %u stop %u address %04x C=%02x AVR=%02x\n",
                                index, stop, i, f.ee[i], original[i]);
                assert(0);
            }
            NMProgramTime read_back;
            nm_program_time_load(&m, index, stop, &read_back);
            assert(!memcmp(time.field, read_back.field, sizeof time.field));
        }
    static const uint8_t keys[] = {1, 4, 0x81, 0x84, 0xff};
    static const uint8_t channels[] = {0, 1, 10, 11, 12, 126, 127};
    for (uint8_t task = 0; task < 2; task++)
        for (uint8_t high = 0; high < 2; high++)
            for (unsigned i = 0; i < sizeof channels; i++)
                for (unsigned j = 0; j < sizeof keys; j++) {
                    Fixture f = {0};
                    const uint8_t index = 31;
                    uint16_t base = 0x4c + 21u * index;
                    f.ee[base] = (uint8_t)(channels[i] * 31u);
                    f.ee[base + 12u] = channels[i] | (high << 7);
                    NM8036 m = fixture_device(&f);
                    avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                    enter_fragment(avr, task ? 0x3258 : 0x3228);
                    avr->data[4] = keys[j] & 15u;
                    avr->data[24] = base;
                    avr->data[25] = base >> 8;
                    unsigned budget = 25000;
                    while (avr->pc != 0x3308 && budget--)
                        step(avr);
                    assert(avr->pc == 0x3308);
                    if (task)
                        nm_program_kind_key(&m, index, keys[j]);
                    else
                        nm_program_output_key(&m, index, keys[j]);
                    uint8_t original[1024];
                    ee.ee = original;
                    avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
                    assert(!memcmp(f.ee, original, sizeof original));
                }
    for (uint8_t index = 0; index < 32; index++) {
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        uint16_t base = 0x4c + 21u * index;
        f.ee[base + 3] = index * 7u;
        avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
        avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
        enter_fragment(avr, 0x30a4);
        avr->data[0x06b4] = index;
        unsigned budget = 30000;
        while (avr->pc != 0x30b2 && budget--)
            step(avr);
        assert(avr->pc == 0x30b2);
        nm_program_toggle(&m, index);
        uint8_t original[1024];
        ee.ee = original;
        avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
        assert(!memcmp(f.ee, original, sizeof original));
    }
    avr_terminate(avr);
    free(avr);
}

int main(int argc, char **argv)
{
    assert(argc == 2);
    FILE *file = fopen(argv[1], "rb");
    assert(file && fread(flash, 1, sizeof flash, file) == sizeof flash);
    assert(fgetc(file) == EOF);
    fclose(file);
    check_output_and_program_editors();
    check_editor_eeprom();
    check_menu_lcd_stream();
    check_timer_interrupts();
    check_adc_calibration();
    check_editors();
    check_clock_editor();
    check_rom_registration();
    check_dallas_search();
    check_dallas_poll();
    check_runtime();
    check_settings_menu();
    check_home_page();
    check_startup_and_sensors();
    check_calendar();
    check_schedule();
    check_control();
    check_pulse_outputs();
    const char commands[] = "VDdtsvbiaclz";
    for (unsigned i = 0; commands[i]; i++)
        check((uint8_t)commands[i], 1, 0);
    check('K', 3, 1);
    check('A', 9, 48);
    check('I', 11, 27);
    check('L', 0, 0);
    check('L', 17, 0);
    for (unsigned i = 0; i < 32; i++)
        check('W', i, 28);
    check('W', 255, 28);
    puts("simavr: редакторы программ и выходов, UART, EEPROM, старт, RTC, меню, Dallas, расписания и выходы прошли сравнение");
}
