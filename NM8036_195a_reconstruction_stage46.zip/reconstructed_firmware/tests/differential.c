#include "nm_program_fields.h"
#include "nm_original_decimal.h"
#include "nm_numeric_display.h"
#include "nm_stage14.h"
/* Оригинал запускается в simavr только для независимой проверки. */
#include "nm_peripherals.h"
#include "nm_runtime.h"
#include "nm_menu.h"
#include "nm_editors.h"
#include "nm_original_helpers.h"
#include "nm_original_numeric.h"
#include "fixture.h"
#include "dallas_bus.h"
#include <simavr/sim_avr.h>
#include <simavr/sim_core.h>
#include <simavr/sim_elf.h>
#include <simavr/avr_eeprom.h>
#include <simavr/avr_uart.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint8_t flash[28668];

static void capture(struct avr_irq_t *irq, uint32_t value, void *param)
{
    (void)irq;
    send(param, (uint8_t)value);
}

static void step(avr_t *avr)
{
    int status = avr_run(avr);
    assert(status != cpu_Crashed && status != cpu_Done);
}

static void check(uint8_t command, unsigned seed, unsigned input_count)
{
    Fixture original = {0};
    uint32_t random = seed;
    for (unsigned i = 0; i < sizeof original.ee; i++) {
        random = random * 1664525u + 1013904223u;
        original.ee[i] = (uint8_t)(random >> 24);
    }
    for (unsigned i = 0; i < sizeof original.ram; i++)
        original.ram[i] = original.ee[i % 1024];
    for (unsigned i = 0; i < sizeof original.rx; i++)
        original.rx[i] = original.ee[i + 99];
    if (command == 'W')
        original.rx[0] = (uint8_t)seed;
    Fixture translated = original;
    NM8036 m = fixture_device(&translated);
    m.output_reply_seed = translated.ram[0x0321 - 0x60];
    assert(nm_command(&m, command));
    assert(translated.rx_count == input_count);

    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr->frequency = 1000000;
    avr_loadcode(avr, flash, sizeof flash, 0);
    avr->log = LOG_NONE;
    memcpy(avr->data + 0x60, original.ram, sizeof original.ram);
    avr_eeprom_desc_t ee = {original.ee, 0, sizeof original.ee};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
    uint32_t flags = 0;
    avr_ioctl(avr, AVR_IOCTL_UART_SET_FLAGS('0'), &flags);
    avr_irq_t *out = avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'), UART_IRQ_OUTPUT);
    avr_irq_t *in = avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'), UART_IRQ_INPUT);
    assert(out && in);
    avr_irq_register_notify(out, capture, &original);

    /* Выполняем оригинальную настройку UART до RET, затем входим
       в диспетчер после приёма команды. Y — программный стек компилятора. */
    avr->pc = 0x2bf6;
    for (unsigned i = 0; i < 8; i++)
        step(avr);
    assert(avr->pc == 0x2c06);
    /* Модель simavr 1.6 трактует запись UCSRC как старший делитель.
       Исправляем только моделируемое значение делителя перед обменом. */
    avr_core_watch_write(avr, 0x40, 0);
    avr->data[0x5d] = 0x5f;
    avr->data[0x5e] = 0x06;
    avr->data[28] = 0x20;
    avr->data[29] = 0x03;
    avr->data[0x0320] = command;
    avr->pc = 0x54cc;
    for (unsigned i = 0; i < input_count; i++)
        avr_raise_irq(in, original.rx[i]);

    while (avr->pc != 0x5848 && avr->cycle < 400000000)
        step(avr);
    if (avr->pc != 0x5848) fprintf(stderr, "timeout %c at %04x, sent %u, SP %02x%02x\n", command, avr->pc, original.tx_count, avr->data[0x5e], avr->data[0x5d]);
    assert(avr->pc == 0x5848);
    avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
    if (original.tx_count != translated.tx_count ||
        memcmp(original.tx, translated.tx, translated.tx_count) ||
        memcmp(original.ee, translated.ee, sizeof original.ee)) {
        fprintf(stderr, "%c seed=%u UART AVR=%u C=%u\n", command, seed,
                original.tx_count, translated.tx_count);
        for (unsigned i = 0; i < translated.tx_count; i++)
            if (original.tx[i] != translated.tx[i]) {
                fprintf(stderr, "TX[%u] AVR=%02x C=%02x\n", i, original.tx[i], translated.tx[i]);
                break;
            }
        for (unsigned i = 0; i < sizeof original.ee; i++)
            if (original.ee[i] != translated.ee[i]) {
                fprintf(stderr, "EEPROM[%03x] AVR=%02x C=%02x\n", i, original.ee[i], translated.ee[i]);
            }
        abort();
    }
    assert(avr->data[0x068e] == *nm_ram(&m, 0x068e));
    assert(avr->data[0x0739] == *nm_ram(&m, 0x0739));
    avr_terminate(avr);
    free(avr);
}

static void check_calendar(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (unsigned year = 0; year < 100; year += 3)
        for (unsigned month = 0; month <= 12; month++) {
            avr->data[28] = 0x20;
            avr->data[29] = 0x03;
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[16] = 19;
            avr->data[17] = 32;
            avr->data[18] = 43;
            avr->data[19] = 29;
            avr->data[20] = (uint8_t)month;
            avr->data[21] = (uint8_t)year;
            avr->pc = 0x3af4;
            unsigned budget = 5000;
            while (avr->pc != 0x3b94 && budget--)
                step(avr);
            assert(avr->pc == 0x3b94);
            uint32_t actual = 0;
            for (unsigned i = 0; i < 4; i++)
                actual |= (uint32_t)avr->data[16 + i] << (8 * i);
            assert(actual == nm_calendar_seconds(year, month, 29, 19, 32, 43));
        }
    avr_terminate(avr);
    free(avr);
}

static void check_schedule(void)
{
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (unsigned period = 0; period < 4; period++)
        for (unsigned pattern = 0; pattern < 3; pattern++) {
            uint8_t record[27] = {0};
            record[0] = pattern == 0 ? 7 : 17;
            record[1] = record[4] = 17;
            record[2] = record[5] = 15;
            record[3] = pattern == 1 ? 7 : 17;
            record[6] = record[7] = 18;
            record[8] = record[9] = 11;
            record[10] = record[11] = 26;
            record[19] = (uint8_t)period;
            record[25] = 1;
            uint8_t mask_bit = period == 1 ? 2 : period == 2 ? 17 : 10;
            record[20 + mask_bit / 8] = (uint8_t)(1u << (mask_bit % 8));
            nm_program_write(&m, 31, record);
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            for (unsigned hour = 0; hour < 24; hour++)
                for (unsigned offset = 0; offset < 3; offset++) {
                    uint8_t rtc[8] = {0x14 + offset,0x17,0,3,0x18,0x11,0x26,0x90};
                    rtc[2] = (uint8_t)((hour / 10) * 16 + hour % 10);
                    memcpy(avr->data + 0x0727, rtc, sizeof rtc);
                    avr->data[0x06b9] = 31;
                    avr->data[28] = 0x20;
                    avr->data[29] = 0x03;
                    avr->data[0x5d] = 0x5f;
                    avr->data[0x5e] = 0x06;
                    avr->pc = 0x3bc0;
                    unsigned budget = 10000;
                    while (avr->pc != 0x3ccc && avr->pc != 0x3d40 && budget--)
                        step(avr);
                    assert(avr->pc == 0x3ccc || avr->pc == 0x3d40);
                    bool actual = avr->pc == 0x3ccc;
                    bool translated = nm_schedule_window(&m, 31, rtc);
                    if (actual != translated)
                        fprintf(stderr, "period=%u pattern=%u hour=%u offset=%u AVR=%d C=%d\n",
                            period, pattern, hour, offset, actual, translated);
                    assert(actual == translated);
                }
        }
    avr_terminate(avr);
    free(avr);
}

static uint8_t unused_key(const NM8036 *m)
{
    (void)m;
    assert(!"Отключённый будильник не должен опрашивать АЦП");
    return 0xff;
}

static void check_control(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);

    for (uint8_t mode = 0; mode < 4; mode++)
        for (uint8_t config = 0; config < 24; config++)
            for (int16_t value = -70; value <= 70; value += 10) {
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                volatile uint8_t *rtc = nm_ram(&m, 0x0727);
                rtc[2] = 0x13;
                rtc[3] = rtc[4] = rtc[5] = 1;
                uint8_t record[27] = {0};
                record[0] = 6;
                record[3] = (config & 4) ? 12 : 18;
                record[13] = 0;
                record[14] = 0xc4;
                record[15] = 0xff;
                record[16] = 60;
                record[18] = mode;
                record[19] = 2;
                record[20] = 1;
                record[25] = 1;
                record[26] = ((config & 2) ? 2 : 0) | ((config & 8) ? 1 : 0);
                nm_program_write(&m, 31, record);
                if (mode == 2)
                    f.ee[0x4c + 21 * 31 + 5] |= 0x80;
                f.ee[0x02ed] = 1;
                *nm_ram(&m, 0x0707) = (config & 16) == 0;
                nm_ram(&m, 0x0677)[0] = (uint8_t)(value + 70);
                nm_ram(&m, 0x0677)[1] = 0;
                nm_ram(&m, 0x06c7)[0] = (uint8_t)value;
                nm_ram(&m, 0x06c7)[1] = (uint8_t)((uint16_t)value >> 8);
                *nm_ram(&m, 0x06b9) = 31;
                *nm_ram(&m, 0x06ba) = config & 1;
                *nm_ram(&m, 0x0747 + 37) = config & 1;
                memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
                avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                nm_schedule_step(&m, unused_key);

                avr->data[28] = 0x20;
                avr->data[29] = 0x03;
                avr->data[0x5d] = 0x5f;
                avr->data[0x5e] = 0x06;
                avr->pc = 0x3bc0;
                unsigned budget = 15000;
                while (avr->pc != 0x3eba && budget--)
                    step(avr);
                assert(avr->pc == 0x3eba);
                if (memcmp(avr->data + 0x06b9, (const void *)nm_ram(&m, 0x06b9), 13) ||
                    memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 49)) {
                    fprintf(stderr, "control mode=%u config=%u val=%d AVR=%u C=%u\n",
                            mode, config, value, avr->data[0x076c], *nm_ram(&m, 0x076c));
                    abort();
                }
            }
    avr_terminate(avr);
    free(avr);
}

static void check_startup_and_sensors(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    memset(avr->data + 0x660, 0x5a, 0x124);
    memset((void *)nm_ram(&m, 0x660), 0x5a, 0x124);
    avr->data[0x5d] = 0x5f;
    avr->data[0x5e] = 0x06;
    avr->pc = 0x6b1a;
    while (avr->pc != 0x6b4c && avr->cycle < 9000)
        step(avr);
    assert(avr->pc == 0x6b4c);
    nm_startup_memory(&m);
    assert(!memcmp(avr->data + 0x660, (const void *)nm_ram(&m, 0x660), 0x124));

    for (unsigned seed = 0; seed < 64; seed++) {
        uint8_t bytes[9];
        for (unsigned i = 0; i < sizeof bytes; i++)
            bytes[i] = (uint8_t)(seed * 17u + i * 73u);
        memcpy(avr->data + 0x0600, bytes, sizeof bytes);
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[16] = 0;
        avr->data[17] = 6;
        avr->data[18] = sizeof bytes;
        avr->pc = 0x411a;
        unsigned budget = 4000;
        while (avr->pc != 0x4158 && budget--)
            step(avr);
        assert(avr->pc == 0x4158);
        assert(avr->data[16] == nm_dallas_crc(bytes, sizeof bytes));
    }

    for (int raw = -880; raw <= 2000; raw += 13)
        for (unsigned family = 0; family < 2; family++) {
            uint8_t bytes[9] = {(uint8_t)raw, (uint8_t)((uint16_t)raw >> 8)};
            bytes[6] = (uint8_t)((uint16_t)raw % 20);
            bytes[7] = (uint8_t)((uint16_t)raw % 18);
            memcpy(avr->data + 0x0600, bytes, sizeof bytes);
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[26] = 0;
            avr->data[27] = 6;
            avr->data[4] = bytes[7];
            avr->data[6] = bytes[6];
            avr->pc = family ? 0x14a2 : 0x14ba;
            unsigned budget = 5000;
            while (avr->pc != 0x14d6 && budget--)
                step(avr);
            assert(avr->pc == 0x14d6);
            int16_t actual = (int16_t)(avr->data[24] | (unsigned)avr->data[25] << 8);
            int16_t translated = nm_dallas_temperature(family ? 0x10 : 0x28, bytes);
            if (actual != translated)
                fprintf(stderr, "sensor family=%u raw=%d count=%u/%u AVR=%d C=%d\n",
                        family, raw, bytes[6], bytes[7], actual, translated);
            assert(actual == translated);
        }
    avr_terminate(avr);
    free(avr);
}

static void check_pulse_outputs(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    for (uint8_t channel = 0; channel < 12; channel++) {
        f.ee[0x15 + 2 * channel] = channel;
        f.ee[0x2d + 2 * channel] = channel % 5;
    }
    nm_outputs_init(&m);
    for (uint8_t channel = 0; channel < 12; channel++)
        *nm_ram(&m, 0x0747 + 37 + channel) = channel % 3 != 2;
    memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
    avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);

    for (unsigned tick = 0; tick < 32; tick++) {
        avr->data[28] = 0x20;
        avr->data[29] = 0x03;
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[16] = 0x47;
        avr->data[17] = 0x07;
        avr->pc = 0x2508;
        unsigned budget = 15000;
        while (avr->pc != 0x259c && budget--)
            step(avr);
        assert(avr->pc == 0x259c);
        nm_outputs_tick(&m);
        assert(!memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 49));
        assert(avr->data[0x3b] == f.porta);
        assert(avr->data[0x35] == f.portc);
        assert(avr->data[0x32] == f.portd);
    }
    avr_terminate(avr);
    free(avr);
}

/* Подставляем уровни PD7 только в момент выборки IN/SBIC, поэтому
 * реально исполняются поиск, рекурсия и драйвер слотов оригинального AVR. */
static void check_dallas_search(void)
{
    for (uint8_t devices = 0; devices <= 3; devices++)
        for (uint8_t scenario = 0; scenario < 6; scenario++) {
            uint8_t desired = scenario == 5 ? 100 : scenario;
            DallasBus original = {
                .rom = {{0x28, 0x12, 0x33, 0xb4, 0x35, 0x36, 0x37, 0x38},
                        {0x28, 0x13, 0x33, 0xb4, 0x35, 0x36, 0x37, 0x38},
                        {0x28, 0x13, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38}},
                .devices = devices
            };
            DallasBus translated = original;
            NMOneWire bus = {.context = &translated, .reset = search_reset,
                .read_bit = search_read, .write_bit = search_write};
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            *nm_ram(&m, 0x0680) = desired;
            uint8_t rom[8];
            uint8_t count;
            if (desired == 100) {
                count = nm_dallas_discovery_count(&m, &bus);
                assert(*nm_ram(&m, 0x0744) == count);
                assert(*nm_ram(&m, 0x0680) == 0);
                /* Для сравнения снимка восстанавливаем входной индекс. */
                *nm_ram(&m, 0x0680) = desired;
            } else {
                bool present = nm_dallas_discovery_rom(&m, &bus, desired, rom);
                count = *nm_ram(&m, 0x068a);
                assert(present == (count > desired));
                if (present)
                    assert(!memcmp(rom, (const void *)nm_ram(&m, 0x0681), 8));
            }
            avr_t *avr = avr_make_mcu_by_name("atmega32");
            assert(avr && avr_init(avr) == 0);
            avr_loadcode(avr, flash, sizeof flash, 0);
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[28] = 0x20;
            avr->data[29] = 0x03;
            avr->data[0x0680] = desired;
            avr->data[16] = 0xff;
            avr->data[17] = 0;
            _avr_push_addr(avr, 0x7000);
            avr->pc = 0x154c;
            bool presence = false;
            unsigned budget = 2500000;
            while (avr->pc != 0x7000 && budget--) {
                if (avr->pc == 0x0cbe)
                    presence = search_reset(&original);
                else if (avr->pc == 0x0cd0)
                    avr->data[0x30] = presence ? 0 : 0x80;
                else if (avr->pc == 0x0d0e)
                    avr->data[0x30] = search_read(&original) ? 0x80 : 0;
                else if (avr->pc == 0x0cea)
                    search_write(&original, avr->data[16] != 0);
                step(avr);
            }
            assert(avr->pc == 0x7000);
            assert(avr->data[16] == count);
            assert(!memcmp(avr->data + 0x067f, (const void *)nm_ram(&m, 0x067f), 15));
            assert(original.reads == translated.reads &&
                   original.writes == translated.writes &&
                   original.resets == translated.resets);
            avr_terminate(avr);
            free(avr);
        }
}

static void save_rtc(void *context, uint8_t address, const uint8_t *data, uint8_t size)
{
    Fixture *f = context;
    assert(address == 0 && size == 8);
    f->tx_count++;
    memcpy(f->tx, data, size);
}

static void check_runtime(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    m.rtc_write = save_rtc;
    uint8_t original_ee[1024];
    for (unsigned i = 0; i < sizeof f.ee; i++)
        f.ee[i] = (uint8_t)(i * 73u + (i >> 2));
    memcpy(original_ee, f.ee, sizeof f.ee);
    avr_eeprom_desc_t ee = {original_ee, 0, sizeof original_ee};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
    const unsigned entries[] = {0x0dce, 0x2a88, 0x24da, 0x3fea};
    for (unsigned i = 0; i < sizeof entries / sizeof entries[0]; i++) {
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[28] = 0x20;
        avr->data[29] = 0x03;
        avr->data[16] = 0x47;
        avr->data[17] = 0x07;
        _avr_push_addr(avr, 0x7000);
        avr->pc = entries[i];
        unsigned budget = 20000000;
        while (avr->pc != 0x7000 && budget--)
            step(avr);
        assert(avr->pc == 0x7000);
    }
    avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
    nm_factory_analog_display_defaults(&m);
    nm_factory_program_defaults(&m);
    for (unsigned i = 0; i < sizeof f.ee; i++) {
        if (f.ee[i] != original_ee[i])
            fprintf(stderr, "factory EEPROM[%03x] AVR=%02x C=%02x\n", i, original_ee[i], f.ee[i]);
    }
    assert(!memcmp(f.ee, original_ee, sizeof f.ee));

    for (unsigned condition = 0; condition < 16; condition++) {
        uint8_t clock[8] = {0x15, 0x21, 0x20, 4, 0x18, 0x11, 0x26, 0x90};
        clock[0] |= (condition & 1) ? 0x80 : 0;
        clock[2] |= (condition & 2) ? 0x40 : 0;
        clock[7] ^= (condition & 4) ? 0x10 : 0;
        clock[7] |= (condition & 8) ? 2 : 0;
        memcpy(avr->data + 0x0727, clock, sizeof clock);
        memcpy((void *)nm_ram(&m, 0x0727), clock, sizeof clock);
        avr->data[10] = avr->data[11] = 7;
        avr->pc = 0x426a;
        unsigned budget = 100;
        while (avr->pc != 0x4296 && avr->pc != 0x429a && budget--)
            step(avr);
        assert(avr->pc == 0x4296 || avr->pc == 0x429a);
        unsigned calls = f.tx_count;
        bool adjusted = nm_rtc_fix_startup(&m);
        assert(adjusted == (avr->pc == 0x4296));
        assert(f.tx_count == calls + adjusted);
        assert(!memcmp(avr->data + 0x0727, (const void *)nm_ram(&m, 0x0727), 8));
        if (adjusted)
            assert(!memcmp(avr->data + 0x0727, f.tx, 8));
    }
    avr_terminate(avr);
    free(avr);
}

static void check_settings_menu(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t row = 0; row <= 10; row++)
        for (uint8_t cursor = 0; cursor <= 1; cursor++)
            for (int8_t delta = -1; delta <= 1; delta++) {
                NMSettingsMenu menu = {row, cursor};
                avr->data[0x5d] = 0x5f;
                avr->data[0x5e] = 0x06;
                avr->data[28] = 0x20;
                avr->data[29] = 0x03;
                avr->data[16] = 0;
                avr->data[17] = 6;
                avr->data[18] = (uint8_t)delta;
                avr->data[0x0605] = 12;
                avr->data[0x0606] = row;
                avr->data[0x0607] = cursor | 0xa0;
                avr->pc = 0x21f4;
                unsigned budget = 200;
                while (avr->pc != 0x2226 && budget--)
                    step(avr);
                assert(avr->pc == 0x2226);
                nm_settings_menu_move(&menu, delta);
                assert(avr->data[0x0606] == menu.first_row);
                assert(avr->data[0x0607] == (menu.cursor | 0xa0));
            }
    avr_terminate(avr);
    free(avr);
}

typedef struct {
    bool parasite, line_high, clock_high, ready, released;
    uint8_t frame[9];
    unsigned reads, writes, resets;
    uint8_t event[180];
    unsigned length;
} PollBus;

static bool poll_reset(void *context)
{
    PollBus *bus = context;
    bus->resets++;
    bus->event[bus->length++] = 'R';
    return true;
}

static bool poll_read(void *context)
{
    PollBus *bus = context;
    unsigned slot = bus->reads++;
    bus->event[bus->length++] = '?';
    if (!bus->parasite) {
        if (slot == 0)
            return bus->ready;
        slot--;
    }
    assert(slot < 72);
    return (bus->frame[slot / 8] >> (slot % 8)) & 1u;
}

static void poll_write(void *context, bool bit)
{
    PollBus *bus = context;
    bus->writes++;
    bus->event[bus->length++] = bit ? '1' : '0';
}

static bool poll_line(void *context)
{
    return ((PollBus *)context)->line_high;
}

static bool poll_clock(void *context)
{
    return ((PollBus *)context)->clock_high;
}

static void poll_power(void *context, bool active)
{
    assert(!active);
    PollBus *bus = context;
    bus->released = true;
    bus->event[bus->length++] = '-';
}

static void check_dallas_poll(void)
{
    for (unsigned condition = 0; condition < 64; condition++) {
        PollBus original = {.parasite = (condition & 1) != 0,
            .ready = (condition & 2) != 0, .line_high = (condition & 4) != 0,
            .clock_high = (condition & 8) != 0,
            .frame = {0x91, 1, 0x4b, 0x46, 0x7f, 0xff, 0x0c, 0x10, 0}};
        original.frame[8] = nm_dallas_crc(original.frame, 8) ^ ((condition >> 4) & 1u);
        PollBus translated = original;
        NMOneWire bus = {.context = &translated, .reset = poll_reset, .read_bit = poll_read,
            .write_bit = poll_write, .line_high = poll_line,
            .clock_high = poll_clock, .strong_pullup = poll_power};
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        *nm_ram(&m, 0x067f) = original.parasite;
        *nm_ram(&m, 0x0681) = 0x28;
        *nm_ram(&m, 0x0689) = (condition & 32) ? 4 : 0;
        *nm_ram(&m, 0x073e) = 5;
        *nm_ram(&m, 0x06d1) = 0x5a;
        *nm_ram(&m, 0x06d2) = 0xa5;

        avr_t *avr = avr_make_mcu_by_name("atmega32");
        assert(avr && avr_init(avr) == 0);
        avr_loadcode(avr, flash, sizeof flash, 0);
        memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
        avr->data[0x5d] = 0x5f;
        avr->data[0x5e] = 0x06;
        avr->data[28] = 0x20;
        avr->data[29] = 0x03;
        avr->data[16] = 0xd1;
        avr->data[17] = 0x06;
        _avr_push_addr(avr, 0x7000);
        avr->pc = 0x13e4;
        unsigned budget = 40000;
        while (avr->pc != 0x7000 && budget--) {
            if (avr->pc == 0x13ec)
                avr->data[0x30] = original.line_high ? 0x80 : 0;
            else if (avr->pc == 0x13f8 || avr->pc == 0x140a)
                avr->data[0x30] = original.clock_high ? 4 : 0;
            else if (avr->pc == 0x1428)
                poll_power(&original, false);
            else if (avr->pc == 0x0cbe)
                (void)poll_reset(&original);
            else if (avr->pc == 0x0cd0)
                avr->data[0x30] = 0;
            else if (avr->pc == 0x0d0e)
                avr->data[0x30] = poll_read(&original) ? 0x80 : 0;
            else if (avr->pc == 0x0cea)
                poll_write(&original, avr->data[16] != 0);
            step(avr);
        }
        assert(avr->pc == 0x7000);
        uint8_t outcome = nm_dallas_poll(&m, &bus);
        assert(avr->data[16] == outcome);
        assert(!memcmp(avr->data + 0x06d1, (const void *)nm_ram(&m, 0x06d1), 2));
        assert(avr->data[0x0689] == *nm_ram(&m, 0x0689));
        assert(original.resets == translated.resets &&
               original.reads == translated.reads &&
               original.writes == translated.writes &&
               original.released == translated.released);
        assert(original.length == translated.length);
        assert(!memcmp(original.event, translated.event, original.length));
        /* Передаём прямо результат оригинального scratchpad и C
           в один и тот же шаг термостата из двух реализаций. */
        if (outcome != NM_DALLAS_PENDING) {
            uint8_t wire[27] = {0};
            wire[3] = 23;
            wire[13] = 5;
            wire[14] = 0xb8;
            wire[15] = 0x0b;
            wire[16] = 0xa0;
            wire[17] = 0x0f;
            wire[19] = 2;
            wire[20] = 1;
            wire[25] = 1;
            nm_program_write(&m, 31, wire);
            f.ee[0x02ed] = 1;
            avr_eeprom_desc_t ee = { .ee = f.ee, .offset = 0, .size = sizeof f.ee };
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            uint8_t recorded = outcome == NM_DALLAS_SAMPLE ? 0xff : 0;
            *nm_ram(&m, 0x070c) = recorded;
            avr->data[0x070c] = avr->data[16] == NM_DALLAS_SAMPLE ? 0xff : 0;
            *nm_ram(&m, 0x072a) = 1;
            *nm_ram(&m, 0x072b) = 1;
            *nm_ram(&m, 0x072c) = 1;
            avr->data[0x072a] = avr->data[0x072b] = avr->data[0x072c] = 1;
            *nm_ram(&m, 0x06b9) = 31;
            avr->data[0x06b9] = 31;
            nm_schedule_step(&m, unused_key);
            avr->data[0x5d] = 0x5f;
            avr->data[0x5e] = 0x06;
            avr->data[28] = 0x20;
            avr->data[29] = 0x03;
            avr->pc = 0x3bc0;
            budget = 15000;
            while (avr->pc != 0x3eba && budget--)
                step(avr);
            assert(avr->pc == 0x3eba);
            assert(avr->data[0x076c] == *nm_ram(&m, 0x076c));
            assert(avr->data[0x076c] == (recorded != 0));
        }
        avr_terminate(avr);
        free(avr);
    }
}

static void check_home_page(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t index = 0; index < 7; index++)
        for (uint8_t key = 0; key < 7; key++)
            for (unsigned settings = 0; settings < 3; settings++) {
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                if (settings)
                    f.ee[0x45 + (settings == 1 ? index : (index + 1) % 7)] = 5;
                *nm_ram(&m, 0x0739) = key;
                *nm_ram(&m, 0x073b) = 7;
                *nm_ram(&m, 0x073c) = index;
                *nm_ram(&m, 0x073f) = 1;
                memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
                avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                avr->data[10] = avr->data[11] = 7;
                avr->data[0x5d] = 0x5f;
                avr->data[0x5e] = 0x06;
                avr->data[28] = 0x20;
                avr->data[29] = 0x03;
                avr->pc = 0x450c;
                unsigned budget = 1000;
                while (avr->pc != 0x457e && avr->pc != 0x43f2 && budget--)
                    step(avr);
                assert(avr->pc == 0x457e || avr->pc == 0x43f2);
                uint8_t interval;
                bool manual;
                bool render = nm_home_page(&m, &interval, &manual);
                assert(render == (avr->pc == 0x457e));
                assert(interval == avr->data[12] && manual == (avr->data[13] != 0));
                assert(!memcmp(avr->data + 0x073b, (const void *)nm_ram(&m, 0x073b), 5));
            }
    avr_terminate(avr);
    free(avr);
}

static void enter_fragment(avr_t *avr, unsigned pc)
{
    avr->data[0x5d] = 0x5f;
    avr->data[0x5e] = 0x06;
    avr->data[28] = 0x20;
    avr->data[29] = 0x03;
    avr->data[26] = avr->data[27] = 7;
    avr->pc = pc;
}

static void check_editors(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    static const uint8_t keys[] = {0, 2, 3, 5, 0x82, 0x83, 0xff};
    static const uint8_t values[] = {0, 3, 96, 100, 101, 123, 247, 254, 255};
    for (uint8_t setting = 0; setting <= 1; setting++)
        for (unsigned i = 0; i < sizeof values; i++)
            for (unsigned j = 0; j < sizeof keys; j++) {
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                uint8_t duty = (uint8_t)~values[i];
                m.backlight_pwm = m.contrast_pwm = &duty;
                uint8_t key = keys[j];
                uint16_t ee_address = 0x02ee + setting;
                f.ee[ee_address] = 169;
                nm_pwm_editor_open(&m, (NMPwmSetting)setting);
                avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                avr->data[0x0745 + setting] = values[i];
                avr->data[0x0739] = key;
                avr->data[0x0733] = 0;
                avr->data[0x0734] = 6;
                memset(avr->data + 0x0600, 0, 16);
                avr->data[0x0602] = setting ? 100 : 0;
                avr->data[0x0606] = 255;
                enter_fragment(avr, setting ? 0x5414 : 0x5356);
                unsigned budget = 15000;
                while (avr->pc != 0x53aa && avr->pc != 0x548e && budget--) {
                    /* 0x297E — отдельный полиморфный вызов рендера LCD.
                       В этом тесте сравниваются редактор и EEPROM. */
                    if (avr->pc == 0x297e)
                        avr->pc = 0x296c;
                    step(avr);
                }
                assert(avr->pc == 0x53aa || avr->pc == 0x548e);
                NMEditResult result = nm_pwm_editor_key(&m, (NMPwmSetting)setting, key);
                assert((result == NM_EDIT_ACTIVE) == (avr->pc == 0x53aa));
                assert(avr->data[0x0745 + setting] == *nm_ram(&m, 0x0745 + setting));
                assert(avr->data[setting ? 0x5c : 0x48] == duty);
                uint8_t original_ee[1024];
                ee.ee = original_ee;
                avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
                assert(!memcmp(original_ee, f.ee, sizeof f.ee));
            }

    static const uint8_t sound_keys[] = {0, 1, 4, 5, 0x81, 0x84, 0xff, 9};
    for (unsigned value = 0; value < 4; value++)
        for (unsigned j = 0; j < sizeof sound_keys; j++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            f.ee[0x02ec] = (uint8_t)value;
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            avr->data[0x0739] = sound_keys[j];
            enter_fragment(avr, 0x4ec6);
            unsigned budget = 500;
            while (avr->pc != 0x4ee8 && avr->pc != 0x5494 &&
                   avr->pc != 0x4f02 && budget--)
                step(avr);
            assert(budget);
            bool done = nm_sound_editor_key(&m, sound_keys[j]);
            assert(done == (avr->pc == 0x5494));
            uint8_t ee_byte;
            avr_eeprom_desc_t get = {&ee_byte, 0x02ec, 1};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &get);
            assert(ee_byte == f.ee[0x02ec]);
        }
    avr_terminate(avr);
    free(avr);
}

static void check_rom_registration(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t slot = 0; slot < 32; slot++)
        for (uint8_t changed = 0; changed < 2; changed++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            uint8_t rom[8] = {0x28, 3, 55, 67, 39, 80, slot, 0};
            rom[7] = nm_dallas_crc(rom, 7);
            memcpy(f.ee + 0x02f0 + 8u * slot, rom, 8);
            if (changed)
                f.ee[0x02f0 + 8u * slot + 3] ^= 1;
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            avr->data[0x0743] = slot;
            avr->data[0x0680] = 1;
            memcpy(avr->data + 0x0608, rom, 8);
            avr->data[2] = 0;
            avr->data[3] = 6;
            enter_fragment(avr, 0x5158);
            unsigned budget = 40000;
            while (avr->pc != 0x51a6 && budget--)
                step(avr);
            assert(avr->pc == 0x51a6);
            NMDallasRegistration actual = nm_dallas_register_rom(&m, slot, rom);
            assert(actual == (changed ? NM_DALLAS_REGISTERED : NM_DALLAS_UNREGISTERED));
            uint8_t original_ee[1024];
            ee.ee = original_ee;
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
            assert(!memcmp(original_ee, f.ee, sizeof f.ee));
            rom[7] ^= 1;
            assert(nm_dallas_register_rom(&m, slot, rom) == NM_DALLAS_BAD_ROM);
            assert(!memcmp(original_ee, f.ee, sizeof f.ee));
            /* Оригинальный ENTER сохраняет даже ROM с плохой CRC. */
            ee.ee = f.ee;
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            memcpy(avr->data + 0x0608, rom, 8);
            avr->data[2] = 0;
            avr->data[3] = 6;
            enter_fragment(avr, 0x5158);
            budget = 40000;
            while (avr->pc != 0x51a6 && budget--)
                step(avr);
            assert(avr->pc == 0x51a6);
            assert(nm_dallas_store_rom_raw(&m, slot, rom));
            ee.ee = original_ee;
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
            assert(!memcmp(original_ee, f.ee, sizeof f.ee));
        }
    avr_terminate(avr);
    free(avr);
}

static void check_clock_editor(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    const uint8_t clocks[][8] = {
        {0x59,0x59,0x23,7,0x31,0x12,0x99,0x90},
        {0x80,0x80,0x40,0xa1,0xc1,0xe1,0,0x90},
        {0x12,0x37,0x09,4,0x18,0x11,0x26,0x90}
    };
    for (uint8_t field = 0; field < 7; field++)
        for (uint8_t clock = 0; clock < 3; clock++)
            for (uint8_t direction = 0; direction <= 1; direction++) {
                uint8_t key = direction ? 1 : 4;
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                m.rtc_write = save_rtc;
                *nm_ram(&m, 0x0740) = field;
                memcpy((void *)nm_ram(&m, 0x0727), clocks[clock], 8);
                memcpy(avr->data + 0x0727, clocks[clock], 8);
                avr->data[0x0740] = field;
                avr->data[25] = key;
                enter_fragment(avr, 0x4b0a);
                unsigned budget = 500;
                while (avr->pc != 0x4c6a && budget--)
                    step(avr);
                assert(avr->pc == 0x4c6a);
                assert(!nm_clock_editor_key(&m, key));
                assert(f.tx_count == 1);
                assert(!memcmp(avr->data + 0x0727, f.tx, 8));
            }
    avr_terminate(avr);
    free(avr);
}

static void check_timer_interrupts(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t on = 0; on < 2; on++)
        for (uint8_t tick = 0; tick < 6; tick++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            f.ee[0x02ec] = on;
            *nm_ram(&m, 0x0697) = tick == 5 ? 255 : tick;
            *nm_ram(&m, 0x069b) = 4;
            memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            avr->data[0x31] = 0x71;
            avr->data[0x32] = 0;
            enter_fragment(avr, 0x1f88);
            _avr_push_addr(avr, 0x7000);
            unsigned budget = 500;
            while (avr->pc != 0x7000 && budget--)
                step(avr);
            assert(avr->pc == 0x7000);
            uint8_t direction = 0x71;
            nm_timer2_tick(&m, &direction);
            assert(avr->data[0x31] == direction && avr->data[0x32] == 0);
            assert(!memcmp(avr->data + 0x0697, (const void *)nm_ram(&m, 0x0697), 8));
        }

    for (uint8_t condition = 0; condition < 8; condition++) {
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        uint8_t pin = condition & 4u;
        uint8_t direction = 0x10;
        f.ee[0x02ed] = condition & 1u;
        *nm_ram(&m, 0x0737) = (condition & 2u) != 0;
        *nm_ram(&m, 0x073b) = 0xff;
        memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
        avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
        avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
        avr->data[0x31] = direction;
        avr->data[0x32] = 0;
        enter_fragment(avr, 0x5968);
        _avr_push_addr(avr, 0x7000);
        unsigned budget = 3000;
        while (avr->pc != 0x7000 && budget--) {
            if (avr->pc == 0x5988 || avr->pc == 0x59a8)
                avr->data[0x30] = pin;
            step(avr);
        }
        assert(avr->pc == 0x7000);
        nm_rtc_edge(&m, &direction, &pin);
        assert(avr->data[0x31] == direction);
        assert(!memcmp(avr->data + 0x069b, (const void *)nm_ram(&m, 0x069b), 4));
        assert(!memcmp(avr->data + 0x0735, (const void *)nm_ram(&m, 0x0735), 7));
        assert(!memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 49));
    }
    avr_terminate(avr);
    free(avr);
}

static void check_adc_calibration(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    const float coefficients[] = {-20.0f, 50.0f, 80.0f, 8.5f};
    const uint16_t inputs[] = {0, 1, 124, 512, 1023};
    for (uint8_t channel = 0; channel < 2; channel++)
        for (unsigned i = 0; i < sizeof inputs / sizeof inputs[0]; i++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            memcpy(f.ee, coefficients, sizeof coefficients);
            *nm_ram(&m, 0x0677 + 2u * channel) = (uint8_t)inputs[i];
            *nm_ram(&m, 0x0678 + 2u * channel) = (uint8_t)(inputs[i] >> 8);
            memcpy(avr->data + 0x60, f.ram, sizeof f.ram);
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            avr->data[8] = channel;
            avr->data[9] = 0;
            enter_fragment(avr, 0x4732);
            unsigned budget = 4000;
            while (avr->pc != 0x4784 && budget--)
                step(avr);
            assert(avr->pc == 0x4784);
            float translated = nm_adc_calibrated(&m, channel);
            if (memcmp(avr->data + 16, &translated, sizeof translated)) {
                float expected;
                memcpy(&expected, avr->data + 16, sizeof expected);
                fprintf(stderr, "ADC %u input=%u AVR=%g C=%g\n",
                        channel, inputs[i], (double)expected, (double)translated);
            }
            assert(!memcmp(avr->data + 16, &translated, sizeof translated));
        }
    avr_terminate(avr);
    free(avr);
}

static void check_menu_lcd_stream(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t outputs = 0; outputs < 2; outputs++)
        for (uint8_t first = 0; first < (outputs ? 23 : 11); first++)
            for (uint8_t cursor = 0; cursor < 2; cursor++) {
                NMSettingsMenu menu = {first, cursor};
                uint8_t expected[32], actual[32];
                memset(actual, ' ', sizeof actual);
                if (outputs)
                    nm_output_menu_screen(&menu, expected);
                else
                    nm_settings_menu_screen(&menu, expected);
                enter_fragment(avr, 0x2282);
                _avr_push_addr(avr, 0x7000);
                avr->data[16] = 0;
                avr->data[17] = 6;
                avr->data[0x0603] = outputs ? 0x40 : 0x18;
                avr->data[0x0604] = outputs ? 0x02 : 0x0a;
                avr->data[0x0606] = first;
                avr->data[0x0607] = cursor;
                uint8_t row = 0, column = 0;
                unsigned budget = 18000;
                while (avr->pc != 0x7000 && budget--) {
                    /* Уровень до перекодировки HD44780. В оригинале
                       исполняется форматтер с чтением строк flash. */
                    if (avr->pc == 0x1e52) {
                        row = avr->data[17];
                        column = avr->data[16];
                        avr->pc = 0x2190;
                    } else if (avr->pc == 0x1ee0) {
                        if (row < 2 && column < 16)
                            actual[16u * row + column] = avr->data[16];
                        column++;
                        avr->pc = 0x2190;
                    } else if (avr->pc == 0x1e86) {
                        avr->pc = 0x2190;
                    }
                    step(avr);
                }
                assert(avr->pc == 0x7000);
                if (memcmp(actual, expected, sizeof actual)) {
                    fprintf(stderr, "LCD outputs=%u first=%u cursor=%u\n", outputs, first, cursor);
                    for (unsigned i = 0; i < sizeof actual; i++)
                        if (actual[i] != expected[i])
                            fprintf(stderr, "%u: AVR=%02x C=%02x\n", i, actual[i], expected[i]);
                    assert(0);
                }
            }
    avr_terminate(avr);
    free(avr);
}

static void check_output_and_program_editors(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    static const uint8_t keys[] = {0,1,2,3,4,5,0x80,0x81,0x82,0x83,0x84,0x85,0xff};
    static const uint16_t values[] = {0,1,2,9,10,11,99,100,101,999,1000,1001,
                                      64534,64535,65435,65525,65534,65535};
    const unsigned editor = 0x0600;
    for (uint8_t wait = 0; wait < 2; wait++)
        for (unsigned i = 0; i < sizeof values / sizeof *values; i++)
            for (unsigned j = 0; j < sizeof keys; j++) {
                uint16_t value = values[i];
                enter_fragment(avr, 0x172a);
                _avr_push_addr(avr, 0x7000);
                memset(avr->data + editor, 0, 20);
                avr->data[16] = 0;
                avr->data[17] = 6;
                avr->data[18] = keys[j];
                avr->data[editor + 2] = !wait;
                avr->data[editor + 6] = avr->data[editor + 7] = 255;
                avr->data[editor + 10] = value;
                avr->data[editor + 11] = value >> 8;
                avr->data[editor + 14] = avr->data[editor + 15] = 255;
                unsigned budget = 500;
                while (avr->pc != 0x7000 && budget--) {
                    if (avr->pc == 0x17ea)
                        avr->pc = 0x17f0; /* Рендер LCD после изменения. */
                    step(avr);
                }
                assert(avr->pc == 0x7000);
                bool done = nm_output_editor_key(wait * 12, &value, keys[j]);
                assert(done == (avr->data[16] == 1));
                assert(value == (avr->data[editor + 10] | (avr->data[editor + 11] << 8)));
            }

    for (uint8_t cursor = 0; cursor < 6; cursor++)
        for (unsigned i = 0; i < sizeof keys; i++)
            for (uint8_t input = 0; input < 4; input++) {
                NMProgramTime time = {{0,0,0,0,0,0},cursor};
                static const uint8_t sample[][6] = {
                    {0,0,0,0,0,0}, {23,59,59,31,12,99},
                    {255,255,255,255,255,255}, {9,10,11,3,4,5}
                };
                memcpy(time.field, sample[input], 6);
                memcpy(avr->data + editor + 3, time.field, 6);
                avr->data[editor + 9] = cursor;
                enter_fragment(avr, 0x2df2);
                avr->data[16] = 0;
                avr->data[17] = 6;
                avr->data[18] = keys[i];
                unsigned budget = 500;
                while (avr->pc != 0x2f76 && budget--)
                    step(avr);
                assert(avr->pc == 0x2f76);
                nm_program_time_key(&time, keys[i]);
                assert(!memcmp(avr->data + editor + 3, time.field, 6));
                assert(time.cursor == avr->data[editor + 9]);
            }
    avr_terminate(avr);
    free(avr);
}

static void check_editor_eeprom(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t row = 0; row < 24; row++) {
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        for (unsigned i = 0; i < sizeof f.ee; i++)
            f.ee[i] = (uint8_t)(91u * i + row);
        avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
        avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
        uint16_t value = 1024u * row + 313u;
        enter_fragment(avr, row < 12 ? 0x236e : 0x2378);
        _avr_push_addr(avr, 0x7000);
        avr->data[18] = row % 12u;
        unsigned budget = 15000;
        while (avr->pc != 0x7000 && budget--)
            step(avr);
        assert(avr->pc == 0x7000);
        assert(nm_output_duration(&m, row) == (avr->data[16] | (avr->data[17] << 8)));

        enter_fragment(avr, row < 12 ? 0x2390 : 0x23b0);
        avr->data[18] = row % 12u;
        avr->data[20] = value;
        avr->data[21] = value >> 8;
        _avr_push_addr(avr, 0x7000);
        budget = 30000;
        while (avr->pc != 0x7000 && budget--)
            step(avr);
        assert(avr->pc == 0x7000);
        enter_fragment(avr, 0x23fa);
        _avr_push_addr(avr, 0x7000);
        avr->data[16] = 0x47;
        avr->data[17] = 7;
        budget = 55000;
        while (avr->pc != 0x7000 && budget--)
            step(avr);
        assert(avr->pc == 0x7000);
        nm_output_save_duration(&m, row, value);
        uint8_t original[1024];
        ee.ee = original;
        avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
        assert(!memcmp(f.ee, original, sizeof original));
        assert(!memcmp(avr->data + 0x0747, (const void *)nm_ram(&m, 0x0747), 36));
    }

    for (uint8_t index = 0; index < 32; index++)
        for (uint8_t stop = 0; stop < 2; stop++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            for (unsigned i = 0; i < sizeof f.ee; i++)
                f.ee[i] = (uint8_t)(67u * i + (stop ? 0x17u : 0xaau));
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            NMProgramTime time = {{23, 57, 58, 30, 11, 42}, 5};
            const unsigned editor = 0x0600;
            memcpy(avr->data + editor + 3, time.field, 6);
            avr->data[0x06b4] = index;
            /* X содержит адрес рабочего окна из AVR-редактора. */
            enter_fragment(avr, stop ? 0x31a4 : 0x3140);
            avr->data[0x0707] = 0;
            avr->data[0x0708] = 6;
            unsigned target = stop ? 0x31e0 : 0x3174;
            unsigned budget = 75000;
            while (avr->pc != target && budget--)
                step(avr);
            if (avr->pc != target) fprintf(stderr, "stage4 %u %u pc %04x target %04x\n", index, stop, avr->pc, target);
            assert(avr->pc == target);
            nm_program_time_save(&m, index, stop, &time);
            uint8_t original[1024];
            ee.ee = original;
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
            if (memcmp(f.ee, original, sizeof original)) {
                for (unsigned i = 0; i < sizeof original; i++)
                    if (f.ee[i] != original[i])
                        fprintf(stderr, "program %u stop %u address %04x C=%02x AVR=%02x\n",
                                index, stop, i, f.ee[i], original[i]);
                assert(0);
            }
            NMProgramTime read_back;
            nm_program_time_load(&m, index, stop, &read_back);
            assert(!memcmp(time.field, read_back.field, sizeof time.field));
        }
    static const uint8_t keys[] = {1, 4, 0x81, 0x84, 0xff};
    static const uint8_t channels[] = {0, 1, 10, 11, 12, 126, 127};
    for (uint8_t task = 0; task < 2; task++)
        for (uint8_t high = 0; high < 2; high++)
            for (unsigned i = 0; i < sizeof channels; i++)
                for (unsigned j = 0; j < sizeof keys; j++) {
                    Fixture f = {0};
                    const uint8_t index = 31;
                    uint16_t base = 0x4c + 21u * index;
                    f.ee[base] = (uint8_t)(channels[i] * 31u);
                    f.ee[base + 12u] = channels[i] | (high << 7);
                    NM8036 m = fixture_device(&f);
                    avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                    enter_fragment(avr, task ? 0x3258 : 0x3228);
                    avr->data[4] = keys[j] & 15u;
                    avr->data[24] = base;
                    avr->data[25] = base >> 8;
                    unsigned budget = 25000;
                    while (avr->pc != 0x3308 && budget--)
                        step(avr);
                    assert(avr->pc == 0x3308);
                    if (task)
                        nm_program_kind_key(&m, index, keys[j]);
                    else
                        nm_program_output_key(&m, index, keys[j]);
                    uint8_t original[1024];
                    ee.ee = original;
                    avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
                    assert(!memcmp(f.ee, original, sizeof original));
                }
    for (uint8_t index = 0; index < 32; index++) {
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        uint16_t base = 0x4c + 21u * index;
        f.ee[base + 3] = index * 7u;
        avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
        avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
        enter_fragment(avr, 0x30a4);
        avr->data[0x06b4] = index;
        unsigned budget = 30000;
        while (avr->pc != 0x30b2 && budget--)
            step(avr);
        assert(avr->pc == 0x30b2);
        nm_program_toggle(&m, index);
        uint8_t original[1024];
        ee.ee = original;
        avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
        assert(!memcmp(f.ee, original, sizeof original));
    }
    avr_terminate(avr);
    free(avr);
}

static void check_threshold_editor(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    const uint8_t keys[] = {0,1,2,3,4,5,0x81,0x82,0x83,0x84,0xff};
    const int16_t limits[] = {-32768,-5510,-5500,-1,0,1,1023,12500,32767};
    uint8_t eeprom[1024] = {0};
    for (uint8_t analog = 0; analog < 2; analog++)
        for (uint8_t selected = 0; selected < 2; selected++)
            for (unsigned k = 0; k < sizeof keys; k++)
                for (unsigned v = 0; v < sizeof limits / sizeof *limits; v++) {
                    NMThresholds editor = {{limits[v], limits[v]}, selected, analog};
                    eeprom[0x51] = analog ? 0x20 : 0;
                    avr_eeprom_desc_t ee = {eeprom, 0, sizeof eeprom};
                    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                    enter_fragment(avr, 0x352a);
                    avr->data[4] = keys[k] & 15u;
                    avr->data[12] = keys[k];
                    avr->data[24] = 0x4c;
                    avr->data[25] = 0;
                    avr->data[26] = 0;
                    avr->data[27] = 6;
                    avr->data[0x607] = selected;
                    for (uint8_t j = 0; j < 2; j++) {
                        avr->data[0x602 + 2*j] = (uint8_t)limits[v];
                        avr->data[0x603 + 2*j] = (uint16_t)limits[v] >> 8;
                    }
                    unsigned budget = 2000;
                    while (avr->pc != 0x35fa && budget--)
                        step(avr);
                    assert(avr->pc == 0x35fa);
                    nm_program_threshold_key(&editor, keys[k]);
                    assert(editor.selected == avr->data[0x607]);
                    for (uint8_t j = 0; j < 2; j++) {
                        int16_t original = (int16_t)(avr->data[0x602 + 2*j] |
                            ((uint16_t)avr->data[0x603 + 2*j] << 8));
                        if (editor.value[j] != original)
                            fprintf(stderr, "analog=%u selected=%u key=%02x initial=%d field=%u C=%d AVR=%d\n",
                                    analog, selected, keys[k], limits[v], j, editor.value[j], original);
                        assert(editor.value[j] == original);
                    }
                }
    avr_terminate(avr);
    free(avr);
}

static void check_program_conditions(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    const uint8_t keys[] = {0, 1, 2, 3, 4, 5, 0x81, 0x84, 0xff};
    for (uint8_t task = 0; task < 7; task++)
        for (uint8_t seed = 0; seed < 8; seed++)
            for (unsigned k = 0; k < sizeof keys; k++) {
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                const uint8_t index = seed * 4;
                const uint16_t base = 0x4cu + 21u * index;
                uint8_t key = keys[k];
                f.ee[base + 1] = (uint8_t)(seed * 35u);
                f.ee[base + 5] = (seed & 1) ? 0xab : 0x4d;
                f.ee[base + 6] = seed;
                f.ee[base + 11] = seed * 5;
                f.ee[base + 12] = seed | 128;
                for (uint8_t j = 0; j < 4; j++)
                    f.ee[base + 17 + j] = 0x35u + j;
                if (seed & 2)
                    f.ee[0x2f0 + 8u * (seed * 3u)] = 0x28;
                avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
                avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
                static const unsigned entry[] = {0x3270,0x32d4,0x3708,0x3780,
                                                  0x3850,0x34bc,0x3742};
                static const unsigned end[] = {0x3308,0x3308,0x3734,0x37aa,
                                                0x389a,0x34e2,0x3758};
                if ((task == 2 || task == 4 || task == 6) && key != 0)
                    continue;
                if (task <= 1 && (key & 15u) != 1 && (key & 15u) != 4)
                    continue;
                if (task == 3 && key != 2 && key != 3)
                    continue;
                if (task == 5 && key != 2 && key != 3)
                    continue;
                enter_fragment(avr, entry[task]);
                avr->data[4] = key & 15u;
                avr->data[12] = key;
                avr->data[24] = base;
                avr->data[25] = base >> 8;
                avr->data[26] = 0;
                avr->data[27] = 6;
                avr->data[0x06b4] = index;
                avr->data[0x06b8] = seed;
                *nm_ram(&m, 0x06b8) = seed;
                avr->data[0x0602] = 0x56;
                avr->data[0x0603] = 0xff;
                avr->data[0x0604] = 0x94;
                avr->data[0x0605] = 0x01;
                unsigned budget = 350000;
                while (avr->pc != end[task] && budget--)
                    step(avr);
                assert(avr->pc == end[task]);
                NMThresholds edit = {{-170,404},0,false};
                if (task == 0) nm_program_sensor_key(&m, index, key);
                else if (task == 1) nm_program_source_key(&m, index, key);
                else if (task == 2) nm_program_thresholds_save(&m, index, &edit);
                else if (task == 3) (void)nm_program_period_key(&m, index, key);
                else if (task == 4) nm_program_period_item(&m, index, 2, key);
                else if (task == 5) nm_program_reference_key(&m, index, key);
                else nm_program_logic_toggle(&m, index);
                uint8_t original[1024];
                ee.ee = original;
                avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
                if (memcmp(original, f.ee, sizeof original))
                    for (unsigned j = 0; j < sizeof original; j++)
                        if (original[j] != f.ee[j])
                            fprintf(stderr, "task=%u seed=%u key=%02x EEPROM[%04x] C=%02x AVR=%02x\n",
                                    task,seed,key,j,f.ee[j],original[j]);
                assert(!memcmp(original, f.ee, sizeof original));
                if (task == 3 || task == 4)
                    assert(avr->data[0x06b8] == *nm_ram(&m, 0x06b8));
            }
    avr_terminate(avr);
    free(avr);
}

/* 0x137A вызывает 0x13CE. Низкий PD7 оставляет ветвь 0x137C.
 * Входим прямо в цикл и исполняем оригинальный слот чтения. */
static void check_dallas_stuck_original(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    enter_fragment(avr, 0x137a);
    unsigned reads = 0;
    unsigned budget = 60000;
    while (reads < 32 && budget--) {
        if (avr->pc == 0x137e)
            assert(0);
        if (avr->pc == 0x0d0e) {
            avr->data[0x30] = 0;
            reads++;
        }
        step(avr);
    }
    assert(reads == 32);
    avr_terminate(avr);
    free(avr);
}

typedef struct {
    uint8_t scratch[9], reads, hold, resets, power;
    bool line, parasite;
} BoundedProbe;

static bool bounded_reset(void *context)
{
    BoundedProbe *probe = context;
    probe->resets++;
    return probe->line;
}

static void bounded_write(void *context, bool bit)
{
    (void)context;
    (void)bit;
}

static bool bounded_line(void *context)
{
    return ((BoundedProbe *)context)->line;
}

static bool bounded_read(void *context)
{
    BoundedProbe *probe = context;
    unsigned i = probe->reads++;
    if (!i)
        return !probe->parasite;
    if (i <= probe->hold)
        return false;
    if (i == probe->hold + 1u)
        return true;
    i -= probe->hold + 2u;
    assert(i < 72);
    return (probe->scratch[i / 8] & (1u << (i & 7u))) != 0;
}

static void bounded_power(void *context, bool active)
{
    BoundedProbe *probe = context;
    assert(active == (probe->power == 0));
    probe->power++;
}

static void bounded_delay(void *context)
{
    assert(((BoundedProbe *)context)->power == 1);
}

static void check_dallas_bounded(void)
{
    for (uint8_t config = 0; config < 8; config++) {
        BoundedProbe probe = {.scratch = {0x90,0x01,0x4b,0x46,0x7f,0xff,0x0c,0x10},
                              .hold = config & 4 ? 10 : 1, .line = true,
                              .parasite = (config & 1) != 0};
        probe.scratch[8] = nm_dallas_crc(probe.scratch, 8) ^ !!(config & 2);
        const NMOneWire bus = {.context = &probe, .reset = bounded_reset,
            .read_bit = bounded_read, .write_bit = bounded_write, .line_high = bounded_line,
            .strong_pullup = bounded_power, .conversion_delay = bounded_delay};
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        *nm_ram(&m, 0x0681) = 0x28;
        int16_t sample = 123;
        bool success = nm_dallas_sample_selected_bounded(&m, &bus, 5, &sample);
        assert(success == !(config & 6));
        assert(sample == (success ? 2500 : 123));
        assert(probe.power == ((config & 1) ? 2 : 0));
        probe.line = false;
        uint8_t resets = probe.resets;
        assert(!nm_dallas_sample_selected_bounded(&m, &bus, 5, &sample));
        assert(probe.resets == resets);
    }
}

/* Сквозной проход ручного режима: порт, SRAM курсора, выход
 * и возврат к автоматической обработке импульсов. */
static void check_manual_outputs(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    *m.porta = *m.portc = *m.portd = 0xff;
    avr->data[0x3b] = avr->data[0x35] = avr->data[0x32] = 0xff;
    enter_fragment(avr, 0x4f2e);
    unsigned budget = 25000;
    while (avr->pc != 0x4f50 && budget--) {
        if (avr->pc == 0x1e86)
            avr->pc = 0x2190;
        step(avr);
    }
    assert(avr->pc == 0x4f50);
    nm_manual_outputs_open(&m);
    assert(avr->data[0x076b] == 1);
    static const uint8_t keys[] = {0,4,0x84,0,4,4,4,4,4,4,4,4,4,4,0,1,0x81,0,5};
    for (unsigned i = 0; i < sizeof keys; i++) {
        enter_fragment(avr, 0x4f50);
        avr->data[0x0739] = keys[i];
        uint8_t actual[32], expected[32], row = 0, column = 0;
        memset(actual, ' ', sizeof actual);
        budget = 40000;
        while (avr->pc != 0x5006 && avr->pc != 0x5008 && budget--) {
            if (avr->pc == 0x1e52) {
                row = avr->data[17];
                column = avr->data[16];
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1ee0) {
                if (row < 2 && column < 16)
                    actual[16u * row + column] = avr->data[16];
                column++;
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1e86)
                avr->pc = 0x2190;
            step(avr);
        }
        assert(avr->pc == 0x5006 || avr->pc == 0x5008);
        assert(nm_manual_outputs_key(&m, keys[i]) == (avr->pc == 0x5008));
        if (keys[i] != 5) {
            nm_manual_outputs_screen(&m, expected);
            if (memcmp(actual, expected, sizeof actual)) {
                for (unsigned j = 0; j < sizeof actual; j++)
                    if (actual[j] != expected[j])
                        fprintf(stderr, "manual LCD step %u col %u AVR=%02x C=%02x\n",
                                i,j,actual[j],expected[j]);
                assert(0);
            }
        }
        assert(avr->data[0x0741] == *nm_ram(&m, 0x0741));
        assert(avr->data[0x0742] == *nm_ram(&m, 0x0742));
        assert(avr->data[0x076b] == *nm_ram(&m, 0x076b));
        assert(avr->data[0x3b] == *m.porta);
        assert(avr->data[0x35] == *m.portc);
        assert(avr->data[0x32] == *m.portd);
        if (keys[i] != 5) {
            uint8_t ports[] = {*m.porta, *m.portc, *m.portd};
            nm_outputs_tick(&m);
            assert(ports[0] == *m.porta && ports[1] == *m.portc && ports[2] == *m.portd);
        }
    }
    avr_terminate(avr);
    free(avr);
}

static void check_threshold_adc_scale(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    const int16_t raw[] = {0,1,192,512,1023};
    for (uint8_t channel = 0; channel < 2; channel++)
        for (unsigned i = 0; i < sizeof raw / sizeof *raw; i++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            const uint32_t range[] = {UINT32_C(0xc1480000), UINT32_C(0x42c88000)};
            for (uint8_t j = 0; j < 8; j++)
                f.ee[channel * 8 + j] = (uint8_t)(range[j / 4] >> (8u * (j & 3u)));
            f.ee[0x51] = 0x20;
            f.ee[0x57] = channel;
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            enter_fragment(avr, 0x363c);
            avr->data[21] = 0;
            avr->data[0x06b4] = 0;
            avr->data[22] = raw[i];
            avr->data[23] = (uint16_t)raw[i] >> 8;
            unsigned budget = 12000;
            while (avr->pc != 0x36c2 && budget--)
                step(avr);
            if (avr->pc != 0x36c2) fprintf(stderr, "ADC %u count=%d PC=%04x EEPROM=%02x%02x\n", channel, raw[i], avr->pc, avr->data[0x3f], avr->data[0x3e]);
            assert(avr->pc == 0x36c2);
            float value = nm_adc_scale(&m, channel, raw[i]);
            uint32_t bits;
            memcpy(&bits, &value, sizeof bits);
            for (uint8_t j = 0; j < 4; j++)
                assert((uint8_t)(bits >> (8u * j)) == avr->data[16 + j]);
        }
    avr_terminate(avr);
    free(avr);
}

/* В отличие от прямой подстановки r16–r19, здесь калибровка
 * читается из EEPROM штатным кодом 0x363C–0x36C1. */
static void check_threshold_adc_inputs(void)
{
    static const uint32_t pairs[][2] = {
        {0, 0x3f800000}, {0x80000000, 0x80000000},
        {0xbf800000, 0x3f800000}, {0x7fc00000, 0x3f800000},
        {0, 0x7f800000}, {0, 0xff800000}
    };
    static const int16_t counts[] = {0, 1, 512, 1023};
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (unsigned p = 0; p < sizeof pairs / sizeof *pairs; ++p) {
        for (unsigned n = 0; n < sizeof counts / sizeof *counts; ++n) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            for (unsigned b = 0; b < 8; ++b)
                f.ee[b] = (uint8_t)(pairs[p][b / 4] >> (8u * (b % 4)));
            f.ee[0x51] = 0x20;
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            enter_fragment(avr, 0x363c);
            avr->data[21] = 0;
            avr->data[22] = (uint8_t)counts[n];
            avr->data[23] = (uint16_t)counts[n] >> 8;
            unsigned budget = 16000;
            while (avr->pc != 0x36c2 && budget--)
                step(avr);
            assert(avr->pc == 0x36c2);
            uint32_t original = 0, translated;
            for (unsigned b = 0; b < 4; ++b)
                original |= (uint32_t)avr->data[16 + b] << (8u*b);
            float value = nm_adc_scale(&m, 0, counts[n]);
            memcpy(&translated, &value, sizeof translated);
            if (p == 0 || p == 2)
                assert(original == translated);
            printf("ADC EEPROM %08x %08x raw=%d binary32 AVR=%08x host=%08x\n",
                   (unsigned)pairs[p][0], (unsigned)pairs[p][1], counts[n],
                   (unsigned)original, (unsigned)translated);
        }
    }
    avr_terminate(avr);
    free(avr);
}

static void check_program_control_confirm(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (uint8_t kind = 0; kind < 4; kind++)
        for (uint8_t flags = 0; flags < 8; flags++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            const uint8_t index = flags * 4u;
            uint16_t base = 0x4c + 21u * index;
            f.ee[base] = (kind << 6) | 23;
            f.ee[base + 5u] = (flags << 5) | 17;
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            enter_fragment(avr, 0x33d8);
            avr->data[0x06b4] = index;
            avr->data[12] = 0;
            avr->data[21] = 0;
            unsigned budget = 15000;
            while (avr->pc != 0x3406 && budget--) {
                if (avr->pc == 0x1e86 || avr->pc == 0x1e52 || avr->pc == 0x1ee0)
                    avr->pc = 0x2190;
                step(avr);
            }
            assert(avr->pc == 0x3406);
            assert(nm_program_control_confirm(&m,index) == avr->data[0x06b6]);
            uint8_t original[1024];
            ee.ee = original;
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
            assert(!memcmp(original, f.ee, sizeof original));
        }
    avr_terminate(avr);
    free(avr);
}

static void check_dallas_dialog_match(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    static const uint8_t cache[3][8] = {{0x28,11,1},{0x28,22,2},{0x28,33,3}};
    for (uint8_t slot = 0; slot < 32; slot += 7)
        for (uint8_t pick = 0; pick < 4; pick++) {
            Fixture f = {0};
            NM8036 m = fixture_device(&f);
            if (pick < 3)
                memcpy(f.ee + 0x02f0u + 8u * slot, cache[pick], 8);
            avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            enter_fragment(avr, 0x51ce);
            avr->data[24] = 0;
            avr->data[0x0731] = 0;
            avr->data[0x0732] = 6;
            avr->data[0x0743] = slot;
            avr->data[0x0744] = 3;
            avr->data[0x0680] = 1;
            memcpy(avr->data + 0x0600, cache, sizeof cache);
            unsigned budget = 12000;
            while (avr->pc != 0x5236 && budget--) {
                if (avr->pc == 0x5214) {
                    if (avr->data[25])
                        break;
                    /* Остальные операции этой ветви рисуют LCD. */
                    avr->pc = 0x51cc;
                }
                step(avr);
            }
            assert(budget);
            uint8_t result = avr->pc == 0x5214 ? avr->data[0x0680] : 0xff;
            assert(nm_dallas_dialog_match(&m, slot, cache, 3) == result);
            assert(result == (pick < 3 ? pick : 0xff));
        }
    avr_terminate(avr);
    free(avr);
}

/* Одна запись EEPROM и один набор SRAM сохраняются всю
 * последовательность. Границы обработчиков задаёт тест, LCD
 * редактора программ остаётся отдельной задачей. */
static void check_program_edit_sequence(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    f.ee[0x51] = 0x20;
    f.ee[0x59] = 100;
    f.ee[0x5b] = 200;
    avr_eeprom_desc_t ee = {f.ee,0,sizeof f.ee};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
    enum { CONFIRM, EDIT, CANCEL, SAVE, LOGIC, PERIOD, ITEM };
    static const struct { unsigned entry, end; uint8_t action, key; } steps[] = {
        {0x33d8,0x3406,CONFIRM,0}, {0x352a,0x35fa,EDIT,3},
        {0x3708,0x3128,CANCEL,5}, {0x33d8,0x3406,CONFIRM,0},
        {0x352a,0x35fa,EDIT,3}, {0x352a,0x35fa,EDIT,1},
        {0x352a,0x35fa,EDIT,0x82}, {0x3708,0x3734,SAVE,0},
        {0x3742,0x3758,LOGIC,1}, {0x3780,0x37aa,PERIOD,3},
        {0x3850,0x389a,ITEM,0},
    };
    NMThresholds editor;
    uint8_t period = 0;
    for (unsigned i = 0; i < sizeof steps / sizeof *steps; i++) {
        uint8_t action = steps[i].action;
        uint8_t key = steps[i].key;
        enter_fragment(avr, steps[i].entry);
        avr->data[4] = key & 15u;
        avr->data[12] = key;
        avr->data[21] = 0;
        avr->data[24] = 0x4c;
        avr->data[25] = 0;
        avr->data[26] = 0;
        avr->data[27] = 6;
        unsigned budget = 30000;
        while (avr->pc != steps[i].end && budget--) {
            if (avr->pc == 0x1e86 || avr->pc == 0x1e52 || avr->pc == 0x1ee0)
                avr->pc = 0x2190;
            step(avr);
        }
        assert(avr->pc == steps[i].end);
        if (action == CONFIRM) {
            assert(nm_program_control_confirm(&m, 0) == 7);
            assert(avr->data[0x06b6] == 7);
            nm_program_thresholds_load(&m, 0, &editor);
            /* Контекст окна значений подаётся на границе LCD-обвязки. */
            for (uint8_t j = 0; j < 2; j++) {
                avr->data[0x0602 + 2*j] = (uint8_t)editor.value[j];
                avr->data[0x0603 + 2*j] = (uint16_t)editor.value[j] >> 8;
            }
            avr->data[0x0607] = editor.selected;
        } else if (action == EDIT) {
            nm_program_threshold_key(&editor, key);
            assert(avr->data[0x0607] == editor.selected);
            for (uint8_t j = 0; j < 2; j++) {
                assert(avr->data[0x0602 + 2*j] == (uint8_t)editor.value[j]);
                assert(avr->data[0x0603 + 2*j] == (uint16_t)editor.value[j] >> 8);
            }
        } else if (action == SAVE) {
            nm_program_thresholds_save(&m, 0, &editor);
        } else if (action == LOGIC) {
            nm_program_logic_toggle(&m, 0);
        } else if (action == PERIOD) {
            period = nm_program_period_key(&m, 0, key);
        } else if (action == ITEM) {
            nm_program_period_item(&m, 0, period, key);
        }
        uint8_t eeprom[1024];
        ee.ee = eeprom;
        avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
        assert(!memcmp(eeprom, f.ee, sizeof eeprom));
    }
    avr_terminate(avr);
    free(avr);
}

/* Оригинальный диалог целиком от 0x5052 при отсутствующих датчиках.
 * Подменяется лишь уровень PD7 при выборке импульса присутствия
 * и транспорт команд/данных LCD. Штатная задержка выполняется. */
static void check_dallas_dialog_empty(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    uint8_t initial[1024], result[1024];
    for (unsigned i = 0; i < sizeof initial; ++i)
        initial[i] = (uint8_t)i;
    avr_eeprom_desc_t ee = {initial, 0, sizeof initial};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
    enter_fragment(avr, 0x5052);
    avr->data[16] = 1; /* Вызов 0x4A6C при открытии. */
    avr->data[17] = 0;
    _avr_push_addr(avr, 0x7000);
    unsigned returns = 0;
    unsigned presence_slots = 0;
    bool no_devices = false;
    uint8_t dialog[32];
    memset(dialog, ' ', sizeof dialog);
    uint8_t col = 0, row = 0;
    while (avr->cycle < 6000000) {
        if (avr->pc == 0x7000) {
            if (++returns == 2)
                break;
            assert(avr->data[16] == 0 && avr->data[0x0738] == 1);
            enter_fragment(avr, 0x5052);
            avr->data[16] = 0; /* Вызов 0x49F6 на очередном проходе. */
            avr->data[0x0739] = 0xff;
            _avr_push_addr(avr, 0x7000);
        }
        no_devices |= avr->pc == 0x50d4;
        switch (avr->pc) {
        case 0x0cd0:
            avr->data[0x30] = 0x80;
            presence_slots++;
            break;
        case 0x1e2a:
            avr->data[16] = 0;
            avr->pc = 0x2190;
            break;
        case 0x1e86:
            memset(dialog, ' ', sizeof dialog);
            col = row = 0;
            avr->pc = 0x2190;
            break;
        case 0x1e52:
            col = avr->data[16];
            row = avr->data[17];
            avr->pc = 0x2190;
            break;
        case 0x1ee0:
            if (row < 2 && col < 16)
                dialog[row*16u + col++] = avr->data[16];
            avr->pc = 0x2190;
            break;
        }
        step(avr);
    }
    if (avr->pc != 0x7000 || !presence_slots || !no_devices)
        fprintf(stderr, "Dallas empty: PC=%04x presence=%u no_devices=%u count=%u\n",
                avr->pc, presence_slots, (unsigned)no_devices, avr->data[0x0744]);
    assert(returns == 2 && presence_slots != 0 && no_devices);
    assert(avr->data[0x0744] == 0 && avr->data[0x0738] == 0 && avr->data[16] == 1);
    uint8_t expected[32];
    memset(expected, ' ', sizeof expected);
    const uint8_t *top = flash + 0x09be;
    const uint8_t *bottom = flash + 0x09cb;
    memcpy(expected, top, strlen((const char *)top));
    memcpy(expected + 16, bottom, strlen((const char *)bottom));
    assert(memcmp(dialog, expected, sizeof dialog) == 0);
    ee.ee = result;
    avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
    assert(memcmp(initial, result, sizeof initial) == 0);
    printf("Dallas 0x5052: empty bus, %u presence slots, LCD, EEPROM unchanged, automatic return\n", presence_slots);
    avr_terminate(avr);
    free(avr);
}

typedef struct {
    uint8_t ddram[128], cgram[64];
    uint8_t address, high, control;
    bool glyph, half;
    unsigned bytes, reads;
} DisplayBus;

static void display_command(DisplayBus *lcd, uint8_t command)
{
    if (command & 0xc0) {
        lcd->glyph = !(command & 0x80);
        lcd->address = command & (lcd->glyph ? 63 : 127);
    } else if (command == 1) {
        memset(lcd->ddram, ' ', sizeof lcd->ddram);
        lcd->address = 0;
        lcd->glyph = false;
    } else if ((command & 0xf8) == 8) {
        lcd->control = command;
    }
}

static uint8_t *display_data(DisplayBus *lcd)
{
    return lcd->glyph ? lcd->cgram + lcd->address : lcd->ddram + lcd->address;
}

static void display_increment(DisplayBus *lcd)
{
    lcd->address = (lcd->address + 1) & (lcd->glyph ? 63 : 127);
}

static void run_display_original(avr_t *avr, DisplayBus *lcd)
{
    _avr_push_addr(avr, 0x7000);
    unsigned budget = 50000;
    while (avr->pc != 0x7000 && budget--) {
        uint8_t before = avr->data[0x38];
        if (avr->pc == 0x1e3c || avr->pc == 0x1e44) {
            assert((before & 3) == 3 && !(avr->data[0x37] & 0xf0));
            bool data = before & 4;
            uint8_t value = data ? *display_data(lcd) : lcd->address;
            avr->data[0x36] = avr->pc == 0x1e3c ? value & 0xf0 : value << 4;
            if (avr->pc == 0x1e44 && data) {
                display_increment(lcd);
                ++lcd->reads;
            }
        }
        step(avr);
        if (!(before & 1) || (avr->data[0x38] & 1) || (before & 2))
            continue;
        assert((avr->data[0x37] & 0xf0) == 0xf0);
        if (!lcd->half) {
            lcd->high = before & 0xf0;
        } else {
            uint8_t byte = lcd->high | (before >> 4);
            if (before & 4) {
                *display_data(lcd) = byte;
                display_increment(lcd);
            } else {
                display_command(lcd, byte);
            }
            ++lcd->bytes;
        }
        lcd->half = !lcd->half;
    }
    assert(avr->pc == 0x7000 && !lcd->half);
}

/* Исполняются оба оригинальных алгоритма и драйвер PORTB.
 * Модель подаёт данные в PINB на двух выборках каждого чтения. */
static void check_display_snapshot(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    DisplayBus lcd = {.control = 0x0c};
    for (unsigned i = 0; i < 64; ++i)
        lcd.cgram[i] = (i ^ (i >> 3)) & 31;
    for (unsigned i = 0; i < 128; ++i)
        lcd.ddram[i] = (i & 1) ? (i >> 1) & 7 : i + 32;
    DisplayBus expected = lcd;
    enter_fragment(avr, 0x1f26);
    run_display_original(avr, &lcd);
    uint16_t snapshot = avr->data[16] | ((uint16_t)avr->data[17] << 8);
    assert(snapshot >= 0x60 && snapshot + 96 <= 0x85f);
    assert(lcd.reads == 96 && lcd.bytes == 3 && !lcd.glyph && lcd.address == 0x50);
    assert(!memcmp(avr->data + snapshot, expected.cgram, 64));
    assert(!memcmp(avr->data + snapshot + 64, expected.ddram, 16));
    assert(!memcmp(avr->data + snapshot + 80, expected.ddram + 64, 16));
    memset(lcd.cgram, 0, sizeof lcd.cgram);
    memset(lcd.ddram, ' ', sizeof lcd.ddram);
    lcd.control = 0x0f;
    enter_fragment(avr, 0x1f4e);
    avr->data[16] = snapshot;
    avr->data[17] = snapshot >> 8;
    run_display_original(avr, &lcd);
    assert(lcd.bytes == 102 && !lcd.glyph && lcd.address == 0x50);
    assert(lcd.control == 0x0f);
    assert(!memcmp(lcd.cgram, expected.cgram, 64));
    assert(!memcmp(lcd.ddram, expected.ddram, 16));
    assert(!memcmp(lcd.ddram + 64, expected.ddram + 64, 16));
    printf("LCD 0x1F26/0x1F4E: %u data reads, %u writes, cursor=%02x, control=%02x\n",
           lcd.reads, lcd.bytes, lcd.address, lcd.control);
    avr_terminate(avr);
    free(avr);
}

/* Проверяет C-диалог без MENU на AVR, включая сообщение до
 * возврата в список. Уровень PD7 высокий, LCD всегда готов. */
static void check_dallas_dialog_empty_c(const char *path)
{
    elf_firmware_t firmware = {0};
    assert(elf_read_firmware(path, &firmware) == 0);
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_load_firmware(avr, &firmware);
    uint8_t initial[1024], result[1024];
    memset(initial, 0xff, sizeof initial);
    avr_eeprom_desc_t ee = {initial, 0, sizeof initial};
    avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
    DisplayBus lcd = {0};
    uint8_t top[16], bottom[16];
    memset(top, ' ', sizeof top);
    memset(bottom, ' ', sizeof bottom);
    const uint8_t *labels[] = {flash + 0x09be, flash + 0x09cb};
    uint8_t *rows[] = {top, bottom};
    for (unsigned row = 0; row < 2; ++row)
        for (unsigned i = 0; labels[row][i]; ++i) {
            uint8_t byte = labels[row][i];
            rows[row][i] = byte < 0xa8 ? byte : flash[0x1bf + byte - 0xa8];
        }
    bool found_screen = false, opened = false;
    uint64_t opened_at = 0;
    uint16_t minimum_sp = 0x65f;
    while (avr->data[0x850] != 0xa5 && avr->cycle < 6000000) {
        uint8_t before = avr->data[0x38];
        avr->data[0x36] = 0;
        avr->data[0x30] |= 0x80;
        step(avr);
        uint16_t sp = avr->data[0x5d] | (uint16_t)avr->data[0x5e] << 8;
        if (sp >= 0x60 && sp < minimum_sp)
            minimum_sp = sp;

        if (avr->data[0x850] == 0x41 && !opened) {
            opened = true;
            opened_at = avr->cycle;
            assert(avr->data[0x851] == 1 && avr->data[0x852] == 0 && avr->data[0x853] == 0);
        }
        if (!(before & 1) || (avr->data[0x38] & 1) || (before & 2))
            continue;
        assert((avr->data[0x37] & 0xf0) == 0xf0);
        if (!lcd.half) {
            lcd.high = before & 0xf0;
        } else {
            uint8_t byte = lcd.high | (before >> 4);
            if (before & 4) {
                *display_data(&lcd) = byte;
                display_increment(&lcd);
            } else {
                display_command(&lcd, byte);
            }
            found_screen |= opened && !memcmp(lcd.ddram, top, 16) &&
                            !memcmp(lcd.ddram + 64, bottom, 16);
        }
        lcd.half = !lcd.half;
    }
    assert(avr->data[0x850] == 0xa5 && opened && found_screen);
    assert(avr->data[0x854] == 0 && avr->data[0x855] == 0);
    printf("Dallas fixture minimum SP 0x%04x, peak from 0x065f = %u bytes\n",
           minimum_sp, 0x65fu - minimum_sp);
    assert(avr->cycle - opened_at >= 1999997);
    ee.ee = result;
    avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
    assert(!memcmp(initial, result, sizeof initial));
    printf("Dallas C on AVR: LCD bytes match Flash templates, EEPROM unchanged, bus ownership released after %lu cycles\n",
           (unsigned long)(avr->cycle - opened_at));
    avr_terminate(avr);
    free(avr);
}

/* Все нажатия проходят через 0x301A. Состояние редактора и
 * EEPROM сохраняются между вызовами. Перехват только драйвера LCD
 * даёт оригинальному AVR выполнять форматтер, malloc и диспетчер. */
static void check_program_dispatch(void)
{
    static const uint8_t sequences[][48] = {
        {4,1,0,0,1,3,1,5,0,0,0,0,1,3,1,3,1,3,1,0,1,3,0,1,0,3,1,0,5,5,0xfe},
        {0,0,0,0,0,0,1,3,1,2,5,0,0,0,0,0,1,0,3,1,0,1,0,2,0,5,0xfe},
        {0,0x85,1,4,5,0,0,0,0,0,3,0,1,0,3,0,5,5,0xfe},
        {0,0,3,0,1,0,0,1,0,3,0,1,5,0,3,1,0,5,5,0xfe},
        {0,0,0xff,0x83,0xff,3,0xff,3,0xff,3,0xff,3,0xff,0,
         0xff,0x82,0xff,2,0xff,2,0xff,2,0xff,2,0xff,0,
         0xff,3,0xff,3,0xff,3,0xff,5,5,0xfe},
        {0,0,0,0,0,0,0xff,1,0xff,3,0xff,1,2,0xff,5,5,0xfe},
        {0,0,0,0,0,0xff,1,3,0x83,0xff,1,0x83,0xff,5,5,0xfe},
        {0,0,0,0,0,0,2,3,0x83,0xff,5,0,0,0,0,0,0,2,0,0,5,5,0xfe},
        {0,0,0,0,0,0,3,2,0xff,0,0,1,1,1,4,5,5,0xfe},
        {1,0xff,0,4,1,3,0xff,5,0xfe},
        {1,0xff,0,4,1,3,0xff,5,0xfe},
        {1,0xff,0,4,1,3,0xff,5,0xfe},
    };
    unsigned visited = 0, total = 0, screens = 0, calendars = 0, controls = 0, thresholds = 0, comparisons = 0, references = 0, periods = 0, baseline = 0;
    for (uint8_t seq = 0; seq < sizeof sequences / sizeof *sequences; seq++) {
        avr_t *avr = avr_make_mcu_by_name("atmega32");
        assert(avr && avr_init(avr) == 0);
        avr_loadcode(avr, flash, sizeof flash, 0);
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        f.ee[0x4f] = 0x80;
        f.ee[0x50] = 0x11;
        f.ee[0x51] = (seq == 1 || seq == 6) ? 0x20 : 0;
        if (seq >= 7)
            f.ee[0x52] = 0x20;
        f.ee[0x55] = f.ee[0x56] = 1;
        f.ee[0x59] = 100;
        f.ee[0x5b] = 200;
        static const uint8_t calibration[] = {0,0,0xa0,0xc1,0,0,0xfa,0x42};
        memcpy(f.ee, calibration, sizeof calibration);
        f.ee[0x10] = 'V';
        if (seq == 8) {
            f.ee[0x4c] = 0x40;
            f.ee[0x57] = 12;
            f.ee[0x59] = 30;
        }
        if (seq == 5) {
            f.ee[0x59] = 0xd5;
            f.ee[0x5a] = 0xfd; /* -555 сотых */
            f.ee[0x5b] = 12345 & 0xff;
            f.ee[0x5c] = 12345 >> 8;
        }
        if (seq >= 9) {
            f.ee[0x4d] = (seq - 8) << 6;
            memset(f.ee + 0x5d, 0x55, 4);
        }
        avr_eeprom_desc_t ee = {f.ee, 0, sizeof f.ee};
        avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
        nm_program_editor_open(&m);
        if (seq >= 9) {
            static const uint8_t last[] = {6, 30, 11};
            avr->data[0x06b6] = *nm_ram(&m, 0x06b6) = NM_PROGRAM_PERIOD;
            avr->data[0x06b8] = *nm_ram(&m, 0x06b8) = last[seq - 9];
        }
        NMProgramEditor editor = {0};
        uint8_t screen[32];
        memset(screen, ' ', sizeof screen);
        for (unsigned i = 0; sequences[seq][i] != 0xfe; i++) {
            uint8_t key = sequences[seq][i];
            uint8_t before = avr->data[0x06b6];
            visited |= 1u << before;
            total++;
            baseline += seq < 9;
            uint8_t period_item = *nm_ram(&m, 0x06b8);
            enter_fragment(avr, 0x301a);
            _avr_push_addr(avr, 0x7000);
            avr->data[16] = key;
            avr->data[17] = 0;
            bool sqw = seq >= 4 ? (i % 4u) >= 2u : (seq & 1u) != 0;
            avr->data[0x30] = sqw ? 4 : 0;
            avr->data[0x0735] = 1;
            unsigned budget = 150000;
            uint8_t column = 0, row = 0;
            bool wrote = false, calendar = false, control = false, threshold = false, comparison = false, reference = false, period = false;
            while (avr->pc != 0x7000 && budget--) {
                calendar |= avr->pc == 0x2d04;
                control |= avr->pc == 0x330e;
                threshold |= avr->pc == 0x3600;
                comparison |= avr->pc == 0x342a;
                reference |= avr->pc == 0x34e2;
                period |= avr->pc == 0x37aa;
                if (avr->pc == 0x1e2a) {
                    avr->data[16] = 0;
                    avr->pc = 0x2190;
                } else if (avr->pc == 0x1e86) {
                    memset(screen, ' ', sizeof screen);
                    column = row = 0;
                    avr->pc = 0x2190;
                } else if (avr->pc == 0x1e52) {
                    column = avr->data[16];
                    row = avr->data[17];
                    avr->pc = 0x2190;
                } else if (avr->pc == 0x1ee0) {
                    if (row < 2 && column < 16)
                        screen[16u*row+column] = avr->data[16];
                    column++;
                    wrote = true;
                    avr->pc = 0x2190;
                }
                step(avr);
            }
            if (avr->pc != 0x7000)
                fprintf(stderr, "dispatcher stalled: seq=%u step=%u key=%02x state=%u pc=%04x\n",
                        seq, i, key, before, avr->pc);
            assert(avr->pc == 0x7000);
            bool quit = nm_program_editor_step(&m, &editor, key);
            if (avr->data[0x06b6] != *nm_ram(&m, 0x06b6))
                fprintf(stderr, "dispatcher seq=%u step=%u key=%02x state=%u AVR=%u C=%u\n",
                        seq,i,key,before,avr->data[0x06b6],*nm_ram(&m,0x06b6));
            assert(avr->data[0x06b6] == *nm_ram(&m, 0x06b6));
            assert(quit == (avr->data[16] != 0));
            assert(avr->data[0x06b4] == *nm_ram(&m, 0x06b4));
            if (avr->data[0x06b5] != *nm_ram(&m, 0x06b5))
                fprintf(stderr, "dispatcher field: seq=%u step=%u key=%02x state=%u AVR=%u C=%u\n",seq,i,key,before,avr->data[0x06b5],*nm_ram(&m,0x06b5));
            assert(avr->data[0x06b5] == *nm_ram(&m, 0x06b5));
            assert(avr->data[0x06b8] == *nm_ram(&m, 0x06b8));
            if (avr->data[0x06b6] == NM_PROGRAM_THRESHOLDS) {
                for (uint8_t t = 0; t < 2; t++) {
                    uint16_t value = avr->data[0x06b0+2*t] | ((uint16_t)avr->data[0x06b1+2*t] << 8);
                    if ((uint16_t)editor.thresholds.value[t] != value)
                        fprintf(stderr, "threshold seq=%u step=%u from=%u field=%u AVR=%u C=%u\n",
                                seq,i,before,t,value,(uint16_t)editor.thresholds.value[t]);
                    assert((uint16_t)editor.thresholds.value[t] == value);
                }
            }
            if (avr->data[0x06b6] == NM_PROGRAM_START || avr->data[0x06b6] == NM_PROGRAM_STOP) {
                uint16_t address = avr->data[0x06ae] | ((uint16_t)avr->data[0x06af] << 8);
                assert(address >= 0x60 && address + 9u <= 0x85f);
                if (avr->data[address+9] != editor.time.cursor)
                    fprintf(stderr, "time cursor seq=%u step=%u AVR=%u C=%u\n",
                            seq,i,avr->data[address+9],editor.time.cursor);
                assert(avr->data[address+9] == editor.time.cursor);
                assert(!memcmp(editor.time.field, avr->data + address+3, 6));
            }
            if (wrote && avr->data[0x06b6] == NM_PROGRAM_ENABLE) {
                uint8_t expected[32];
                nm_program_enable_screen(&m, *nm_ram(&m, 0x06b4), expected);
                if (memcmp(expected,screen,32))
                    for (uint8_t j = 0; j < 32; j++)
                        if (expected[j] != screen[j])
                            fprintf(stderr,"program LCD seq=%u step=%u col=%u AVR=%02x C=%02x\n",
                                    seq,i,j,screen[j],expected[j]);
                assert(!memcmp(expected, screen, 32));
                screens++;
            }
            uint8_t state = avr->data[0x06b6];
            if (comparison && state == NM_PROGRAM_COMPARE) {
                uint8_t expected[32];
                nm_program_compare_screen(&m, *nm_ram(&m, 0x06b4), expected);
                if (memcmp(expected, screen, 32))
                    for (uint8_t j = 0; j < 32; j++)
                        if (expected[j] != screen[j])
                            fprintf(stderr,"compare LCD seq=%u step=%u col=%u AVR=%02x C=%02x\n",
                                    seq,i,j,screen[j],expected[j]);
                assert(!memcmp(expected, screen, 32));
                comparisons++;
            }
            if (reference && state == NM_PROGRAM_REFERENCE) {
                uint8_t expected[32];
                nm_program_reference_screen(&m, *nm_ram(&m, 0x06b4), expected);
                if (memcmp(expected, screen, 32))
                    for (uint8_t j = 0; j < 32; j++)
                        if (expected[j] != screen[j])
                            fprintf(stderr,"reference LCD seq=%u step=%u col=%u AVR=%02x C=%02x\n",
                                    seq,i,j,screen[j],expected[j]);
                assert(!memcmp(expected, screen, 32));
                references++;
            }
            if (period && state == NM_PROGRAM_PERIOD) {
                uint8_t expected[32];
                if ((key & 15u) != 1 && (key & 15u) != 4)
                    period_item = *nm_ram(&m, 0x06b8);
                nm_program_period_screen(&m, *nm_ram(&m, 0x06b4), period_item, expected);
                if (memcmp(expected, screen, 32))
                    for (uint8_t j = 0; j < 32; j++)
                        if (expected[j] != screen[j])
                            fprintf(stderr,"period LCD seq=%u step=%u col=%u AVR=%02x C=%02x\n",
                                    seq,i,j,screen[j],expected[j]);
                assert(!memcmp(expected, screen, 32));
                periods++;
            }
            if ((calendar && (state == NM_PROGRAM_START || state == NM_PROGRAM_STOP)) ||
                (control && state == NM_PROGRAM_CONTROL) ||
                (threshold && state == NM_PROGRAM_THRESHOLDS)) {
                uint8_t expected[32];
                if (calendar) {
                    nm_program_calendar_screen(&editor.time, state == NM_PROGRAM_STOP,
                                               *nm_ram(&m, 0x06b4), sqw, key, expected);
                    calendars++;
                } else if (threshold) {
                    nm_program_threshold_screen(&m, *nm_ram(&m, 0x06b4), &editor.thresholds,
                                                 sqw, expected);
                    thresholds++;
                } else {
                    nm_program_control_screen(&m, *nm_ram(&m, 0x06b4), sqw, key, expected);
                    controls++;
                }
                for (uint8_t j = 0; j < 32; j++) {
                    if (expected[j] != screen[j])
                        fprintf(stderr,"calendar/control seq=%u step=%u key=%02x col=%u AVR=%02x C=%02x\n",
                                seq,i,key,j,screen[j],expected[j]);
                    assert(expected[j] == screen[j]);
                }
            }
            uint8_t original[1024];
            ee.ee = original;
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
            if (memcmp(original, f.ee, sizeof original))
                for (unsigned j = 0; j < sizeof original; j++)
                    if (original[j] != f.ee[j])
                        fprintf(stderr, "dispatcher seq=%u step=%u key=%02x state=%u EE[%03x] AVR=%02x C=%02x\n",
                                seq,i,key,before,j,original[j],f.ee[j]);
            assert(!memcmp(original, f.ee, sizeof original));
        }
        avr_terminate(avr);
        free(avr);
    }
    assert(visited == 0x3ff);
    assert(baseline == 198 && calendars && controls && comparisons && references && periods);
    printf("dispatcher 0x301A: %u keys, 10 states, LCD enable=%u calendar=%u source=%u thresholds=%u compare=%u reference=%u period=%u\n",
           total,screens,calendars,controls,thresholds,comparisons,references,periods);
}

static uint32_t helper_word(avr_t *avr, uint8_t reg, uint8_t bytes)
{
    uint32_t value = 0;
    for (uint8_t i = 0; i < bytes; ++i)
        value |= (uint32_t)avr->data[reg + i] << (8u*i);
    return value;
}

static void run_helper(avr_t *avr, uint16_t entry, uint32_t left, uint32_t right)
{
    enter_fragment(avr, entry);
    for (uint8_t i = 0; i < 4; ++i) {
        avr->data[16 + i] = (uint8_t)(left >> (8u*i));
        avr->data[20 + i] = (uint8_t)(right >> (8u*i));
    }
    _avr_push_addr(avr, 0x7000);
    unsigned budget = 30000;
    while (avr->pc != 0x7000 && budget--)
        step(avr);
    assert(avr->pc == 0x7000);
}

static void check_original_heap(avr_t *avr)
{
    uint8_t ram[0x860] = {0};
    memset(avr->data + 0x360, 0, 0x200);
    memset(avr->data + 0x77e, 0, 6);
    uint16_t slots[16] = {0};
    uint32_t random = 12;
    for (unsigned i = 0; i < 1200; ++i) {
        random = random * UINT32_C(1664525) + UINT32_C(1013904223);
        unsigned slot = (random >> 20) & 15;
        if (slots[slot]) {
            run_helper(avr, 0x6dae, slots[slot], 0);
            nm_avr_heap_free(ram, slots[slot]);
            slots[slot] = 0;
        } else {
            uint16_t size = i % 29 == 0 ? UINT16_MAX : (random >> 12) & 127;
            run_helper(avr, 0x6f20, size, 0);
            slots[slot] = nm_avr_heap_alloc(ram, size);
            assert(helper_word(avr, 16, 2) == slots[slot]);
        }
        for (unsigned address = 0x360; address < 0x560; ++address) {
            if (ram[address] != avr->data[address])
                fprintf(stderr, "heap step=%u SRAM=%04x original=%02x translated=%02x\n",
                        i,address,avr->data[address],ram[address]);
            assert(ram[address] == avr->data[address]);
        }
        assert(!memcmp(avr->data + 0x77e, ram + 0x77e, 6));
    }
    memset(ram + 0x360, 0, 0x200);
    memset(ram + 0x77c, 0, 8);
    memset(avr->data + 0x360, 0, 0x200);
    memset(avr->data + 0x77c, 0, 8);
    run_helper(avr, 0x6a78, 96, 0);
    assert(helper_word(avr, 16, 2) == nm_avr_heap_alloc_retry(ram, 96, NULL, NULL));
    assert(!memcmp(avr->data + 0x360, ram + 0x360, 0x200));
    assert(!memcmp(avr->data + 0x77c, ram + 0x77c, 8));
    enter_fragment(avr, 0x6a78);
    avr->data[16] = avr->data[17] = 0xff;
    _avr_push_addr(avr, 0x7000);
    unsigned budget = 3000;
    while (avr->pc != 0x6dac && budget--)
        step(avr);
    assert(avr->pc == 0x6dac);
    for (unsigned i = 0; i < 20; ++i) {
        step(avr);
        assert(avr->pc == 0x6dac);
    }
    puts("Original heap: 1200 allocation/free operations, arena and link metadata");
}

static void stage14_until(avr_t *avr, uint16_t target)
{
    unsigned budget = 200000;
    while (avr->pc != target && budget--)
        step(avr);
    if (avr->pc != target)
        fprintf(stderr, "stage14 expected pc=%04x, got %04x\n",target,avr->pc);
    assert(avr->pc == target);
}

typedef struct {
    uint8_t text[20];
    uint32_t word;
} ScientificInput;

static void fixture_scientific_format(void *context, uint16_t format,
                                      uint32_t word, uint8_t buffer[20])
{
    ScientificInput *input = context;
    assert(format == 0x01a7 && word == input->word);
    memcpy(buffer, input->text, 20);
}

typedef struct {
    uint8_t bytes[256];
    unsigned count;
} NumericLcdTrace;

static void numeric_lcd_pos(void *context, uint8_t x, uint8_t y)
{
    NumericLcdTrace *t = context;
    assert(t->count + 3 <= sizeof t->bytes);
    t->bytes[t->count++] = 2;
    t->bytes[t->count++] = x;
    t->bytes[t->count++] = y;
}

static void numeric_lcd_write(void *context, uint8_t value, uint8_t data)
{
    NumericLcdTrace *t = context;
    assert(t->count + 2 <= sizeof t->bytes);
    t->bytes[t->count++] = data != 0;
    t->bytes[t->count++] = value;
}

typedef struct {
    NumericLcdTrace trace;
    uint8_t ram[0x860];
    unsigned snapshots;
} DigitOpenFixture;

static uint16_t digit_open_allocate(void *context, uint16_t size)
{
    DigitOpenFixture *fixture = context;
    assert(size == 19 || size == 22);
    uint16_t address = nm_avr_heap_alloc(fixture->ram,size);
    assert(address);
    return address;
}

static uint16_t digit_open_snapshot(void *context)
{
    DigitOpenFixture *fixture = context;
    ++fixture->snapshots;
    return 0x600;
}

static void digit_close_restore(void *context, uint16_t address)
{
    DigitOpenFixture *fixture = context;
    ++fixture->snapshots;
    nm_avr_heap_free(fixture->ram,address);
}

static void check_digit_open(avr_t *avr)
{
    for (uint8_t cursor = 0; cursor < 9; ++cursor) {
        DigitOpenFixture fixture = {0};
        NumericLcdTrace observed = {0};
        NMNumericDisplay lcd = {&fixture,numeric_lcd_pos,numeric_lcd_write};
        uint8_t parent[20] = {0};
        parent[4] = 3; parent[5] = 4; parent[7] = 3; parent[8] = 8;
        parent[9] = cursor; parent[10] = 2; parent[11] = 1;
        parent[17] = 0x84; parent[18] = 1;
        enter_fragment(avr,0x1c30);
        memset(avr->data+0x360,0,0x200);
        memset(avr->data+0x77c,0,8);
        memcpy(avr->data+0x600,parent,sizeof parent);
        avr->data[26] = 0; avr->data[27] = 6;
        avr->data[24] = cursor;
        bool opened = nm_avr_scientific_begin_digit(&lcd,fixture.ram,parent,flash,
                                                    cursor,digit_open_allocate,digit_open_snapshot);
        unsigned snapshots = 0, budget = 120000;
        while (avr->pc != 0x1cc6 && budget--) {
            if (avr->pc == 0x1f26) {
                ++snapshots;
                avr->data[16] = 0; avr->data[17] = 6;
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1e86) {
                numeric_lcd_write(&observed,1,0);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1e52) {
                numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1ee0 || avr->pc == 0x1efa) {
                numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            }
            step(avr);
        }
        assert(avr->pc == 0x1cc6);
        assert(opened == (cursor != 0 && cursor != 6));
        assert(snapshots == fixture.snapshots && snapshots == opened);
        assert(!memcmp(avr->data+0x600,parent,sizeof parent));
        assert(!memcmp(avr->data+0x360,fixture.ram+0x360,0x200));
        assert(!memcmp(avr->data+0x77c,fixture.ram+0x77c,8));
        assert(observed.count == fixture.trace.count);
        assert(!memcmp(observed.bytes,fixture.trace.bytes,observed.count));
    }
    for (unsigned sample = 0; sample < 8; ++sample) {
        DigitOpenFixture fixture = {0};
        NumericLcdTrace observed = {0};
        NMNumericDisplay lcd = {&fixture,numeric_lcd_pos,numeric_lcd_write};
        uint8_t parent[20] = {0};
        parent[4] = sample; parent[9] = 1; parent[11] = 1;
        parent[17] = 0x84; parent[18] = 1;
        uint16_t child = nm_avr_heap_alloc(fixture.ram,22);
        uint16_t saved = nm_avr_heap_alloc(fixture.ram,96);
        fixture.ram[child] = (uint8_t)saved;
        fixture.ram[child+1] = saved >> 8;
        parent[12] = (uint8_t)child; parent[13] = child >> 8;
        enter_fragment(avr,0x1d50);
        memcpy(avr->data+0x360,fixture.ram+0x360,0x200);
        memcpy(avr->data+0x77c,fixture.ram+0x77c,8);
        memcpy(avr->data+0x600,parent,sizeof parent);
        avr->data[26] = avr->data[30] = 0;
        avr->data[27] = avr->data[31] = 6;
        nm_avr_scientific_end_digit(&lcd,fixture.ram,parent,flash,digit_close_restore);
        unsigned restores = 0, budget = 120000;
        while (avr->pc != 0x1d58 && budget--) {
            if (avr->pc == 0x1f4e) {
                assert(helper_word(avr,16,2) == saved);
                ++restores;
                /* Исполнить освобождение из 0x1F64, пропустив шину. */
                avr->pc = 0x62e8;
            } else if (avr->pc == 0x1e86) {
                numeric_lcd_write(&observed,1,0);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1e52) {
                numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1ee0 || avr->pc == 0x1efa) {
                numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            }
            step(avr);
        }
        assert(avr->pc == 0x1d58);
        assert(restores == 1 && restores == fixture.snapshots);
        assert(!memcmp(avr->data+0x600,parent,sizeof parent));
        assert(!memcmp(avr->data+0x360,fixture.ram+0x360,0x200));
        assert(!memcmp(avr->data+0x77c,fixture.ram+0x77c,8));
        assert(observed.count == fixture.trace.count);
        assert(!memcmp(observed.bytes,fixture.trace.bytes,observed.count));
    }
    puts("stage23: all 9 digit-open cursor positions and 8 digit closes, arena, logical LCD and SRAM");
}

static uint16_t digit_dispatch_snapshot(void *context)
{
    DigitOpenFixture *fixture = context;
    return nm_avr_heap_alloc(fixture->ram,96);
}

static void check_digit_dispatch(avr_t *avr)
{
    static const uint8_t keys[] = {1,3,1,1,5,4,1,2,2,3,4,4,0,3,1,2,5};
    DigitOpenFixture fixture = {0};
    NMNumericDisplay lcd = {&fixture,numeric_lcd_pos,numeric_lcd_write};
    uint8_t parent[20] = {0};
    parent[4] = 3; parent[5] = 4; parent[7] = 3; parent[8] = 8;
    parent[10] = 2; parent[11] = 1; parent[17] = 0x84; parent[18] = 1;
    memset(avr->data+0x360,0,0x200);
    memset(avr->data+0x77c,0,8);
    memcpy(avr->data+0x600,parent,sizeof parent);

    for (unsigned action = 0; action < sizeof keys; ++action) {
        uint8_t key = keys[action] | 0x80;
        NumericLcdTrace observed = {0};
        fixture.trace.count = 0;
        enter_fragment(avr,0x1b9e);
        avr->data[16] = 0; avr->data[17] = 6;
        avr->data[18] = key;
        _avr_push_addr(avr,0x7000);
        uint8_t result = nm_avr_scientific_step(&lcd,fixture.ram,parent,flash,key,0,
                                 digit_open_allocate,digit_dispatch_snapshot,digit_close_restore);
        unsigned budget = 120000;
        while (avr->pc != 0x7000 && budget--) {
            if (avr->pc == 0x1f26) {
                avr->data[16] = 96; avr->data[17] = 0;
                avr->pc = 0x6a7c;
            } else if (avr->pc == 0x1f4e) {
                avr->pc = 0x62e8;
            } else if (avr->pc == 0x1e86) {
                numeric_lcd_write(&observed,1,0);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1e52) {
                numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1ee0 || avr->pc == 0x1efa) {
                numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            }
            step(avr);
        }
        assert(avr->pc == 0x7000);
        assert(result == avr->data[16]);
        if (observed.count != fixture.trace.count) {
            fprintf(stderr,"key %u action %u LCD AVR %u C %u\n",key,action,observed.count,fixture.trace.count);
            for (unsigned j=0;j<observed.count || j<fixture.trace.count;++j) fprintf(stderr,"%02x:%02x ",observed.bytes[j],fixture.trace.bytes[j]);
            fputc(10,stderr);
        }
        assert(!memcmp(avr->data+0x600,parent,sizeof parent));
        assert(!memcmp(avr->data+0x360,fixture.ram+0x360,0x200));
        assert(!memcmp(avr->data+0x77c,fixture.ram+0x77c,8));
        assert(observed.count == fixture.trace.count);
        assert(!memcmp(observed.bytes,fixture.trace.bytes,observed.count));
    }
    puts("stage24: 17 consecutive scientific-editor keys through 0x1B9E");
}

static void check_calibration_and_adc(avr_t *avr)
{
    DigitOpenFixture model = {0};
    Fixture fixture = {0};
    NM8036 m = fixture_device(&fixture);
    NMNumericDisplay lcd = {&model,numeric_lcd_pos,numeric_lcd_write};
    uint8_t eeprom[1024] = {0};
    for (unsigned i = 8; i < sizeof eeprom; ++i)
        eeprom[i] = (uint8_t)(i * 73u + 11u);
    eeprom[6] = 0x80; eeprom[7] = 0x3f;
    memcpy(fixture.ee,eeprom,sizeof eeprom);
    avr_eeprom_desc_t ee = {eeprom,0,sizeof eeprom};
    avr_ioctl(avr,AVR_IOCTL_EEPROM_SET,&ee);
    memset(avr->data+0x360,0,0x200);
    memset(avr->data+0x77c,0,8);

    const uint8_t keys[] = {0,3,1,1,5,1,3,5,0};
    for (unsigned action = 0; action < sizeof keys; ++action) {
        bool open = action == 0 || action == sizeof keys - 1;
        NumericLcdTrace observed = {0};
        model.trace.count = 0;
        uint8_t menu[8] = {0};
        menu[6] = 4;
        enter_fragment(avr,open ? 0xe7a : 0xf9c);
        avr->data[0x67b] = 0; avr->data[0x67c] = 6;
        menu[2] = open;
        memcpy(avr->data+0x600,menu,sizeof menu);
        avr->sreg[6] = 0;
        avr->data[16] = open;
        avr->data[17] = 1;
        avr->data[0x739] = *nm_ram(&m,0x739) = keys[action];
        if (open)
            nm_avr_calibration_menu_open_field(&m,&lcd,model.ram,flash,menu,false,
                                             digit_open_allocate,digit_dispatch_snapshot);
        else
            assert(nm_avr_calibration_menu_step(&m,&lcd,model.ram,flash,menu,
                       digit_open_allocate,digit_dispatch_snapshot,digit_close_restore) == (action == 7));
        unsigned budget = 200000;
        while (avr->pc != 0xe9a && avr->pc != 0xfa8 && avr->pc != 0xfaa && budget--) {
            if (avr->pc == 0x1f26) {
                avr->data[16] = 96; avr->data[17] = 0;
                avr->pc = 0x6a7c;
            } else if (avr->pc == 0x1f4e) {
                avr->pc = 0x62e8;
            } else if (avr->pc == 0x1e86) {
                numeric_lcd_write(&observed,1,0);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1e52) {
                numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1ee0 || avr->pc == 0x1efa) {
                numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            }
            step(avr);
        }
        assert(avr->pc == (open ? 0xe9a : action == 7 ? 0xfaa : 0xfa8));
        assert(!memcmp(avr->data+0x600,menu,sizeof menu));
        assert(!memcmp(avr->data+0x360,model.ram+0x360,0x200));
        assert(!memcmp(avr->data+0x77c,model.ram+0x77c,8));
        assert(avr->data[0x67d] == *nm_ram(&m,0x67d));
        assert(avr->data[0x67e] == *nm_ram(&m,0x67e));
        assert(observed.count == model.trace.count);
        assert(!memcmp(observed.bytes,model.trace.bytes,observed.count));
        avr_ioctl(avr,AVR_IOCTL_EEPROM_GET,&ee);
        assert(!memcmp(eeprom,fixture.ee,sizeof eeprom));
        const uint8_t initial[] = {0,0,0x80,0x3f};
        assert((memcmp(eeprom+4,initial,sizeof initial) != 0) == (action >= 7));
    }

    uint8_t glyphs[64];
    for (unsigned i = 0; i < sizeof glyphs; ++i)
        glyphs[i] = i & 31u;
    avr_loadcode(avr,glyphs,sizeof glyphs,0x7100);
    NumericLcdTrace observed = {0};
    model.trace.count = 0;
    uint8_t ready = 0;
    nm_avr_adc_load_glyphs(&lcd,glyphs,&ready);
    enter_fragment(avr,0x4848);
    avr->data[16] = 0; avr->data[17] = 0x71;
    avr->data[0x73f] = 0;
    _avr_push_addr(avr,0x7000);
    unsigned budget = 5000;
    while (avr->pc != 0x7000 && budget--) {
        if (avr->pc == 0x1ee0 || avr->pc == 0x1e66) {
            numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
            avr->pc = 0x2190;
        }
        step(avr);
    }
    assert(avr->pc == 0x7000 && avr->data[0x73f] == ready);
    assert(observed.count == model.trace.count);
    assert(!memcmp(observed.bytes,model.trace.bytes,observed.count));

    for (unsigned i = 0; i < 32; ++i) {
        uint16_t base = 0xfff0u + i;
        uint16_t offset = 20;
        enter_fragment(avr,0x48a0);
        avr->data[16] = (uint8_t)offset; avr->data[17] = offset >> 8;
        avr->data[20] = (uint8_t)base; avr->data[21] = base >> 8;
        _avr_push_addr(avr,0x7000);
        stage14_until(avr,0x7000);
        assert(helper_word(avr,16,4) == nm_avr_adc_read_operand(&m,base,offset));
    }
    puts("stages25-29 and 42: coefficient open/menu keys/save/reopen, CGRAM trace and 32 ADC EEPROM reads");
}

static void check_unit_editor(avr_t *avr)
{
    static const uint8_t key_paths[][6] = {
        {1,1,0x81,0x85,0xff,0}, {4,4,2,0x84,4,5},
        {2,0x84,4,0x82,0x83,0}, {0x84,4,0x81,3,0xff,0}
    };
    static const uint8_t initial[] = {4,3,255,110};
    for (unsigned path = 0; path < sizeof initial; ++path) {
        DigitOpenFixture model = {0};
        Fixture fixture = {0};
        NM8036 m = fixture_device(&fixture);
        NMNumericDisplay lcd = {&model,numeric_lcd_pos,numeric_lcd_write};
        uint8_t eeprom[1024] = {0};
        eeprom[0x13] = fixture.ee[0x13] = initial[path];
        avr_eeprom_desc_t ee = {eeprom,0,sizeof eeprom};
        avr_ioctl(avr,AVR_IOCTL_EEPROM_SET,&ee);
        memset(avr->data+0x360,0,0x200);
        memset(avr->data+0x77c,0,8);
        for (unsigned action = 0; action <= sizeof *key_paths; ++action) {
            bool open = action == 0;
            uint8_t key = open ? 0xff : key_paths[path][action-1];
            NumericLcdTrace observed = {0};
            model.trace.count = 0;
            uint8_t menu[8] = {0};
        menu[6] = 8;
        enter_fragment(avr,open ? 0xe86 : 0xfac);
        avr->data[0x67b] = 0; avr->data[0x67c] = 6;
        menu[2] = open;
        memcpy(avr->data+0x600,menu,sizeof menu);
            avr->data[16] = open; avr->data[17] = 1;
            avr->data[0x739] = *nm_ram(&m,0x739) = key;
                bool result = true;
            if (open)
                nm_avr_calibration_menu_open_field(&m,&lcd,model.ram,flash,menu,false,
                                             digit_open_allocate,digit_dispatch_snapshot);
            else
                result = nm_avr_calibration_menu_step(&m,&lcd,model.ram,flash,menu,
                            digit_open_allocate,digit_dispatch_snapshot,digit_close_restore);
            unsigned budget = 120000;
            while (avr->pc != 0xe9a && avr->pc != 0xfa8 && avr->pc != 0xfaa && budget--) {
                if (avr->pc == 0x1f26) {
                    avr->data[16] = 96; avr->data[17] = 0;
                    avr->pc = 0x6a7c;
                } else if (avr->pc == 0x1f4e) {
                    avr->pc = 0x62e8;
                } else if (avr->pc == 0x1e86) {
                    numeric_lcd_write(&observed,1,0);
                    avr->pc = 0x2190;
                } else if (avr->pc == 0x1e52) {
                    numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                    avr->pc = 0x2190;
                } else if (avr->pc == 0x1ee0 || avr->pc == 0x1efa) {
                    numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                    avr->pc = 0x2190;
                }
                step(avr);
            }
            assert(avr->pc == (open ? 0xe9a : result ? 0xfaa : 0xfa8));
            assert(!memcmp(avr->data+0x600,menu,sizeof menu));
        assert(!memcmp(avr->data+0x360,model.ram+0x360,0x200));
            assert(!memcmp(avr->data+0x77c,model.ram+0x77c,8));
            assert(avr->data[0x67d] == *nm_ram(&m,0x67d));
            assert(avr->data[0x67e] == *nm_ram(&m,0x67e));
            assert(observed.count == model.trace.count);
            assert(!memcmp(observed.bytes,model.trace.bytes,observed.count));
            avr_ioctl(avr,AVR_IOCTL_EEPROM_GET,&ee);
            assert(!memcmp(eeprom,fixture.ee,sizeof eeprom));
        }
    }
    puts("stages30-34 and 42: 28 unit-editor actions through 0x1120 and 0x0FAC");
}

static void check_calibration_route(avr_t *avr)
{
    static const unsigned entries[] = {0xed4,0xf9c,0xfac,0xfb8,0xe9a};
    for (unsigned base = 0; base < 256; ++base) {
        for (unsigned row = 0; row < 4; ++row) {
            uint8_t menu[8] = {0};
            menu[6] = base;
            menu[7] = (uint8_t)((base & 0xfc) | row);
            enter_fragment(avr,0xeb2);
            avr->data[0x67b] = 0; avr->data[0x67c] = 4;
            memcpy(avr->data+0x400,menu,sizeof menu);
            stage14_until(avr,entries[nm_avr_calibration_route(menu)]);
        }
    }
    puts("stage40: 1024 calibration menu dispatch cases");
}

static void check_calibration_interval(avr_t *avr)
{
    const uint8_t values[] = {0,7,8,9,118,119,120,255};
    for (uint8_t item = 9; item <= 10; ++item) {
        for (unsigned v = 0; v < sizeof values; ++v) {
            for (uint8_t key = 0; key < 8; ++key) {
                Fixture f = {0};
                NM8036 m = fixture_device(&f);
                uint8_t menu[8] = {0};
                menu[6] = item;
                uint8_t eeprom[1024] = {0};
                eeprom[item+7] = f.ee[item+7] = values[v];
                avr_eeprom_desc_t ee = {eeprom,0,sizeof eeprom};
                avr_ioctl(avr,AVR_IOCTL_EEPROM_SET,&ee);
                enter_fragment(avr,0xfb8);
                avr->data[0x67b] = 0; avr->data[0x67c] = 6;
                memcpy(avr->data+0x600,menu,sizeof menu);
                avr->data[0x739] = *nm_ram(&m,0x739) = key | 0x80;
                NumericLcdTrace expected = {0}, observed = {0};
                NMNumericDisplay lcd = {&expected,numeric_lcd_pos,numeric_lcd_write};
                bool closed = nm_avr_calibration_interval_step(&m,&lcd,menu);
                unsigned budget = 5000;
                while (avr->pc != 0xfa8 && avr->pc != 0xfaa && budget--) {
                    if (avr->pc == 0x1e52) {
                        numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                        avr->pc = 0x2190;
                    } else if (avr->pc == 0x1efa) {
                        numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                        avr->pc = 0x2190;
                    }
                    step(avr);
                }
                if (avr->pc != (closed ? 0xfaa : 0xfa8)) fprintf(stderr,"item=%u value=%u key=%u pc=%04x budget=%u\n",item,values[v],key,avr->pc,budget);
                assert(avr->pc == (closed ? 0xfaa : 0xfa8));
                assert(observed.count == expected.count);
                assert(!memcmp(observed.bytes,expected.bytes,observed.count));
                avr_ioctl(avr,AVR_IOCTL_EEPROM_GET,&ee);
                assert(!memcmp(eeprom,f.ee,sizeof eeprom));
            }
        }
    }
    puts("stage43: 128 calibration interval routes with EEPROM and LCD");
}

static void check_calibration_menu_lcd(avr_t *avr)
{
    for (unsigned sample = 0; sample < 22; ++sample) {
        bool interval = sample >= 20;
        uint8_t menu[8] = {0,0,interval,0xa3,0,11,sample/2,sample&1};
        NumericLcdTrace expected = {0}, observed = {0};
        NMNumericDisplay lcd = {&expected,numeric_lcd_pos,numeric_lcd_write};
        enter_fragment(avr,interval ? 0xe92 : 0xf92);
        avr->data[0x67b] = 0; avr->data[0x67c] = 6;
        memcpy(avr->data+0x600,menu,sizeof menu);
        if (interval)
            nm_avr_calibration_interval_open(&lcd,flash,menu);
        else
            nm_avr_calibration_menu_resume(&lcd,flash,menu);
        unsigned budget = 10000;
        while (avr->pc != 0xe9a && budget--) {
            if (avr->pc == 0x1e86) {
                numeric_lcd_write(&observed,1,0);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1e52) {
                numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1ee0 || avr->pc == 0x1efa) {
                numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            }
            step(avr);
        }
        assert(avr->pc == 0xe9a);
        assert(!memcmp(avr->data+0x600,menu,sizeof menu));
        assert(observed.count == expected.count);
        assert(!memcmp(observed.bytes,expected.bytes,observed.count));
    }
    puts("stages45-46: 20 calibration list redraws and 2 interval openings");
}

static void check_display_helpers(avr_t *avr)
{
    Fixture fixture = {0};
    NM8036 m = fixture_device(&fixture);
    for (unsigned i = 0; i < 256; ++i) {
        uint16_t index = i * 257u;
        enter_fragment(avr,0x48e6);
        avr->data[24] = (uint8_t)index; avr->data[25] = index >> 8;
        _avr_push_addr(avr,0x7000);
        stage14_until(avr,0x7000);
        assert(helper_word(avr,30,2) == nm_avr_adc_word_offset(index));

        NumericLcdTrace trace = {0};
        NMNumericDisplay lcd = {&trace,numeric_lcd_pos,numeric_lcd_write};
        nm_avr_adc_compact_position(&lcd,index);
        enter_fragment(avr,0x48fe);
        avr->data[24] = (uint8_t)index; avr->data[25] = index >> 8;
        stage14_until(avr,0x1e52);
        assert(avr->data[16] == trace.bytes[1] && avr->data[17] == trace.bytes[2]);

        avr->data[0x0739] = *nm_ram(&m,0x0739) = i;
        run_helper(avr,0x1078,0,0);
        assert(avr->data[16] == nm_avr_calibration_key(&m));

        avr->data[0x072b] = i;
        run_helper(avr,0x4db2,0,0);
        uint16_t y = helper_word(avr,28,2);
        assert((avr->data[y] | ((uint16_t)avr->data[y+1] << 8)) == nm_avr_rtc_display_day(i));
    }
    for (unsigned i = 0; i < 32; ++i) {
        NumericLcdTrace expected = {0}, observed = {0};
        NMNumericDisplay lcd = {&expected,numeric_lcd_pos,numeric_lcd_write};
        uint8_t first = i % 16, last = (i * 7u) % 16;
        nm_avr_lcd_fill_spaces(&lcd,first,last,i & 1);
        enter_fragment(avr,0x1e68);
        avr->data[16] = first; avr->data[17] = last; avr->data[18] = i & 1;
        _avr_push_addr(avr,0x7000);
        unsigned budget = 2000;
        while (avr->pc != 0x7000 && budget--) {
            if (avr->pc == 0x1e52) {
                numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1e66) {
                numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            }
            step(avr);
        }
        assert(avr->pc == 0x7000 && observed.count == expected.count);
        assert(!memcmp(observed.bytes,expected.bytes,observed.count));
    }
    puts("stages35-39: 32 LCD fills and 1024 key, ADC and RTC cases");
}

static void adc_format_capture(void *context, uint16_t address, uint16_t channel,
                               uint32_t binary32)
{
    uint32_t *args = context;
    args[0] = address;
    args[1] = channel;
    args[2] = binary32;
}

static uint16_t ram_fmt_emit(void *context, uint16_t state, uint8_t byte)
{
    NumericLcdTrace *t = context;
    assert(t->count < sizeof t->bytes);
    t->bytes[t->count++] = byte;
    return state + 1u;
}

static void check_ram_formatter(avr_t *avr)
{
    static const uint8_t format[] = "A%%:%d:%i:%o:%u:%X:%x:%p:%s:%c:%q!";
    avr->data[0x66f] = '-';
    avr->data[0x671] = '%';
    for (unsigned i = 0; i < 64; ++i) {
        NumericLcdTrace expected = {0}, observed = {0};
        uint16_t argument = 0x450;
        memcpy(avr->data+0x400,format,sizeof format);
        memcpy(avr->data+0x490,"NM",3);
        for (unsigned j = 0; j < 9; ++j) {
            uint16_t value = (i == 0 ? 0 : i == 1 ? 0xffff : i == 2 ? 0x8000 : i*1373u+j*1877u);
            if (j == 7)
                value = 0x490;
            avr->data[argument+2*j] = (uint8_t)value;
            avr->data[argument+2*j+1] = value >> 8;
        }
        assert(nm_avr_format_ram(avr->data,format,&argument,0,ram_fmt_emit,&expected) == 0);
        enter_fragment(avr,0x6c16);
        avr->data[16] = 0xc8; avr->data[17] = 0x10;
        avr->data[18] = avr->data[19] = 0;
        avr->data[20] = 0; avr->data[21] = 4;
        avr->data[22] = 0x80; avr->data[23] = 4;
        avr->data[0x480] = 0x50; avr->data[0x481] = 4;
        _avr_push_addr(avr,0x7000);
        unsigned budget = 50000;
        while (avr->pc != 0x7000 && budget--) {
            if (avr->pc == 0x6c02) {
                assert(helper_word(avr,16,2) == observed.count);
                uint16_t next = ram_fmt_emit(&observed,observed.count,avr->data[18]);
                avr->data[16] = next; avr->data[17] = next >> 8;
                avr->pc += 2;
                continue;
            }
            step(avr);
        }
        assert(avr->pc == 0x7000 && helper_word(avr,16,2) == 0);
        assert(argument == (uint16_t)(avr->data[0x480] | (uint16_t)avr->data[0x481]<<8));
        if (expected.count != observed.count || memcmp(expected.bytes,observed.bytes,expected.count))
            fprintf(stderr,"RAM format case %u: C |%s| AVR |%s|\n",i,expected.bytes,observed.bytes);
        assert(expected.count == observed.count && !memcmp(expected.bytes,observed.bytes,expected.count));
    }
    NumericLcdTrace expected = {0}, observed = {0};
    NMNumericDisplay lcd = {&expected,numeric_lcd_pos,numeric_lcd_write};
    const uint8_t lcd_format[] = "%% %c %d %s";
    memcpy(avr->data+0x400,lcd_format,sizeof lcd_format);
    const uint8_t args[] = {'K',0,0xff,0xff,0x90,4};
    memcpy(avr->data+0x320,args,sizeof args);
    nm_avr_lcd_format_ram(&lcd,avr->data,lcd_format,0x320);
    enter_fragment(avr,0x6aba);
    avr->data[16] = 0; avr->data[17] = 4;
    _avr_push_addr(avr,0x7000);
    unsigned budget = 50000;
    while (avr->pc != 0x7000 && budget--) {
        if (avr->pc == 0x1ee0) {
            numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
            avr->pc = 0x2190;
        }
        step(avr);
    }
    assert(avr->pc == 0x7000 && helper_word(avr,28,2) == 0x320);
    assert(expected.count == observed.count && !memcmp(expected.bytes,observed.bytes,expected.count));
    puts("stage15 RAM formatter: 64 format streams with all supported argument types");
}

static void check_stage18(avr_t *avr)
{
    static const uint8_t mixed[] = "A%%:%5c:%-5c:%.2s:%16.0s:%9.2e:%ln!";
    static const uint8_t integer[] = "%+08d:%-7i:%#06x:%#X:%#.0o:%.0u:%p:%ld:%lu:%08.4x";
    static const uint8_t scientific[] = "%+.0E:%#.0e:%-12.4e:%E";
    static const uint8_t floats[] = "%+012.2e:%8.2f:%.4g:%#.3G";
    static const uint8_t rounding[] = "%+010.0f:%#.0f:%.0g:%-10.2G";
    static const uint8_t unknown[] = "A%q:%8Q:%-8z:%+07.1j:% .0k:%d!";
    for (unsigned test = 0; test < 72; ++test) {

        const uint8_t *pattern = test < 3 ? mixed : test < 35 ? integer : test < 43 ? scientific : test < 55 ? floats : test < 71 ? rounding : unknown;
        uint8_t ram[0x600] = {0};
        uint8_t args[] = {'K',0,'B',0,0x90,4,0,0,0,0,0x80,0x3f,0xa0,4};
        args[11] = test == 0 ? 0x3f : test == 1 ? 0xbf : 0x7f;
        if (test == 2) args[10] = 0xc0;
        memcpy(ram+0x450,args,sizeof args);
        if (test >= 3 && test < 35) {
            uint16_t values[] = {0x8000,0x7fff,0xab,0xAbCd,0,0,0x1234,1,0x8000,0xffff,0xffff,test};
            if (test > 3)
                for (unsigned j = 0; j < sizeof values / sizeof *values; ++j)
                    values[j] ^= (test - 3u) * (1729u + j * 157u);
            for (unsigned j = 0; j < sizeof values / sizeof *values; ++j) {
                ram[0x450+j*2] = (uint8_t)values[j];
                ram[0x451+j*2] = values[j] >> 8;
            }
        }
        if (test >= 35) {
            const uint32_t values[] = {0, 0x80000000, 0x3f800000,0xbf800000,
                0x411feb86,0x7fc00000,1,0x7f7fffff,
                0x38d1b717,0x3727c5ac,0x447a0000,0x3f7fbe77,
                0x3effffff,0x3f000000,0x411fffff,0x42c7ffff};
            for (unsigned j = 0; j < 4; ++j)
                for (unsigned k = 0; k < 4; ++k)
                    ram[0x450+j*4+k] = values[(test-35+j)%(test < 43 ? 8 : test < 55 ? 12 : 16)] >> (8*k);
        }
        memcpy(ram+0x490,"Test",5);
        memcpy(avr->data+0x450,ram+0x450,0x60);
        avr_loadcode(avr,(uint8_t *)pattern,strlen((const char *)pattern)+1,0x7100);
        enter_fragment(avr,0x5ce2);
        avr->data[16] = 0; avr->data[17] = 0x71;
        avr->data[18] = 1; avr->data[19] = 0;
        avr->data[20] = 0x33; avr->data[21] = 0x12;
        avr->data[22] = 0xc0; avr->data[23] = 4;
        avr->data[0x4c0] = 0x50; avr->data[0x4c1] = 4;
        _avr_push_addr(avr,0x7000);
        NumericLcdTrace expected = {0}, observed = {0};
        uint16_t argument = 0x450, count;
        assert(nm_avr_flash_format(flash,pattern,ram,&argument,0x1233,ram_fmt_emit,&expected,&count));
        unsigned budget = 200000;
        while (avr->pc != 0x7000 && budget--) {
            if (avr->pc == 0x615a) {
                assert(helper_word(avr,18,2) == 0x1233);
                ram_fmt_emit(&observed,0,avr->data[16]);
                avr->pc += 2;
            }
            step(avr);
        }
        assert(avr->pc == 0x7000);
        if (observed.count != count || memcmp(expected.bytes,observed.bytes,count))
            fprintf(stderr,"stage18 case %u AVR |%s| C |%s|\n",test,observed.bytes,expected.bytes);
        assert(observed.count == count && count == helper_word(avr,16,2));
        assert(!memcmp(expected.bytes,observed.bytes,count));
        assert(!memcmp(avr->data+0x4a0,ram+0x4a0,4));
        assert(argument == (uint16_t)(avr->data[0x4c0] | avr->data[0x4c1]<<8));
    }
    puts("Flash formatter: 3 mixed streams and 32 integer and 8 scientific and 28 fixed/general streams and 1 fallback stream");
}

static void check_stage16_decimal(avr_t *avr)
{
    static const uint32_t words[] = {0,0x80000000,0x7fc00000,0xffc00000,1,0x007fffff,
        0x00800000,0x7f7fffff,0x3f800000,0x3f80a3d7,0x3f80a3d8,
        0x411feb85,0x411feb86,0xc11feb86,0x41200000};
    for (unsigned i = 0; i < sizeof words / sizeof *words; ++i) {
        for (unsigned sticky = 0; sticky < 2; ++sticky) {
            uint8_t expected[10];
            nm_avr_format_e92(expected, words[i], sticky);
            enter_fragment(avr, 0x19f0);
            avr->sreg[6] = sticky;
            avr->data[16] = 0;
            avr->data[17] = 4;
            for (unsigned j = 0; j < 4; ++j)
                avr->data[20+j] = words[i] >> (8*j);
            stage14_until(avr, 0x1a0e);
            uint16_t y = helper_word(avr,28,2);
            if (memcmp(expected,avr->data+y,10))
                fprintf(stderr,"e92 %08x T=%u C=%s AVR=%s\n",(unsigned)words[i],sticky,expected,avr->data+y);
            assert(!memcmp(expected,avr->data+y,10));
        }
    }
    for (unsigned i = 0; i < 16; ++i) {
        uint8_t parent[20] = {0}, child[22] = {0};
        parent[9] = i % 9;
        parent[10] = i % 3;
        parent[11] = 1;
        parent[12] = 0x50;
        parent[13] = 4;
        child[20] = 0x82;
        child[21] = 1;
        memcpy(avr->data + 0x400,parent,sizeof parent);
        memcpy(avr->data + 0x450,child,sizeof child);
        NumericLcdTrace expected = {0}, observed = {0};
        NMNumericDisplay lcd = {&expected,numeric_lcd_pos,numeric_lcd_write};
        nm_avr_scientific_open_digit(&lcd,parent,child,i);
        enter_fragment(avr,0x1ca4);
        avr->data[26] = avr->data[30] = 0;
        avr->data[27] = avr->data[31] = 4;
        avr->data[24] = i;
        unsigned budget = 2000;
        while (avr->pc != 0x1cc6 && budget--) {
            if (avr->pc == 0x1e52) {
                numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            } else if (avr->pc == 0x1ee0) {
                numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                avr->pc = 0x2190;
            }
            step(avr);
        }
        assert(avr->pc == 0x1cc6);
        assert(expected.count == observed.count && !memcmp(expected.bytes,observed.bytes,expected.count));
        assert(!memcmp(parent,avr->data+0x400,sizeof parent));
        assert(!memcmp(child,avr->data+0x450,sizeof child));
    }
    for (unsigned i = 0; i < 256; ++i) {
        uint8_t active = i ^ 0x77;
        avr->data[0x73a] = active;
        enter_fragment(avr,0x482e);
        avr->data[16] = i;
        stage14_until(avr,0x441e);
        nm_avr_adc_finish_menu(&active,i);
        assert(avr->data[0x73a] == active);
    }
    static const char *const templates[] = {"9.2e","-#012.8Lf","+ 3d","*.*f",".*s",
        "077777777777777hx","++#--0.*le","*u",".f"," hX","-32768d"};
    for (unsigned i = 0; i < sizeof templates / sizeof *templates; ++i) {
        avr_loadcode(avr,(uint8_t *)templates[i],strlen(templates[i])+1,0x7100);
        enter_fragment(avr,0x5d32);
        avr->data[14] = 0; avr->data[15] = 0x71;
        avr->data[12] = 0x60; avr->data[13] = 4;
        avr->data[0x460] = 0x70; avr->data[0x461] = 4;
        avr->data[0x470] = 0xfa; avr->data[0x471] = 0xff;
        avr->data[0x472] = 7; avr->data[0x473] = 0;
        const uint8_t *format = (const uint8_t *)templates[i];
        const uint8_t *start = format;
        uint16_t argument = 0x470;
        NMFlashFormat out = nm_avr_flash_format_parse(&format,avr->data,&argument);
        stage14_until(avr,0x5e48);
        assert(helper_word(avr,14,2) == 0x7100u + (unsigned)(format-start));
        assert(helper_word(avr,8,2) == out.precision && helper_word(avr,10,2) == out.width);
        assert((uint16_t)(avr->data[0x460] | avr->data[0x461] << 8) == argument);
        assert(avr->data[16] == out.specifier && avr->data[24] == out.wide);
        assert(avr->data[0x321] == out.sign && avr->data[0x322] == out.left &&
               avr->data[0x323] == out.alternate && avr->data[0x324] == out.zero);
    }
    const uint8_t keys[] = {0,5,0xff,0x85};
    for (unsigned i = 0; i < sizeof keys; ++i) {
        Fixture fixture = {0};
        NM8036 m = fixture_device(&fixture);
        uint8_t eeprom[1024] = {0}, field[20] = {0};
        field[4] = 2; field[5] = 4; field[6] = i;
        avr_eeprom_desc_t ee = {eeprom,0,sizeof eeprom};
        avr_ioctl(avr,AVR_IOCTL_EEPROM_SET,&ee);
        memcpy(avr->data+0x400,field,sizeof field);
        enter_fragment(avr,0x10f4);
        avr->data[0x67d] = 0; avr->data[0x67e] = 4;
        avr->data[0x739] = keys[i];
        avr->data[24] = 0; avr->data[25] = 0;
        bool save = keys[i] != 0xff;
        stage14_until(avr,save ? 0x1110 : 0x1118);
        assert(nm_avr_calibration_finish(&m,0,save,field) == save);
        avr_ioctl(avr,AVR_IOCTL_EEPROM_GET,&ee);
        assert(!memcmp(eeprom,fixture.ee,sizeof eeprom));
        if (save)
            assert(avr->sreg[7]);
    }
    for (unsigned i = 0; i < 256; ++i) {
        avr->data[0x6b4] = i;
        run_helper(avr,0x3a1c,0,0);
        assert(helper_word(avr,20,2) == nm_avr_program_record_base(i));
        enter_fragment(avr,0x3922);
        avr->data[30] = 0; avr->data[31] = 4;
        avr->data[0x404] = (uint8_t)(i*3);
        avr->data[16] = i;
        _avr_push_addr(avr,0x7000);
        stage14_until(avr,0x7000);
        assert(avr->data[16] == nm_avr_program_merge_time(i,i*3));
        enter_fragment(avr,0x392c);
        avr->data[26] = 0; avr->data[27] = 4;
        avr->data[0x400] = 0x50; avr->data[0x401] = 4;
        avr->data[16] = i;
        _avr_push_addr(avr,0x7000);
        stage14_until(avr,0x7000);
        uint8_t editor[8] = {0};
        nm_avr_program_record_key(editor,i);
        assert(avr->data[0x457] == editor[7]);
        enter_fragment(avr,i & 1 ? 0x3962 : 0x396c);
        avr->data[30] = 0x50; avr->data[31] = 4;
        memset(avr->data+0x450,0,6);
        _avr_push_addr(avr,0x7000);
        stage14_until(avr,0x7000);
        nm_avr_program_limit(editor,i & 1);
        assert(!memcmp(editor,avr->data+0x450,6));
    }
    for (unsigned i = 0; i < 256; ++i) {
        Fixture f = {0};
        NM8036 m = fixture_device(&f);
        *nm_ram(&m,0x6b4) = avr->data[0x6b4] = i%32;
        f.ee[nm_avr_program_record_base(i%32)+1] = i;
        avr_eeprom_desc_t ee = {f.ee,0,sizeof f.ee};
        avr_ioctl(avr,AVR_IOCTL_EEPROM_SET,&ee);
        run_helper(avr,0x3a4a,0,0);
        uint8_t mode = nm_avr_program_period_mode(&m);
        assert(avr->data[16] == mode && avr->sreg[1] == (mode == 0));
    }
    for (unsigned value = 0; value < 256; ++value) {
        const uint8_t key = (uint8_t)value;
        enter_fragment(avr, 0x1cc6);
        avr->data[25] = key & 0x0f;
        stage14_until(avr, 0x1d5a);
        assert(avr->data[16] == nm_avr_scientific_idle_result(key));

        uint8_t channel = key;
        enter_fragment(avr, 0x4894);
        avr->data[10] = 0;
        avr->data[11] = 4;
        avr->data[0x435] = channel;
        _avr_push_addr(avr, 0x7000);
        stage14_until(avr, 0x7000);
        assert(nm_avr_adc_next_channel(&channel) == !!avr->sreg[0]);
        assert(channel == avr->data[0x435] && channel == avr->data[16]);
    }
    for (unsigned sample = 0; sample < 32; ++sample) {
        uint8_t child[22];
        for (unsigned i = 0; i < sizeof child; ++i)
            child[i] = 0x11u * sample + 13u * i;
        enter_fragment(avr, 0x1848);
        avr->data[26] = 0x50;
        avr->data[27] = 4;
        memcpy(avr->data+0x450, child, sizeof child);
        _avr_push_addr(avr, 0x7000);
        stage14_until(avr, 0x7000);
        nm_avr_scientific_init_digit(child);
        assert(!memcmp(avr->data+0x450, child, sizeof child));
        assert(helper_word(avr, 16, 2) == 0x450);
    }
    for (unsigned i = 0; i < 32; ++i) {
        Fixture fixture = {0};
        NM8036 m = fixture_device(&fixture);
        uint16_t address = (uint16_t)(0x360 + 13u * i);
        enter_fragment(avr, 0x118e);
        avr->data[16] = (uint8_t)address;
        avr->data[17] = address >> 8;
        avr->sreg[7] = i & 1;
        _avr_push_addr(avr, 0x7000);
        stage14_until(avr, 0x7000);
        fixture.irq = (i & 1) ? 0x80 : 0;
        nm_avr_calibration_bind(&m,address);
        assert(fixture.irq == 0);
        assert(*nm_ram(&m,0x67d) == avr->data[0x67d]);
        assert(*nm_ram(&m,0x67e) == avr->data[0x67e]);
        assert(!avr->sreg[7]);
    }
    const uint8_t digit_paths[][4] = {{1,1,4,0}, {4,4,1,5}, {1,4,1,2}, {4,1,4,3}};
    for (unsigned path = 0; path < sizeof digit_paths / sizeof *digit_paths; ++path) {
        uint8_t parent[20] = {0}, child[22] = {0};
        parent[9] = 1;
        parent[12] = 0x50; parent[13] = 4; parent[14] = 1;
        nm_avr_scientific_init_digit(child);
        child[10] = child[14] = path + 3;
        for (unsigned action = 0; action < sizeof *digit_paths; ++action) {
            uint8_t key = digit_paths[path][action];
            NumericLcdTrace expected = {0}, observed = {0};
            NMNumericDisplay lcd = {&expected,numeric_lcd_pos,numeric_lcd_write};
            enter_fragment(avr,0x1cd4);
            avr->data[26] = avr->data[30] = 0;
            avr->data[27] = avr->data[31] = 4;
            avr->data[18] = key;
            memcpy(avr->data+0x400,parent,sizeof parent);
            memcpy(avr->data+0x450,child,sizeof child);
            bool done = nm_avr_scientific_step_digit(&lcd,parent,child,key);
            unsigned budget = 2000;
            while (avr->pc != 0x1d50 && avr->pc != 0x1d58 && budget--) {
                if (avr->pc == 0x1e52 || avr->pc == 0x1ee0) {
                    if (avr->pc == 0x1e52)
                        numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                    else
                        numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                    avr->pc = 0x2190;
                }
                step(avr);
            }
            assert(avr->pc == (done ? 0x1d50 : 0x1d58));
            assert(done == (action == sizeof *digit_paths - 1));
            assert(observed.count == expected.count);
            assert(!memcmp(observed.bytes,expected.bytes,expected.count));
            assert(!memcmp(avr->data+0x400,parent,sizeof parent));
            assert(!memcmp(avr->data+0x450,child,sizeof child));
        }
    }
    puts("stage22: 16 active digit actions with SRAM and LCD comparison, 32 calibration field bindings");
    puts("stage21: 256 editor return codes, 256 ADC channel counter states, 32 child initializations");
    for (unsigned scientific = 0; scientific < 2; ++scientific) {
        uint8_t digits[8] = "0.00";
        int16_t exponent = -9;
        memcpy(avr->data+0x400,digits,sizeof digits);
        enter_fragment(avr,0x5b94);
        avr->data[0x330] = scientific ? 'e' : 0;
        avr->data[8] = (uint8_t)exponent; avr->data[9] = 0xff;
        avr->data[10] = 0; avr->data[11] = 4;
        avr->data[12] = 4; avr->data[13] = 4;
        avr->data[20] = 0;
        stage14_until(avr,0x5be6);
        size_t length = nm_avr_decimal_leading_carry(digits,4,&exponent,scientific);
        assert(length == helper_word(avr,12,2)-0x400u);
        assert(!memcmp(digits,avr->data+0x400,length));
        assert((uint16_t)exponent == helper_word(avr,8,2));
    }
    for (unsigned i = 0; i < 256; ++i) {
        uint8_t parent[20] = {0}, child[22] = {0};
        parent[9] = i % 10;
        parent[12] = 0x50; parent[13] = 4; parent[14] = 1;
        child[10] = i;
        memcpy(avr->data+0x400,parent,sizeof parent);
        memcpy(avr->data+0x450,child,sizeof child);
        enter_fragment(avr,0x1cda);
        avr->data[26] = 0; avr->data[27] = 4;
        stage14_until(avr,0x1d14);
        nm_avr_scientific_commit_digit(parent,child);
        assert(!memcmp(parent,avr->data+0x400,sizeof parent));

        uint8_t ram[0x500] = {0};
        ram[0x470] = 0x80; ram[0x471] = 4;
        memcpy(avr->data+0x470,ram+0x470,24);
        enter_fragment(avr,0x5e50);
        avr->data[12] = 0x60; avr->data[13] = 4;
        avr->data[0x460] = 0x70; avr->data[0x461] = 4;
        uint16_t count = i * 257u;
        avr->data[0x325] = (uint8_t)count; avr->data[0x326] = count >> 8;
        avr->data[24] = i & 1;
        stage14_until(avr,0x5d08);
        uint16_t argument = 0x470;
        nm_avr_flash_format_count(ram,&argument,count,i & 1);
        assert(argument == 0x472 && avr->data[0x460] == 0x72);
        assert(!memcmp(ram+0x480,avr->data+0x480,8));

        enter_fragment(avr,0x5e76);
        avr->data[12] = 0x60; avr->data[13] = 4;
        avr->data[0x460] = 0x70; avr->data[0x461] = 4;
        ram[0x470] = avr->data[0x470] = i;
        argument = 0x470;
        stage14_until(avr,0x6084);
        assert(avr->data[0x334] == nm_avr_flash_format_char(ram,&argument));
        assert(argument == 0x472 && avr->data[0x460] == 0x72);
    }
    for (unsigned i = 0; i < 12; ++i) {
        static const uint16_t precisions[] = {0,1,7,32,0xffff,0x8000};
        uint16_t precision = precisions[i % 6];
        uint16_t argument = 0x470;
        enter_fragment(avr,0x5e86);
        avr->data[12] = 0x60; avr->data[13] = 4;
        avr->data[0x460] = 0x70; avr->data[0x461] = 4;
        avr->data[0x470] = i < 6 ? 0 : 0x90;
        avr->data[0x471] = i < 6 ? 0 : 4;
        memcpy(avr->data + 0x490,"Example",8);
        avr->data[8] = precision; avr->data[9] = precision >> 8;
        NMFlashString string = nm_avr_flash_format_string(avr->data,&argument,precision);
        stage14_until(avr,0x6084);
        assert(argument == 0x472 && avr->data[0x460] == 0x72);
        if (string.flash) {
            assert((avr->data[0x32c] | avr->data[0x32d] << 8) == string.address);
            assert(helper_word(avr,4,2) == string.length && helper_word(avr,6,2) == 0);
        } else {
            assert(helper_word(avr,6,2) == string.address);
            assert(helper_word(avr,4,2) == string.address + string.length);
        }
    }
    puts("stage17: 256 nested digit commits, 256 %n and 256 %c vectors");
    puts("stage16: 30 end-to-end %9.2e, 16 nested fields, 256 menu returns and 11 format templates");
}

static void check_stage15(avr_t *avr)
{
    static const uint32_t magnitudes[] = {1, 0x007fffff, 0x00800000,
        0x2edbe6ff, 0x2edbe700, 0x3f7fffff, 0x3f800000, 0x41200000,
        0x51ba43b6, 0x51ba43b7, 0x7f7fffff, 0x7fc00000};
    for (unsigned i = 0; i < sizeof magnitudes / sizeof *magnitudes; ++i) {
        NMDecimalScale c = nm_avr_decimal_scale(magnitudes[i]);
        enter_fragment(avr, magnitudes[i] >= 0x3f800000 && magnitudes[i] <= 0x7f800000 ? 0x5a6a : 0x5a9c);
        avr->data[8] = avr->data[9] = 0;
        for (unsigned j = 0; j < 4; ++j)
            avr->data[24+j] = magnitudes[i] >> (8*j);
        avr->data[20] = 2;
        avr->data[21] = 0;
        stage14_until(avr,0x5a2c);
        fprintf(stderr,"scale %08x AVR=%08x/%d C=%08x/%d\n",magnitudes[i],(unsigned)helper_word(avr,24,4),(int16_t)helper_word(avr,8,2),c.magnitude,c.exponent);
        assert(helper_word(avr,24,4) == c.magnitude);
        assert(helper_word(avr,8,2) == (uint16_t)c.exponent);
    }
    static const char *const carries[] = {"0.00","0.09","0.99","9.99","99","8.9","3.500"};
    for (unsigned i = 0; i < sizeof carries / sizeof *carries; ++i) {
        uint8_t text[16] = {0};
        size_t length = strlen(carries[i]);
        memcpy(text,carries[i],length);
        memcpy(avr->data+0x400,text,length);
        enter_fragment(avr,0x5b64);
        avr->data[10] = 0; avr->data[11] = 4;
        avr->data[12] = length; avr->data[13] = 4;
        unsigned budget = 300;
        while (avr->pc != 0x5be6 && avr->pc != 0x5b94 && budget--)
            step(avr);
        bool overflow = nm_avr_decimal_carry(text,length);
        assert(avr->pc == (overflow ? 0x5b94 : 0x5be6));
        assert(!memcmp(text,avr->data+0x400,length));
        if (i != 3 && i != 4) {
            memcpy(avr->data+0x400,carries[i],length);
            enter_fragment(avr,0x5bf4);
            avr->data[12] = length; avr->data[13] = 4;
            stage14_until(avr,0x5c06);
            assert(helper_word(avr,12,2) == 0x400u+nm_avr_decimal_trim((const uint8_t*)carries[i],length));
        }
    }
    for (int exponent = -100; exponent <= 100; ++exponent) {
        uint8_t buffer[8] = {0};
        size_t length = nm_avr_decimal_exponent(buffer,'e',exponent);
        memset(avr->data+0x400,0,32);
        enter_fragment(avr,0x5c06);
        avr->data[0x330] = 'e';
        avr->data[8] = (uint8_t)exponent;
        avr->data[9] = (uint16_t)exponent >> 8;
        avr->data[12] = 0; avr->data[13] = 4;
        stage14_until(avr,0x5c7c);
        assert(helper_word(avr,12,2) == 0x400u+length);
        assert(!memcmp(buffer,avr->data+0x400,length));
    }
    for (unsigned width = 0; width < 20; ++width)
        for (unsigned sign = 0; sign < 2; ++sign) {
            enter_fragment(avr,0x6084);
            avr->data[4] = 9; avr->data[5] = 4;
            avr->data[6] = 1; avr->data[7] = 4;
            avr->data[10] = width; avr->data[11] = 0;
            avr->data[0x321] = sign ? '-' : 0;
            stage14_until(avr,0x60a4);
            assert(helper_word(avr,24,2) == nm_avr_decimal_padding(width,0x409,0x401,sign));
        }
    const uint16_t callbacks[] = {0x16ea,0x18d4,0x1afe};
    for (unsigned kind = 0; kind < sizeof callbacks / sizeof *callbacks; ++kind)
        for (unsigned i = 0; i < 16; ++i) {
            uint8_t field[22] = {0};
            field[2] = i&1; field[3] = i&2;
            for (unsigned j = 4; j < 9; ++j)
                field[j] = (i+j)%10;
            field[9] = i%9;
            field[10] = kind == 2 ? i%3 : i;
            field[11] = kind == 2 ? 1 : 0;
            if (kind == 0 && (i&1))
                field[13] = 0x80;
            if (kind == 0 && (i&2)) {
                field[18] = 0x5e; field[19] = 1;
            }
            if (kind == 1) {
                field[18] = 1; field[19] = i&1;
            }
            if (kind == 2 && (i&2)) {
                field[15] = 0x5e; field[16] = 1;
            }
            NumericLcdTrace c = {0}, observed = {0};
            NMNumericDisplay lcd = {&c,numeric_lcd_pos,numeric_lcd_write};
            if (kind == 0)
                nm_avr_editor_redraw_word(&lcd,field,flash);
            else if (kind == 1)
                nm_avr_editor_redraw_digit(&lcd,field);
            else
                nm_avr_editor_redraw_scientific(&lcd,field,flash);
            memcpy(avr->data+0x400,field,sizeof field);
            enter_fragment(avr,callbacks[kind]);
            avr->data[16] = 0; avr->data[17] = 4;
            _avr_push_addr(avr,0x7000);
            unsigned budget = 120000;
            while (avr->pc != 0x7000 && budget--) {
                if (avr->pc == 0x1e86) {
                    numeric_lcd_write(&observed,1,0);
                    avr->pc = 0x2190;
                } else if (avr->pc == 0x1e52) {
                    numeric_lcd_pos(&observed,avr->data[16],avr->data[17]);
                    avr->pc = 0x2190;
                } else if (avr->pc == 0x1ee0 || avr->pc == 0x1efa) {
                    numeric_lcd_write(&observed,avr->data[16],avr->data[17]);
                    avr->pc = 0x2190;
                }
                step(avr);
            }
            assert(avr->pc == 0x7000);
            if (observed.count != c.count || memcmp(observed.bytes,c.bytes,c.count)) {
                fprintf(stderr,"callback %04x case %u: expected %u, AVR %u\n",callbacks[kind],i,c.count,observed.count);
                for (unsigned j=0; j<c.count || j<observed.count; ++j)
                    fprintf(stderr,"%02x:%02x ",c.bytes[j],observed.bytes[j]);
                fputc('\n',stderr);
            }
            assert(observed.count == c.count && !memcmp(c.bytes,observed.bytes,c.count));
            assert(!memcmp(avr->data+0x400,field,sizeof field));
        }
    for (unsigned channel = 0; channel < 2; ++channel) {
        NumericLcdTrace c = {0};
        NMNumericDisplay lcd = {&c,numeric_lcd_pos,numeric_lcd_write};
        uint16_t number = nm_avr_adc_position(&lcd, channel);
        enter_fragment(avr, 0x47d4);
        avr->data[8] = channel;
        avr->data[9] = 0;
        stage14_until(avr, 0x1e52);
        assert(c.count == 3 && c.bytes[1] == avr->data[16] && c.bytes[2] == avr->data[17]);
        avr->pc = 0x2190;
        stage14_until(avr, 0x47dc);
        assert(helper_word(avr,26,2) == number);
        uint32_t args[3], word = UINT32_C(0xcb189680) + channel;
        nm_avr_adc_scientific_draw(number,word,adc_format_capture,args);
        enter_fragment(avr,0x4820);
        avr->data[26] = number; avr->data[27] = 0;
        for (unsigned j = 0; j < 4; ++j)
            avr->data[4+j] = word >> (8*j);
        stage14_until(avr,0x4826);
        uint16_t y = helper_word(avr,28,2);
        assert(args[0] == helper_word(avr,16,2));
        assert(args[1] == (uint32_t)(avr->data[y] | (uint16_t)avr->data[y+1]<<8));
        uint32_t stacked = 0;
        for (unsigned j = 0; j < 4; ++j)
            stacked |= (uint32_t)avr->data[y+2+j] << (8*j);
        assert(stacked == args[2]);
    }
    puts("stage15: decimal scaling, carry/trim, 201 exponents, 40 widths, 48 callback traces");
}

static void check_stage14(avr_t *avr)
{
    uint32_t random = 314;
    for (unsigned i = 0; i < 4096; ++i) {
        random = random * UINT32_C(1664525) + UINT32_C(1013904223);
        uint32_t a = random;
        uint32_t b = a ^ UINT32_C(0x8070f102);
        if (i < 16) {
            a = (uint32_t)i;
            b = UINT32_C(0x80000000) | (i << 23);
        }
        run_helper(avr, 0x64d0, a, b);
        NMFloatParts left = nm_avr_unpack_binary32(a), right = nm_avr_unpack_binary32(b);
        assert(helper_word(avr, 16, 3) == left.mantissa && avr->data[19] == left.exponent);
        assert(helper_word(avr, 20, 3) == right.mantissa && avr->data[23] == right.exponent);
        assert(avr->data[0] == (left.negative ? 128 : 0));
        assert(avr->data[1] == (right.negative ? 128 : 0));
        assert((bool)avr->sreg[6] == left.negative);
        uint8_t exponent = i;
        if (i < 512)
            a = ((i & 256) ? UINT32_C(0xffffff00) : 0) | 128u;
        avr->data[30] = (uint8_t)a;
        avr->data[0] = left.negative ? 128 : 0;
        avr->sreg[6] = i & 1;
        run_helper(avr, 0x64fa, (a >> 8) | ((uint32_t)exponent << 24), 0);
        uint32_t expected = nm_avr_pack_binary32(a, exponent, left.negative, i & 1);
        if (helper_word(avr, 16, 4) != expected)
            fprintf(stderr, "pack %08x exp=%u avr=%08x c=%08x\n",(unsigned)a,exponent,
                    (unsigned)helper_word(avr,16,4),(unsigned)expected);
        assert(helper_word(avr, 16, 4) == expected);
    }
    const uint16_t tables[] = {0x0180, 0x0182, 0x0184};
    for (unsigned i = 0; i < sizeof tables / sizeof *tables; ++i) {
        enter_fragment(avr, 0x198a);
        avr->data[26] = 0;
        avr->data[27] = 4;
        avr->data[0x414] = tables[i];
        avr->data[0x415] = tables[i] >> 8;
        stage14_until(avr, 0x1996);
        step(avr);
        assert(avr->pc == nm_avr_redraw_callback(flash, tables[i]));
    }
    for (unsigned i = 0; i < 256; ++i) {
        enter_fragment(avr, 0x457e);
        avr->data[0x073c] = i;
        avr->data[0x073f] = 0xa5;
        avr->data[0x0735] = 0x11;
        stage14_until(avr, nm_avr_display_entry(i));
        assert(avr->data[16] == 0xa5 && avr->data[17] == 0x11);
        enter_fragment(avr, 0x4792);
        avr->data[16] = i;
        stage14_until(avr, 0x47d4);
        assert(helper_word(avr, 24, 2) == nm_avr_adc_template(i));
    }
    for (unsigned i = 0; i < 20; ++i)
        for (uint8_t key = 1; key <= 5; ++key) {
            uint8_t field[20] = {0};
            field[2] = i >> 1; field[3] = i >> 2; field[9] = i % 10;
            for (unsigned j = 4; j < 9; ++j)
                field[j] = i+j;
            memcpy(avr->data + 0x400, field, sizeof field);
            enter_fragment(avr, 0x1bde);
            avr->data[26] = avr->data[30] = 0;
            avr->data[27] = avr->data[31] = 4;
            avr->data[25] = key;
            uint8_t digit = avr->data[24] = 0xa5;
            bool sign = nm_avr_digit_selection(field,key,&digit);
            bool lcd = false;
            unsigned budget = 100;
            while (avr->pc != 0x1c30 && avr->pc != 0x1cc6 && budget--) {
                if (avr->pc == 0x1d7e) {
                    lcd = true;
                    avr->pc = 0x2190;
                }
                step(avr);
            }
            assert(avr->pc == (key == 1 || key == 4 ? 0x1c30 : 0x1cc6));
            assert(sign == lcd && digit == avr->data[24]);
            assert(!memcmp(field,avr->data + 0x400,sizeof field));
        }
    const uint32_t adc_words[] = {0,0x80000000,0x4cbebc1f,0x4cbebc20,0x4cbebc21,
        0xcb18967e,0xcb18967f,0xcb189680,0x38d1b716,0x38d1b717,0x38d1b718,
        0xb8d1b715,0xb8d1b716,0xb8d1b717,0x7f800000,0xff800000,0xffff0000};
    for (unsigned i = 0; i < sizeof adc_words / sizeof *adc_words; ++i) {
        enter_fragment(avr, 0x47dc);
        for (unsigned j = 0; j < 4; ++j)
            avr->data[4+j] = adc_words[i] >> (8*j);
        unsigned budget = 2000;
        while (avr->pc != 0x4820 && avr->pc != 0x43b8 && budget--)
            step(avr);
        assert(avr->pc == (nm_avr_adc_scientific(adc_words[i]) ? 0x4820 : 0x43b8));
    }
    for (unsigned i = 0; i < 90; ++i) {
        uint8_t parent[20] = {0}, child[22];
        memset(child, 0xa7, sizeof child);
        parent[7] = (i / 10) % 3 + 2;
        parent[8] = (i / 30) + 7;
        parent[9] = i % 10;
        parent[12] = 0x50;
        parent[13] = 4;
        memcpy(avr->data + 0x400, parent, sizeof parent);
        memcpy(avr->data + 0x450, child, sizeof child);
        enter_fragment(avr, 0x1c52);
        avr->data[17] = 4;
        avr->data[26] = avr->data[30] = 0;
        avr->data[27] = avr->data[31] = 4;
        stage14_until(avr, 0x1ca4);
        nm_avr_digit_limits(parent, child);
        assert(!memcmp(child,avr->data + 0x450,sizeof child));
    }
    static const uint32_t inputs[] = {0,0x80000000,0x3f800000,0xc1200000,
        0x3f80a3d7,0x3f80a3d8,0x7f7fffff,0x00800000,0x00000001,0x7fc00000};
    for (unsigned i = 0; i < sizeof inputs / sizeof *inputs; ++i) {
        uint8_t editor[20] = {0};
        ScientificInput f = {.word = inputs[i]};
        memset(avr->data + 0x400,0,sizeof editor);
        enter_fragment(avr,0x19f0);
        avr->data[16] = 0;
        avr->data[17] = 4;
        for (unsigned j = 0; j < 4; ++j)
            avr->data[20+j] = f.word >> (8*j);
        stage14_until(avr,0x1a0e);
        uint16_t y = helper_word(avr,28,2);
        assert(y == 0x30a);
        memcpy(f.text,avr->data + y,sizeof f.text);
        assert(f.text[9] == 0);
        nm_avr_scientific_load(editor, f.word, fixture_scientific_format, &f);
        stage14_until(avr,0x1a54);
        assert(!memcmp(editor,avr->data + 0x400,sizeof editor));
        printf("stage14 %%9.2e %08x |%s|\n",(unsigned)f.word,f.text);
    }
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    uint8_t original[1024] = {0};
    avr_eeprom_desc_t ee = {original, 0, sizeof original};
    for (uint8_t index = 0; index < 32; ++index) {
        uint32_t word = UINT32_C(0x9c95a0ef) * index;
        avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
        enter_fragment(avr,0x1106);
        for (unsigned j = 0; j < 4; ++j)
            avr->data[16+j] = word >> (8*j);
        avr->data[24] = index*4u;
        avr->data[25] = 0;
        stage14_until(avr,0x110c);
        nm_avr_calibration_commit(&m,index,word);
        enter_fragment(avr,0x10e0);
        avr->data[24] = index*4u;
        avr->data[25] = 0;
        stage14_until(avr,0x10ea);
        assert(helper_word(avr,20,4) == nm_avr_calibration_read(&m,index));
        enter_fragment(avr,0x117a);
        avr->data[16] = (uint8_t)word;
        avr->data[24] = index;
        avr->data[25] = 0;
        stage14_until(avr,0x1180);
        nm_avr_calibration_unit_commit(&m,index,word);
        avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
        assert(!memcmp(f.ee,original,sizeof original));
    }
    puts("stage14: 4096 float states, 3 callbacks, 512 page/format choices, 100 digit states and 17 ADC boundaries");
}

static void check_numeric_algorithms(void)
{
    static const uint32_t vectors[] = {
        0,1,0x80000000,0x7fffffff,0xffffffff,0x01000001,0x01000003,
        0x3f800000,0xbf800000,0x4effffff,0xcf000000,0x7f800000,0xff800000,
        0x7f800001,0xffff0000,0x007fffff,0x807fffff
    };
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    check_ram_formatter(avr);
    check_stage18(avr);
    check_digit_open(avr);
    check_digit_dispatch(avr);
    check_calibration_and_adc(avr);
    check_unit_editor(avr);
    check_display_helpers(avr);
    check_calibration_route(avr);
    check_calibration_interval(avr);
    check_calibration_menu_lcd(avr);
    check_stage16_decimal(avr);
    check_stage15(avr);
    check_stage14(avr);
    uint32_t random = 17;
    for (unsigned i = 0; i < 1024; ++i) {
        random = random * UINT32_C(1664525) + UINT32_C(1013904223);
        uint32_t word = i < sizeof vectors / sizeof *vectors ? vectors[i] : random;
        bool sticky = i % 2;
        avr->sreg[6] = sticky;
        run_helper(avr, 0x6550, word, 0);
        if (helper_word(avr,16,4) != nm_avr_int_to_binary32(word,true,sticky)) fprintf(stderr,"int word=%08x AVR=%08x C=%08x\n", (unsigned)word,(unsigned)helper_word(avr,16,4),(unsigned)nm_avr_int_to_binary32(word,true,sticky));
        assert(helper_word(avr,16,4) == nm_avr_int_to_binary32(word,true,sticky));
        avr->sreg[6] = sticky;
        run_helper(avr, 0x6566, word, 0);
        assert(helper_word(avr,16,4) == nm_avr_int_to_binary32(word,false,sticky));
        run_helper(avr, 0x656a, word, 0);
        assert(helper_word(avr,16,4) == nm_avr_binary32_to_int(word));
        run_helper(avr, 0x65a0, word, 0);
        uint8_t flags = avr->sreg[0] | avr->sreg[1]*2u | avr->sreg[3]*8u | avr->sreg[6]*64u;
        assert(flags == nm_avr_binary32_flags(word));
        run_helper(avr, 0x65ce, 0, word);
        flags = avr->sreg[0] | avr->sreg[1]*2u | avr->sreg[3]*8u | avr->sreg[6]*64u;
        assert(flags == nm_avr_binary32_flags(word));
    }
    for (unsigned i = 0; i < sizeof vectors / sizeof *vectors; ++i)
        for (unsigned j = 0; j < sizeof vectors / sizeof *vectors; ++j) {
            uint32_t a = vectors[i], b = vectors[j];
            run_helper(avr, 0x68c0, a, b);
            assert((bool)avr->sreg[1] == nm_avr_binary32_equal(a,b));
            run_helper(avr, 0x68d4, a, b);
            assert((bool)avr->sreg[0] == nm_avr_binary32_less(a,b));
            run_helper(avr, 0x6904, a, b);
            assert((bool)avr->sreg[0] == nm_avr_binary32_ge(a,b));
        }
    for (unsigned i = 0; i < 256; ++i) {
        uint8_t field[22];
        memset(field, 0xa5, sizeof field);
        memcpy(avr->data + 0x400, field, sizeof field);
        run_helper(avr, 0x1892, ((uint32_t)(255-i)<<24) | ((uint32_t)i<<16) | 0x400, 0);
        nm_avr_editor_set_limits(field, i, 255-i);
        assert(!memcmp(field, avr->data + 0x400, sizeof field));
        field[4] = i % 10;
        field[5] = (i / 10) % 10;
        field[6] = i % 7;
        field[7] = 3;
        field[8] = i % 11;
        memcpy(avr->data + 0x400, field, sizeof field);
        /* enter_fragment меняет X: устанавливаем его после входа. */
        enter_fragment(avr, 0x1d14);
        avr->data[26] = avr->data[30] = 0;
        avr->data[27] = avr->data[31] = 4;
        unsigned budget = 100;
        while (avr->pc != 0x1d50 && budget--)
            step(avr);
        assert(avr->pc == 0x1d50);
        nm_avr_scientific_limit(field);
        assert(!memcmp(field, avr->data + 0x400, sizeof field));
        field[2] = i & 1;
        field[3] = (i >> 1) & 1;
        field[7] = (i / 19) % 4;
        field[8] = i % 10;
        memcpy(avr->data + 0x400, field, sizeof field);
        run_helper(avr, 0x1a60, 0x400, 0);
        assert(helper_word(avr,16,4) == nm_avr_scientific_value(field));
    }
    for (unsigned i = 0; i < 128; ++i) {
        uint8_t field[22];
        memset(field, 0, sizeof field);
        uint8_t text[] = "-3.43e-08";
        text[0] = i & 1 ? '+' : '-';
        text[1] = '0' + i % 10;
        text[3] = '0' + (i / 10) % 10;
        text[4] = (uint8_t)(i + 32);
        text[6] = i & 2 ? '+' : '-';
        text[7] = '0' + (i / 7) % 10;
        text[8] = '0' + i % 10;
        memcpy(avr->data + 0x320, text, 9);
        memcpy(avr->data + 0x400, field, sizeof field);
        nm_avr_scientific_digits(field,text);
        enter_fragment(avr, 0x1a0e);
        avr->data[26] = 0;
        avr->data[27] = 4;
        while (avr->pc != 0x1a54)
            step(avr);
        assert(!memcmp(field, avr->data + 0x400, sizeof field));
        uint8_t key = i & 15;
        field[2] = 250; field[3] = field[4] = field[5] = 255;
        field[6] = 4;
        field[10] = ((i >> 4) & 7) - 3;
        field[11] = field[12] = field[13] = field[10] > 127 ? 255 : 0;
        memcpy(avr->data + 0x400, field, sizeof field);
        NMNumericEditResult result = nm_avr_editor_adjust_word(field, key);
        avr->data[16] = 0; avr->data[17] = 4; avr->data[18] = key;
        /* 0x198A читает указатель из записи; выбираем валидную
           таблицу и перехватываем только внешний обработчик. */
        avr->data[0x414] = 0x82; avr->data[0x415] = 1;
        field[20] = 0x82; field[21] = 1;
        enter_fragment(avr, 0x18ee);
        _avr_push_addr(avr, 0x7000);
        bool redraw = false;
        unsigned budget = 1000;
        while (avr->pc != 0x7000 && budget--) {
            if (avr->pc == 0x1996) {
                redraw = true;
                avr->pc = 0x2190;
            }
            step(avr);
        }
        assert(avr->pc == 0x7000);
        assert((bool)avr->data[16] == result.accepted);
        assert(redraw == result.redraw);
        assert(!memcmp(field, avr->data + 0x400, sizeof field));
    }
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    uint8_t original[1024] = {0};
    avr_eeprom_desc_t ee = {original, 0, sizeof original};
    for (unsigned value = 0; value < 256; ++value)
        for (uint8_t key = 1; key <= 4; ++key) {
            const uint8_t index = value % 7;
            f.ee[0x10 + index] = original[0x10 + index] = value;
            avr_ioctl(avr, AVR_IOCTL_EEPROM_SET, &ee);
            enter_fragment(avr, 0x0fd8);
            avr->data[18] = index;
            avr->data[19] = 0;
            avr->data[0x0739] = key | 0x80;
            unsigned budget = 40000;
            while (avr->pc != 0x1012 && budget--)
                step(avr);
            assert(avr->pc == 0x1012);
            nm_avr_display_interval_key(&m, index, key | 0x80);
            avr_ioctl(avr, AVR_IOCTL_EEPROM_GET, &ee);
            assert(!memcmp(original, f.ee, sizeof original));
        }
    for (unsigned i = 0; i < 9; ++i)
        for (unsigned direction = 0; direction < 2; ++direction) {
            enter_fragment(avr, 0x1bb4);
            avr->data[17] = avr->data[27] = avr->data[31] = 4;
            avr->data[26] = avr->data[30] = 0;
            avr->data[25] = direction ? 3 : 2;
            avr->data[0x409] = i;
            unsigned budget = 50;
            while (avr->pc != 0x1bc8 && budget--)
                step(avr);
            assert(avr->pc == 0x1bc8);
            assert(nm_avr_scientific_cursor(i, direction) == avr->data[0x409]);
        }
    avr_terminate(avr);
    free(avr);
    puts("Numeric stage13: conversions, SREG, decimal fields and word editor verified");
}

static void check_original_helpers(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr_loadcode(avr, flash, sizeof flash, 0);
    for (unsigned a = 0; a < 256; ++a)
        for (unsigned b = 0; b < 256; ++b) {
            uint8_t remainder;
            run_helper(avr, 0x637e, a, b);
            assert(avr->data[16] == nm_avr_div8(a, b, &remainder));
            assert(avr->data[20] == remainder);
        }

    uint32_t rng = UINT32_C(0x9dc31e8a);
    for (unsigned i = 0; i < 1024; ++i) {
        uint32_t a = rng = rng * UINT32_C(1664525) + UINT32_C(1013904223);
        uint32_t b = rng = rng * UINT32_C(1664525) + UINT32_C(1013904223);
        uint8_t count = (uint8_t)i;
        uint32_t remainder32;
        uint16_t remainder16;
        if ((i & 15) == 0)
            b >>= 24;
        if ((i & 15) == 1)
            b = 0;
        if (i == 2) {
            a = 0x8000;
            b = 0xffff;
        }
        run_helper(avr, 0x6374, a, count);
        assert(helper_word(avr, 16, 1) == nm_avr_shl8(a, count));
        run_helper(avr, 0x63aa, a, count);
        assert(helper_word(avr, 16, 2) == nm_avr_shl16(a, count));
        run_helper(avr, 0x63b6, a, count);
        assert(helper_word(avr, 16, 2) == nm_avr_asr16(a, count));
        run_helper(avr, 0x645a, a, count);
        assert(helper_word(avr, 16, 4) == nm_avr_shl32(a, count));
        run_helper(avr, 0x646a, a, count);
        assert(helper_word(avr, 16, 4) == nm_avr_lsr32(a, count));
        run_helper(avr, 0x639a, a, b);
        assert(helper_word(avr, 16, 2) == nm_avr_mul16(a, b));
        run_helper(avr, 0x641a, a, b);
        assert(helper_word(avr, 16, 4) == nm_avr_mul32(a, b));
        run_helper(avr, 0x63c2, a, b);
        assert(helper_word(avr, 16, 2) == nm_avr_div16(a, b, &remainder16));
        assert(helper_word(avr, 20, 2) == remainder16);
        run_helper(avr, 0x63f2, a, b);
        assert(helper_word(avr, 16, 2) == nm_avr_sdiv16(a, b, &remainder16));
        assert(helper_word(avr, 20, 2) == remainder16);
        run_helper(avr, 0x647a, a, b);
        assert(helper_word(avr, 16, 4) == nm_avr_div32(a, b, &remainder32));
        assert(helper_word(avr, 20, 4) == remainder32);
        run_helper(avr, 0x64c0, a, 0);
        assert(helper_word(avr, 16, 4) == nm_avr_neg32(a));
    }
    for (uint16_t size = 0; size <= 16; ++size) {
        uint8_t reference[18];
        memset(reference, 0x4b, sizeof reference);
        memset(avr->data + 0x300, 0x4b, sizeof reference);
        nm_avr_fill_bytes(reference + 1, 0xa3, size);
        run_helper(avr, 0x6a66, 0x00a30301, size);
        assert(!memcmp(avr->data + 0x300, reference, sizeof reference));
        for (unsigned variant = 0; variant < 3; ++variant) {
            memcpy(avr->data + 0x350, reference, sizeof reference);
            if (variant == 1 && size)
                avr->data[0x350 + size/2] = 0xff;
            if (variant == 2 && size)
                avr->data[0x350 + size/2] = 0;
            run_helper(avr, 0x6a38, 0x03500300, size);
            int expected = nm_avr_compare_bytes(reference, avr->data + 0x350, size);
            assert(helper_word(avr, 16, 2) == (uint16_t)expected);
        }
    }
    check_original_heap(avr);
    puts("Original helpers: 65536 byte divisions, 11264 word operations, 68 SRAM cases");
    avr_terminate(avr);
    free(avr);
}

int main(int argc, char **argv)
{
    assert((argc == 4 && !strcmp(argv[2], "dallas")) || argc == 2 || (argc == 3 && (!strcmp(argv[2], "editor") || !strcmp(argv[2], "dallas") || !strcmp(argv[2], "helpers"))));
    FILE *file = fopen(argv[1], "rb");
    assert(file && fread(flash, 1, sizeof flash, file) == sizeof flash);
    assert(fgetc(file) == EOF);
    fclose(file);
    if (argc >= 3) {
        if (!strcmp(argv[2], "helpers")) {
            check_numeric_algorithms();
            check_original_helpers();
            return 0;
        }
        if (!strcmp(argv[2], "editor")) {
            check_display_snapshot();
            check_program_dispatch();
        }
        else {
            check_dallas_dialog_empty();
            if (argc == 4)
                check_dallas_dialog_empty_c(argv[3]);
        }
        return 0;
    }
    check_numeric_algorithms();
    check_original_helpers();
    check_output_and_program_editors();
    check_editor_eeprom();
    check_threshold_editor();
    check_program_conditions();
    check_program_control_confirm();
    check_program_edit_sequence();
    check_display_snapshot();
    check_program_dispatch();
    check_manual_outputs();
    check_menu_lcd_stream();
    check_timer_interrupts();
    check_adc_calibration();
    check_threshold_adc_scale();
    check_threshold_adc_inputs();
    check_editors();
    check_clock_editor();
    check_rom_registration();
    check_dallas_dialog_empty();
    check_dallas_dialog_match();
    check_dallas_search();
    check_dallas_poll();
    check_dallas_stuck_original();
    check_dallas_bounded();
    check_runtime();
    check_settings_menu();
    check_home_page();
    check_startup_and_sensors();
    check_calendar();
    check_schedule();
    check_control();
    check_pulse_outputs();
    const char commands[] = "VDdtsvbiaclz";
    for (unsigned i = 0; commands[i]; i++)
        check((uint8_t)commands[i], 1, 0);
    check('K', 3, 1);
    check('A', 9, 48);
    check('I', 11, 27);
    check('L', 0, 0);
    check('L', 17, 0);
    for (unsigned i = 0; i < 32; i++)
        check('W', i, 28);
    check('W', 255, 28);
    puts("simavr: редакторы программ и выходов, UART, EEPROM, старт, RTC, меню, Dallas, расписания и выходы прошли сравнение");
}
