#include "nm_menu.h"
#include "nm_editors.h"
#include "nm_dallas.h"
#include "nm_peripherals.h"
#include "nm_runtime.h"

#ifdef __AVR__
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <string.h>

/* Собственная C-обвязка для списка и восстановленных экранов.
 * Идентификаторы пунктов берутся из таблиц flash 0x0C0A/0x0C26. */
enum { SETTINGS_LIST, SETTINGS_PWM, SETTINGS_SOUND, SETTINGS_CLOCK, SETTINGS_DALLAS, SETTINGS_PROGRAM,
       SETTINGS_OUTPUT_LIST, SETTINGS_OUTPUT_VALUE, SETTINGS_PROGRAM_ENABLE,
       SETTINGS_PROGRAM_START, SETTINGS_PROGRAM_STOP, SETTINGS_PROGRAM_CONTROL,
       SETTINGS_PROGRAM_COMPARE, SETTINGS_PROGRAM_REFERENCE, SETTINGS_PROGRAM_THRESHOLDS,
       SETTINGS_PROGRAM_LOGIC, SETTINGS_PROGRAM_PERIOD };
static NMSettingsMenu list, output_list;
static uint16_t output_seconds;
static uint8_t view;
static NMPwmSetting setting;
static uint8_t found_rom[NM_RECORDS][8], ordinal, slot, found;
static uint8_t preview[2], preview_state;
static NMProgramTime program_time;
static uint8_t program_control_field;
static NMThresholds thresholds;

static void draw(const NM8036 *m, const uint8_t screen[32])
{
    for (uint8_t row = 0; row < 2; row++)
        nm_atmega32_lcd_text(m, row, 0, screen + 16u * row, 16);
}

/* [БИНАРНИК] Список 0x0240, 24 записи по 17 байт.
 * Заголовок ввода 0x022F. Перенос содержимого DDRAM, положение
 * числового поля уточняется при проверке LCD на оригинале. */
static void draw_output(const NM8036 *m)
{
    static const uint8_t title[] = {0xc2,0xe2,0xe5,0xe4,0xe8,0xf2,0xe5,' ',
                                    0xe2,0xf0,0xe5,0xec,0xff,'(',0xf1,')'};
    uint8_t screen[32];
    memset(screen, ' ', sizeof screen);
    if (view == SETTINGS_OUTPUT_LIST) {
        nm_output_menu_screen(&output_list, screen);
    } else {
        memcpy(screen, title, sizeof title);
        uint16_t value = output_seconds;
        uint8_t col = 23;
        do {
            screen[col--] = '0' + value % 10u;
            value /= 10u;
        } while (value);
    }
    draw(m, screen);
}

/* [БИНАРНИК] 0x5236..0x525E. Номер хранится в 0x0680,
 * копия ROM выбирает адресат Match ROM. Проба использует отдельные
 * два байта, чтобы не портить данные, доступные планировщику. */
static void select_sensor(const NM8036 *m)
{
    *nm_ram(m, 0x0680) = ordinal;
    for (uint8_t i = 0; i < 8; i++)
        *nm_ram(m, 0x0681 + i) = found_rom[ordinal][i];
    nm_dallas_start_conversion(m, &nm_atmega32_onewire);
    preview_state = NM_DALLAS_PENDING;
}

static bool rom_registered(const NM8036 *m, const uint8_t rom[8])
{
    for (uint8_t i = 0; i < 8; i++)
        if (nm_ee_read(m, 0x02f0u + 8u * slot + i) != rom[i])
            return false;
    return true;
}

/* Строки flash 0x09BE, 0x09CB, 0x09DA, 0x09E3, 0x09F5.
 * Сохраняем кодировку LCD. Живой результат — T=%5.1f. */
static void sensor_screen(const NM8036 *m)
{
    static const uint8_t assign[] = {0xcd,0xe0,0xe7,0xed,0xe0,0xf7,0xe8,0xf2,0xfc,' ','N','o',' '};
    static const uint8_t empty1[] = {0xc2,0xee,0xe7,0xec,0xee,0xe6,0xed,0xee,' ',0xf7,0xf2,0xee};
    static const uint8_t empty2[] = {0xe4,0xe0,0xf2,0xf7,0xe8,0xea,0xee,0xe2,' ',0xed,0xe5,0xf2,':','('};
    uint8_t screen[32];
    memset(screen, ' ', sizeof screen);
    if (!found) {
        memcpy(screen, empty1, sizeof empty1);
        memcpy(screen + 16, empty2, sizeof empty2);
        draw(m, screen);
        return;
    }
    memcpy(screen + 16, assign, sizeof assign);
    uint8_t number = slot + 1;
    if (number >= 10)
        screen[29] = '0' + number / 10;
    screen[number >= 10 ? 30 : 29] = '0' + number % 10;
    number = ordinal + 1;
    screen[10] = number < 10 ? ' ' : '0' + number / 10;
    screen[11] = '0' + number % 10;
    screen[12] = '/';
    screen[13] = '0' + found / 10;
    screen[14] = '0' + found % 10;
    screen[15] = rom_registered(m, found_rom[ordinal]) ? 'M' : '-';
    if (preview_state == NM_DALLAS_SAMPLE) {
        int16_t raw = (int16_t)((uint16_t)preview[0] | ((uint16_t)preview[1] << 8));
        uint16_t tenths = ((uint16_t)(raw < 0 ? -(int32_t)raw : raw) + 5u) / 10u;
        screen[0] = 'T';
        screen[1] = '=';
        screen[5] = '.';
        screen[6] = '0' + tenths % 10u;
        tenths /= 10u;
        uint8_t col = 4;
        do {
            screen[col--] = '0' + tenths % 10u;
            tenths /= 10u;
        } while (tenths && col > 1);
        if (raw < 0 && col > 1)
            screen[col] = '-';
    } else if (preview_state == NM_DALLAS_ERROR) {
        screen[0] = '!';
    }
    draw(m, screen);
}

/* [БИНАРНИК] 0x505A..0x50BE. Поиск и кеширование выполняются
 * при входе. Фоновый опрос приостановлен, пока диалог владеет шиной. */
static void discover_sensors(const NM8036 *m)
{
    static const uint8_t searching[] = {0xcf,0xee,0xe8,0xf1,0xea,' ',0xe4,0xe0,0xf2,0xf7,0xe8,0xea,0xee,0xe2};
    static const uint8_t waiting[] = {0xef,0xee,0xe4,0xee,0xe6,0xe4,0xe8,0xf2,0xe5,'.','.','.'};
    nm_atmega32_lcd_clear(m);
    nm_atmega32_lcd_text(m, 0, 1, searching, sizeof searching);
    nm_atmega32_lcd_text(m, 1, 2, waiting, sizeof waiting);
    *nm_ram(m, 0x0738) = 1;
    nm_atmega32_onewire.strong_pullup(nm_atmega32_onewire.context, false);
    uint8_t count = nm_dallas_discovery_count(m, &nm_atmega32_onewire);
    if (count > NM_RECORDS)
        count = NM_RECORDS;
    found = 0;
    while (found < count &&
           nm_dallas_discovery_rom(m, &nm_atmega32_onewire, found, found_rom[found])) {
        /* 0x508C вызывает настройку и блокирующую пробу.
         * Проба запускает первое измерение, результат здесь отбрасывается.
         * После кеширования ROM 0x50A0 снова запускает измерение. */
        nm_dallas_configure_selected(m, &nm_atmega32_onewire);
        (void)nm_dallas_sample_selected_sync(m, &nm_atmega32_onewire);
        nm_dallas_start_conversion(m, &nm_atmega32_onewire);
        found++;
    }
    *nm_ram(m, 0x0744) = found;
    ordinal = slot = 0;
    *nm_ram(m, 0x0743) = 0;
    if (found) {
        nm_atmega32_onewire.strong_pullup(nm_atmega32_onewire.context, false);
        select_sensor(m);
    }
    sensor_screen(m);
}

/* [БИНАРНИК] 0x5104..0x5157. Индекс ROM насыщается на краях,
 * номер назначения циклический. Сравнение ROM для отметки M
 * выполняется и при смене номера, до записи. */
static bool sensor_key(const NM8036 *m, uint8_t key)
{
    if (!found)
        return false;
    uint8_t previous = ordinal;
    if (key == 1 && ordinal + 1u < found)
        ordinal++;
    else if (key == 4 && ordinal)
        ordinal--;
    else if (key == 2 || key == 3) {
        slot = (uint8_t)((slot + (key == 2 ? 31u : 1u)) & 31u);
        *nm_ram(m, 0x0743) = slot;
    } else if (key == 0) {
        (void)nm_dallas_register_rom(m, slot, found_rom[ordinal]);
    }
    if (previous != ordinal) {
        nm_atmega32_onewire.strong_pullup(nm_atmega32_onewire.context, false);
        select_sensor(m);
    }
    return key <= 4;
}

static void decimal_right(uint8_t *end, uint16_t value)
{
    do {
        *--end = '0' + value % 10u;
        value /= 10u;
    } while (value);
}

/* Строки 0x059A, 0x0609, 0x060C, 0x0628..0x069B.
 * Раскладка C до проверки точных колонок форматтера AVR. */
static void draw_program_condition(const NM8036 *m, uint16_t base)
{
    static const uint8_t comparison[] PROGMEM = {0xd3,0xf1,0xf2,0xe0,0xed,'.',' ',0xee,0xf2,0xed,0xee,0xf1,0xe8,0xf2,'.'};
    static const uint8_t other_sensor[] PROGMEM = {0xe4,0xf0,0xf3,0xe3,0xee,0xe3,0xee,' ',0xe4,0xe0,0xf2,0xf7,0xe8,0xea,0xe0};
    static const uint8_t absolute[] PROGMEM = {0xc0,0xe1,0xf1,0xee,0xeb,0xfe,0xf2,0xed,0xe0,0xff};
    static const uint8_t setting[] PROGMEM = {0xf3,0xf1,0xf2,0xe0,0xed,0xee,0xe2,0xea,0xe0};
    static const uint8_t logic[] PROGMEM = {0xd0,0xe5,0xe6,0xe8,0xec,' ',0xe0,0xea,0xf2,0xe8,0xe2,0xed,0xee,0xf1,0xf2,0xe8};
    static const uint8_t period[][16] PROGMEM = {
        {0xcf,0xe5,0xf0,0xe8,0xee,0xe4,0xe0,' ',0xed,0xe5,0xf2},
        {0xcf,0xee,' ',0xe4,0xed,0xff,0xec,' ',0xed,0xe5,0xe4,0xe5,0xeb,0xe8},
        {0xcf,0xee,' ',0xe4,0xed,0xff,0xec,' ',0xec,0xe5,0xf1,0xff,0xf6,0xe0},
        {0xcf,0xee,' ',0xec,0xe5,0xf1,0xff,0xf6,0xe0,0xec,':'},
    };
    uint8_t screen[32];
    memset(screen, ' ', sizeof screen);
    if (view == SETTINGS_PROGRAM_COMPARE) {
        if (nm_ee_read(m, base + 6u) & 0x20u) {
            memcpy_P(screen, comparison, sizeof comparison);
            memcpy_P(screen + 16, other_sensor, sizeof other_sensor);
        } else {
            memcpy_P(screen, absolute, sizeof absolute);
            memcpy_P(screen + 16, setting, sizeof setting);
        }
    } else if (view == SETTINGS_PROGRAM_REFERENCE) {
        screen[0] = 'T';
        decimal_right(screen + 3, (nm_ee_read(m, base + 11u) & 31u) + 1u);
        screen[5] = (nm_ee_read(m, base) >> 6) == 0 ? '<' : '>';
        screen[7] = 'T';
        decimal_right(screen + 10, (nm_ee_read(m, base + 13u) & 31u) + 1u);
    } else if (view == SETTINGS_PROGRAM_THRESHOLDS) {
        screen[0] = 'L';
        screen[16] = 'H';
        screen[1] = screen[17] = ':';
        for (uint8_t i = 0; i < 2; i++) {
            if (thresholds.selected == i && !(PIND & _BV(PD2)))
                continue;
            int16_t value = thresholds.value[i];
            uint16_t magnitude = value < 0 ? (uint16_t)(-(int32_t)value) : (uint16_t)value;
            uint8_t *line = screen + 16u * i;
            if (thresholds.analog) {
                decimal_right(line + 8, magnitude);
            } else {
                uint16_t tenths = (magnitude + 5u) / 10u;
                line[6] = '.';
                line[7] = '0' + tenths % 10u;
                decimal_right(line + 6, tenths / 10u);
                if (value < 0)
                    line[tenths < 100 ? 4 : 3] = '-';
            }
        }
    } else if (view == SETTINGS_PROGRAM_LOGIC) {
        memcpy_P(screen, logic, sizeof logic);
        static const uint8_t or_text[] PROGMEM = {0xcb,0xce,0xc3,0xc8,0xd7,0xc5,0xd1,0xca,0xce,0xc5,' ','"',0xc8,0xcb,0xc8,'"'};
        static const uint8_t and_text[] PROGMEM = {' ',0xcb,0xce,0xc3,0xc8,0xd7,0xc5,0xd1,0xca,0xce,0xc5,' ','"',0xc8,'"',' '};
        memcpy_P(screen + 16, nm_ee_read(m, base + 12u) & 0x80u ? and_text : or_text, 16);
    } else {
        uint8_t mode = nm_ee_read(m, base + 1u) >> 6;
        for (uint8_t i = 0; i < 16; i++) {
            uint8_t c = pgm_read_byte(&period[mode][i]);
            if (!c)
                break;
            screen[i] = c;
        }
        if (mode) {
            uint8_t item = *nm_ram(m, 0x06b8);
            decimal_right(screen + 24, item + 1u);
            if (item < 32)
                screen[29] = nm_ee_read(m, base + 17u + item / 8u) & (1u << (item & 7u))
                    ? '+' : '-';
        }
    }
    draw(m, screen);
}

static void draw_program(const NM8036 *m, uint8_t index)
{
    if (view >= SETTINGS_PROGRAM_COMPARE) {
        draw_program_condition(m, 0x4cu + 21u * index);
        return;
    }
    uint8_t screen[32];
    nm_program_overview(m, index, screen);
    if (view != SETTINGS_PROGRAM) {
        static const uint8_t title[] = {0xd8,0xc0,0xc3};
        static const uint8_t on[] = {0xc2,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
        static const uint8_t off[] = {0xc2,0xfb,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
        memset(screen, ' ', sizeof screen);
        memcpy(screen + 5, title, sizeof title);
        screen[9] = index < 9 ? ' ' : '0' + (index + 1u) / 10u;
        screen[10] = '0' + (index + 1u) % 10u;
        if (view == SETTINGS_PROGRAM_ENABLE) {
            if (nm_program_enabled(m, index))
                memcpy(screen + 20, on, sizeof on);
            else
                memcpy(screen + 20, off, sizeof off);
        } else if (view == SETTINGS_PROGRAM_CONTROL) {
            /* 0x330E..0x33D6, шаблоны 0x056D и 0x0581. */
            static const uint8_t output[] = {0xcd,0xe0,0xe3,0xf0,0xf3,0xe7,0xea,0xe0,':',' '};
            static const uint8_t kind[] = {0xd2,0xe8,0xef,':',' '};
            static const uint8_t symbol[] = {1,2,0xa9,'x'};
            uint16_t base = 0x4cu + 21u * index;
            uint8_t number = (nm_ee_read(m, base + 12u) & 127u) + 1u;
            memset(screen, ' ', sizeof screen);
            memcpy(screen, output, sizeof output);
            memcpy(screen + 16, kind, sizeof kind);
            if (program_control_field != 0 || (PIND & _BV(PD2))) {
                screen[10] = number < 10 ? ' ' : '0' + number / 10u;
                screen[11] = '0' + number % 10u;
            }
            if (program_control_field != 1 || (PIND & _BV(PD2)))
                screen[21] = symbol[nm_ee_read(m, base) >> 6];
            if (program_control_field != 2 || (PIND & _BV(PD2))) {
                uint8_t number = (nm_ee_read(m, base + 11u) & 31u) + 1u;
                decimal_right(screen + 31, number);
            }
            if (program_control_field != 3 || (PIND & _BV(PD2)))
                screen[31] = nm_ee_read(m, base + 5u) & 0x20u ? 'A' : 'D';
        } else {
            static const uint8_t start[] = {0xf1,0xf2,0xe0,0xf0,0xf2};
            static const uint8_t stop[] = {0xf1,0xf2,0xee,0xef,' '};
            static const uint8_t columns[] = {8,11,14,22,25,30};
            memcpy(screen, view == SETTINGS_PROGRAM_START ? start : stop, sizeof start);
            screen[10] = screen[13] = ':';
            screen[24] = screen[27] = '-';
            screen[28] = '2';
            screen[29] = '0';
            for (uint8_t field = 0; field < 6; field++) {
                uint8_t col = columns[field];
                if (field == program_time.cursor && !(PIND & _BV(PD2)))
                    continue;
                screen[col] = '0' + program_time.field[field] / 10u;
                screen[col + 1] = '0' + program_time.field[field] % 10u;
            }
        }
    }
    draw(m, screen);
}

/* Возвращает false для ещё не восстановленного редактора.
 * Список остаётся на выбранной строке для следующей клавиши. */
bool nm_atmega32_settings_step(NM8036 *m)
{
    volatile uint8_t *visible = nm_ram(m, 0x073a);
    uint8_t key = *nm_ram(m, 0x0739);
    if (!*visible) {
        if ((key & 15u) != 5)
            return false;
        *visible = 1;
        list = (NMSettingsMenu){0};
        view = SETTINGS_LIST;
        nm_atmega32_settings_menu_glyphs(m);
        nm_atmega32_settings_menu_draw(m, &list);
        return true;
    }
    bool opening = view == SETTINGS_LIST;
    if (view >= SETTINGS_PROGRAM_START || view == SETTINGS_PROGRAM_ENABLE ||
        view == SETTINGS_PROGRAM) {
        uint8_t index = *nm_ram(m, 0x06b4);
        uint8_t action = key & 15u;
        if (view == SETTINGS_PROGRAM) {
            if (action == 5) {
                view = SETTINGS_LIST;
                nm_atmega32_settings_menu_draw(m, &list);
                return true;
            }
            if (action == 0)
                view = SETTINGS_PROGRAM_ENABLE;
            else
                index = nm_program_select(m, key);
        } else if (view == SETTINGS_PROGRAM_ENABLE) {
            if (action >= 1 && action <= 4)
                nm_program_toggle(m, index);
            else if (action == 5 || (action == 0 && !nm_program_enabled(m, index)))
                view = SETTINGS_PROGRAM;
            else if (action == 0) {
                nm_program_time_load(m, index, false, &program_time);
                view = SETTINGS_PROGRAM_START;
            }
        } else if (view == SETTINGS_PROGRAM_CONTROL) {
            uint16_t base = 0x4cu + 21u * index;
            if (action == 5)
                view = SETTINGS_PROGRAM;
            else if (action == 2 || action == 3)
                program_control_field = (program_control_field + (action == 2 ? 3u : 1u)) & 3u;
            else if (action == 1 || action == 4) {
                switch (program_control_field) {
                case 0: nm_program_output_key(m, index, key); break;
                case 1: nm_program_kind_key(m, index, key); break;
                case 2: nm_program_sensor_key(m, index, key); break;
                case 3: nm_program_source_key(m, index, key); break;
                }
            } else if (key == 0) {
                if (nm_ee_read(m, base) >> 6 >= 2)
                    view = SETTINGS_PROGRAM_LOGIC;
                else if (nm_ee_read(m, base + 5u) & 0x20u) {
                    nm_program_thresholds_load(m, index, &thresholds);
                    view = SETTINGS_PROGRAM_THRESHOLDS;
                } else
                    view = SETTINGS_PROGRAM_COMPARE;
            }
        } else if (view >= SETTINGS_PROGRAM_COMPARE) {
            uint16_t base = 0x4cu + 21u * index;
            if (key == 5) {
                view = SETTINGS_PROGRAM;
            } else if (view == SETTINGS_PROGRAM_COMPARE) {
                if (action == 1 || action == 4)
                    nm_program_relative_toggle(m, index);
                else if (key == 0) {
                    if (nm_ee_read(m, base + 6u) & 0x20u)
                        view = SETTINGS_PROGRAM_REFERENCE;
                    else {
                        nm_program_thresholds_load(m, index, &thresholds);
                        view = SETTINGS_PROGRAM_THRESHOLDS;
                    }
                }
            } else if (view == SETTINGS_PROGRAM_REFERENCE) {
                nm_program_reference_key(m, index, key);
                if (key == 0)
                    view = SETTINGS_PROGRAM_LOGIC;
            } else if (view == SETTINGS_PROGRAM_THRESHOLDS) {
                nm_program_threshold_key(&thresholds, key);
                if (key == 0) {
                    nm_program_thresholds_save(m, index, &thresholds);
                    view = SETTINGS_PROGRAM_LOGIC;
                }
            } else if (view == SETTINGS_PROGRAM_LOGIC) {
                if (action == 1 || action == 4)
                    nm_program_logic_toggle(m, index);
                else if (key == 0) {
                    *nm_ram(m, 0x06b8) = 0;
                    view = SETTINGS_PROGRAM_PERIOD;
                }
            } else {
                uint8_t period = nm_program_period_key(m, index, key);
                if (!period && key == 0)
                    view = SETTINGS_PROGRAM;
                else
                    nm_program_period_item(m, index, period, key);
            }
        } else {
            nm_program_time_key(&program_time, key);
            if (key == 5)
                view = SETTINGS_PROGRAM_ENABLE;
            else if (key == 0) {
                bool stop = view == SETTINGS_PROGRAM_STOP;
                nm_program_time_save(m, index, stop, &program_time);
                if (stop) {
                    view = SETTINGS_PROGRAM_CONTROL;
                    program_control_field = 0;
                } else {
                    nm_program_time_load(m, index, true, &program_time);
                    view = SETTINGS_PROGRAM_STOP;
                }
            }
        }
        if (key != 0xff || *nm_ram(m, 0x0735))
            draw_program(m, index);
        *nm_ram(m, 0x0735) = 0;
        return true;
    }
    if (view == SETTINGS_OUTPUT_LIST || view == SETTINGS_OUTPUT_VALUE) {
        if (key == 0xff)
            return true;
        uint8_t row = nm_settings_menu_selection(&output_list);
        if (view == SETTINGS_OUTPUT_VALUE) {
            if (nm_output_editor_key(row, &output_seconds, key)) {
                nm_output_save_duration(m, row, output_seconds);
                view = SETTINGS_OUTPUT_LIST;
            }
        } else {
            switch (key & 15u) {
            case 5:
                view = SETTINGS_LIST;
                nm_atmega32_settings_menu_glyphs(m);
                nm_atmega32_settings_menu_draw(m, &list);
                return true;
            case 1: case 4:
                nm_menu_move(&output_list, (key & 15u) == 1 ? -1 : 1, 24);
                break;
            case 0:
                output_seconds = nm_output_duration(m, row);
                view = SETTINGS_OUTPUT_VALUE;
                break;
            }
        }
        draw_output(m);
        return true;
    }
    if (view == SETTINGS_LIST) {
        switch (key & 15u) {
        case 5:
            *visible = 0;
            *nm_ram(m, 0x073f) = 0;
            return true;
        case 1: case 4:
            nm_settings_menu_move(&list, (key & 15u) == 1 ? -1 : 1);
            nm_atmega32_settings_menu_draw(m, &list);
            return true;
        case 0: {
            uint8_t selected = nm_settings_menu_selection(&list);
            if (selected == 7 || selected == 8) {
                setting = selected == 7 ? NM_EDIT_BACKLIGHT : NM_EDIT_CONTRAST;
                nm_pwm_editor_open(m, setting);
                view = SETTINGS_PWM;
            } else if (selected == 9) {
                view = SETTINGS_SOUND;
            } else if (selected == 0) {
                view = SETTINGS_CLOCK;
                nm_atmega32_refresh_clock(m);
            } else if (selected == 1) {
                uint8_t screen[32];
                *nm_ram(m, 0x06b4) = 0;
                view = SETTINGS_PROGRAM;
                nm_program_overview(m, 0, screen);
                draw(m, screen);
                return true;
            } else if (selected == 5) {
                view = SETTINGS_OUTPUT_LIST;
                output_list = (NMSettingsMenu){0};
                draw_output(m);
                return true;
            } else if (selected == 2) {
                view = SETTINGS_DALLAS;
                discover_sensors(m);
                return true;
            } else {
                return false;
            }
            key = 0xff;
            break;
        }
        default:
            return true;
        }
    }

    if (!opening && key == 0xff &&
        (view != SETTINGS_DALLAS && (view != SETTINGS_CLOCK || !*nm_ram(m, 0x0735))))
        return true;
    uint8_t screen[32];
    bool done = false;
    if (view == SETTINGS_PWM) {
        done = nm_pwm_editor_key(m, setting, key) != NM_EDIT_ACTIVE;
        nm_pwm_editor_screen(m, setting, screen);
    } else if (view == SETTINGS_SOUND) {
        done = nm_sound_editor_key(m, key);
        nm_sound_editor_screen(m, screen);
    } else if (view == SETTINGS_CLOCK) {
        done = nm_clock_editor_key(m, key);
        nm_home_clock_screen(m, screen);
        /* [БИНАРНИК] 0x4CAC..0x4D0B. Гашение выбранного поля
         * на низкой фазе SQW, кроме непосредственного изменения. */
        if (!done && !(PIND & _BV(PD2)) && (key & 15u) != 1 && (key & 15u) != 4) {
            static const uint8_t start[] = {0,3,6,9,16,19,28};
            static const uint8_t width[] = {2,2,2,7,2,8,4};
            uint8_t field = *nm_ram(m, 0x0740);
            memset(screen + start[field], ' ', width[field]);
        }
        *nm_ram(m, 0x0735) = 0;
    } else {
        if (key != 5) {
            bool redraw = sensor_key(m, key);
            if (found && preview_state == NM_DALLAS_PENDING) {
                preview_state = nm_dallas_poll_sample(m, &nm_atmega32_onewire, preview);
                redraw |= preview_state != NM_DALLAS_PENDING;
            }
            if (redraw)
                sensor_screen(m);
            return true;
        }
        nm_atmega32_onewire.strong_pullup(nm_atmega32_onewire.context, false);
        if (nm_dallas_load_rom(m, *nm_ram(m, 0x073e)))
            nm_dallas_start_conversion(m, &nm_atmega32_onewire);
        *nm_ram(m, 0x0738) = 0;
        done = true;
    }
    if (done) {
        view = SETTINGS_LIST;
        nm_atmega32_settings_menu_draw(m, &list);
    } else {
        draw(m, screen);
    }
    return true;
}
#endif
