#ifndef NM_ORIGINAL_NUMERIC_H
#define NM_ORIGINAL_NUMERIC_H

#include "nm8036.h"
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    bool accepted;
    bool redraw;
} NMNumericEditResult;

void nm_avr_editor_set_limits(uint8_t field[22], uint8_t lower, uint8_t upper);
NMNumericEditResult nm_avr_editor_adjust_word(uint8_t field[22], uint8_t key);
void nm_avr_scientific_digits(uint8_t field[20], const uint8_t text[9]);
uint8_t nm_avr_scientific_cursor(uint8_t cursor, bool next);
void nm_avr_scientific_limit(uint8_t field[20]);
uint32_t nm_avr_scientific_value(const uint8_t field[20]);
uint32_t nm_avr_int_to_binary32(uint32_t word, bool is_signed, bool sticky);
uint32_t nm_avr_binary32_to_int(uint32_t word);
uint8_t nm_avr_binary32_flags(uint32_t word);

bool nm_avr_binary32_equal(uint32_t left, uint32_t right);
bool nm_avr_binary32_less(uint32_t left, uint32_t right);
bool nm_avr_binary32_ge(uint32_t left, uint32_t right);

void nm_avr_display_interval_key(const NM8036 *m, uint8_t index, uint8_t key);

#endif
