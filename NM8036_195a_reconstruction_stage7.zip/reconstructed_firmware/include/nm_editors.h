#ifndef NM_EDITORS_H
#define NM_EDITORS_H
#include "nm8036.h"

typedef enum { NM_EDIT_BACKLIGHT, NM_EDIT_CONTRAST } NMPwmSetting;
typedef enum { NM_EDIT_ACTIVE, NM_EDIT_SAVED, NM_EDIT_CANCELLED } NMEditResult;

void nm_pwm_editor_open(const NM8036 *m, NMPwmSetting setting);
NMEditResult nm_pwm_editor_key(const NM8036 *m, NMPwmSetting setting, uint8_t key);
bool nm_sound_editor_key(const NM8036 *m, uint8_t key);
bool nm_clock_editor_key(const NM8036 *m, uint8_t key);
void nm_pwm_editor_screen(const NM8036 *m, NMPwmSetting setting, uint8_t screen[32]);
void nm_sound_editor_screen(const NM8036 *m, uint8_t screen[32]);
bool nm_output_editor_key(uint8_t row, uint16_t *seconds, uint8_t key);
typedef struct { uint8_t field[6], cursor; } NMProgramTime;
void nm_program_time_key(NMProgramTime *time, uint8_t key);
void nm_program_time_load(const NM8036 *m, uint8_t index, bool stop, NMProgramTime *time);
void nm_program_time_save(const NM8036 *m, uint8_t index, bool stop, const NMProgramTime *time);
typedef struct { int16_t value[2]; uint8_t selected; bool analog; } NMThresholds;
void nm_program_threshold_key(NMThresholds *editor, uint8_t key);
void nm_program_thresholds_load(const NM8036 *m, uint8_t index, NMThresholds *editor);
void nm_program_thresholds_save(const NM8036 *m, uint8_t index, const NMThresholds *editor);
#endif
