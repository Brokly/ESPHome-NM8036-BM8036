#ifndef NM_NUMERIC_DISPLAY_H
#define NM_NUMERIC_DISPLAY_H
#include <stdint.h>
#include <stdbool.h>
#include "nm8036.h"

typedef struct {
    void *context;
    void (*position)(void *, uint8_t column, uint8_t row);
    void (*write)(void *, uint8_t byte, uint8_t data);
} NMNumericDisplay;

void nm_avr_editor_redraw_word(const NMNumericDisplay *lcd, const uint8_t field[22],
                               const uint8_t *flash);
void nm_avr_editor_redraw_digit(const NMNumericDisplay *lcd, const uint8_t field[22]);
void nm_avr_editor_redraw_scientific(const NMNumericDisplay *lcd, const uint8_t field[20],
                                     const uint8_t *flash);

typedef void (*NMAdcFormat)(void *context, uint16_t flash_format,
                            uint16_t channel_number, uint32_t binary32);
uint16_t nm_avr_adc_position(const NMNumericDisplay *lcd, uint16_t channel);
void nm_avr_adc_scientific_draw(uint16_t channel_number, uint32_t binary32,
                                NMAdcFormat format, void *context);

void nm_avr_lcd_format_ram(const NMNumericDisplay *lcd, const uint8_t *sram,
                           const uint8_t *format, uint16_t argument);

void nm_avr_scientific_open_digit(const NMNumericDisplay *lcd, uint8_t parent[20],
                                   uint8_t child[22], uint8_t value);
typedef uint16_t (*NMNumericAlloc)(void *context, uint16_t size);
typedef uint16_t (*NMNumericSnapshot)(void *context);
bool nm_avr_scientific_begin_digit(const NMNumericDisplay *lcd, uint8_t *sram,
                                  uint8_t parent[20], const uint8_t *flash, uint8_t value,
                                  NMNumericAlloc allocate, NMNumericSnapshot snapshot);
typedef void (*NMNumericRestore)(void *context, uint16_t snapshot_address);
void nm_avr_scientific_end_digit(const NMNumericDisplay *lcd, uint8_t *sram,
                                const uint8_t parent[20], const uint8_t *flash,
                                NMNumericRestore restore);
void nm_avr_scientific_init_digit(uint8_t child[22]);
uint8_t nm_avr_scientific_idle_result(uint8_t key);
bool nm_avr_adc_next_channel(uint8_t *channel);
/* true: обработать следующий канал, false: вернуться в общий цикл. */
bool nm_avr_adc_advance_page(uint16_t *channel);
typedef uint8_t (*NMAdcSettingsStep)(void *context, uint8_t open);
bool nm_avr_adc_step_settings(volatile uint8_t *active, NMAdcSettingsStep step, void *context);
bool nm_avr_adc_finish_menu(volatile uint8_t *active, uint8_t result);

void nm_avr_scientific_commit_digit(uint8_t parent[20], const uint8_t child[22]);
bool nm_avr_scientific_step_digit(const NMNumericDisplay *lcd, uint8_t parent[20],
                                 uint8_t child[22], uint8_t key);
uint8_t nm_avr_scientific_step(const NMNumericDisplay *lcd, uint8_t *sram,
                              uint8_t parent[20], const uint8_t *flash,
                              uint8_t key, uint8_t digit,
                              NMNumericAlloc allocate, NMNumericSnapshot snapshot,
                              NMNumericRestore restore);
uint16_t nm_avr_calibration_open(const NM8036 *m, const NMNumericDisplay *lcd,
                                 uint8_t *sram, const uint8_t *flash, uint8_t index,
                                 bool sticky, NMNumericAlloc allocate, NMNumericSnapshot snapshot);
bool nm_avr_calibration_step(const NM8036 *m, const NMNumericDisplay *lcd,
                             uint8_t *sram, const uint8_t *flash, uint8_t index, uint8_t key,
                             NMNumericAlloc allocate, NMNumericSnapshot snapshot, NMNumericRestore restore);
void nm_avr_adc_load_glyphs(const NMNumericDisplay *lcd, const uint8_t glyphs[64],
                            volatile uint8_t *ready);
uint32_t nm_avr_adc_read_operand(const NM8036 *m, uint16_t base, uint16_t offset);
void nm_avr_unit_open(const NM8036 *m, const NMNumericDisplay *lcd,
                      uint8_t *sram, const uint8_t *flash, uint8_t index,
                      NMNumericAlloc allocate, NMNumericSnapshot snapshot);
bool nm_avr_unit_step(const NM8036 *m, const NMNumericDisplay *lcd,
                      uint8_t *sram, const uint8_t *flash, uint8_t index, uint8_t key,
                      NMNumericRestore restore);
void nm_avr_lcd_fill_spaces(const NMNumericDisplay *lcd, uint8_t first, uint8_t last, uint8_t row);
uint8_t nm_avr_calibration_key(const NM8036 *m);
uint16_t nm_avr_adc_word_offset(uint16_t index);
void nm_avr_adc_compact_position(const NMNumericDisplay *lcd, uint16_t index);
uint16_t nm_avr_rtc_display_day(uint8_t bcd);
typedef enum {
    NM_CALIBRATION_PREVIEW,
    NM_CALIBRATION_COEFFICIENT,
    NM_CALIBRATION_UNIT,
    NM_CALIBRATION_OFFSET,
    NM_CALIBRATION_REDRAW
} NMCalibrationRoute;

NMCalibrationRoute nm_avr_calibration_route(const uint8_t menu[8]);
bool nm_avr_calibration_menu_step(const NM8036 *m, const NMNumericDisplay *lcd,
                                  uint8_t *sram, const uint8_t *flash, const uint8_t menu[8],
                                  NMNumericAlloc allocate, NMNumericSnapshot snapshot,
                                  NMNumericRestore restore);
bool nm_avr_calibration_interval_step(const NM8036 *m, const NMNumericDisplay *lcd,
                                      const uint8_t menu[8]);
void nm_avr_calibration_menu_open_field(const NM8036 *m, const NMNumericDisplay *lcd,
                                         uint8_t *sram, const uint8_t *flash, uint8_t menu[8],
                                         bool sticky, NMNumericAlloc allocate, NMNumericSnapshot snapshot);
void nm_avr_calibration_menu_resume(const NMNumericDisplay *lcd, const uint8_t *flash,
                                      uint8_t menu[8]);
void nm_avr_calibration_interval_open(const NMNumericDisplay *lcd, const uint8_t *flash,
                                     uint8_t menu[8]);
void nm_avr_calibration_menu_open(const NM8036 *m, const NMNumericDisplay *lcd,
                                   uint8_t *sram, const uint8_t *flash,
                                   NMNumericAlloc allocate, NMNumericSnapshot snapshot);
bool nm_avr_calibration_menu_navigate(const NMNumericDisplay *lcd, uint8_t *sram,
                                       const uint8_t *flash, uint8_t menu[8],
                                       uint8_t key, NMNumericRestore restore);
bool nm_avr_calibration_menu_update(const NM8036 *m, const NMNumericDisplay *lcd,
                                     uint8_t *sram, const uint8_t *flash, bool sticky,
                                     NMNumericAlloc allocate, NMNumericSnapshot snapshot,
                                     NMNumericRestore restore);
bool nm_avr_adc_preview_sample(const NM8036 *m, const NMNumericDisplay *lcd,
                             const uint8_t *flash, uint8_t mode);
#endif
