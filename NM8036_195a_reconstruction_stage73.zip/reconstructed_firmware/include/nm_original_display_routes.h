#ifndef NM_ORIGINAL_DISPLAY_ROUTES_H
#define NM_ORIGINAL_DISPLAY_ROUTES_H
#include "nm_numeric_display.h"

void nm_avr_display_field_set(uint8_t field[16], uint32_t word);
void nm_avr_display_numbered_arguments(uint8_t args[4], uint16_t index, uint16_t value);
uint16_t nm_avr_display_next_number(uint16_t index);
void nm_avr_display_row_start(const NMNumericDisplay *lcd, uint16_t row);
void nm_avr_display_row_indent(const NMNumericDisplay *lcd, uint8_t row);
uint8_t nm_avr_dallas_read_after_word(const NM8036 *m, uint16_t address);
bool nm_avr_dallas_advance_rom_byte(uint16_t *index);
uint16_t nm_avr_dallas_rom_offset(uint8_t index);
uint16_t nm_avr_dallas_rom_base(uint16_t base, uint8_t index);
uint16_t nm_avr_dallas_rom_cursor(const NM8036 *m, const uint8_t dialog[44], uint16_t offset);
#endif
