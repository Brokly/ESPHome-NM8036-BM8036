#include "nm_original_display_routes.h"

/* 0x486C–0x4871 → 0x2796–0x27A3. Четыре байта
 * значения записываются перед вызовом отрисовки 0x2978.
 * Эта функция переводит запись поля; выбор callback остаётся
 * в вызывающем коде. */
void nm_avr_display_field_set(uint8_t field[16], uint32_t word)
{
    for (uint8_t i = 0; i < 4; ++i)
        field[10+i] = (uint8_t)(word >> (8u*i));
}

/* 0x52A6–0x52AD. Экран показывает номер с единицы.
 * Сумма остаётся 16-битной, включая переполнение. */
uint16_t nm_avr_display_next_number(uint16_t index)
{
    return (uint16_t)(index+1u);
}

/* 0x4872–0x4877 и 0x53DA–0x53DF. В аргументах
 * форматтера сначала стоит номер, затем переданное слово. */
void nm_avr_display_numbered_arguments(uint8_t args[4], uint16_t index, uint16_t value)
{
    uint16_t number = nm_avr_display_next_number(index);
    args[0] = (uint8_t)number;
    args[1] = (uint8_t)(number >> 8);
    args[2] = (uint8_t)value;
    args[3] = (uint8_t)(value >> 8);
}

/* 0x52E8–0x52EF. Колонка 0, строка передана младшим байтом. */
void nm_avr_display_row_start(const NMNumericDisplay *lcd, uint16_t row)
{
    lcd->position(lcd->context,0,(uint8_t)row);
}

/* 0x532C–0x532F. Общая установка курсора с колонкой 1. */
void nm_avr_display_row_indent(const NMNumericDisplay *lcd, uint8_t row)
{
    lcd->position(lcd->context,1,row);
}

/* 0x52C4–0x52CB. Пропустить четыре байта перед чтением EEPROM. */
uint8_t nm_avr_dallas_read_after_word(const NM8036 *m, uint16_t address)
{
    return nm_ee_read(m,(uint16_t)(address+4u));
}

/* 0x52D8–0x52E1. Цикл ROM обрабатывает ровно восемь байтов. */
bool nm_avr_dallas_advance_rom_byte(uint16_t *index)
{
    ++*index;
    return *index < 8u;
}

/* 0x52F8–0x52FB. Запись ROM занимает восемь байтов. */
uint16_t nm_avr_dallas_rom_offset(uint8_t index)
{
    return (uint16_t)index * 8u;
}

/* 0x52FC–0x5303. Адрес записи складывается с базой блока. */
uint16_t nm_avr_dallas_rom_base(uint16_t base, uint8_t index)
{
    return (uint16_t)(base + nm_avr_dallas_rom_offset(index));
}

/* 0x5318–0x532B. Адрес ROM в диалоге состоит из сохранённой
 * базы, номера по 0x0680 и текущего смещения в записи. */
uint16_t nm_avr_dallas_rom_cursor(const NM8036 *m, const uint8_t dialog[44], uint16_t offset)
{
    uint16_t base = dialog[42] | ((uint16_t)dialog[43] << 8);
    return (uint16_t)(nm_avr_dallas_rom_base(base,*nm_ram(m,0x0680)) + offset);
}
