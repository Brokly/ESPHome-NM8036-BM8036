#include "nm_original_display_routes.h"
#include "nm_stage14.h"
#include "nm_original_helpers.h"

/* 0x486C–0x4871 → 0x2796–0x27A3. Четыре байта
 * значения записываются перед вызовом отрисовки 0x2978.
 * Эта функция переводит запись поля; выбор callback остаётся
 * в вызывающем коде. */
void nm_avr_display_field_set(uint8_t field[16], uint32_t word)
{
    for (uint8_t i = 0; i < 4; ++i)
        field[10+i] = (uint8_t)(word >> (8u*i));
}

/* 0x52A6–0x52AD. Экран показывает номер с единицы.
 * Сумма остаётся 16-битной, включая переполнение. */
uint16_t nm_avr_display_next_number(uint16_t index)
{
    return (uint16_t)(index+1u);
}

/* 0x4872–0x4877 и 0x53DA–0x53DF. В аргументах
 * форматтера сначала стоит номер, затем переданное слово. */
void nm_avr_display_numbered_arguments(uint8_t args[4], uint16_t index, uint16_t value)
{
    uint16_t number = nm_avr_display_next_number(index);
    args[0] = (uint8_t)number;
    args[1] = (uint8_t)(number >> 8);
    args[2] = (uint8_t)value;
    args[3] = (uint8_t)(value >> 8);
}

/* 0x52E8–0x52EF. Колонка 0, строка передана младшим байтом. */
void nm_avr_display_row_start(const NMNumericDisplay *lcd, uint16_t row)
{
    lcd->position(lcd->context,0,(uint8_t)row);
}

/* 0x532C–0x532F. Общая установка курсора с колонкой 1. */
void nm_avr_display_row_indent(const NMNumericDisplay *lcd, uint8_t row)
{
    lcd->position(lcd->context,1,row);
}

/* 0x52C4–0x52CB. Пропустить четыре байта перед чтением EEPROM. */
uint8_t nm_avr_dallas_read_after_word(const NM8036 *m, uint16_t address)
{
    return nm_ee_read(m,(uint16_t)(address+4u));
}

/* 0x52D8–0x52E1. Цикл ROM обрабатывает ровно восемь байтов. */
bool nm_avr_dallas_advance_rom_byte(uint16_t *index)
{
    ++*index;
    return *index < 8u;
}

/* 0x52F8–0x52FB. Запись ROM занимает восемь байтов. */
uint16_t nm_avr_dallas_rom_offset(uint8_t index)
{
    return (uint16_t)index * 8u;
}

/* 0x52FC–0x5303. Адрес записи складывается с базой блока. */
uint16_t nm_avr_dallas_rom_base(uint16_t base, uint8_t index)
{
    return (uint16_t)(base + nm_avr_dallas_rom_offset(index));
}

/* 0x5318–0x532B. Адрес ROM в диалоге состоит из сохранённой
 * базы, номера по 0x0680 и текущего смещения в записи. */
uint16_t nm_avr_dallas_rom_cursor(const NM8036 *m, const uint8_t dialog[44], uint16_t offset)
{
    uint16_t base = dialog[42] | ((uint16_t)dialog[43] << 8);
    return (uint16_t)(nm_avr_dallas_rom_base(base,*nm_ram(m,0x0680)) + offset);
}

/* 0x297E–0x298B. Поле +14 хранит байтовый адрес записи
 * Flash. Запись хранит адрес обработчика в словах AVR. */
uint16_t nm_avr_display_field_callback(const uint8_t *flash, const uint8_t field[16])
{
    uint16_t table = field[14] | ((uint16_t)field[15] << 8);
    return nm_avr_redraw_callback(flash,table);
}

/* 0x2778–0x2795. Границы поля — два четырёхбайтовых слова.
 * Нижняя граница поступает в регистрах, верхняя — через стек. */
void nm_avr_display_field_limits(uint8_t field[16], uint32_t lower, uint32_t upper)
{
    for (uint8_t i = 0; i < 4; ++i) {
        field[2+i] = (uint8_t)(lower >> (8u*i));
        field[6+i] = (uint8_t)(upper >> (8u*i));
    }
}

/* 0x273E–0x2771. Сохраняет снимок, выбирает таблицу
 * отрисовки 0x03D8, очищает LCD и задаёт границы 0–100.
 * Значение по +10 остаётся до отдельной записи поля. */
void nm_avr_display_field_init(const NMNumericDisplay *lcd, uint8_t field[16],
                               NMNumericSnapshot snapshot)
{
    uint16_t saved = snapshot(lcd->context);
    field[0] = (uint8_t)saved;
    field[1] = (uint8_t)(saved >> 8);
    field[14] = 0xd8;
    field[15] = 3;
    lcd->write(lcd->context,1,0);
    nm_avr_display_field_limits(field,0,100);
}

static uint32_t field_word(const uint8_t *bytes)
{
    return (uint32_t)bytes[0] | ((uint32_t)bytes[1] << 8) |
           ((uint32_t)bytes[2] << 16) | ((uint32_t)bytes[3] << 24);
}

/* 0x2926–0x2931, 0x2A60–0x2A69 и 0x2A6E–0x2A87.
 * Оригинал сравнивает слова без знака. Внутри диапазона
 * произведение остаётся 32-битным с переполнением. */
static uint8_t bar_level(const uint8_t field[16], uint8_t scale)
{
    uint32_t lower = field_word(field+2);
    uint32_t upper = field_word(field+6);
    uint32_t value = field_word(field+10);
    if (value <= lower)
        return 0;
    if (value >= upper)
        return scale-1u;
    return (uint8_t)(((value-lower)*scale)/(upper-lower));
}

/* 0x2890–0x2925. Полоса на второй строке, две рамки и
 * четырнадцать внутренних ячеек. Счётчик включает левую рамку. */
static void draw_coarse_bar(const NMNumericDisplay *lcd, const uint8_t field[16])
{
    uint32_t lower = field_word(field+2);
    uint32_t upper = field_word(field+6);
    uint32_t value = field_word(field+10);
    /* 0x28C0: сравнение идёт от верхней границы к значению. */
    uint8_t level = lower < value && value < upper ? bar_level(field,16) :
                    value <= upper ? 15 : 0;
    lcd->position(lcd->context,0,1);
    for (uint8_t column = 0; column < 16; ++column) {
        bool filled = column <= level;
        uint8_t glyph = column == 0 ? (filled ? 1 : 0) :
                        column == 15 ? (filled ? 5 : 4) : (filled ? 3 : 2);
        lcd->write(lcd->context,glyph,1);
    }
}

/* 0x298C–0x2A5F. Точная полоса загружает крайние глифы
 * и рисует по три деления на ячейку. IRQ остаются закрыты
 * на время записи CGRAM и DDRAM. */
static void draw_fine_bar(const NM8036 *m, const NMNumericDisplay *lcd,
                          const uint8_t *flash, const uint8_t field[16])
{
    uint8_t flags = m->irq_disable(m->context);
    uint8_t level = bar_level(field,47);
    uint16_t right = level == 45 ? 0x0420 : level == 46 ? 0x0428 : 0x0408;
    lcd->write(lcd->context,0x68,0);
    for (uint8_t i = 0; i < 8; ++i)
        lcd->write(lcd->context,flash[right+i],1);
    uint16_t left = level == 0 ? 0x03e0 : level == 1 ? 0x0410 : 0x0418;
    lcd->write(lcd->context,0x40,0);
    for (uint8_t i = 0; i < 8; ++i)
        lcd->write(lcd->context,flash[left+i],1);
    level = level >= 2 ? level-2 : 0;
    lcd->position(lcd->context,1,1);
    for (uint8_t i = 0; i < 14; ++i) {
        uint8_t divisions = level >= 3 ? 3 : level;
        lcd->write(lcd->context,divisions+1u,1);
        level -= divisions;
    }
    m->irq_restore(m->context,flags);
}

/* 0x2978–0x297D. Выбирает уже переведённые обработчики
 * полосы по исходной таблице. Другие цели оставлены вызывающему коду. */
bool nm_avr_display_redraw_bar(const NM8036 *m, const NMNumericDisplay *lcd,
                               const uint8_t *flash, const uint8_t field[16])
{
    switch (nm_avr_display_field_callback(flash,field)) {
    case 0x2890:
        draw_coarse_bar(lcd,field);
        return true;
    case 0x298c:
        draw_fine_bar(m,lcd,flash,field);
        return true;
    default:
        return false;
    }
}

/* 0x2728–0x273D и 0x2932–0x2975. Подготовка точной
 * шкалы выделяет 16 байт, сохраняет дисплей, переносит
 * 64 байта CGRAM и отображает крайние глифы. */
uint16_t nm_avr_display_bar_open(const NMNumericDisplay *lcd, uint8_t *sram,
                                  const uint8_t *flash, NMNumericAlloc allocate,
                                  NMNumericSnapshot snapshot)
{
    uint16_t address = allocate(lcd->context,16);
    if (!address)
        return 0;
    uint8_t *field = sram+address;
    nm_avr_display_field_init(lcd,field,snapshot);
    field[14] = 0xdc;
    lcd->write(lcd->context,0x40,0);
    for (uint8_t i = 0; i < 64; ++i)
        lcd->write(lcd->context,flash[0x03e0+i],1);
    lcd->position(lcd->context,0,1);
    lcd->write(lcd->context,0,1);
    lcd->position(lcd->context,15,1);
    lcd->write(lcd->context,5,1);
    return address;
}

/* 0x270C–0x2727 и вход 0x2772. Снимок восстанавливается
 * перед освобождением поля. Нулевой адрес пропускается. */
void nm_avr_display_bar_close(const NMNumericDisplay *lcd, uint8_t *sram,
                               uint16_t address, NMNumericRestore restore)
{
    if (address) {
        const uint8_t *field = sram+address;
        restore(lcd->context,field[0] | ((uint16_t)field[1]<<8));
        nm_avr_heap_free(sram,address);
    }
}

/* 0x27D0–0x2871. Сложение оборачивается до знакового
 * сравнения. Положительный шаг проверяет только верхнюю
 * границу, отрицательный — только нижнюю. При нуле оригинал
 * запускает отрисовку, сохраняя и слово, и текущее поле. */
void nm_avr_display_field_adjust(uint8_t field[16], uint8_t word[4], int16_t step)
{
    if (step) {
        const uint32_t sign = UINT32_C(0x80000000);
        uint32_t next = field_word(word)+(uint32_t)(int32_t)step;
        uint32_t bound = field_word(field + (step < 0 ? 2 : 6));
        if (step < 0 ? (next ^ sign) < (bound ^ sign) :
                       (next ^ sign) > (bound ^ sign))
            next = bound;
        for (uint8_t i = 0; i < 4; ++i)
            word[i] = (uint8_t)(next >> (8u*i));
        nm_avr_display_field_set(field,next);
    }
}

/* 0x27A4–0x27C9. Однобайтовое значение расширяется нулями
 * до 32 бит, преобразуется тем же редактором, затем берётся
 * только младший байт результата. */
void nm_avr_display_byte_adjust(uint8_t field[16], uint8_t *value, int16_t step)
{
    uint8_t word[4] = {*value,0,0,0};
    nm_avr_display_field_adjust(field,word,step);
    *value = word[0];
}
