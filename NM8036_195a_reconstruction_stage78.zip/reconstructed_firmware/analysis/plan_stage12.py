#!/usr/bin/env python3
"""Очередь перевода из CFG. Конец диапазона исключён."""
import argparse
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def rows(path):
    with path.open() as file:
        return list(csv.DictReader(file))


def classify(start):
    # Имена неподтверждённых участков относятся к группе вызовов.
    for lo, hi, name, difficulty in (
        (0, 0x54, "Неактивные векторы", "низкая"),
        (0xe16, 0x1d8c, "Редактор числовых полей, АЦП и календарь", "высокая"),
        (0x1d8c, 0x2308, "Драйвер LCD и временные экраны", "высокая"),
        (0x263a, 0x2bdc, "Меню редактирования строк и LCD", "высокая"),
        (0x2cb8, 0x4108, "Календарь и редактор программ, упаковка полей", "средняя"),
        (0x4108, 0x457e, "Инициализация, опрос датчиков и страницы", "средняя"),
        (0x457e, 0x49a4, "Страницы АЦП/температуры и переходы", "средняя"),
        (0x49a4, 0x501a, "Диспетчер настроек, RTC, выходы", "высокая"),
        (0x501a, 0x5336, "Регистрация Dallas и кеш ROM", "высокая"),
        (0x5336, 0x5596, "Настройки, EEPROM и вход UART", "средняя"),
        (0x5848, 0x59fc, "Эпилог UART", "низкая"),
        (0x59fc, 0x62b8, "Системная библиотека, форматтер и косвенные вызовы", "высокая"),
        (0x62e0, 0x6370, "Обёртки освобождения памяти и EEPROM", "средняя"),
        (0x6370, 0x64d0, "Целочисленная арифметика и вход форматтера", "низкая"),
        (0x64d0, 0x6914, "Библиотека float и флаги сравнений", "высокая"),
        (0x6914, 0x6a38, "Косвенные переходы и ABI", "высокая"),
        (0x6a38, 0x6aba, "Сравнение и заполнение SRAM, обёртка аллокатора", "низкая"),
        (0x6aba, 0x6dac, "Диспетчер вывода форматтера и инициализация арены", "высокая"),
        (0x6dac, 0x6fd2, "Аллокатор SRAM и аварийное ожидание", "средняя"),
    ):
        if lo <= start < hi:
            return name, difficulty
    return "Требуется разбор входов", "высокая"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ranges", type=Path, default=ROOT / "untranslated_reachable.csv")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    links = [(int(e["from"], 16), int(e["to"], 16), e["kind"])
             for e in rows(ROOT / "edges.csv")]
    entries = {int(e["entry"], 16) for e in rows(ROOT / "entries.csv")}
    result = []
    for row in rows(args.ranges):
        start, end = int(row["start"], 16), int(row["end_exclusive"], 16)
        local = lambda addr: start <= addr < end
        incoming = [(a,b,k) for a,b,k in links if local(b) and not local(a)]
        outgoing = [(a,b,k) for a,b,k in links if local(a) and not local(b)]
        name, complexity = classify(start)
        feasibility = {"низкая": "прямой перевод",
                       "средняя": "после сверки вызывающих участков",
                       "высокая": "после установления контрактов и границ"}[complexity]
        score = int(row["bytes"]) * {"низкая": 4, "средняя": 2, "высокая": 1}[complexity]
        def format_edges(edges):
            return " ".join(f"{a:04X}>{b:04X}/{kind}" for a, b, kind in edges)
        result.append((score, row["start"], row["end_exclusive"], row["bytes"],
                       name, format_edges(incoming), format_edges(outgoing),
                       " ".join(f"{b:04X}" for b in sorted({b for _,b,_ in outgoing})),
                       " ".join(f"{b:04X}" for b in sorted(filter(local, entries))),
                       feasibility, complexity))
    with args.output.open("w", newline="") as file:
        out = csv.writer(file, delimiter="\t")
        out.writerow(("приоритет","начало","конец_искл","байт","назначение_гипотеза",
                      "входящие","исходящие","зависимости","точки_входа",
                      "возможность_перевода","сложность_проверки"))
        out.writerows(sorted(result, key=lambda row: (-row[0], -int(row[3]), row[1])))


if __name__ == "__main__":
    main()
