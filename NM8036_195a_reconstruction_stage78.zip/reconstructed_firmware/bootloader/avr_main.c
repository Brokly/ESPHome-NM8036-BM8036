#include "loader.h"
#include <avr/boot.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <util/delay_basic.h>

_Static_assert(SPM_PAGESIZE == NM_BL_PAGE, "ATmega32 page size");

/* Передача идёт отдельными страницами. ПК ждёт запрос 0x3f
 * перед каждым байтом, поэтому стирание Flash не теряет данные. */
static void send(uint8_t byte)
{
    while (!(UCSRA & _BV(UDRE))) {}
    UDR = byte;
}

static int read_uart(void)
{
    uint16_t remaining = 20000;
    while (!(UCSRA & _BV(RXC))) {
        if (!remaining--)
            return -1;
        _delay_loop_2(F_CPU / 40000UL);
    }
    uint8_t status = UCSRA;
    uint8_t byte = UDR;
    return status & (_BV(FE) | _BV(DOR) | _BV(PE)) ? -1 : byte;
}

static int receive(void *context)
{
    (void)context;
    send('?');
    return read_uart();
}

static uint8_t flash_read(void *context, uint16_t address)
{
    (void)context;
    return pgm_read_byte_near(address);
}

static bool flash_page(void *context, uint16_t address, const uint8_t *page)
{
    (void)context;
    if (address >= NM_BL_START || (address & (NM_BL_PAGE - 1u)))
        return false;
    eeprom_busy_wait();
    boot_page_erase(address);
    boot_spm_busy_wait();
    for (uint8_t i = 0; i < NM_BL_PAGE; i += 2)
        boot_page_fill(address + i, (uint16_t)page[i] | ((uint16_t)page[i + 1] << 8));
    boot_page_write(address);
    boot_spm_busy_wait();
    boot_rww_enable();
    return true;
}

int main(void)
{
    cli();
    wdt_disable();
    /* E может войти с запущенными таймерами. Останавливаем источники IRQ. */
    TIMSK = 0;
    GICR = 0;
    /* Те же активные высоким уровнем линии, что в 0x2414. */
    PORTA &= (uint8_t)~0xf0u;
    PORTC &= (uint8_t)~0xfcu;
    PORTD &= (uint8_t)~0x48u;
    TCCR1A = 0;
    TCCR1B = 0;
    UCSRB = 0;
    UCSRA = (UCSRA & (uint8_t)~(_BV(U2X) | _BV(MPCM))) | _BV(TXC);
    UBRRH = 0;
    UBRRL = (uint8_t)(F_CPU / (16UL * 9600) - 1);
    UCSRC = _BV(URSEL) | _BV(UCSZ1) | _BV(UCSZ0);
    UCSRB = _BV(RXEN) | _BV(TXEN);
    const NMBootIO io = {0, receive, flash_read, flash_page};
    send('B');
    for (;;) {
        int command = read_uart();
        if (command == '?') {
            send('B');
        } else if (command == 'U') {
            NMBootStatus status = nm_boot_upload(&io);
            send('0' + status);
        } else if (command == 'R') {
            if (!nm_boot_valid(&io)) {
                send('5');
                continue;
            }
            UCSRA = (UCSRA & (uint8_t)~(_BV(U2X) | _BV(MPCM))) | _BV(TXC);
            send('0');
            while (!(UCSRA & _BV(TXC))) {}
            UCSRB = 0;
            TCCR1B = 0;
            __asm__ volatile ("jmp 0" ::: "memory");
            __builtin_unreachable();
        }
    }
}
