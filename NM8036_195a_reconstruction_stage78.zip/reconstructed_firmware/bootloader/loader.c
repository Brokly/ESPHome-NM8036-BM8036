#include "loader.h"
#include <string.h>

/* Новый протокол. Метаданные занимают отдельную страницу перед
 * загрузчиком. Они стираются до первой записи приложения и
 * фиксируются только после проверки всего нового образа. */
static const uint8_t signature[] = {'N','M','6','1'};

static uint32_t crc_byte(uint32_t crc, uint8_t byte)
{
    crc ^= byte;
    for (uint8_t bit = 0; bit < 8; bit++)
        crc = (crc >> 1) ^ ((crc & 1u) ? UINT32_C(0xedb88320) : 0);
    return crc;
}

static uint16_t length_of(const uint8_t *header)
{
    return (uint16_t)header[4] | ((uint16_t)header[5] << 8);
}

static uint32_t expected_crc(const uint8_t *header)
{
    uint32_t crc = 0;
    for (uint8_t i = 0; i < 4; i++)
        crc |= (uint32_t)header[6 + i] << (8u * i);
    return crc;
}

static bool header_ok(const uint8_t *header)
{
    uint16_t length = length_of(header);
    return !memcmp(signature, header, sizeof signature) && length >= 4 && length <= NM_BL_META;
}

static bool image_ok(const NMBootIO *io, const uint8_t *header)
{
    if (io->flash_read(io->context, 0) == 0xff && io->flash_read(io->context, 1) == 0xff)
        return false;
    uint32_t crc = UINT32_MAX;
    uint16_t length = length_of(header);
    for (uint16_t i = 0; i < length; i++)
        crc = crc_byte(crc, io->flash_read(io->context, i));
    return ~crc == expected_crc(header);
}

bool nm_boot_valid(const NMBootIO *io)
{
    uint8_t header[10];
    for (uint8_t i = 0; i < sizeof header; i++)
        header[i] = io->flash_read(io->context, NM_BL_META + i);
    return header_ok(header) && image_ok(io, header);
}

static bool receive(const NMBootIO *io, uint8_t *p, uint16_t count)
{
    while (count--) {
        int value = io->receive(io->context);
        if (value < 0 || value > 255)
            return false;
        *p++ = (uint8_t)value;
    }
    return true;
}

NMBootStatus nm_boot_upload(const NMBootIO *io)
{
    uint8_t page[NM_BL_PAGE], header[10];
    if (!receive(io, header, sizeof header))
        return NM_BL_INPUT;
    if (!header_ok(header))
        return NM_BL_HEADER;
    memset(page, 0xff, sizeof page);
    if (!io->flash_page(io->context, NM_BL_META, page))
        return NM_BL_FLASH;
    for (uint8_t i = 0; i < NM_BL_PAGE; i++)
        if (io->flash_read(io->context, NM_BL_META + i) != 0xff)
            return NM_BL_FLASH;

    uint16_t length = length_of(header);
    for (uint16_t address = 0; address < NM_BL_META; address += NM_BL_PAGE) {
        memset(page, 0xff, sizeof page);
        if (address < length) {
            uint16_t count = length - address;
            if (count > NM_BL_PAGE)
                count = NM_BL_PAGE;
            if (!receive(io, page, count))
                return NM_BL_INPUT;
        }
        /* Удаляем хвост предыдущего приложения и сверяем запись. */
        if (!io->flash_page(io->context, address, page))
            return NM_BL_FLASH;
        for (uint8_t i = 0; i < NM_BL_PAGE; i++)
            if (io->flash_read(io->context, address + i) != page[i])
                return NM_BL_FLASH;
    }
    if (!image_ok(io, header))
        return NM_BL_CRC;
    memset(page, 0xff, sizeof page);
    memcpy(page, header, sizeof header);
    if (!io->flash_page(io->context, NM_BL_META, page))
        return NM_BL_FLASH;
    return nm_boot_valid(io) ? NM_BL_OK : NM_BL_FLASH;
}
