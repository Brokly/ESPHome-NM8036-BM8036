#ifndef NM_LOADER_H
#define NM_LOADER_H
#include <stdbool.h>
#include <stdint.h>

enum { NM_BL_PAGE = 128, NM_BL_META = 0x6f80, NM_BL_START = 0x7000 };
typedef struct {
    void *context;
    /* Отрицательное значение означает ошибку UART или тайм-аут. */
    int (*receive)(void *);
    uint8_t (*flash_read)(void *, uint16_t);
    bool (*flash_page)(void *, uint16_t, const uint8_t *);
} NMBootIO;

typedef enum { NM_BL_OK, NM_BL_HEADER, NM_BL_INPUT, NM_BL_FLASH, NM_BL_CRC } NMBootStatus;
bool nm_boot_valid(const NMBootIO *io);
NMBootStatus nm_boot_upload(const NMBootIO *io);
#endif
