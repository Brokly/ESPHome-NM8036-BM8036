#include "loader.h"
#include <assert.h>
#include <simavr/avr_uart.h>
#include <simavr/sim_avr.h>
#include <simavr/sim_core.h>
#include <simavr/sim_hex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int response = -1;
static void output(struct avr_irq_t *irq, uint32_t value, void *param)
{
    (void)irq;
    (void)param;
    response = value & 255u;
}

static void expect(avr_t *avr, int expected)
{
    unsigned budget = expected == '2' ? 6000000 : 1500000;
    while (response < 0 && budget--) {
        /* ATmega32 simavr 1.6 совмещает UBRRH/UCSRC и оставляет
         * UDRE после повторного RX/TX init в нуле. Корректируем
         * модель перед первым отправленным символом. */
        if (expected == 'B' && avr->data[0x2a] == 0x18) {
            avr_core_watch_write(avr, 0x40, 0);
            avr->data[0x2b] |= 0x20;
        }
        avr_run(avr);
    }
    if (response != expected)
        fprintf(stderr, "UART expected=%d got=%d pc=%04x\n", expected, response, avr->pc);
    assert(response == expected);
    response = -1;
}

static uint32_t crc32(const uint8_t *p, size_t count)
{
    uint32_t crc = UINT32_MAX;
    while (count--) {
        crc ^= *p++;
        for (uint8_t j = 0; j < 8; j++)
            crc = (crc >> 1) ^ ((crc & 1u) ? UINT32_C(0xedb88320) : 0);
    }
    return ~crc;
}

int main(int argc, char **argv)
{
    assert(argc == 2);
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr->frequency = 4000000;
    uint32_t size, start;
    uint8_t *code = read_ihex_file(argv[1], &size, &start);
    assert(code && start == NM_BL_START && size <= 0x1000);
    memset(avr->flash, 0xff, 0x8000);
    avr_loadcode(avr, code, size, start);
    avr_irq_t *uart = avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'), UART_IRQ_INPUT);
    assert(uart);
    avr_irq_register_notify(avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'), UART_IRQ_OUTPUT),
                            output, NULL);
    avr->pc = NM_BL_START;
    expect(avr, 'B');
    avr_raise_irq(uart, 'R');
    expect(avr, '5');

    /* RJMP на себя в 0. Остальные байты шаблона пересекают границу страницы. */
    uint8_t image[129] = {0xff,0xcf,0,0};
    image[128] = 0x37;
    uint8_t header[] = {'N','M','6','1',sizeof image,0,0,0,0,0};
    uint32_t crc = crc32(image, sizeof image);
    for (uint8_t i = 0; i < 4; i++)
        header[6 + i] = (uint8_t)(crc >> (8u * i));

    avr_raise_irq(uart, 'U');
    for (unsigned i = 0; i < sizeof header + sizeof image; i++) {
        expect(avr, '?');
        avr_raise_irq(uart, i < sizeof header ? header[i] : image[i - sizeof header]);
    }
    expect(avr, '0');
    assert(!memcmp(avr->flash, image, sizeof image));
    assert(!memcmp(avr->flash + NM_BL_START, code, size));

    /* Проверка нового входа в загрузчик с уже записанной Flash. */
    avr_reset(avr);
    avr->pc = NM_BL_START;
    expect(avr, 'B');
    avr_raise_irq(uart, 'R');
    expect(avr, '0');
    unsigned budget = 30000;
    while (avr->pc && budget--)
        avr_run(avr);
    assert(avr->pc == 0);
    avr_reset(avr);
    avr->flash[128] ^= 1;
    avr->pc = NM_BL_START;
    expect(avr, 'B');
    avr_raise_irq(uart, 'R');
    expect(avr, '5');

    /* U с законченным заголовком и оборванным телом. */
    avr_raise_irq(uart, 'U');
    for (unsigned i = 0; i < sizeof header; i++) {
        expect(avr, '?');
        avr_raise_irq(uart, header[i]);
    }
    expect(avr, '?');
    expect(avr, '2');
    avr_raise_irq(uart, 'R');
    expect(avr, '5');
    assert(!memcmp(avr->flash + NM_BL_START, code, size));
    avr_terminate(avr);
    free(avr);
    free(code);
    puts("simavr loader: UART, SPM, retry after reset, CRC rejection and timeout");
}
