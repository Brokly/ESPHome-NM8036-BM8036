#include "loader.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static uint8_t flash[0x8000], wire[NM_BL_META + 10];
static size_t cursor, limit;
static int fail_page = -1;
static unsigned writes;

static int recv_byte(void *context)
{
    (void)context;
    return cursor < limit ? wire[cursor++] : -1;
}

static uint8_t load_byte(void *context, uint16_t address)
{
    (void)context;
    return flash[address];
}

static bool write_page(void *context, uint16_t address, const uint8_t *bytes)
{
    (void)context;
    assert(address < NM_BL_START && !(address % NM_BL_PAGE));
    if ((int)writes++ == fail_page)
        return false;
    memcpy(flash + address, bytes, NM_BL_PAGE);
    return true;
}

static uint32_t crc32(const uint8_t *bytes, uint16_t count)
{
    uint32_t crc = UINT32_MAX;
    while (count--) {
        crc ^= *bytes++;
        for (unsigned j = 0; j < 8; j++)
            crc = (crc >> 1) ^ (crc & 1u ? UINT32_C(0xedb88320) : 0);
    }
    return ~crc;
}

static void frame(uint16_t count)
{
    memcpy(wire, "NM61", 4);
    wire[4] = (uint8_t)count;
    wire[5] = count >> 8;
    for (uint16_t i = 0; i < count; i++)
        wire[10 + i] = (uint8_t)(i * 31u + 12);
    uint32_t crc = crc32(wire + 10, count);
    for (unsigned i = 0; i < 4; i++)
        wire[6 + i] = (uint8_t)(crc >> (8*i));
    limit = 10u + count;
    cursor = writes = 0;
}

int main(void)
{
    const NMBootIO io = {0, recv_byte, load_byte, write_page};
    memset(flash, 0xff, sizeof flash);
    memset(flash + NM_BL_START, 0x71, sizeof flash - NM_BL_START);
    assert(!nm_boot_valid(&io));

    frame(129);
    assert(nm_boot_upload(&io) == NM_BL_OK);
    assert(nm_boot_valid(&io) && !memcmp(flash, wire + 10, 129));
    for (unsigned i = 129; i < NM_BL_META; i++)
        assert(flash[i] == 0xff);

    frame(4);
    wire[5] = 0x70;
    assert(nm_boot_upload(&io) == NM_BL_HEADER && writes == 0);
    assert(nm_boot_valid(&io));

    frame(129);
    limit -= 1;
    assert(nm_boot_upload(&io) == NM_BL_INPUT && writes == 2);
    assert(!nm_boot_valid(&io));

    frame(129);
    wire[12] ^= 1;
    assert(nm_boot_upload(&io) == NM_BL_CRC);
    assert(!nm_boot_valid(&io));

    frame(128);
    fail_page = 1 + NM_BL_META / NM_BL_PAGE;
    assert(nm_boot_upload(&io) == NM_BL_FLASH);
    assert(!nm_boot_valid(&io));

    frame(NM_BL_META);
    fail_page = -1;
    assert(nm_boot_upload(&io) == NM_BL_OK);
    assert(nm_boot_valid(&io) && !memcmp(flash, wire + 10, NM_BL_META));
    flash[0x100] ^= 1;
    assert(!nm_boot_valid(&io));
    for (unsigned i = NM_BL_START; i < sizeof flash; i++)
        assert(flash[i] == 0x71);
    puts("loader: full/partial pages, bounds, CRC, interrupted transfer, failed commit and restart validated");
}
