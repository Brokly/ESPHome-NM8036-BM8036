"""Клиент NM61. Принимает плоский BIN экспериментального приложения."""
import argparse
from pathlib import Path
import struct
import time
import zlib


def exchange(port, frame):
    port.write(b"U")
    for byte in frame:
        prompt = port.read(1)
        if prompt != b"?":
            raise RuntimeError(f"ожидался запрос байта, получено {prompt!r}")
        port.write(bytes((byte,)))
    result = port.read(1)
    if result != b"0":
        raise RuntimeError(f"обновление не принято: {result!r}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("port")
    parser.add_argument("image", type=Path)
    parser.add_argument("--enter-baud", type=int, help="скорость приложения для входа через E, 8N2")
    parser.add_argument("--run", action="store_true", help="запросить запуск после успешной проверки")
    args = parser.parse_args()
    image = args.image.read_bytes()
    if not 4 <= len(image) <= 0x6F80 or image[:2] == b"\xff\xff":
        parser.error("размер BIN должен быть 4..28544, с заполненным вектором сброса")
    frame = struct.pack("<4sHI", b"NM61", len(image), zlib.crc32(image)) + image
    import serial

    with serial.Serial(args.port, args.enter_baud or 9600, timeout=6,
                       stopbits=serial.STOPBITS_TWO if args.enter_baud else serial.STOPBITS_ONE) as port:
        if args.enter_baud:
            port.write(b"E")
            if port.read(1) != b"E":
                raise RuntimeError("приложение не подтвердило E")
            port.baudrate = 9600
            port.stopbits = serial.STOPBITS_ONE
            time.sleep(0.2)
        port.reset_input_buffer()
        port.write(b"?")
        if port.read(1) != b"B":
            raise RuntimeError("загрузчик NM61 не подтвердил вход")
        exchange(port, frame)
        if args.run:
            port.write(b"R")
            if port.read(1) != b"0":
                raise RuntimeError("загрузчик не подтвердил запуск")


if __name__ == "__main__":
    main()
