#ifndef NM_EDITORS_H
#define NM_EDITORS_H
#include "nm8036.h"

typedef enum { NM_EDIT_BACKLIGHT, NM_EDIT_CONTRAST } NMPwmSetting;
typedef enum { NM_EDIT_ACTIVE, NM_EDIT_SAVED, NM_EDIT_CANCELLED } NMEditResult;

void nm_avr_backlight_store_enabled(const NM8036 *m, uint8_t enabled);
void nm_avr_backlight_restore_pwm(const NM8036 *m);
uint8_t nm_avr_rtc_pack_hours(uint8_t previous, uint8_t hour);
uint8_t nm_avr_rtc_pack_minutes_seconds(uint8_t previous, uint8_t value);
void nm_pwm_editor_open(const NM8036 *m, NMPwmSetting setting);
NMEditResult nm_pwm_editor_key(const NM8036 *m, NMPwmSetting setting, uint8_t key);
bool nm_sound_editor_key(const NM8036 *m, uint8_t key);
bool nm_clock_editor_key(const NM8036 *m, uint8_t key);
void nm_pwm_editor_screen(const NM8036 *m, NMPwmSetting setting, uint8_t screen[32]);
void nm_sound_editor_screen(const NM8036 *m, uint8_t screen[32]);
bool nm_output_editor_key(uint8_t row, uint16_t *seconds, uint8_t key);
typedef struct { uint8_t field[6], cursor; } NMProgramTime;
void nm_program_time_key(NMProgramTime *time, uint8_t key);
void nm_program_time_load(const NM8036 *m, uint8_t index, bool stop, NMProgramTime *time);
void nm_program_time_save(const NM8036 *m, uint8_t index, bool stop, const NMProgramTime *time);
typedef struct { int16_t value[2]; uint8_t selected; bool analog; } NMThresholds;
void nm_program_threshold_key(NMThresholds *editor, uint8_t key);
void nm_program_thresholds_load(const NM8036 *m, uint8_t index, NMThresholds *editor);
void nm_program_thresholds_save(const NM8036 *m, uint8_t index, const NMThresholds *editor);
enum {
    NM_PROGRAM_LIST, NM_PROGRAM_ENABLE, NM_PROGRAM_START, NM_PROGRAM_STOP,
    NM_PROGRAM_CONTROL, NM_PROGRAM_COMPARE, NM_PROGRAM_REFERENCE,
    NM_PROGRAM_THRESHOLDS, NM_PROGRAM_LOGIC, NM_PROGRAM_PERIOD
};
typedef struct {
    NMProgramTime time;
    NMThresholds thresholds;
} NMProgramEditor;
void nm_program_editor_open(const NM8036 *m);
bool nm_program_editor_step(const NM8036 *m, NMProgramEditor *editor, uint8_t key);
void nm_program_enable_screen(const NM8036 *m, uint8_t index, uint8_t screen[32]);
void nm_program_calendar_screen(const NMProgramTime *time, bool stop, uint8_t index,
                                bool sqw, uint8_t key, uint8_t screen[32]);
void nm_program_control_screen(const NM8036 *m, uint8_t index,
                               bool sqw, uint8_t key, uint8_t screen[32]);
void nm_program_compare_screen(const NM8036 *m, uint8_t index, uint8_t screen[32]);
void nm_program_reference_screen(const NM8036 *m, uint8_t index, uint8_t screen[32]);
void nm_program_period_screen(const NM8036 *m, uint8_t index, uint8_t item, uint8_t screen[32]);
void nm_program_threshold_screen(const NM8036 *m, uint8_t index,
                                 const NMThresholds *thresholds, bool sqw,
                                 uint8_t screen[32]);
#endif
