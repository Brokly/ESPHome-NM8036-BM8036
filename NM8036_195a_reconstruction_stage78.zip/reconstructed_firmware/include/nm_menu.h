#ifndef NM_MENU_H
#define NM_MENU_H
#include "nm8036.h"

typedef struct {
    uint8_t first_row, cursor;
} NMSettingsMenu;

void nm_menu_move(NMSettingsMenu *menu, int8_t direction, uint8_t rows);
void nm_settings_menu_move(NMSettingsMenu *menu, int8_t direction);
uint8_t nm_settings_menu_selection(const NMSettingsMenu *menu);
void nm_settings_menu_screen(const NMSettingsMenu *menu, uint8_t screen[32]);
void nm_output_menu_screen(const NMSettingsMenu *menu, uint8_t screen[32]);
#ifdef __AVR__
void nm_atmega32_settings_menu_glyphs(const NM8036 *m);
void nm_atmega32_settings_menu_draw(const NM8036 *m, const NMSettingsMenu *menu);
bool nm_atmega32_settings_step(NM8036 *m);
#endif
#endif
