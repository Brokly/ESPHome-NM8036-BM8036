#ifndef NM_ORIGINAL_DECIMAL_H
#define NM_ORIGINAL_DECIMAL_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint32_t magnitude;
    int16_t exponent;
} NMDecimalScale;

NMDecimalScale nm_avr_decimal_scale(uint32_t magnitude);
bool nm_avr_decimal_carry(uint8_t *digits, size_t length);
size_t nm_avr_decimal_trim(const uint8_t *digits, size_t length);
size_t nm_avr_decimal_exponent(uint8_t *output, uint8_t marker, int16_t exponent);
uint16_t nm_avr_decimal_padding(uint16_t width, uint16_t length, uint16_t offset, bool sign);

typedef uint16_t (*NMFormatEmit)(void *context, uint16_t state, uint8_t byte);
uint16_t nm_avr_format_ram(const uint8_t *sram, const uint8_t *format,
                           uint16_t *argument, uint16_t state,
                           NMFormatEmit emit, void *context);

bool nm_avr_decimal_digits(uint8_t *digits, uint16_t count, uint32_t magnitude,
                           bool point, bool sticky);
size_t nm_avr_decimal_leading_carry(uint8_t *digits, size_t length,
                                     int16_t *exponent, bool scientific);
void nm_avr_format_e92(uint8_t output[10], uint32_t word, bool sticky);

typedef struct {
    uint16_t width, precision;
    uint8_t sign, left, alternate, zero, specifier;
    bool wide;
} NMFlashFormat;
NMFlashFormat nm_avr_flash_format_parse(const uint8_t **format,
                                        const uint8_t *sram, uint16_t *argument);
void nm_avr_flash_format_count(uint8_t *sram, uint16_t *argument, uint16_t count, bool wide);
uint8_t nm_avr_flash_format_char(const uint8_t *sram, uint16_t *argument);
typedef struct {
    uint16_t address, length;
    bool flash;
} NMFlashString;
NMFlashString nm_avr_flash_format_string(const uint8_t *sram, uint16_t *argument,
                                          uint16_t precision);
bool nm_avr_flash_format(const uint8_t *flash, const uint8_t *format,
                         uint8_t *sram, uint16_t *argument, uint16_t state,
                         NMFormatEmit emit, void *context, uint16_t *count);
#endif
