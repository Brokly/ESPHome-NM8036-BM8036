#ifndef NM_ORIGINAL_HELPERS_H
#define NM_ORIGINAL_HELPERS_H

#include <stdint.h>

uint8_t nm_avr_shl8(uint8_t value, uint8_t count);
uint16_t nm_avr_shl16(uint16_t value, uint8_t count);
uint16_t nm_avr_asr16(uint16_t value, uint8_t count);
uint32_t nm_avr_shl32(uint32_t value, uint8_t count);
uint32_t nm_avr_lsr32(uint32_t value, uint8_t count);
uint16_t nm_avr_mul16(uint16_t left, uint16_t right);
uint32_t nm_avr_mul32(uint32_t left, uint32_t right);
uint8_t nm_avr_div8(uint8_t dividend, uint8_t divisor, uint8_t *remainder);
uint16_t nm_avr_div16(uint16_t dividend, uint16_t divisor, uint16_t *remainder);
uint16_t nm_avr_sdiv16(uint16_t dividend, uint16_t divisor, uint16_t *remainder);
uint32_t nm_avr_div32(uint32_t dividend, uint32_t divisor, uint32_t *remainder);
uint32_t nm_avr_neg32(uint32_t value);
int nm_avr_compare_bytes(const uint8_t *left, const uint8_t *right, uint16_t count);
void nm_avr_fill_bytes(uint8_t *buffer, uint8_t byte, uint16_t count);

uint16_t nm_avr_heap_init(volatile uint8_t *sram);
void nm_avr_heap_free(volatile uint8_t *sram, uint16_t payload);
uint16_t nm_avr_heap_alloc(volatile uint8_t *sram, uint16_t size);

typedef void (*NMHeapFailureHandler)(void *context, uint16_t word_address);
uint16_t nm_avr_heap_alloc_retry(volatile uint8_t *sram, uint16_t size,
                                 NMHeapFailureHandler handler, void *context);

#endif
