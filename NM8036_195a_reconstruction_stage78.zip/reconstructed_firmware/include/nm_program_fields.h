#ifndef NM_PROGRAM_FIELDS_H
#define NM_PROGRAM_FIELDS_H
#include "nm8036.h"

uint16_t nm_avr_program_record_base(uint8_t index);
uint8_t nm_avr_program_period_mode(const NM8036 *m);
uint8_t nm_avr_program_merge_time(uint8_t previous, uint8_t field);
void nm_avr_program_record_key(uint8_t editor[8], uint8_t key);
void nm_avr_program_limit(uint8_t editor[6], bool upper);
#endif
