#ifndef NM_RUNTIME_H
#define NM_RUNTIME_H
#include "nm8036.h"

bool nm_rtc_fix_startup(const NM8036 *m);
void nm_factory_analog_display_defaults(const NM8036 *m);
void nm_clock_text(const NM8036 *m, uint8_t display[8]);
void nm_home_clock_screen(const NM8036 *m, uint8_t screen[32]);
void nm_home_adc_screen(const NM8036 *m, bool volts, uint8_t screen[32]);
void nm_home_temperature_screen(const NM8036 *m, uint8_t group, bool sqw, uint8_t screen[32]);
float nm_adc_scale(const NM8036 *m, uint8_t channel, int16_t count);
float nm_adc_calibrated(const NM8036 *m, uint8_t channel);
bool nm_home_page(const NM8036 *m, uint8_t *interval, bool *manual);

#ifdef __AVR__
void nm_atmega32_home_temperature_glyphs(const NM8036 *m, uint8_t group);
/* Начальный блок возвращает код клавиши, выбирающий ветвь 0x41EC. */
uint8_t nm_atmega32_startup_prefix(NM8036 *m);
void nm_atmega32_initialize(NM8036 *m);
void nm_atmega32_startup_normal(NM8036 *m);
void nm_atmega32_front_scan(NM8036 *m);
void nm_atmega32_control_service(const NM8036 *m);
void nm_atmega32_standby(NM8036 *m);
bool nm_atmega32_main_iteration(NM8036 *m);
#endif
#endif
