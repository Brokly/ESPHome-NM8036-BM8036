
/mnt/data/nm8036_195_corrected.elf:	file format elf32-avr

Disassembly of section .text:

00000000 <.text>:
       0: 0c 94 5c 31  	<unknown>
       4: 0c 94 b4 2c  	<unknown>
       8: 18 95        	reti
       a: 18 95        	reti
       c: 18 95        	reti
       e: 18 95        	reti
      10: 18 95        	reti
      12: 18 95        	reti
      14: 0c 94 c4 0f  	<unknown>
      18: 18 95        	reti
      1a: 18 95        	reti
      1c: 18 95        	reti
      1e: 18 95        	reti
      20: 18 95        	reti
      22: 18 95        	reti
      24: 18 95        	reti
      26: 18 95        	reti
      28: 18 95        	reti
      2a: 18 95        	reti
      2c: 18 95        	reti
      2e: 18 95        	reti
      30: 18 95        	reti
      32: 18 95        	reti
      34: 18 95        	reti
      36: 18 95        	reti
      38: 18 95        	reti
      3a: 18 95        	reti
      3c: 18 95        	reti
      3e: 18 95        	reti
      40: 0c 94 e6 06  	<unknown>
      44: 18 95        	reti
      46: 18 95        	reti
      48: 18 95        	reti
      4a: 18 95        	reti
      4c: 18 95        	reti
      4e: 18 95        	reti
      50: 18 95        	reti
      52: 18 95        	reti
      54: 18 95        	reti
      56: 18 95        	reti
      58: c2 e2        	ldi	r28, 0x22
      5a: e5 e4        	ldi	r30, 0x45
      5c: e8 f2        	brlo	.-70
      5e: e5 20        	and	r14, r5
      60: f1 f3        	breq	.-4
      62: f4 f4        	brge	.+60
      64: e8 ea        	ldi	r30, 0xa8
      66: f1 00 c4 e0  	<unknown>
      6a: f2 f7        	brpl	.-4
      6c: 2e 25        	eor	r18, r14
      6e: 64 3a        	cpi	r22, 0xa4
      70: 25 34        	cpi	r18, 0x45
      72: 64 28        	or	r6, r4
      74: 62 69        	ori	r22, 0x92
      76: 6e 29        	or	r22, r14
      78: 20 20        	and	r2, r0
      7a: 20 00 c4 e0  	<unknown>
      7e: f2 f7        	brpl	.-4
      80: 2e 25        	eor	r18, r14
      82: 64 3a        	cpi	r22, 0xa4
      84: 25 20        	and	r2, r5
      86: 35 2e        	mov	r3, r21
      88: 33 66        	ori	r19, 0x63
      8a: 56 20        	and	r5, r6
      8c: 20 20        	and	r2, r0
      8e: 20 20        	and	r2, r0
      90: 00 c4        	rjmp	.+2048
      92: e0 f2        	brlo	.-72
      94: f7 2e        	mov	r15, r23
      96: 25 64        	ori	r18, 0x45
      98: 3a 25        	eor	r19, r10
      9a: 39 2e        	mov	r3, r25
      9c: 32 65        	ori	r19, 0x52
      9e: 20 20        	and	r2, r0
      a0: 20 20        	and	r2, r0
      a2: 00 20        	tst	r0
      a4: c0 d6        	rcall	.+3456
      a6: cf 20        	and	r12, r15
      a8: 28 62        	ori	r18, 0x28
      aa: 69 6e        	ori	r22, 0xe9
      ac: 2d 64        	ori	r18, 0x4d
      ae: 61 74        	andi	r22, 0x41
      b0: 61 29        	or	r22, r1
      b2: 00 00        	nop
      b4: 20 c0        	rjmp	.+64
      b6: d6 cf        	rjmp	.-84
      b8: 20 28        	or	r2, r0
      ba: c2 ee        	ldi	r28, 0xe2
      bc: eb fc f2 fb  	<unknown>
      c0: 29 00 00 00  	<unknown>
      c4: 00 20        	tst	r0
      c6: c0 d6        	rcall	.+3456
      c8: cf 20        	and	r12, r15
      ca: 28 d4        	rcall	.+2128
      cc: e8 e7        	ldi	r30, 0x78
      ce: e8 ea        	ldi	r30, 0xa8
      d0: e0 29        	or	r30, r0
      d2: 00 00        	nop
      d4: 00 00        	nop
      d6: 20 49        	sbci	r18, 0x90
      d8: 20 20        	and	r2, r0
      da: cc e8        	ldi	r28, 0x8c
      dc: ed e8        	ldi	r30, 0x8d
      de: ec f3        	brlt	.-6
      e0: ec 00 00 00  	<unknown>
      e4: 00 00        	nop
      e6: 00 20        	tst	r0
      e8: 49 20        	and	r4, r9
      ea: 20 cc        	rjmp	.-1984
      ec: e0 ea        	ldi	r30, 0xa0
      ee: f1 e8        	ldi	r31, 0x81
      f0: ec f3        	brlt	.-6
      f2: ec 00 00 00  	<unknown>
      f6: 00 00        	nop
      f8: 20 49        	sbci	r18, 0x90
      fa: 49 20        	and	r4, r9
      fc: cc e8        	ldi	r28, 0x8c
      fe: ed e8        	ldi	r30, 0x8d
     100: ec f3        	brlt	.-6
     102: ec 00 00 00  	<unknown>
     106: 00 00        	nop
     108: 00 20        	tst	r0
     10a: 49 49        	sbci	r20, 0x99
     10c: 20 cc        	rjmp	.-1984
     10e: e0 ea        	ldi	r30, 0xa0
     110: f1 e8        	ldi	r31, 0x81
     112: ec f3        	brlt	.-6
     114: ec 00 00 00  	<unknown>
     118: 00 00        	nop
     11a: 20 49        	sbci	r18, 0x90
     11c: 20 20        	and	r2, r0
     11e: d2 ee        	ldi	r29, 0xe2
     120: f7 ed        	ldi	r31, 0xd7
     122: ee f1        	brts	.+122
     124: f2 fc        	sbrc	r15, 0x2
     126: 00 00        	nop
     128: 00 00        	nop
     12a: 00 20        	tst	r0
     12c: 49 49        	sbci	r20, 0x99
     12e: 20 d2        	rcall	.+1088
     130: ee f7        	brtc	.-6
     132: ed ee        	ldi	r30, 0xed
     134: f1 f2        	breq	.-68
     136: fc 00 00 00  	<unknown>
     13a: 00 00        	nop
     13c: 20 49        	sbci	r18, 0x90
     13e: 20 20        	and	r2, r0
     140: d1 f3        	breq	.-12
     142: f4 f4        	brge	.+60
     144: e8 ea        	ldi	r30, 0xa8
     146: f1 00 00 00  	<unknown>
     14a: 00 00        	nop
     14c: 00 20        	tst	r0
     14e: 49 49        	sbci	r20, 0x99
     150: 20 d1        	rcall	.+576
     152: f3 f4        	brvc	.+60
     154: f4 e8        	ldi	r31, 0x84
     156: ea f1        	brmi	.+122
     158: 00 00        	nop
     15a: 00 00        	nop
     15c: 00 00        	nop
     15e: 20 c2        	rjmp	.+1088
     160: e2 e5        	ldi	r30, 0x52
     162: e4 e8        	ldi	r30, 0x84
     164: f2 e5        	ldi	r31, 0x52
     166: 20 ef        	ldi	r18, 0xf0
     168: f0 e5        	ldi	r31, 0x50
     16a: e4 e5        	ldi	r30, 0x54
     16c: eb 20        	and	r14, r11
     16e: 00 c7        	rjmp	.+3584
     170: ed e0        	ldi	r30, 0xd
     172: ea ee        	ldi	r30, 0xea
     174: e2 20        	and	r14, r2
     176: ef ee        	ldi	r30, 0xef
     178: f1 eb        	ldi	r31, 0xb1
     17a: e5 20        	and	r14, r5
     17c: e7 ef        	ldi	r30, 0xf7
     17e: f2 00 75 0b  	<unknown>
     182: 6a 0c        	add	r6, r10
     184: 7f 0d        	add	r23, r15
     186: 25 6c        	ori	r18, 0xc5
     188: 64 00 c2 e2  	<unknown>
     18c: ee e4        	ldi	r30, 0x4e
     18e: 20 e7        	ldi	r18, 0x70
     190: ed e0        	ldi	r30, 0xd
     192: f7 e5        	ldi	r31, 0x57
     194: ed e8        	ldi	r30, 0x8d
     196: ff 3a        	cpi	r31, 0xaf
     198: 00 25        	eor	r16, r0
     19a: 64 2e        	mov	r6, r20
     19c: 25 64        	ori	r18, 0x45
     19e: 25 64        	ori	r18, 0x45
     1a0: 65 20        	and	r6, r5
     1a2: 25 64        	ori	r18, 0x45
     1a4: 25 64        	ori	r18, 0x45
     1a6: 00 25        	eor	r16, r0
     1a8: 39 2e        	mov	r3, r25
     1aa: 32 65        	ori	r19, 0x52
     1ac: 00 01 03 00  	<unknown>
     1b0: 04 06        	cpc	r0, r20
     1b2: 00 07        	cpc	r16, r16
     1b4: 08 00 08 00  	<unknown>
     1b8: 00 01 03 00  	<unknown>
     1bc: 04 06        	cpc	r0, r20
     1be: 07 a2 ed 20  	<unknown>
     1c2: 20 20        	and	r2, r0
     1c4: 20 20        	and	r2, r0
     1c6: 20 20        	and	r2, r0
     1c8: 20 20        	and	r2, r0
     1ca: 20 20        	and	r2, r0
     1cc: 20 20        	and	r2, r0
     1ce: 20 b5        	in	r18, 0x20
     1d0: 20 20        	and	r2, r0
     1d2: 20 20        	and	r2, r0
     1d4: 20 20        	and	r2, r0
     1d6: 20 41        	sbci	r18, 0x10
     1d8: a0 42        	sbci	r26, 0x20
     1da: a1 e0        	ldi	r26, 0x1
     1dc: 45 a3 a4 a5  	<unknown>
     1e0: a6 4b        	sbci	r26, 0xb6
     1e2: a7 4d        	sbci	r26, 0xd7
     1e4: 48 4f        	sbci	r20, 0xf8
     1e6: a8 50        	subi	r26, 0x8
     1e8: 43 54        	subi	r20, 0x43
     1ea: a9 aa 58 e1  	<unknown>
     1ee: ab ac e2 ad  	<unknown>
     1f2: ae 62        	ori	r26, 0x2e
     1f4: af b0        	in	r10, 0xf
     1f6: b1 61        	ori	r27, 0x11
     1f8: b2 b3        	in	r27, 0x12
     1fa: b4 e3        	ldi	r27, 0x34
     1fc: 65 b6        	in	r6, 0x35
     1fe: b7 b8        	out	0x7, r11
     200: b9 ba        	out	0x19, r11
     202: bb bc        	out	0x2b, r11
     204: bd 6f        	ori	r27, 0xfd
     206: be 70        	andi	r27, 0xe
     208: 63 bf        	out	0x33, r22
     20a: 79 e4        	ldi	r23, 0x49
     20c: 78 e5        	ldi	r23, 0x58
     20e: c0 c1        	rjmp	.+896
     210: e6 c2        	rjmp	.+1484
     212: c3 c4        	rjmp	.+2438
     214: c5 c6        	rjmp	.+3466
     216: c7 08        	sbc	r12, r7
     218: 0c 1e        	adc	r0, r28
     21a: 1f 1e        	adc	r1, r31
     21c: 0c 08        	sbc	r0, r12
     21e: 00 04        	cpc	r0, r0
     220: 0e 1f        	adc	r16, r30
     222: 04 04        	cpc	r0, r4
     224: 04 04        	cpc	r0, r4
     226: 00 04        	cpc	r0, r0
     228: 04 04        	cpc	r0, r4
     22a: 04 1f        	adc	r16, r20
     22c: 0e 04        	cpc	r0, r14
     22e: 00 c2        	rjmp	.+1024
     230: e2 e5        	ldi	r30, 0x52
     232: e4 e8        	ldi	r30, 0x84
     234: f2 e5        	ldi	r31, 0x52
     236: 20 e2        	ldi	r18, 0x20
     238: f0 e5        	ldi	r31, 0x50
     23a: ec ff 28 f1  	<unknown>
     23e: 29 00 20 c0  	<unknown>
     242: ea f2        	brmi	.-70
     244: e8 e2        	ldi	r30, 0x28
     246: ed ee        	ldi	r30, 0xed
     248: f1 f2        	breq	.-68
     24a: fc 20        	and	r15, r12
     24c: 31 00 00 00  	<unknown>
     250: 00 20        	tst	r0
     252: c0 ea        	ldi	r28, 0xa0
     254: f2 e8        	ldi	r31, 0x82
     256: e2 ed        	ldi	r30, 0xd2
     258: ee f1        	brts	.+122
     25a: f2 fc        	sbrc	r15, 0x2
     25c: 20 32        	cpi	r18, 0x20
     25e: 00 00        	nop
     260: 00 00        	nop
     262: 20 c0        	rjmp	.+64
     264: ea f2        	brmi	.-70
     266: e8 e2        	ldi	r30, 0x28
     268: ed ee        	ldi	r30, 0xed
     26a: f1 f2        	breq	.-68
     26c: fc 20        	and	r15, r12
     26e: 33 00 00 00  	<unknown>
     272: 00 20        	tst	r0
     274: c0 ea        	ldi	r28, 0xa0
     276: f2 e8        	ldi	r31, 0x82
     278: e2 ed        	ldi	r30, 0xd2
     27a: ee f1        	brts	.+122
     27c: f2 fc        	sbrc	r15, 0x2
     27e: 20 34        	cpi	r18, 0x40
     280: 00 00        	nop
     282: 00 00        	nop
     284: 20 c0        	rjmp	.+64
     286: ea f2        	brmi	.-70
     288: e8 e2        	ldi	r30, 0x28
     28a: ed ee        	ldi	r30, 0xed
     28c: f1 f2        	breq	.-68
     28e: fc 20        	and	r15, r12
     290: 35 00 00 00  	<unknown>
     294: 00 20        	tst	r0
     296: c0 ea        	ldi	r28, 0xa0
     298: f2 e8        	ldi	r31, 0x82
     29a: e2 ed        	ldi	r30, 0xd2
     29c: ee f1        	brts	.+122
     29e: f2 fc        	sbrc	r15, 0x2
     2a0: 20 36        	cpi	r18, 0x60
     2a2: 00 00        	nop
     2a4: 00 00        	nop
     2a6: 20 c0        	rjmp	.+64
     2a8: ea f2        	brmi	.-70
     2aa: e8 e2        	ldi	r30, 0x28
     2ac: ed ee        	ldi	r30, 0xed
     2ae: f1 f2        	breq	.-68
     2b0: fc 20        	and	r15, r12
     2b2: 37 00 00 00  	<unknown>
     2b6: 00 20        	tst	r0
     2b8: c0 ea        	ldi	r28, 0xa0
     2ba: f2 e8        	ldi	r31, 0x82
     2bc: e2 ed        	ldi	r30, 0xd2
     2be: ee f1        	brts	.+122
     2c0: f2 fc        	sbrc	r15, 0x2
     2c2: 20 38        	cpi	r18, 0x80
     2c4: 00 00        	nop
     2c6: 00 00        	nop
     2c8: 20 c0        	rjmp	.+64
     2ca: ea f2        	brmi	.-70
     2cc: e8 e2        	ldi	r30, 0x28
     2ce: ed ee        	ldi	r30, 0xed
     2d0: f1 f2        	breq	.-68
     2d2: fc 20        	and	r15, r12
     2d4: 39 00 00 00  	<unknown>
     2d8: 00 20        	tst	r0
     2da: c0 ea        	ldi	r28, 0xa0
     2dc: f2 e8        	ldi	r31, 0x82
     2de: e2 ed        	ldi	r30, 0xd2
     2e0: ee f1        	brts	.+122
     2e2: f2 fc        	sbrc	r15, 0x2
     2e4: 20 31        	cpi	r18, 0x10
     2e6: 30 00 00 00  	<unknown>
     2ea: 20 c0        	rjmp	.+64
     2ec: ea f2        	brmi	.-70
     2ee: e8 e2        	ldi	r30, 0x28
     2f0: ed ee        	ldi	r30, 0xed
     2f2: f1 f2        	breq	.-68
     2f4: fc 20        	and	r15, r12
     2f6: 31 31        	cpi	r19, 0x11
     2f8: 00 00        	nop
     2fa: 00 20        	tst	r0
     2fc: c0 ea        	ldi	r28, 0xa0
     2fe: f2 e8        	ldi	r31, 0x82
     300: e2 ed        	ldi	r30, 0xd2
     302: ee f1        	brts	.+122
     304: f2 fc        	sbrc	r15, 0x2
     306: 20 31        	cpi	r18, 0x10
     308: 32 00 00 00  	<unknown>
     30c: 20 cd        	rjmp	.-1472
     30e: e5 c0        	rjmp	.+458
     310: ea f2        	brmi	.-70
     312: e8 e2        	ldi	r30, 0x28
     314: 2d f2        	brhs	.-118
     316: fc 20        	and	r15, r12
     318: 31 00 00 00  	<unknown>
     31c: 00 20        	tst	r0
     31e: cd e5        	ldi	r28, 0x5d
     320: c0 ea        	ldi	r28, 0xa0
     322: f2 e8        	ldi	r31, 0x82
     324: e2 2d        	mov	r30, r2
     326: f2 fc        	sbrc	r15, 0x2
     328: 20 32        	cpi	r18, 0x20
     32a: 00 00        	nop
     32c: 00 00        	nop
     32e: 20 cd        	rjmp	.-1472
     330: e5 c0        	rjmp	.+458
     332: ea f2        	brmi	.-70
     334: e8 e2        	ldi	r30, 0x28
     336: 2d f2        	brhs	.-118
     338: fc 20        	and	r15, r12
     33a: 33 00 00 00  	<unknown>
     33e: 00 20        	tst	r0
     340: cd e5        	ldi	r28, 0x5d
     342: c0 ea        	ldi	r28, 0xa0
     344: f2 e8        	ldi	r31, 0x82
     346: e2 2d        	mov	r30, r2
     348: f2 fc        	sbrc	r15, 0x2
     34a: 20 34        	cpi	r18, 0x40
     34c: 00 00        	nop
     34e: 00 00        	nop
     350: 20 cd        	rjmp	.-1472
     352: e5 c0        	rjmp	.+458
     354: ea f2        	brmi	.-70
     356: e8 e2        	ldi	r30, 0x28
     358: 2d f2        	brhs	.-118
     35a: fc 20        	and	r15, r12
     35c: 35 00 00 00  	<unknown>
     360: 00 20        	tst	r0
     362: cd e5        	ldi	r28, 0x5d
     364: c0 ea        	ldi	r28, 0xa0
     366: f2 e8        	ldi	r31, 0x82
     368: e2 2d        	mov	r30, r2
     36a: f2 fc        	sbrc	r15, 0x2
     36c: 20 36        	cpi	r18, 0x60
     36e: 00 00        	nop
     370: 00 00        	nop
     372: 20 cd        	rjmp	.-1472
     374: e5 c0        	rjmp	.+458
     376: ea f2        	brmi	.-70
     378: e8 e2        	ldi	r30, 0x28
     37a: 2d f2        	brhs	.-118
     37c: fc 20        	and	r15, r12
     37e: 37 00 00 00  	<unknown>
     382: 00 20        	tst	r0
     384: cd e5        	ldi	r28, 0x5d
     386: c0 ea        	ldi	r28, 0xa0
     388: f2 e8        	ldi	r31, 0x82
     38a: e2 2d        	mov	r30, r2
     38c: f2 fc        	sbrc	r15, 0x2
     38e: 20 38        	cpi	r18, 0x80
     390: 00 00        	nop
     392: 00 00        	nop
     394: 20 cd        	rjmp	.-1472
     396: e5 c0        	rjmp	.+458
     398: ea f2        	brmi	.-70
     39a: e8 e2        	ldi	r30, 0x28
     39c: 2d f2        	brhs	.-118
     39e: fc 20        	and	r15, r12
     3a0: 39 00 00 00  	<unknown>
     3a4: 00 20        	tst	r0
     3a6: cd e5        	ldi	r28, 0x5d
     3a8: c0 ea        	ldi	r28, 0xa0
     3aa: f2 e8        	ldi	r31, 0x82
     3ac: e2 2d        	mov	r30, r2
     3ae: f2 fc        	sbrc	r15, 0x2
     3b0: 20 31        	cpi	r18, 0x10
     3b2: 30 00 00 00  	<unknown>
     3b6: 20 cd        	rjmp	.-1472
     3b8: e5 c0        	rjmp	.+458
     3ba: ea f2        	brmi	.-70
     3bc: e8 e2        	ldi	r30, 0x28
     3be: 2d f2        	brhs	.-118
     3c0: fc 20        	and	r15, r12
     3c2: 31 31        	cpi	r19, 0x11
     3c4: 00 00        	nop
     3c6: 00 20        	tst	r0
     3c8: cd e5        	ldi	r28, 0x5d
     3ca: c0 ea        	ldi	r28, 0xa0
     3cc: f2 e8        	ldi	r31, 0x82
     3ce: e2 2d        	mov	r30, r2
     3d0: f2 fc        	sbrc	r15, 0x2
     3d2: 20 31        	cpi	r18, 0x10
     3d4: 32 00 00 00  	<unknown>
     3d8: 48 14        	cp	r4, r8
     3da: bb 13        	cpse	r27, r27
     3dc: c6 14        	cp	r12, r6
     3de: bb 14        	cp	r11, r11
     3e0: 1f 10        	cpse	r1, r15
     3e2: 10 10        	cpse	r1, r0
     3e4: 10 10        	cpse	r1, r0
     3e6: 10 1f        	adc	r17, r16
     3e8: 1f 00 00 00  	<unknown>
     3ec: 00 00        	nop
     3ee: 00 1f        	rol	r16
     3f0: 1f 00 10 10  	<unknown>
     3f4: 10 10        	cpse	r1, r0
     3f6: 00 1f        	rol	r16
     3f8: 1f 00 14 14  	<unknown>
     3fc: 14 14        	cp	r1, r4
     3fe: 00 1f        	rol	r16
     400: 1f 00 15 15  	<unknown>
     404: 15 15        	cp	r17, r5
     406: 00 1f        	rol	r16
     408: 1f 01 01 01  	<unknown>
     40c: 01 01 01 1f  	<unknown>
     410: 1f 10        	cpse	r1, r15
     412: 14 14        	cp	r1, r4
     414: 14 14        	cp	r1, r4
     416: 10 1f        	adc	r17, r16
     418: 1f 10        	cpse	r1, r15
     41a: 15 15        	cp	r17, r5
     41c: 15 15        	cp	r17, r5
     41e: 10 1f        	adc	r17, r16
     420: 1f 01 11 11  	<unknown>
     424: 11 11        	cpse	r17, r1
     426: 01 1f        	adc	r16, r17
     428: 1f 01 15 15  	<unknown>
     42c: 15 15        	cp	r17, r5
     42e: 01 1f        	adc	r16, r17
     430: c2 e2        	ldi	r28, 0x22
     432: e5 e4        	ldi	r30, 0x45
     434: e8 f2        	brlo	.-70
     436: e5 20        	and	r14, r5
     438: e7 ed        	ldi	r30, 0xd7
     43a: e0 f7        	brsh	.-8
     43c: e5 ed        	ldi	r30, 0xd5
     43e: e8 e5        	ldi	r30, 0x58
     440: 3a 00 20 ca  	<unknown>
     444: e0 ed        	ldi	r30, 0xd0
     446: e0 eb        	ldi	r30, 0xb0
     448: fb 20        	and	r15, r11
     44a: 31 20        	and	r3, r1
     44c: ef ee        	ldi	r30, 0xef
     44e: 20 34        	cpi	r18, 0x40
     450: 00 00        	nop
     452: 00 20        	tst	r0
     454: ca e0        	ldi	r28, 0xa
     456: ed e0        	ldi	r30, 0xd
     458: eb fb 20 35  	<unknown>
     45c: 20 ef        	ldi	r18, 0xf0
     45e: ee 20        	tst	r14
     460: 38 00 00 00  	<unknown>
     464: 20 ca        	rjmp	.-3008
     466: e0 ed        	ldi	r30, 0xd0
     468: e0 eb        	ldi	r30, 0xb0
     46a: fb 20        	and	r15, r11
     46c: 39 20        	and	r3, r9
     46e: ef ee        	ldi	r30, 0xef
     470: 20 31        	cpi	r18, 0x10
     472: 32 00 00 20  	<unknown>
     476: c2 f0        	brmi	.+48
     478: e5 ec        	ldi	r30, 0xc5
     47a: ff 2f        	mov	r31, r31
     47c: e4 e0        	ldi	r30, 0x4
     47e: f2 e0        	ldi	r31, 0x2
     480: 00 00        	nop
     482: 00 00        	nop
     484: 00 00        	nop
     486: 20 c0        	rjmp	.+64
     488: ed e0        	ldi	r30, 0xd
     48a: eb ee        	ldi	r30, 0xeb
     48c: e3 20        	and	r14, r3
     48e: f6 e8        	ldi	r31, 0x86
     490: f4 f0        	brlt	.+60
     492: e0 00 00 00  	<unknown>
     496: 00 20        	tst	r0
     498: c0 ed        	ldi	r28, 0xd0
     49a: e0 eb        	ldi	r30, 0xb0
     49c: ee e3        	ldi	r30, 0x3e
     49e: 20 ed        	ldi	r18, 0xd0
     4a0: e0 ef        	ldi	r30, 0xf0
     4a2: f0 ff        	sbrs	r31, 0x0
     4a4: e6 2e        	mov	r14, r22
     4a6: 00 00        	nop
     4a8: 20 c0        	rjmp	.+64
     4aa: ed e0        	ldi	r30, 0xd
     4ac: eb ee        	ldi	r30, 0xeb
     4ae: e3 20        	and	r14, r3
     4b0: f4 e8        	ldi	r31, 0x84
     4b2: e7 e8        	ldi	r30, 0x87
     4b4: ea e0        	ldi	r30, 0xa
     4b6: 00 00        	nop
     4b8: 00 25        	eor	r16, r0
     4ba: 32 64        	ori	r19, 0x42
     4bc: 3a 25        	eor	r19, r10
     4be: 2e 32        	cpi	r18, 0x2e
     4c0: 64 3a        	cpi	r22, 0xa4
     4c2: 25 2e        	mov	r2, r21
     4c4: 32 64        	ori	r19, 0x42
     4c6: 20 00 25 32  	<unknown>
     4ca: 64 2d        	mov	r22, r4
     4cc: 25 2e        	mov	r2, r21
     4ce: 32 64        	ori	r19, 0x42
     4d0: 2d 32        	cpi	r18, 0x2d
     4d2: 30 25        	eor	r19, r0
     4d4: 2e 32        	cpi	r18, 0x2e
     4d6: 64 00 25 2e  	<unknown>
     4da: 32 64        	ori	r19, 0x42
     4dc: 00 25        	eor	r16, r0
     4de: 32 64        	ori	r19, 0x42
     4e0: 20 00 25 2e  	<unknown>
     4e4: 32 64        	ori	r19, 0x42
     4e6: 3a 25        	eor	r19, r10
     4e8: 2e 32        	cpi	r18, 0x2e
     4ea: 64 20        	and	r6, r4
     4ec: 25 2e        	mov	r2, r21
     4ee: 32 64        	ori	r19, 0x42
     4f0: 3a 25        	eor	r19, r10
     4f2: 2e 32        	cpi	r18, 0x2e
     4f4: 64 00 2d cd  	<unknown>
     4f8: c5 20        	and	r12, r5
     4fa: c0 ca        	rjmp	.-2688
     4fc: d2 c8        	rjmp	.-3676
     4fe: c2 c5        	rjmp	.+2948
     500: cd 2d        	mov	r28, r13
     502: 20 00 4e 6f  	<unknown>
     506: 20 4c        	sbci	r18, 0xc0
     508: 20 20        	and	r2, r0
     50a: 20 4f        	sbci	r18, 0xf0
     50c: 6e 20        	and	r6, r14
     50e: 20 20        	and	r2, r0
     510: 4f 66        	ori	r20, 0x6f
     512: 66 00 20 20  	<unknown>
     516: 20 20        	and	r2, r0
     518: 20 20        	and	r2, r0
     51a: 20 20        	and	r2, r0
     51c: 20 20        	and	r2, r0
     51e: 20 20        	and	r2, r0
     520: 20 20        	and	r2, r0
     522: 20 20        	and	r2, r0
     524: 00 00        	nop
     526: 00 00        	nop
     528: 20 20        	and	r2, r0
     52a: 20 20        	and	r2, r0
     52c: 20 d8        	rcall	.-4032
     52e: c0 c3        	rjmp	.+1920
     530: 20 25        	eor	r18, r0
     532: 32 64        	ori	r19, 0x42
     534: 00 20        	tst	r0
     536: 20 20        	and	r2, r0
     538: 20 c2        	rjmp	.+1088
     53a: ea eb        	ldi	r30, 0xba
     53c: fe f7        	brtc	.-2
     53e: e5 ed        	ldi	r30, 0xd5
     540: 20 20        	and	r2, r0
     542: 20 20        	and	r2, r0
     544: 20 00 20 20  	<unknown>
     548: 20 20        	and	r2, r0
     54a: c2 fb        	bst	r28, 0x2
     54c: ea eb        	ldi	r30, 0xba
     54e: fe f7        	brtc	.-2
     550: e5 ed        	ldi	r30, 0xd5
     552: 20 20        	and	r2, r0
     554: 20 20        	and	r2, r0
     556: 00 25        	eor	r16, r0
     558: 32 64        	ori	r19, 0x42
     55a: 3a 20        	and	r3, r10
     55c: 20 20        	and	r2, r0
     55e: 20 20        	and	r2, r0
     560: 00 f1        	brlo	.+64
     562: f2 e0        	ldi	r31, 0x2
     564: f0 f2        	brlo	.-68
     566: 00 f1        	brlo	.+64
     568: f2 ee        	ldi	r31, 0xe2
     56a: ef 20        	and	r14, r15
     56c: 00 cd        	rjmp	.-1536
     56e: e0 e3        	ldi	r30, 0x30
     570: f0 f3        	brlo	.-4
     572: e7 ea        	ldi	r30, 0xa7
     574: e0 3a        	cpi	r30, 0xa0
     576: 25 32        	cpi	r18, 0x25
     578: 64 d2        	rcall	.+1224
     57a: e8 ef        	ldi	r30, 0xf8
     57c: 3a 20        	and	r3, r10
     57e: 00 78        	andi	r16, 0x80
     580: 00 c4        	rjmp	.+2048
     582: e0 f2        	brlo	.-72
     584: f7 e8        	ldi	r31, 0x87
     586: ea 3a        	cpi	r30, 0xaa
     588: 25 2e        	mov	r2, r21
     58a: 32 64        	ori	r19, 0x42
     58c: 20 20        	and	r2, r0
     58e: d2 e8        	ldi	r29, 0x82
     590: ef 3a        	cpi	r30, 0xaf
     592: 44 00 d2 e8  	<unknown>
     596: ef 3a        	cpi	r30, 0xaf
     598: 41 00 d3 f1  	<unknown>
     59c: f2 e0        	ldi	r31, 0x2
     59e: ed 2e        	mov	r14, r29
     5a0: 20 ee        	ldi	r18, 0xe0
     5a2: f2 ed        	ldi	r31, 0xd2
     5a4: ee f1        	brts	.+122
     5a6: e8 f2        	brlo	.-70
     5a8: 2e 00 e4 f0  	<unknown>
     5ac: f3 e3        	ldi	r31, 0x33
     5ae: ee e3        	ldi	r30, 0x3e
     5b0: ee 20        	tst	r14
     5b2: e4 e0        	ldi	r30, 0x4
     5b4: f2 f7        	brpl	.-4
     5b6: e8 ea        	ldi	r30, 0xa8
     5b8: e0 00 c0 e1  	<unknown>
     5bc: f1 ee        	ldi	r31, 0xe1
     5be: eb fe f2 ed  	<unknown>
     5c2: e0 ff        	sbrs	r30, 0x0
     5c4: 00 f3        	brlo	.-64
     5c6: f1 f2        	breq	.-68
     5c8: e0 ed        	ldi	r30, 0xd0
     5ca: ee e2        	ldi	r30, 0x2e
     5cc: ea e0        	ldi	r30, 0xa
     5ce: 00 c2        	rjmp	.+1024
     5d0: ea eb        	ldi	r30, 0xba
     5d2: fe f7        	brtc	.-2
     5d4: e0 f2        	brlo	.-72
     5d6: fc 20        	and	r15, r12
     5d8: ed e0        	ldi	r30, 0xd
     5da: e3 f0        	brvs	.+56
     5dc: e5 e2        	ldi	r30, 0x25
     5de: 00 e5        	ldi	r16, 0x50
     5e0: f1 eb        	ldi	r31, 0xb1
     5e2: e8 20        	and	r14, r8
     5e4: 54 25        	eor	r21, r4
     5e6: 64 3c        	cpi	r22, 0xc4
     5e8: 54 25        	eor	r21, r4
     5ea: 64 00 c2 ea  	<unknown>
     5ee: eb 2e        	mov	r14, r27
     5f0: 20 ee        	ldi	r18, 0xe0
     5f2: f5 eb        	ldi	r31, 0xb5
     5f4: e0 e4        	ldi	r30, 0x40
     5f6: e8 f2        	brlo	.-70
     5f8: e5 eb        	ldi	r30, 0xb5
     5fa: fc 00 e5 f1  	<unknown>
     5fe: eb e8        	ldi	r30, 0x8b
     600: 20 54        	subi	r18, 0x40
     602: 25 64        	ori	r18, 0x45
     604: 3e 54        	subi	r19, 0x4e
     606: 25 64        	ori	r18, 0x45
     608: 00 4c        	sbci	r16, 0xc0
     60a: 3a 00 48 3a  	<unknown>
     60e: 00 20        	tst	r0
     610: 25 39        	cpi	r18, 0x95
     612: 2e 33        	cpi	r18, 0x3e
     614: 65 25        	eor	r22, r5
     616: 63 00 25 36  	<unknown>
     61a: 2e 31        	cpi	r18, 0x1e
     61c: 66 43        	sbci	r22, 0x36
     61e: 20 20        	and	r2, r0
     620: 20 20        	and	r2, r0
     622: 20 20        	and	r2, r0
     624: 00 25        	eor	r16, r0
     626: 73 00 d0 e5  	<unknown>
     62a: e6 e8        	ldi	r30, 0x86
     62c: ec 20        	and	r14, r12
     62e: e0 ea        	ldi	r30, 0xa0
     630: f2 e8        	ldi	r31, 0x82
     632: e2 ed        	ldi	r30, 0xd2
     634: ee f1        	brts	.+122
     636: f2 e8        	ldi	r31, 0x82
     638: 00 cb        	rjmp	.-2560
     63a: ce c3        	rjmp	.+1948
     63c: c8 d7        	rcall	.+3984
     63e: c5 d1        	rcall	.+906
     640: ca ce        	rjmp	.-620
     642: c5 20        	and	r12, r5
     644: 22 c8        	rjmp	.-4028
     646: cb c8        	rjmp	.-3690
     648: 22 00 20 cb  	<unknown>
     64c: ce c3        	rjmp	.+1948
     64e: c8 d7        	rcall	.+3984
     650: c5 d1        	rcall	.+906
     652: ca ce        	rjmp	.-620
     654: c5 20        	and	r12, r5
     656: 22 c8        	rjmp	.-4028
     658: 22 20        	tst	r2
     65a: 00 cf        	rjmp	.-512
     65c: e5 f0        	brhs	.+56
     65e: e8 ee        	ldi	r30, 0xe8
     660: e4 e0        	ldi	r30, 0x4
     662: 20 ed        	ldi	r18, 0xd0
     664: e5 f2        	brhs	.-72
     666: 20 20        	and	r2, r0
     668: 20 20        	and	r2, r0
     66a: 00 cf        	rjmp	.-512
     66c: ee 20        	tst	r14
     66e: e4 ed        	ldi	r30, 0xd4
     670: ff ec        	ldi	r31, 0xcf
     672: 20 ed        	ldi	r18, 0xd0
     674: e5 e4        	ldi	r30, 0x45
     676: e5 eb        	ldi	r30, 0xb5
     678: e8 20        	and	r14, r8
     67a: 00 cf        	rjmp	.-512
     67c: ee 20        	tst	r14
     67e: e4 ed        	ldi	r30, 0xd4
     680: ff ec        	ldi	r31, 0xcf
     682: 20 ec        	ldi	r18, 0xc0
     684: e5 f1        	brhs	.+120
     686: ff f6        	brid	.-66
     688: e0 20        	and	r14, r0
     68a: 00 cf        	rjmp	.-512
     68c: ee 20        	tst	r14
     68e: ec e5        	ldi	r30, 0x5c
     690: f1 ff        	sbrs	r31, 0x1
     692: f6 e0        	ldi	r31, 0x6
     694: ec 3a        	cpi	r30, 0xac
     696: 20 20        	and	r2, r0
     698: 20 20        	and	r2, r0
     69a: 00 20        	tst	r0
     69c: 20 20        	and	r2, r0
     69e: 20 20        	and	r2, r0
     6a0: 20 20        	and	r2, r0
     6a2: 20 20        	and	r2, r0
     6a4: 20 20        	and	r2, r0
     6a6: 20 20        	and	r2, r0
     6a8: 20 20        	and	r2, r0
     6aa: 20 00 20 20  	<unknown>
     6ae: 20 20        	and	r2, r0
     6b0: 00 28        	or	r0, r0
     6b2: 2b 29        	or	r18, r11
     6b4: 00 28        	or	r0, r0
     6b6: 2d 29        	or	r18, r13
     6b8: 00 c4        	rjmp	.+2048
     6ba: e5 ed        	ldi	r30, 0xd5
     6bc: fc 20        	and	r15, r12
     6be: 25 32        	cpi	r18, 0x25
     6c0: 64 20        	and	r6, r4
     6c2: 20 20        	and	r2, r0
     6c4: 20 20        	and	r2, r0
     6c6: 20 00 20 20  	<unknown>
     6ca: 20 20        	and	r2, r0
     6cc: 20 20        	and	r2, r0
     6ce: 20 20        	and	r2, r0
     6d0: 00 ff        	sbrs	r16, 0x0
     6d2: ed e2        	ldi	r30, 0x2d
     6d4: e0 f0        	brlo	.+56
     6d6: fc 20        	and	r15, r12
     6d8: 20 00 f4 e5  	<unknown>
     6dc: e2 f0        	brmi	.+56
     6de: e0 eb        	ldi	r30, 0xb0
     6e0: fc 20        	and	r15, r12
     6e2: 00 ec        	ldi	r16, 0xc0
     6e4: e0 f0        	brlo	.+56
     6e6: f2 20        	and	r15, r2
     6e8: 20 20        	and	r2, r0
     6ea: 20 00 e0 ef  	<unknown>
     6ee: f0 e5        	ldi	r31, 0x50
     6f0: eb fc 20 20  	<unknown>
     6f4: 00 ec        	ldi	r16, 0xc0
     6f6: e0 e9        	ldi	r30, 0x90
     6f8: 20 20        	and	r2, r0
     6fa: 20 20        	and	r2, r0
     6fc: 20 00 e8 fe  	<unknown>
     700: ed fc 20 20  	<unknown>
     704: 20 20        	and	r2, r0
     706: 00 e8        	ldi	r16, 0x80
     708: fe eb        	ldi	r31, 0xbe
     70a: fc 20        	and	r15, r12
     70c: 20 20        	and	r2, r0
     70e: 20 00 e0 e2  	<unknown>
     712: e3 f3        	brvs	.-8
     714: f1 f2        	breq	.-68
     716: 20 20        	and	r2, r0
     718: 00 f1        	brlo	.+64
     71a: e5 ed        	ldi	r30, 0xd5
     71c: f2 ff        	sbrs	r31, 0x2
     71e: e1 f0        	breq	.+56
     720: fc 00 ee ea  	<unknown>
     724: f2 ff        	sbrs	r31, 0x2
     726: e1 f0        	breq	.+56
     728: fc 20        	and	r15, r12
     72a: 00 ed        	ldi	r16, 0xd0
     72c: ee ff e1 f0  	<unknown>
     730: fc 20        	and	r15, r12
     732: 20 00 e4 e5  	<unknown>
     736: ea e0        	ldi	r30, 0xa
     738: e1 f0        	breq	.+56
     73a: fc 20        	and	r15, r12
     73c: 00 cf        	rjmp	.-512
     73e: ce cd        	rjmp	.-1124
     740: c5 c4        	rjmp	.+2442
     742: c5 cb        	rjmp	.-2166
     744: dc cd        	rjmp	.-1096
     746: c8 ca        	rjmp	.-2672
     748: 00 c2        	rjmp	.+1024
     74a: d2 ce        	rjmp	.-604
     74c: d0 cd        	rjmp	.-1120
     74e: c8 ca        	rjmp	.-2672
     750: 00 00        	nop
     752: 00 00        	nop
     754: 00 d1        	rcall	.+512
     756: d0 c5        	rjmp	.+2976
     758: c4 c0        	rjmp	.+392
     75a: 00 00        	nop
     75c: 00 00        	nop
     75e: 00 00        	nop
     760: 00 d7        	rcall	.+3584
     762: c5 d2        	rcall	.+1418
     764: c2 c5        	rjmp	.+2948
     766: d0 c3        	rjmp	.+1952
     768: 00 00        	nop
     76a: 00 00        	nop
     76c: 00 cf        	rjmp	.-512
     76e: df d2        	rcall	.+1470
     770: cd c8        	rjmp	.-3686
     772: d6 c0        	rjmp	.+428
     774: 00 00        	nop
     776: 00 00        	nop
     778: 00 d1        	rcall	.+512
     77a: d3 c1        	rjmp	.+934
     77c: c1 ce        	rjmp	.-638
     77e: d2 c0        	rjmp	.+420
     780: 00 00        	nop
     782: 00 00        	nop
     784: 00 c2        	rjmp	.+1024
     786: ce d1        	rcall	.+924
     788: ca d0        	rcall	.+404
     78a: c5 d1        	rcall	.+906
     78c: c5 cd        	rjmp	.-1142
     78e: dc c5        	rjmp	.+3000
     790: 00 1f        	rol	r16
     792: 1c 1f        	adc	r17, r28
     794: 1e 1f        	adc	r17, r30
     796: 1e 1f        	adc	r17, r30
     798: 1f 1e        	adc	r1, r31
     79a: 1f 1e        	adc	r1, r31
     79c: 1f cd        	rjmp	.-1474
     79e: e0 f7        	brsh	.-8
     7a0: e0 eb        	ldi	r30, 0xb0
     7a2: fc ed        	ldi	r31, 0xdc
     7a4: e0 ff        	sbrs	r30, 0x0
     7a6: 00 e8        	ldi	r16, 0x80
     7a8: ed e8        	ldi	r30, 0x8d
     7aa: f6 e8        	ldi	r31, 0x86
     7ac: e0 eb        	ldi	r30, 0xb0
     7ae: e8 e7        	ldi	r30, 0x78
     7b0: e0 f6        	brsh	.-72
     7b2: e8 ff 00 53  	<unknown>
     7b6: 74 61        	ori	r23, 0x14
     7b8: 72 74        	andi	r23, 0x42
     7ba: 75 70        	andi	r23, 0x5
     7bc: 00 20        	tst	r0
     7be: 20 20        	and	r2, r0
     7c0: 20 c2        	rjmp	.+1088
     7c2: fb ea        	ldi	r31, 0xab
     7c4: eb fe f7 e5  	<unknown>
     7c8: ed 20        	and	r14, r13
     7ca: 20 20        	and	r2, r0
     7cc: 20 00 25 32  	<unknown>
     7d0: 64 3a        	cpi	r22, 0xa4
     7d2: 25 2e        	mov	r2, r21
     7d4: 32 64        	ori	r19, 0x42
     7d6: 3a 25        	eor	r19, r10
     7d8: 2e 32        	cpi	r18, 0x2e
     7da: 64 00 25 35  	<unknown>
     7de: 2e 31        	cpi	r18, 0x1e
     7e0: 66 43        	sbci	r22, 0x36
     7e2: 20 00 20 2d  	<unknown>
     7e6: 2d 2d        	mov	r18, r13
     7e8: 2d 2d        	mov	r18, r13
     7ea: 20 00 25 32  	<unknown>
     7ee: 64 3a        	cpi	r22, 0xa4
     7f0: 25 2e        	mov	r2, r21
     7f2: 32 64        	ori	r19, 0x42
     7f4: 3a 25        	eor	r19, r10
     7f6: 2e 32        	cpi	r18, 0x2e
     7f8: 64 20        	and	r6, r4
     7fa: 00 25        	eor	r16, r0
     7fc: 32 64        	ori	r19, 0x42
     7fe: 20 00 20 32  	<unknown>
     802: 30 25        	eor	r19, r0
     804: 2e 32        	cpi	r18, 0x2e
     806: 64 00 c4 e0  	<unknown>
     80a: f2 f7        	brpl	.-4
     80c: 2e 25        	eor	r18, r14
     80e: 64 3a        	cpi	r22, 0xa4
     810: 25 34        	cpi	r18, 0x45
     812: 64 28        	or	r6, r4
     814: 62 69        	ori	r22, 0x92
     816: 6e 29        	or	r22, r14
     818: 00 c4        	rjmp	.+2048
     81a: e0 f2        	brlo	.-72
     81c: f7 2e        	mov	r15, r23
     81e: 25 64        	ori	r18, 0x45
     820: 3a 20        	and	r3, r10
     822: 20 20        	and	r2, r0
     824: 25 35        	cpi	r18, 0x55
     826: 2e 33        	cpi	r18, 0x3e
     828: 66 56        	subi	r22, 0x66
     82a: 20 20        	and	r2, r0
     82c: 20 20        	and	r2, r0
     82e: 20 00 25 64  	<unknown>
     832: 3a 25        	eor	r19, r10
     834: 38 2e        	mov	r3, r24
     836: 30 66        	ori	r19, 0x60
     838: 25 63        	ori	r18, 0x35
     83a: 00 25        	eor	r16, r0
     83c: 64 3a        	cpi	r22, 0xa4
     83e: 25 38        	cpi	r18, 0x85
     840: 2e 31        	cpi	r18, 0x1e
     842: 66 25        	eor	r22, r6
     844: 63 00 25 64  	<unknown>
     848: 3a 25        	eor	r19, r10
     84a: 38 2e        	mov	r3, r24
     84c: 32 66        	ori	r19, 0x62
     84e: 25 63        	ori	r18, 0x35
     850: 00 25        	eor	r16, r0
     852: 64 3a        	cpi	r22, 0xa4
     854: 25 38        	cpi	r18, 0x85
     856: 2e 33        	cpi	r18, 0x3e
     858: 66 25        	eor	r22, r6
     85a: 63 00 25 64  	<unknown>
     85e: 3a 25        	eor	r19, r10
     860: 38 2e        	mov	r3, r24
     862: 34 66        	ori	r19, 0x64
     864: 25 63        	ori	r18, 0x35
     866: 00 25        	eor	r16, r0
     868: 64 3a        	cpi	r22, 0xa4
     86a: 25 38        	cpi	r18, 0x85
     86c: 2e 35        	cpi	r18, 0x5e
     86e: 66 25        	eor	r22, r6
     870: 63 00 25 64  	<unknown>
     874: 3a 25        	eor	r19, r10
     876: 38 2e        	mov	r3, r24
     878: 36 66        	ori	r19, 0x66
     87a: 25 63        	ori	r18, 0x35
     87c: 00 c4        	rjmp	.+2048
     87e: e0 f2        	brlo	.-72
     880: f7 2e        	mov	r15, r23
     882: 25 64        	ori	r18, 0x45
     884: 3a 25        	eor	r19, r10
     886: 39 2e        	mov	r3, r25
     888: 32 65        	ori	r19, 0x52
     88a: 00 c4        	rjmp	.+2048
     88c: e0 f2        	brlo	.-72
     88e: f7 2e        	mov	r15, r23
     890: 00 20        	tst	r0
     892: 20 20        	and	r2, r0
     894: 20 20        	and	r2, r0
     896: c7 e2        	ldi	r28, 0x27
     898: f3 ea        	ldi	r31, 0xa3
     89a: 20 20        	and	r2, r0
     89c: 20 20        	and	r2, r0
     89e: 20 20        	and	r2, r0
     8a0: 20 00 20 20  	<unknown>
     8a4: 20 20        	and	r2, r0
     8a6: c2 ea        	ldi	r28, 0xa2
     8a8: eb fe f7 e5  	<unknown>
     8ac: ed 20        	and	r14, r13
     8ae: 20 20        	and	r2, r0
     8b0: 20 20        	and	r2, r0
     8b2: 00 1f        	rol	r16
     8b4: 1b 13        	cpse	r17, r27
     8b6: 1b 1b        	sub	r17, r27
     8b8: 11 1f        	rol	r17
     8ba: 00 1f        	rol	r16
     8bc: 11 1d        	adc	r17, r1
     8be: 11 17        	cp	r17, r17
     8c0: 11 1f        	rol	r17
     8c2: 00 1f        	rol	r16
     8c4: 11 1d        	adc	r17, r1
     8c6: 11 1d        	adc	r17, r1
     8c8: 11 1f        	rol	r17
     8ca: 00 1f        	rol	r16
     8cc: 15 15        	cp	r17, r5
     8ce: 11 1d        	adc	r17, r1
     8d0: 1d 1f        	adc	r17, r29
     8d2: 00 00        	nop
     8d4: 04 0c        	add	r0, r4
     8d6: 04 04        	cpc	r0, r4
     8d8: 0e 00 00 00  	<unknown>
     8dc: 0e 02 0e 08  	<unknown>
     8e0: 0e 00 00 00  	<unknown>
     8e4: 0e 02 0e 02  	<unknown>
     8e8: 0e 00 00 00  	<unknown>
     8ec: 0a 0a        	sbc	r0, r26
     8ee: 0e 02 02 00  	<unknown>
     8f2: 00 1f        	rol	r16
     8f4: 11 17        	cp	r17, r17
     8f6: 11 1d        	adc	r17, r1
     8f8: 11 1f        	rol	r17
     8fa: 00 1f        	rol	r16
     8fc: 11 17        	cp	r17, r17
     8fe: 11 15        	cp	r17, r1
     900: 11 1f        	rol	r17
     902: 00 1f        	rol	r16
     904: 11 1d        	adc	r17, r1
     906: 1d 1d        	adc	r17, r13
     908: 1d 1f        	adc	r17, r29
     90a: 00 1f        	rol	r16
     90c: 11 15        	cp	r17, r1
     90e: 11 15        	cp	r17, r1
     910: 11 1f        	rol	r17
     912: 00 00        	nop
     914: 0e 08        	sbc	r0, r14
     916: 0e 02 0e 00  	<unknown>
     91a: 00 00        	nop
     91c: 0e 08        	sbc	r0, r14
     91e: 0e 0a        	sbc	r0, r30
     920: 0e 00 00 00  	<unknown>
     924: 0e 02 02 02  	<unknown>
     928: 02 00 00 00  	<unknown>
     92c: 0e 0a        	sbc	r0, r30
     92e: 0e 0a        	sbc	r0, r30
     930: 0e 00 00 1f  	<unknown>
     934: 11 15        	cp	r17, r1
     936: 11 1d        	adc	r17, r1
     938: 11 1f        	rol	r17
     93a: 00 00        	nop
     93c: 0e 0a        	sbc	r0, r30
     93e: 0a 0a        	sbc	r0, r26
     940: 0e 00 00 00  	<unknown>
     944: 04 0c        	add	r0, r4
     946: 04 04        	cpc	r0, r4
     948: 0e 00 00 00  	<unknown>
     94c: 0e 02 0e 08  	<unknown>
     950: 0e 00 00 00  	<unknown>
     954: 0e 0a        	sbc	r0, r30
     956: 0e 02 0e 00  	<unknown>
     95a: 00 1f        	rol	r16
     95c: 11 15        	cp	r17, r1
     95e: 15 15        	cp	r17, r5
     960: 11 1f        	rol	r17
     962: 00 1f        	rol	r16
     964: 1b 13        	cpse	r17, r27
     966: 1b 1b        	sub	r17, r27
     968: 11 1f        	rol	r17
     96a: 00 1f        	rol	r16
     96c: 11 1d        	adc	r17, r1
     96e: 11 17        	cp	r17, r17
     970: 11 1f        	rol	r17
     972: 00 55        	subi	r16, 0x50
     974: 62 61        	ori	r22, 0x12
     976: 74 3d        	cpi	r23, 0xd4
     978: 25 34        	cpi	r18, 0x45
     97a: 2e 32        	cpi	r18, 0x2e
     97c: 66 00 55 6b  	<unknown>
     980: 65 79        	andi	r22, 0x95
     982: 3d 25        	eor	r19, r13
     984: 34 2e        	mov	r3, r20
     986: 32 66        	ori	r19, 0x62
     988: 56 20        	and	r5, r6
     98a: 25 34        	cpi	r18, 0x45
     98c: 64 00 3a 00  	<unknown>
     990: 20 00 c2 fb  	<unknown>
     994: f5 ee        	ldi	r31, 0xe5
     996: e4 20        	and	r14, r4
     998: 23 25        	eor	r18, r3
     99a: 32 64        	ori	r19, 0x42
     99c: 20 3d        	cpi	r18, 0xd0
     99e: 20 25        	eor	r18, r0
     9a0: 64 00 cf ee  	<unknown>
     9a4: e8 f1        	brlo	.+122
     9a6: ea 20        	and	r14, r10
     9a8: e4 e0        	ldi	r30, 0x4
     9aa: f2 f7        	brpl	.-4
     9ac: e8 ea        	ldi	r30, 0xa8
     9ae: ee e2        	ldi	r30, 0x2e
     9b0: 00 ef        	ldi	r16, 0xf0
     9b2: ee e4        	ldi	r30, 0x4e
     9b4: ee e6        	ldi	r30, 0x6e
     9b6: e4 e8        	ldi	r30, 0x84
     9b8: f2 e5        	ldi	r31, 0x52
     9ba: 2e 2e        	mov	r2, r30
     9bc: 2e 00 c2 ee  	<unknown>
     9c0: e7 ec        	ldi	r30, 0xc7
     9c2: ee e6        	ldi	r30, 0x6e
     9c4: ed ee        	ldi	r30, 0xed
     9c6: 20 f7        	brsh	.-56
     9c8: f2 ee        	ldi	r31, 0xe2
     9ca: 00 e4        	ldi	r16, 0x40
     9cc: e0 f2        	brlo	.-72
     9ce: f7 e8        	ldi	r31, 0x87
     9d0: ea ee        	ldi	r30, 0xea
     9d2: e2 20        	and	r14, r2
     9d4: ed e5        	ldi	r30, 0x5d
     9d6: f2 3a        	cpi	r31, 0xa2
     9d8: 28 00 25 32  	<unknown>
     9dc: 64 2f        	mov	r22, r20
     9de: 25 2e        	mov	r2, r21
     9e0: 32 64        	ori	r19, 0x42
     9e2: 00 cd        	rjmp	.-1536
     9e4: e0 e7        	ldi	r30, 0x70
     9e6: ed e0        	ldi	r30, 0xd
     9e8: f7 e8        	ldi	r31, 0x87
     9ea: f2 fc        	sbrc	r15, 0x2
     9ec: 20 4e        	sbci	r18, 0xe0
     9ee: 6f 20        	and	r6, r15
     9f0: 25 64        	ori	r18, 0x45
     9f2: 20 20        	and	r2, r0
     9f4: 00 54        	subi	r16, 0x40
     9f6: 3d 25        	eor	r19, r13
     9f8: 35 2e        	mov	r3, r21
     9fa: 31 66        	ori	r19, 0x61
     9fc: 00 20        	tst	r0
     9fe: 20 20        	and	r2, r0
     a00: 20 df        	rcall	.-448
     a02: f0 ea        	ldi	r31, 0xa0
     a04: ee f1        	brts	.+122
     a06: f2 fc        	sbrc	r15, 0x2
     a08: 00 20        	tst	r0
     a0a: ca ee        	ldi	r28, 0xea
     a0c: ed f2        	brhs	.-70
     a0e: f0 e0        	ldi	r31, 0x0
     a10: f1 f2        	breq	.-68
     a12: ed ee        	ldi	r30, 0xed
     a14: f1 f2        	breq	.-68
     a16: fc 00 20 d3  	<unknown>
     a1a: f1 f2        	breq	.-68
     a1c: 2d ea        	ldi	r18, 0xad
     a1e: e0 20        	and	r14, r0
     a20: f7 e0        	ldi	r31, 0x7
     a22: f1 ee        	ldi	r31, 0xe1
     a24: e2 00 00 00  	<unknown>
     a28: 00 20        	tst	r0
     a2a: cf f0        	brie	.+50
     a2c: ee e3        	ldi	r30, 0x3e
     a2e: f0 e0        	ldi	r31, 0x0
     a30: ec ec        	ldi	r30, 0xcc
     a32: e0 20        	and	r14, r0
     a34: f3 ef        	ldi	r31, 0xf3
     a36: f0 2e        	mov	r15, r16
     a38: 00 00        	nop
     a3a: 20 cf        	rjmp	.-448
     a3c: ee e8        	ldi	r30, 0x8e
     a3e: f1 ea        	ldi	r31, 0xa1
     a40: 20 e4        	ldi	r18, 0x40
     a42: e0 f2        	brlo	.-72
     a44: f7 e8        	ldi	r31, 0x87
     a46: ea ee        	ldi	r30, 0xea
     a48: e2 00 00 20  	<unknown>
     a4c: cf e0        	ldi	r28, 0xf
     a4e: f0 e0        	ldi	r31, 0x0
     a50: ec e5        	ldi	r30, 0x5c
     a52: f2 f0        	brmi	.+60
     a54: fb 00 00 00  	<unknown>
     a58: 00 00        	nop
     a5a: 00 00        	nop
     a5c: 20 d3        	rcall	.+1600
     a5e: f1 f2        	breq	.-68
     a60: e0 ed        	ldi	r30, 0xd0
     a62: ee e2        	ldi	r30, 0x2e
     a64: ea e8        	ldi	r30, 0x8a
     a66: 20 c0        	rjmp	.+64
     a68: d6 cf        	rjmp	.-84
     a6a: 00 00        	nop
     a6c: 00 20        	tst	r0
     a6e: d0 e5        	ldi	r29, 0x50
     a70: e6 e8        	ldi	r30, 0x86
     a72: ec 20        	and	r14, r12
     a74: e2 fb        	bst	r30, 0x2
     a76: f5 ee        	ldi	r31, 0xe5
     a78: e4 ee        	ldi	r30, 0xe4
     a7a: e2 00 00 00  	<unknown>
     a7e: 20 d0        	rcall	.+64
     a80: f3 f7        	brvc	.-4
     a82: ed ee        	ldi	r30, 0xed
     a84: e5 20        	and	r14, r5
     a86: f3 ef        	ldi	r31, 0xf3
     a88: f0 e0        	ldi	r31, 0x0
     a8a: e2 eb        	ldi	r30, 0xb2
     a8c: 2e 00 00 20  	<unknown>
     a90: cf ee        	ldi	r28, 0xef
     a92: e4 f1        	brlt	.+120
     a94: e2 e5        	ldi	r30, 0x52
     a96: f2 ea        	ldi	r31, 0xa2
     a98: e0 00 00 00  	<unknown>
     a9c: 00 00        	nop
     a9e: 00 00        	nop
     aa0: 20 ca        	rjmp	.-3008
     aa2: ee ed        	ldi	r30, 0xde
     aa4: f2 f0        	brmi	.+60
     aa6: e0 f1        	brlo	.+120
     aa8: f2 ed        	ldi	r31, 0xd2
     aaa: ee f1        	brts	.+122
     aac: f2 fc        	sbrc	r15, 0x2
     aae: 00 00        	nop
     ab0: 00 20        	tst	r0
     ab2: c7 e2        	ldi	r28, 0x27
     ab4: f3 ea        	ldi	r31, 0xa3
		...
     ac2: 20 d0        	rcall	.+64
     ac4: e5 e6        	ldi	r30, 0x65
     ac6: e8 ec        	ldi	r30, 0xc8
     ac8: 20 fd        	sbrc	r18, 0x0
     aca: ea f0        	brmi	.+58
     acc: e0 ed        	ldi	r30, 0xd0
     ace: e0 00 00 00  	<unknown>
     ad2: 00 20        	tst	r0
     ad4: c2 e5        	ldi	r28, 0x52
     ad6: f0 f1        	brlo	.+124
     ad8: e8 ff 20 31  	<unknown>
     adc: 2e 39        	cpi	r18, 0x9e
     ade: 35 00 00 00  	<unknown>
     ae2: 00 00        	nop
     ae4: 66 69        	ori	r22, 0x96
     ae6: 72 6d        	ori	r23, 0xd2
     ae8: 77 61        	ori	r23, 0x17
     aea: 72 65        	ori	r23, 0x52
     aec: 00 75        	andi	r16, 0x50
     aee: 70 64        	ori	r23, 0x40
     af0: 61 74        	andi	r22, 0x41
     af2: 65 00 ff ed  	<unknown>
     af6: e2 e0        	ldi	r30, 0x2
     af8: f0 ff        	sbrs	r31, 0x0
     afa: 20 20        	and	r2, r0
     afc: 00 f4        	brsh	.+0
     afe: e5 e2        	ldi	r30, 0x25
     b00: f0 e0        	ldi	r31, 0x0
     b02: eb ff 20 00  	<unknown>
     b06: ec e0        	ldi	r30, 0xc
     b08: f0 f2        	brlo	.-68
     b0a: e0 20        	and	r14, r0
     b0c: 20 20        	and	r2, r0
     b0e: 00 e0        	ldi	r16, 0x0
     b10: ef f0        	brie	.+58
     b12: e5 eb        	ldi	r30, 0xb5
     b14: ff 20        	tst	r15
     b16: 20 00 ec e0  	<unknown>
     b1a: ff 20        	tst	r15
     b1c: 20 20        	and	r2, r0
     b1e: 20 20        	and	r2, r0
     b20: 00 e8        	ldi	r16, 0x80
     b22: fe ed        	ldi	r31, 0xde
     b24: ff 20        	tst	r15
     b26: 20 20        	and	r2, r0
     b28: 20 00 e8 fe  	<unknown>
     b2c: eb ff 20 20  	<unknown>
     b30: 20 20        	and	r2, r0
     b32: 00 e0        	ldi	r16, 0x0
     b34: e2 e3        	ldi	r30, 0x32
     b36: f3 f1        	brvs	.+124
     b38: f2 e0        	ldi	r31, 0x2
     b3a: 20 00 f1 e5  	<unknown>
     b3e: ed f2        	brhs	.-70
     b40: ff e1        	ldi	r31, 0x1f
     b42: f0 ff        	sbrs	r31, 0x0
     b44: 00 ee        	ldi	r16, 0xe0
     b46: ea f2        	brmi	.-70
     b48: ff e1        	ldi	r31, 0x1f
     b4a: f0 ff        	sbrs	r31, 0x0
     b4c: 20 00 ed ee  	<unknown>
     b50: ff e1        	ldi	r31, 0x1f
     b52: f0 ff        	sbrs	r31, 0x0
     b54: 20 20        	and	r2, r0
     b56: 00 e4        	ldi	r16, 0x40
     b58: e5 ea        	ldi	r30, 0xa5
     b5a: e0 e1        	ldi	r30, 0x10
     b5c: f0 ff        	sbrs	r31, 0x0
     b5e: 20 00 cf ce  	<unknown>
     b62: cd c5        	rjmp	.+2970
     b64: c4 c5        	rjmp	.+2952
     b66: cb 00 c2 d2  	<unknown>
     b6a: ce d0        	rcall	.+412
     b6c: cd c8        	rjmp	.-3686
     b6e: ca 00 d1 d0  	<unknown>
     b72: c5 c4        	rjmp	.+2442
     b74: c0 20        	and	r12, r0
     b76: 20 00 d7 c5  	<unknown>
     b7a: d2 c2        	rjmp	.+1444
     b7c: c5 d0        	rcall	.+394
     b7e: c3 00 cf df  	<unknown>
     b82: d2 cd        	rjmp	.-1116
     b84: c8 d6        	rcall	.+3472
     b86: c0 00 d1 d3  	<unknown>
     b8a: c1 c1        	rjmp	.+898
     b8c: ce d2        	rcall	.+1436
     b8e: c0 00 c2 ce  	<unknown>
     b92: d1 ca        	rjmp	.-2654
     b94: d0 c5        	rjmp	.+2976
     b96: d1 00 20 20  	<unknown>
     b9a: 20 cc        	rjmp	.-1984
     b9c: c0 d1        	rcall	.+896
     b9e: d2 c5        	rjmp	.+2980
     ba0: d0 ca        	rjmp	.-2656
     ba2: c8 d2        	rcall	.+1424
     ba4: 00 00        	nop
     ba6: 00 00        	nop
     ba8: 00 77        	andi	r16, 0x70
     baa: 77 77        	andi	r23, 0x77
     bac: 2e 6d        	ori	r18, 0xde
     bae: 61 73        	andi	r22, 0x31
     bb0: 74 65        	ori	r23, 0x54
     bb2: 72 6b        	ori	r23, 0xb2
     bb4: 69 74        	andi	r22, 0x49
     bb6: 2e 72        	andi	r18, 0x2e
     bb8: 75 00 30 31  	<unknown>
     bbc: 32 33        	cpi	r19, 0x32
     bbe: 34 35        	cpi	r19, 0x54
     bc0: 36 37        	cpi	r19, 0x76
     bc2: 38 39        	cpi	r19, 0x98
     bc4: 41 42        	sbci	r20, 0x21
     bc6: 43 44        	sbci	r20, 0x43
     bc8: 45 46        	sbci	r20, 0x65
     bca: 00 30        	cpi	r16, 0x0
     bcc: 31 32        	cpi	r19, 0x21
     bce: 33 34        	cpi	r19, 0x43
     bd0: 35 36        	cpi	r19, 0x65
     bd2: 37 38        	cpi	r19, 0x87
     bd4: 39 61        	ori	r19, 0x19
     bd6: 62 63        	ori	r22, 0x32
     bd8: 64 65        	ori	r22, 0x54
     bda: 66 00 28 6e  	<unknown>
     bde: 75 6c        	ori	r23, 0xc5
     be0: 6c 20        	and	r6, r12
     be2: 70 6f        	ori	r23, 0xf0
     be4: 69 6e        	ori	r22, 0xe9
     be6: 74 65        	ori	r23, 0x54
     be8: 72 29        	or	r23, r2
     bea: 00 3f        	cpi	r16, 0xf0
     bec: 3f 3f        	cpi	r19, 0xff
     bee: 00 ff        	sbrs	r16, 0x0
     bf0: 00 00        	nop
     bf2: 08 1c        	adc	r0, r8
     bf4: 0a 00 22 18  	<unknown>
     bf8: 46 18        	sub	r4, r6
     bfa: 8e 18        	sub	r8, r14
     bfc: cd 18        	sub	r12, r13
     bfe: f6 18        	sub	r15, r6
     c00: 07 1a        	sub	r0, r23
     c02: 5e 1a        	sub	r5, r30
     c04: 95 1a        	sub	r9, r21
     c06: 9d 1b        	sub	r25, r29
     c08: c0 1b        	sub	r28, r16
     c0a: 00 00        	nop
     c0c: f3 24        	eor	r15, r3
     c0e: 0b 00 eb 24  	<unknown>
     c12: f5 24        	eor	r15, r5
     c14: fa 24        	eor	r15, r10
     c16: 11 25        	eor	r17, r1
     c18: 14 25        	eor	r17, r4
     c1a: fd 24        	eor	r15, r13
     c1c: 01 25        	eor	r16, r1
     c1e: 0e 25        	eor	r16, r14
     c20: 04 25        	eor	r16, r4
     c22: 07 25        	eor	r16, r7
     c24: 0a 25        	eor	r16, r10
     c26: 00 00        	nop
     c28: f3 24        	eor	r15, r3
     c2a: 0b 00 2f 25  	<unknown>
     c2e: 32 25        	eor	r19, r2
     c30: 35 25        	eor	r19, r5
     c32: 45 25        	eor	r20, r5
     c34: 48 25        	eor	r20, r8
     c36: 4f 25        	eor	r20, r15
     c38: 4c 25        	eor	r20, r12
     c3a: 3b 25        	eor	r19, r11
     c3c: 38 25        	eor	r19, r8
     c3e: 3e 25        	eor	r19, r14
     c40: 41 25        	eor	r20, r1
     c42: 41 01 24 2c  	<unknown>
     c46: fd 2b        	or	r31, r29
     c48: 03 cd        	rjmp	.-1530
     c4a: 2b 01 99 2a  	<unknown>
     c4e: 03 de        	rcall	.-1018
     c50: 2b 01 ea 2b  	<unknown>
     c54: 02 07        	cpc	r16, r18
     c56: 2c 01 cb 2a  	<unknown>
     c5a: 07 0f        	add	r16, r23
     c5c: 2c 01 c2 2a  	<unknown>
     c60: 02 ad 2a 01  	<unknown>
     c64: 25 2b        	or	r18, r21
     c66: 0a 02 2c 01  	<unknown>
     c6a: 97 2a        	or	r9, r23
     c6c: 01 bf        	out	0x31, r16
     c6e: 2a 01 d5 2b  	<unknown>
     c72: 04 e4        	ldi	r16, 0x44
     c74: 2b 01 f4 2b  	<unknown>
     c78: 03 77        	andi	r16, 0x73
     c7a: 2a 07        	cpc	r18, r26
     c7c: 1c 2c        	mov	r1, r12
     c7e: 01 6b        	ori	r16, 0xb1
     c80: 2a 02 71 2a  	<unknown>
     c84: 04 77        	andi	r16, 0x74
     c86: 2a fb 00 01  	<unknown>
     c8a: 39 30        	cpi	r19, 0x9
     c8c: 38 30        	cpi	r19, 0x8
     c8e: 45 0d        	add	r20, r5
     c90: 30 02 00 30  	<unknown>
     c94: 11 77        	andi	r17, 0x71
     c96: 2f 0b        	sbc	r18, r31
     c98: 3b 2f        	mov	r19, r27
     c9a: 01 91        	ld	r16, Z+
     c9c: 2f 01 0d 30  	<unknown>
     ca0: 01 0b        	sbc	r16, r17
     ca2: 30 01 00 30  	<unknown>
     ca6: 02 91        	ld	r16, -Z
     ca8: 2f 05        	cpc	r18, r15
     caa: 28 2f        	mov	r18, r24
     cac: 01 6a        	ori	r16, 0xa1
     cae: 2f 01 77 2f  	<unknown>
     cb2: 03 43        	sbci	r16, 0x33
     cb4: 2f 02 77 2f  	<unknown>
     cb8: 03 73        	andi	r16, 0x33
     cba: 2f fb ad 20  	<unknown>
     cbe: 8a 93        	st	-Y, r24
     cc0: 97 98        	cbi	0x12, 0x7
     cc2: 8f ef        	ldi	r24, 0xff
     cc4: 8f 9a        	sbi	0x11, 0x7
     cc6: 0f d0        	rcall	.+30
     cc8: f8 94        	cli
     cca: 8f 98        	cbi	0x11, 0x7
     ccc: 8a 95        	dec	r24
     cce: 11 f0        	breq	.+4
     cd0: 87 99        	sbic	0x10, 0x7
     cd2: fc cf        	rjmp	.-8
     cd4: 78 94        	sei
     cd6: 07 d0        	rcall	.+14
     cd8: 88 23        	tst	r24
     cda: 11 f4        	brne	.+4
     cdc: 01 e0        	ldi	r16, 0x1
     cde: 01 c0        	rjmp	.+2
     ce0: 00 e0        	ldi	r16, 0x0
     ce2: 89 91        	ld	r24, Y+
     ce4: 08 95        	ret
     ce6: 04 e6        	ldi	r16, 0x64
     ce8: 50 c0        	rjmp	.+160
     cea: f8 94        	cli
     cec: 8f 9a        	sbi	0x11, 0x7
     cee: 00 23        	tst	r16
     cf0: 09 f0        	breq	.+2
     cf2: 8f 98        	cbi	0x11, 0x7
     cf4: 01 e2        	ldi	r16, 0x21
     cf6: 0a 95        	dec	r16
     cf8: f1 f7        	brne	.-4
     cfa: 00 00        	nop
     cfc: 8f 98        	cbi	0x11, 0x7
     cfe: 78 94        	sei
     d00: 08 95        	ret
     d02: 8a 93        	st	-Y, r24
     d04: f8 94        	cli
     d06: 8f 9a        	sbi	0x11, 0x7
     d08: 8f 98        	cbi	0x11, 0x7
     d0a: 0b d0        	rcall	.+22
     d0c: 0a d0        	rcall	.+20
     d0e: 80 b3        	in	r24, 0x10
     d10: 78 94        	sei
     d12: 0f e0        	ldi	r16, 0xf
     d14: 3a d0        	rcall	.+116
     d16: 87 fb        	bst	r24, 0x7
     d18: 16 f4        	brtc	.+4
     d1a: 01 e0        	ldi	r16, 0x1
     d1c: 01 c0        	rjmp	.+2
     d1e: 00 e0        	ldi	r16, 0x0
     d20: e0 cf        	rjmp	.-64
		...
     d2a: 08 95        	ret
     d2c: 9a 93        	st	-Y, r25
     d2e: 8a 93        	st	-Y, r24
     d30: 90 2f        	mov	r25, r16
     d32: 81 e0        	ldi	r24, 0x1
     d34: 09 2f        	mov	r16, r25
     d36: 08 23        	and	r16, r24
     d38: d8 df        	rcall	.-80
     d3a: 88 0f        	lsl	r24
     d3c: d9 f7        	brne	.-10
     d3e: 89 91        	ld	r24, Y+
     d40: 99 91        	ld	r25, Y+
     d42: 08 95        	ret
     d44: 08 e0        	ldi	r16, 0x8
     d46: 0e 94 ee 34  	<unknown>
     d4a: 40 2e        	mov	r4, r16
     d4c: a1 e0        	ldi	r26, 0x1
     d4e: b0 e0        	ldi	r27, 0x0
     d50: 80 e0        	ldi	r24, 0x0
     d52: 90 e0        	ldi	r25, 0x0
     d54: d6 df        	rcall	.-84
     d56: 00 23        	tst	r16
     d58: 11 f0        	breq	.+4
     d5a: 8a 2b        	or	r24, r26
     d5c: 9b 2b        	or	r25, r27
     d5e: aa 0f        	lsl	r26
     d60: bb 1f        	rol	r27
     d62: 4a 94        	dec	r4
     d64: b9 f7        	brne	.-18
     d66: 8c 01 e5 e0  	<unknown>
     d6a: 0c 94 ff 34  	<unknown>
     d6e: 0e 94 ef 34  	<unknown>
     d72: d8 01 82 2f  	<unknown>
     d76: 02 c0        	rjmp	.+4
     d78: 0d 91        	ld	r16, X+
     d7a: d8 df        	rcall	.-80
     d7c: 08 2f        	mov	r16, r24
     d7e: 8a 95        	dec	r24
     d80: 00 23        	tst	r16
     d82: d1 f7        	brne	.-12
     d84: e4 e0        	ldi	r30, 0x4
     d86: 0c 94 00 35  	<unknown>
     d8a: 10 2f        	mov	r17, r16
     d8c: 0a 95        	dec	r16
     d8e: 11 23        	tst	r17
     d90: e1 f7        	brne	.-8
     d92: 08 95        	ret
     d94: d1 98        	cbi	0x1a, 0x1
     d96: 0f e8        	ldi	r16, 0x8f
     d98: 06 b9        	out	0x6, r16
     d9a: 05 b7        	in	r16, 0x35
     d9c: 00 61        	ori	r16, 0x10
     d9e: 05 bf        	out	0x35, r16
     da0: 01 e0        	ldi	r16, 0x1
     da2: 2f b7        	in	r18, 0x3f
     da4: f8 94        	cli
     da6: 10 2f        	mov	r17, r16
     da8: 10 5c        	subi	r17, 0xc0
     daa: 17 b9        	out	0x7, r17
     dac: 36 9a        	sbi	0x6, 0x6
     dae: 34 9b        	sbis	0x6, 0x4
     db0: fe cf        	rjmp	.-4
     db2: 12 e0        	ldi	r17, 0x2
     db4: 01 9f e3 e7  	<unknown>
     db8: f6 e0        	ldi	r31, 0x6
     dba: e0 0d        	add	r30, r0
     dbc: f1 1d        	adc	r31, r1
     dbe: 04 b1        	in	r16, 0x4
     dc0: 15 b1        	in	r17, 0x5
     dc2: 00 83        	std	Z+0, r16
     dc4: 11 83        	std	Z+1, r17
     dc6: 00 81        	ldd	r16, Z+0
     dc8: 2f bf        	out	0x3f, r18
     dca: 08 95        	ret
     dcc: 18 95        	reti
     dce: 60 e0        	ldi	r22, 0x0
     dd0: 00 e0        	ldi	r16, 0x0
     dd2: 10 e0        	ldi	r17, 0x0
     dd4: 20 e8        	ldi	r18, 0x80
     dd6: 3f e3        	ldi	r19, 0x3f
     dd8: 44 e0        	ldi	r20, 0x4
     dda: 64 9f 40 e0  	<unknown>
     dde: 50 e0        	ldi	r21, 0x0
     de0: 40 0d        	add	r20, r0
     de2: 51 1d        	adc	r21, r1
     de4: 0e 94 ab 31  	<unknown>
     de8: 63 95        	inc	r22
     dea: 64 30        	cpi	r22, 0x4
     dec: 88 f3        	brlo	.-30
     dee: 05 e2        	ldi	r16, 0x25
     df0: 40 e1        	ldi	r20, 0x10
     df2: 50 e0        	ldi	r21, 0x0
     df4: 0e d0        	rcall	.+28
     df6: 00 e5        	ldi	r16, 0x50
     df8: 41 e1        	ldi	r20, 0x11
     dfa: 50 e0        	ldi	r21, 0x0
     dfc: 0a d0        	rcall	.+20
     dfe: 01 e0        	ldi	r16, 0x1
     e00: 42 e1        	ldi	r20, 0x12
     e02: 50 e0        	ldi	r21, 0x0
     e04: 06 d0        	rcall	.+12
     e06: 43 e1        	ldi	r20, 0x13
     e08: 50 e0        	ldi	r21, 0x0
     e0a: 03 d0        	rcall	.+6
     e0c: 00 e0        	ldi	r16, 0x0
     e0e: 44 e1        	ldi	r20, 0x14
     e10: 50 e0        	ldi	r21, 0x0
     e12: 0c 94 a0 31  	<unknown>
     e16: 0e 94 e5 34  	<unknown>
     e1a: 00 23        	tst	r16
     e1c: 79 f0        	breq	.+30
     e1e: 0e 94 be 10  	<unknown>
     e22: eb e7        	ldi	r30, 0x7b
     e24: f6 e0        	ldi	r31, 0x6
     e26: 00 83        	std	Z+0, r16
     e28: 11 83        	std	Z+1, r17
     e2a: 4b e0        	ldi	r20, 0xb
     e2c: 23 ea        	ldi	r18, 0xa3
     e2e: 30 e0        	ldi	r19, 0x0
     e30: 0e 94 f5 10  	<unknown>
     e34: 01 e0        	ldi	r16, 0x1
     e36: ee e0        	ldi	r30, 0xe
     e38: 0c 94 f6 34  	<unknown>
     e3c: 21 d1        	rcall	.+578
     e3e: 0e 94 6f 11  	<unknown>
     e42: 00 23        	tst	r16
     e44: b1 f1        	breq	.+108
     e46: 18 d1        	rcall	.+560
     e48: 01 30        	cpi	r16, 0x1
     e4a: 11 f4        	brne	.+4
     e4c: 2f ef        	ldi	r18, 0xff
     e4e: 1d d1        	rcall	.+570
     e50: 13 d1        	rcall	.+550
     e52: 04 30        	cpi	r16, 0x4
     e54: 11 f4        	brne	.+4
     e56: 21 e0        	ldi	r18, 0x1
     e58: 18 d1        	rcall	.+560
     e5a: 0e d1        	rcall	.+540
     e5c: 01 f5        	brne	.+64
     e5e: 2c d1        	rcall	.+600
     e60: 50 f0        	brlo	.+20
     e62: 04 50        	subi	r16, 0x4
     e64: 50 f0        	brlo	.+20
     e66: 79 f0        	breq	.+30
     e68: 0a 95        	dec	r16
     e6a: 69 f0        	breq	.+26
     e6c: 0a 95        	dec	r16
     e6e: 89 f0        	breq	.+34
     e70: 0a 95        	dec	r16
     e72: 79 f0        	breq	.+30
     e74: 12 c0        	rjmp	.+36
     e76: 10 d1        	rcall	.+544
     e78: 10 c0        	rjmp	.+32
     e7a: 15 d1        	rcall	.+554
     e7c: 10 2f        	mov	r17, r16
     e7e: 13 50        	subi	r17, 0x3
     e80: 01 e0        	ldi	r16, 0x1
     e82: 1d d1        	rcall	.+570
     e84: 0a c0        	rjmp	.+20
     e86: 0f d1        	rcall	.+542
     e88: 07 50        	subi	r16, 0x7
     e8a: 10 2f        	mov	r17, r16
     e8c: 01 e0        	ldi	r16, 0x1
     e8e: 48 d1        	rcall	.+656
     e90: 04 c0        	rjmp	.+8
     e92: 02 d1        	rcall	.+516
     e94: 08 e5        	ldi	r16, 0x58
     e96: 10 e0        	ldi	r17, 0x0
     e98: d9 d0        	rcall	.+434
     e9a: 00 e0        	ldi	r16, 0x0
     e9c: cc cf        	rjmp	.-104
     e9e: 00 91 39 07  	<unknown>
     ea2: 05 30        	cpi	r16, 0x5
     ea4: 11 f0        	breq	.+4
     ea6: 05 38        	cpi	r16, 0x85
     ea8: c1 f7        	brne	.-16
     eaa: ea d0        	rcall	.+468
     eac: 0e 94 c9 10  	<unknown>
     eb0: c1 cf        	rjmp	.-126
     eb2: 02 d1        	rcall	.+516
     eb4: 78 f0        	brlo	.+30
     eb6: 04 50        	subi	r16, 0x4
     eb8: 08 f4        	brsh	.+2
     eba: 70 c0        	rjmp	.+224
     ebc: 09 f4        	brne	.+2
     ebe: 76 c0        	rjmp	.+236
     ec0: 0a 95        	dec	r16
     ec2: 09 f4        	brne	.+2
     ec4: 73 c0        	rjmp	.+230
     ec6: 0a 95        	dec	r16
     ec8: 09 f4        	brne	.+2
     eca: 76 c0        	rjmp	.+236
     ecc: 0a 95        	dec	r16
     ece: 09 f4        	brne	.+2
     ed0: 73 c0        	rjmp	.+230
     ed2: e3 cf        	rjmp	.-58
     ed4: 44 24        	clr	r4
     ed6: 55 24        	clr	r5
     ed8: 14 2d        	mov	r17, r4
     eda: e2 d0        	rcall	.+452
     edc: b3 d0        	rcall	.+358
     ede: 23 e7        	ldi	r18, 0x73
     ee0: 62 2e        	mov	r6, r18
     ee2: 26 e0        	ldi	r18, 0x6
     ee4: 72 2e        	mov	r7, r18
     ee6: 60 0e        	add	r6, r16
     ee8: 71 1e        	adc	r7, r17
     eea: 62 01 01 e0  	<unknown>
     eee: c0 0e        	add	r12, r16
     ef0: 00 e0        	ldi	r16, 0x0
     ef2: d0 1e        	adc	r13, r16
     ef4: de d0        	rcall	.+444
     ef6: 00 23        	tst	r16
     ef8: 41 f4        	brne	.+16
     efa: f3 01 04 81  	<unknown>
     efe: 15 81        	ldd	r17, Z+5
     f00: af d0        	rcall	.+350
     f02: 08 e6        	ldi	r16, 0x68
     f04: 10 e0        	ldi	r17, 0x0
     f06: a2 d0        	rcall	.+324
     f08: 24 96 d3 d0  	<unknown>
     f0c: 01 30        	cpi	r16, 0x1
     f0e: 61 f4        	brne	.+24
     f10: ac d0        	rcall	.+344
     f12: 40 e0        	ldi	r20, 0x0
     f14: 50 e0        	ldi	r21, 0x0
     f16: 60 ea        	ldi	r22, 0xa0
     f18: 70 e4        	ldi	r23, 0x40
     f1a: 9e d0        	rcall	.+316
     f1c: 99 d0        	rcall	.+306
     f1e: 9e d0        	rcall	.+316
     f20: 0c e7        	ldi	r16, 0x7c
     f22: 10 e0        	ldi	r17, 0x0
     f24: 93 d0        	rcall	.+294
     f26: 26 96 c4 d0  	<unknown>
     f2a: 02 30        	cpi	r16, 0x2
     f2c: 19 f5        	brne	.+70
     f2e: 43 e0        	ldi	r20, 0x3
     f30: 82 01 0e 94  	<unknown>
     f34: d5 31        	cpi	r29, 0x15
     f36: 40 e0        	ldi	r20, 0x0
     f38: 50 e0        	ldi	r21, 0x0
     f3a: 7b d0        	rcall	.+246
     f3c: c8 01 d9 01  	<unknown>
     f40: 44 e0        	ldi	r20, 0x4
     f42: 50 e0        	ldi	r21, 0x0
     f44: 7f d0        	rcall	.+254
     f46: 7f d0        	rcall	.+254
     f48: 7e d0        	rcall	.+252
     f4a: 73 d0        	rcall	.+230
     f4c: ac 01 bd 01  	<unknown>
     f50: 0e 94 4b 33  	<unknown>
     f54: 7d d0        	rcall	.+250
     f56: 48 01 59 01  	<unknown>
     f5a: 87 d0        	rcall	.+270
     f5c: a4 01 b5 01  	<unknown>
     f60: 7b d0        	rcall	.+246
     f62: ac 01 bd 01  	<unknown>
     f66: 0e 94 07 33  	<unknown>
     f6a: 78 d0        	rcall	.+240
     f6c: 01 e9        	ldi	r16, 0x91
     f6e: 10 e0        	ldi	r17, 0x0
     f70: 6d d0        	rcall	.+218
     f72: 26 96 01 e0  	<unknown>
     f76: 40 0e        	add	r4, r16
     f78: 00 e0        	ldi	r16, 0x0
     f7a: 50 1e        	adc	r5, r16
     f7c: 02 e0        	ldi	r16, 0x2
     f7e: 40 16        	cp	r4, r16
     f80: 00 e0        	ldi	r16, 0x0
     f82: 50 06        	cpc	r5, r16
     f84: 08 f4        	brsh	.+2
     f86: a8 cf        	rjmp	.-176
     f88: 77 d0        	rcall	.+238
     f8a: 19 f0        	breq	.+6
     f8c: 05 30        	cpi	r16, 0x5
     f8e: 09 f0        	breq	.+2
     f90: 84 cf        	rjmp	.-248
     f92: 21 e0        	ldi	r18, 0x1
     f94: 75 d0        	rcall	.+234
     f96: 0e 94 69 11  	<unknown>
     f9a: 7f cf        	rjmp	.-258
     f9c: 8d d0        	rcall	.+282
     f9e: 10 2f        	mov	r17, r16
     fa0: 00 e0        	ldi	r16, 0x0
     fa2: 8d d0        	rcall	.+282
     fa4: 01 30        	cpi	r16, 0x1
     fa6: 09 f0        	breq	.+2
     fa8: 78 cf        	rjmp	.-272
     faa: f3 cf        	rjmp	.-26
     fac: 82 d0        	rcall	.+260
     fae: 07 50        	subi	r16, 0x7
     fb0: 10 2f        	mov	r17, r16
     fb2: 00 e0        	ldi	r16, 0x0
     fb4: b5 d0        	rcall	.+362
     fb6: f6 cf        	rjmp	.-20
     fb8: 5f d0        	rcall	.+190
     fba: 02 30        	cpi	r16, 0x2
     fbc: 31 f0        	breq	.+12
     fbe: 01 30        	cpi	r16, 0x1
     fc0: 21 f0        	breq	.+8
     fc2: 03 30        	cpi	r16, 0x3
     fc4: 11 f0        	breq	.+4
     fc6: 04 30        	cpi	r16, 0x4
     fc8: 21 f5        	brne	.+72
     fca: 73 d0        	rcall	.+230
     fcc: 09 50        	subi	r16, 0x9
     fce: 10 e0        	ldi	r17, 0x0
     fd0: 20 e0        	ldi	r18, 0x0
     fd2: 30 e0        	ldi	r19, 0x0
     fd4: 20 0f        	add	r18, r16
     fd6: 31 1f        	adc	r19, r17
     fd8: 10 91 39 07  	<unknown>
     fdc: 1f 70        	andi	r17, 0xf
     fde: 12 30        	cpi	r17, 0x2
     fe0: 11 f0        	breq	.+4
     fe2: 14 30        	cpi	r17, 0x4
     fe4: 19 f4        	brne	.+6
     fe6: 29 d0        	rcall	.+82
     fe8: 0a 95        	dec	r16
     fea: 52 d0        	rcall	.+164
     fec: 13 30        	cpi	r17, 0x3
     fee: 11 f0        	breq	.+4
     ff0: 11 30        	cpi	r17, 0x1
     ff2: 19 f4        	brne	.+6
     ff4: 22 d0        	rcall	.+68
     ff6: 03 95        	inc	r16
     ff8: 4b d0        	rcall	.+150
     ffa: 1f d0        	rcall	.+62
     ffc: 08 37        	cpi	r16, 0x78
     ffe: 10 f0        	brlo	.+4
    1000: 08 e0        	ldi	r16, 0x8
    1002: 03 c0        	rjmp	.+6
    1004: 08 30        	cpi	r16, 0x8
    1006: 28 f4        	brsh	.+10
    1008: 07 e7        	ldi	r16, 0x77
    100a: 20 5f        	subi	r18, 0xf0
    100c: 3f 4f        	sbci	r19, 0xff
    100e: a9 01 00 df  	<unknown>
    1012: 11 e0        	ldi	r17, 0x1
    1014: 07 e0        	ldi	r16, 0x7
    1016: 0e 94 29 0f  	<unknown>
    101a: 4b d0        	rcall	.+150
    101c: 11 e0        	ldi	r17, 0x1
    101e: 47 e0        	ldi	r20, 0x7
    1020: 50 e0        	ldi	r21, 0x0
    1022: 30 e0        	ldi	r19, 0x0
    1024: 40 0f        	add	r20, r16
    1026: 53 1f        	adc	r21, r19
    1028: 0b d0        	rcall	.+22
    102a: 0e 94 7d 0f  	<unknown>
    102e: 24 d0        	rcall	.+72
    1030: ba cf        	rjmp	.-140
    1032: 40 0f        	add	r20, r16
    1034: 51 1f        	adc	r21, r17
    1036: 0c 94 8e 31  	<unknown>
    103a: a9 01 40 5f  	<unknown>
    103e: 5f 4f        	sbci	r21, 0xff
    1040: 0c 94 86 31  	<unknown>
    1044: 82 01 00 0f  	<unknown>
    1048: 11 1f        	rol	r17
    104a: 08 95        	ret
    104c: 0c 94 70 35  	<unknown>
    1050: 40 e0        	ldi	r20, 0x0
    1052: 50 e0        	ldi	r21, 0x0
    1054: 60 e8        	ldi	r22, 0x80
    1056: 7a e3        	ldi	r23, 0x3a
    1058: 0c 94 68 33  	<unknown>
    105c: 3a 93        	st	-Y, r19
    105e: 2a 93        	st	-Y, r18
    1060: 1a 93        	st	-Y, r17
    1062: 0a 93        	st	-Y, r16
    1064: da 92        	st	-Y, r13
    1066: ca 92        	st	-Y, r12
    1068: 08 95        	ret
    106a: f3 01 04 81  	<unknown>
    106e: 15 81        	ldd	r17, Z+5
    1070: 20 e0        	ldi	r18, 0x0
    1072: 30 e0        	ldi	r19, 0x0
    1074: 0c 94 b3 32  	<unknown>
    1078: 00 91 39 07  	<unknown>
    107c: 0f 70        	andi	r16, 0xf
    107e: 08 95        	ret
    1080: eb e7        	ldi	r30, 0x7b
    1082: f6 e0        	ldi	r31, 0x6
    1084: 00 81        	ldd	r16, Z+0
    1086: 11 81        	ldd	r17, Z+1
    1088: 08 95        	ret
    108a: fa df        	rcall	.-12
    108c: 0c 94 fa 10  	<unknown>
    1090: a9 01 40 5f  	<unknown>
    1094: 5f 4f        	sbci	r21, 0xff
    1096: bd ce        	rjmp	.-646
    1098: 0e 94 43 0f  	<unknown>
    109c: 06 d0        	rcall	.+12
    109e: 10 e0        	ldi	r17, 0x0
    10a0: 00 e0        	ldi	r16, 0x0
    10a2: 0c 94 29 0f  	<unknown>
    10a6: 01 d0        	rcall	.+2
    10a8: 04 c0        	rjmp	.+8
    10aa: 20 e0        	ldi	r18, 0x0
    10ac: e9 df        	rcall	.-46
    10ae: 0c 94 69 11  	<unknown>
    10b2: e6 df        	rcall	.-52
    10b4: 0c 94 31 11  	<unknown>
    10b8: fc df        	rcall	.-8
    10ba: 03 50        	subi	r16, 0x3
    10bc: 08 95        	ret
    10be: 9a 93        	st	-Y, r25
    10c0: 8a 93        	st	-Y, r24
    10c2: 24 e0        	ldi	r18, 0x4
    10c4: 12 9f 80 e0  	<unknown>
    10c8: 90 e0        	ldi	r25, 0x0
    10ca: 80 0d        	add	r24, r0
    10cc: 91 1d        	adc	r25, r1
    10ce: 00 23        	tst	r16
    10d0: 89 f0        	breq	.+34
    10d2: 0e 94 3c 0b  	<unknown>
    10d6: 5b d0        	rcall	.+182
    10d8: 2e e5        	ldi	r18, 0x5e
    10da: 31 e0        	ldi	r19, 0x1
    10dc: 0e 94 7b 0d  	<unknown>
    10e0: ac 01 0e 94  	<unknown>
    10e4: 8e 31        	cpi	r24, 0x1e
    10e6: a8 01 b9 01  	<unknown>
    10ea: 5d d0        	rcall	.+186
    10ec: 0e 94 f8 0c  	<unknown>
    10f0: 78 94        	sei
    10f2: 12 c0        	rjmp	.+36
    10f4: 52 d0        	rcall	.+164
    10f6: 0e 94 cf 0d  	<unknown>
    10fa: 01 30        	cpi	r16, 0x1
    10fc: 69 f4        	brne	.+26
    10fe: f8 94        	cli
    1100: 52 d0        	rcall	.+164
    1102: 0e 94 30 0d  	<unknown>
    1106: ac 01 0e 94  	<unknown>
    110a: ab 31        	cpi	r26, 0x1b
    110c: 78 94        	sei
    110e: 4b d0        	rcall	.+150
    1110: 0e 94 41 0b  	<unknown>
    1114: 01 e0        	ldi	r16, 0x1
    1116: 01 c0        	rjmp	.+2
    1118: 00 e0        	ldi	r16, 0x0
    111a: 89 91        	ld	r24, Y+
    111c: 99 91        	ld	r25, Y+
    111e: 08 95        	ret
    1120: 9a 93        	st	-Y, r25
    1122: 8a 93        	st	-Y, r24
    1124: 30 e0        	ldi	r19, 0x0
    1126: 80 e0        	ldi	r24, 0x0
    1128: 90 e0        	ldi	r25, 0x0
    112a: 81 0f        	add	r24, r17
    112c: 93 1f        	adc	r25, r19
    112e: 00 23        	tst	r16
    1130: d9 f0        	breq	.+54
    1132: 0e 94 2d 0b  	<unknown>
    1136: 2b d0        	rcall	.+86
    1138: 2f e6        	ldi	r18, 0x6f
    113a: 31 e0        	ldi	r19, 0x1
    113c: 0e 94 71 0b  	<unknown>
    1140: 42 96 ac 01  	<unknown>
    1144: 7d df        	rcall	.-262
    1146: 40 2f        	mov	r20, r16
    1148: 2b d0        	rcall	.+86
    114a: 0e 94 68 0b  	<unknown>
    114e: 78 94        	sei
    1150: 06 e0        	ldi	r16, 0x6
    1152: 10 e0        	ldi	r17, 0x0
    1154: 1a 93        	st	-Y, r17
    1156: 1a 93        	st	-Y, r17
    1158: 1a 93        	st	-Y, r17
    115a: 0a 93        	st	-Y, r16
    115c: 40 e0        	ldi	r20, 0x0
    115e: 20 d0        	rcall	.+64
    1160: 0e 94 59 0b  	<unknown>
    1164: 01 e0        	ldi	r16, 0x1
    1166: 12 c0        	rjmp	.+36
    1168: 18 d0        	rcall	.+48
    116a: 0e 94 95 0b  	<unknown>
    116e: 01 30        	cpi	r16, 0x1
    1170: 61 f4        	brne	.+24
    1172: f8 94        	cli
    1174: 18 d0        	rcall	.+48
    1176: 0e 94 6b 0b  	<unknown>
    117a: ac 01 4e 5e  	<unknown>
    117e: 8a df        	rcall	.-236
    1180: 78 94        	sei
    1182: 11 d0        	rcall	.+34
    1184: 0e 94 33 0b  	<unknown>
    1188: ed cf        	rjmp	.-38
    118a: 00 e0        	ldi	r16, 0x0
    118c: c6 cf        	rjmp	.-116
    118e: ed e7        	ldi	r30, 0x7d
    1190: f6 e0        	ldi	r31, 0x6
    1192: 00 83        	std	Z+0, r16
    1194: 11 83        	std	Z+1, r17
    1196: f8 94        	cli
    1198: 08 95        	ret
    119a: 20 91 39 07  	<unknown>
    119e: 03 c0        	rjmp	.+6
    11a0: 50 e0        	ldi	r21, 0x0
    11a2: 60 e0        	ldi	r22, 0x0
    11a4: 70 e0        	ldi	r23, 0x0
    11a6: ed e7        	ldi	r30, 0x7d
    11a8: f6 e0        	ldi	r31, 0x6
    11aa: 6c cf        	rjmp	.-296
    11ac: a9 98        	cbi	0x15, 0x1
    11ae: 00 23        	tst	r16
    11b0: 11 f0        	breq	.+4
    11b2: a1 98        	cbi	0x14, 0x1
    11b4: 01 c0        	rjmp	.+2
    11b6: a1 9a        	sbi	0x14, 0x1
    11b8: 99 9b        	sbis	0x13, 0x1
    11ba: 02 c0        	rjmp	.+4
    11bc: 01 e0        	ldi	r16, 0x1
    11be: 08 95        	ret
    11c0: 00 e0        	ldi	r16, 0x0
    11c2: 08 95        	ret
    11c4: a0 9a        	sbi	0x14, 0x0
    11c6: 00 23        	tst	r16
    11c8: 11 f0        	breq	.+4
    11ca: a8 9a        	sbi	0x15, 0x0
    11cc: 08 95        	ret
    11ce: a8 98        	cbi	0x15, 0x0
    11d0: 08 95        	ret
    11d2: 1d d0        	rcall	.+58
    11d4: 25 d0        	rcall	.+74
    11d6: 1a d0        	rcall	.+52
    11d8: 18 d0        	rcall	.+48
    11da: 65 d0        	rcall	.+202
    11dc: 01 ed        	ldi	r16, 0xd1
    11de: 16 d0        	rcall	.+44
    11e0: 03 c0        	rjmp	.+6
    11e2: 09 2f        	mov	r16, r25
    11e4: 3f d0        	rcall	.+126
    11e6: 0d 93        	st	X+, r16
    11e8: 17 d0        	rcall	.+46
    11ea: d9 f7        	brne	.-10
    11ec: 0e d0        	rcall	.+28
    11ee: e4 e0        	ldi	r30, 0x4
    11f0: 0c 94 00 35  	<unknown>
    11f4: 0c d0        	rcall	.+24
    11f6: 33 23        	tst	r19
    11f8: 39 f0        	breq	.+14
    11fa: 12 d0        	rcall	.+36
    11fc: 01 c0        	rjmp	.+2
    11fe: 0d 91        	ld	r16, X+
    1200: 05 d0        	rcall	.+10
    1202: 0a d0        	rcall	.+20
    1204: e1 f7        	brne	.-8
    1206: 01 d0        	rcall	.+2
    1208: f2 cf        	rjmp	.-28
    120a: 50 c0        	rjmp	.+160
    120c: 0e c0        	rjmp	.+28
    120e: 0e 94 ef 34  	<unknown>
    1212: c9 01 d8 01  	<unknown>
    1216: 08 95        	ret
    1218: 09 2f        	mov	r16, r25
    121a: 9a 95        	dec	r25
    121c: 00 23        	tst	r16
    121e: 08 95        	ret
    1220: 42 d0        	rcall	.+132
    1222: 00 ed        	ldi	r16, 0xd0
    1224: 02 d0        	rcall	.+4
    1226: 08 2f        	mov	r16, r24
    1228: 08 95        	ret
    122a: 9a 93        	st	-Y, r25
    122c: 8a 93        	st	-Y, r24
    122e: 90 2f        	mov	r25, r16
    1230: 88 e0        	ldi	r24, 0x8
    1232: 04 c0        	rjmp	.+8
    1234: 00 e0        	ldi	r16, 0x0
    1236: 31 d0        	rcall	.+98
    1238: 99 0f        	lsl	r25
    123a: 30 d0        	rcall	.+96
    123c: 08 2f        	mov	r16, r24
    123e: 8a 95        	dec	r24
    1240: 00 23        	tst	r16
    1242: 21 f0        	breq	.+8
    1244: 97 fb        	bst	r25, 0x7
    1246: b6 f7        	brtc	.-20
    1248: 01 e0        	ldi	r16, 0x1
    124a: f5 cf        	rjmp	.-22
    124c: 25 d0        	rcall	.+74
    124e: 23 d0        	rcall	.+70
    1250: 00 23        	tst	r16
    1252: 11 f0        	breq	.+4
    1254: 81 e0        	ldi	r24, 0x1
    1256: 01 c0        	rjmp	.+2
    1258: 80 e0        	ldi	r24, 0x0
    125a: 21 d0        	rcall	.+66
    125c: 08 2f        	mov	r16, r24
    125e: 89 91        	ld	r24, Y+
    1260: 99 91        	ld	r25, Y+
    1262: 08 95        	ret
    1264: 0e 94 f0 34  	<unknown>
    1268: a0 2f        	mov	r26, r16
    126a: 98 e0        	ldi	r25, 0x8
    126c: 15 d0        	rcall	.+42
    126e: 06 c0        	rjmp	.+12
    1270: 88 0f        	lsl	r24
    1272: 11 d0        	rcall	.+34
    1274: 00 23        	tst	r16
    1276: 09 f0        	breq	.+2
    1278: 81 60        	ori	r24, 0x1
    127a: 11 d0        	rcall	.+34
    127c: cd df        	rcall	.-102
    127e: c1 f7        	brne	.-16
    1280: aa 23        	tst	r26
    1282: 11 f0        	breq	.+4
    1284: 00 e0        	ldi	r16, 0x0
    1286: 01 c0        	rjmp	.+2
    1288: 01 e0        	ldi	r16, 0x1
    128a: 07 d0        	rcall	.+14
    128c: 07 d0        	rcall	.+14
    128e: 08 2f        	mov	r16, r24
    1290: e3 e0        	ldi	r30, 0x3
    1292: 0c 94 01 35  	<unknown>
    1296: 05 d0        	rcall	.+10
    1298: 01 e0        	ldi	r16, 0x1
    129a: 88 cf        	rjmp	.-240
    129c: 02 d0        	rcall	.+4
    129e: 00 e0        	ldi	r16, 0x0
    12a0: 91 cf        	rjmp	.-222
    12a2: 01 e0        	ldi	r16, 0x1
    12a4: fd cf        	rjmp	.-6
    12a6: 00 e0        	ldi	r16, 0x0
    12a8: f8 df        	rcall	.-16
    12aa: f9 cf        	rjmp	.-14
    12ac: fa df        	rcall	.-12
    12ae: 01 e0        	ldi	r16, 0x1
    12b0: f4 cf        	rjmp	.-24
    12b2: 8a 93        	st	-Y, r24
    12b4: 8f ef        	ldi	r24, 0xff
    12b6: 0f ef        	ldi	r16, 0xff
    12b8: 0e 94 c5 06  	<unknown>
    12bc: 8a 95        	dec	r24
    12be: d9 f7        	brne	.-10
    12c0: 89 91        	ld	r24, Y+
    12c2: 08 95        	ret
    12c4: 13 d0        	rcall	.+38
    12c6: 05 e5        	ldi	r16, 0x55
    12c8: 46 d0        	rcall	.+140
    12ca: 28 e0        	ldi	r18, 0x8
    12cc: 01 e8        	ldi	r16, 0x81
    12ce: 16 e0        	ldi	r17, 0x6
    12d0: 0c 94 b7 06  	<unknown>
    12d4: 32 d0        	rcall	.+100
    12d6: d8 01 7f d0  	<unknown>
    12da: 83 e0        	ldi	r24, 0x3
    12dc: 7b d0        	rcall	.+246
    12de: 0d 93        	st	X+, r16
    12e0: 8a 95        	dec	r24
    12e2: e1 f7        	brne	.-8
    12e4: 03 d0        	rcall	.+6
    12e6: e4 e0        	ldi	r30, 0x4
    12e8: 0c 94 00 35  	<unknown>
    12ec: 0c 94 5f 06  	<unknown>
    12f0: ba 93        	st	-Y, r27
    12f2: aa 93        	st	-Y, r26
    12f4: d8 01 2d d0  	<unknown>
    12f8: 0e e4        	ldi	r16, 0x4e
    12fa: 2d d0        	rcall	.+90
    12fc: 2b d0        	rcall	.+86
    12fe: 2a d0        	rcall	.+84
    1300: 0c 91        	ld	r16, X
    1302: 29 d0        	rcall	.+82
    1304: 26 d0        	rcall	.+76
    1306: 08 e4        	ldi	r16, 0x48
    1308: 26 d0        	rcall	.+76
    130a: d3 df        	rcall	.-90
    130c: a9 91        	ld	r26, Y+
    130e: b9 91        	ld	r27, Y+
    1310: 08 95        	ret
    1312: 13 d0        	rcall	.+38
    1314: 23 97 a0 2f  	<unknown>
    1318: 81 2f        	mov	r24, r17
    131a: 0b d0        	rcall	.+22
    131c: b0 e0        	ldi	r27, 0x0
    131e: ea 0f        	add	r30, r26
    1320: fb 1f        	adc	r31, r27
    1322: 00 81        	ldd	r16, Z+0
    1324: 08 17        	cp	r16, r24
    1326: 19 f0        	breq	.+6
    1328: 80 83        	std	Z+0, r24
    132a: 8e 01 e1 df  	<unknown>
    132e: 23 96 da cf  	<unknown>
    1332: 8e 01 cf df  	<unknown>
    1336: fe 01 08 95  	<unknown>
    133a: 0c 94 ef 34  	<unknown>
    133e: 09 d0        	rcall	.+18
    1340: 04 eb        	ldi	r16, 0xb4
    1342: 09 d0        	rcall	.+18
    1344: 44 d0        	rcall	.+136
    1346: 11 f0        	breq	.+4
    1348: 1f e7        	ldi	r17, 0x7f
    134a: 01 c0        	rjmp	.+2
    134c: 1f e3        	ldi	r17, 0x3f
    134e: 02 e0        	ldi	r16, 0x2
    1350: e0 cf        	rjmp	.-64
    1352: b8 cf        	rjmp	.-144
    1354: 0d 91        	ld	r16, X+
    1356: 0c 94 96 06  	<unknown>
    135a: ef df        	rcall	.-34
    135c: e3 d0        	rcall	.+454
    135e: 69 f0        	breq	.+26
    1360: 8f 9a        	sbi	0x11, 0x7
    1362: 97 9a        	sbi	0x12, 0x7
    1364: 0f ef        	ldi	r16, 0xff
    1366: 10 e7        	ldi	r17, 0x70
    1368: 22 e0        	ldi	r18, 0x2
    136a: 01 50        	subi	r16, 0x1
    136c: 10 40        	sbci	r17, 0x0
    136e: 20 40        	sbci	r18, 0x0
    1370: e1 f7        	brne	.-8
    1372: 00 c0        	rjmp	.+0
    1374: 00 00        	nop
    1376: 8f 98        	cbi	0x11, 0x7
    1378: 97 98        	cbi	0x12, 0x7
    137a: 29 d0        	rcall	.+82
    137c: f1 f3        	breq	.-4
    137e: 2c d0        	rcall	.+88
    1380: c8 01 00 e2  	<unknown>
    1384: 0e 94 a3 06  	<unknown>
    1388: 25 d0        	rcall	.+74
    138a: a0 2f        	mov	r26, r16
    138c: 23 d0        	rcall	.+70
    138e: 20 2f        	mov	r18, r16
    1390: 00 91 81 06  	<unknown>
    1394: 00 31        	cpi	r16, 0x10
    1396: 59 f4        	brne	.+22
    1398: 8e 7f        	andi	r24, 0xfe
    139a: 42 e3        	ldi	r20, 0x32
    139c: 50 e0        	ldi	r21, 0x0
    139e: 8c 01 a2 d0  	<unknown>
    13a2: 42 2f        	mov	r20, r18
    13a4: 4a 1b        	sub	r20, r26
    13a6: a2 d0        	rcall	.+324
    13a8: 42 2f        	mov	r20, r18
    13aa: a5 d0        	rcall	.+330
    13ac: 0e c0        	rjmp	.+28
    13ae: 44 e0        	ldi	r20, 0x4
    13b0: 8c 01 0e 94  	<unknown>
    13b4: db 31        	cpi	r29, 0x1b
    13b6: 44 e6        	ldi	r20, 0x64
    13b8: 50 e0        	ldi	r21, 0x0
    13ba: 9b d0        	rcall	.+310
    13bc: d8 01 8f 70  	<unknown>
    13c0: 08 2f        	mov	r16, r24
    13c2: a0 d0        	rcall	.+320
    13c4: cd 01 80 0f  	<unknown>
    13c8: 91 1f        	adc	r25, r17
    13ca: 8c 01 8c cf  	<unknown>
    13ce: b9 d0        	rcall	.+370
    13d0: 00 23        	tst	r16
    13d2: 08 95        	ret
    13d4: 0c 94 a2 06  	<unknown>
    13d8: bc df        	rcall	.-136
    13da: 0e eb        	ldi	r16, 0xbe
    13dc: bc df        	rcall	.-136
    13de: 00 e1        	ldi	r16, 0x10
    13e0: 0c 94 a3 06  	<unknown>
    13e4: 0e 94 ec 34  	<unknown>
    13e8: 62 97 d8 01  	<unknown>
    13ec: 87 99        	sbic	0x10, 0x7
    13ee: 02 c0        	rjmp	.+4
    13f0: 02 e0        	ldi	r16, 0x2
    13f2: 74 c0        	rjmp	.+232
    13f4: a8 d0        	rcall	.+336
    13f6: d9 f0        	breq	.+54
    13f8: 82 9b        	sbis	0x10, 0x2
    13fa: 07 c0        	rjmp	.+14
    13fc: 00 91 89 06  	<unknown>
    1400: 00 23        	tst	r16
    1402: 19 f4        	brne	.+6
    1404: 01 e0        	ldi	r16, 0x1
    1406: 00 93 89 06  	<unknown>
    140a: 82 99        	sbic	0x10, 0x2
    140c: 07 c0        	rjmp	.+14
    140e: 00 91 89 06  	<unknown>
    1412: 00 23        	tst	r16
    1414: 39 f0        	breq	.+14
    1416: 03 95        	inc	r16
    1418: 00 93 89 06  	<unknown>
    141c: 00 91 89 06  	<unknown>
    1420: 05 30        	cpi	r16, 0x5
    1422: 10 f4        	brsh	.+4
    1424: 00 e0        	ldi	r16, 0x0
    1426: 5a c0        	rjmp	.+180
    1428: 8f 98        	cbi	0x11, 0x7
    142a: 97 98        	cbi	0x12, 0x7
    142c: 02 c0        	rjmp	.+4
    142e: cf df        	rcall	.-98
    1430: c9 f3        	breq	.-14
    1432: d2 df        	rcall	.-92
    1434: 0d 93        	st	X+, r16
    1436: 1c 93        	st	X, r17
    1438: 11 97 0d 91  	<unknown>
    143c: 08 83        	std	Y+0, r16
    143e: 0c 91        	ld	r16, X
    1440: 11 97 09 83  	<unknown>
    1444: c7 df        	rcall	.-114
    1446: 0a 83        	std	Y+2, r16
    1448: c5 df        	rcall	.-118
    144a: 0b 83        	std	Y+3, r16
    144c: c3 df        	rcall	.-122
    144e: 0c 83        	std	Y+4, r16
    1450: c1 df        	rcall	.-126
    1452: 0d 83        	std	Y+5, r16
    1454: bf df        	rcall	.-130
    1456: 60 2e        	mov	r6, r16
    1458: 0e 83        	std	Y+6, r16
    145a: bc df        	rcall	.-136
    145c: 40 2e        	mov	r4, r16
    145e: 0f 83        	std	Y+7, r16
    1460: b9 df        	rcall	.-142
    1462: 08 87        	std	Y+0, r16
    1464: 8e 01 07 5f  	<unknown>
    1468: 1f 4f        	sbci	r17, 0xff
    146a: f8 01 20 e0  	<unknown>
    146e: 89 e0        	ldi	r24, 0x9
    1470: 21 93        	st	Z+, r18
    1472: 8a 95        	dec	r24
    1474: e9 f7        	brne	.-6
    1476: 29 e0        	ldi	r18, 0x9
    1478: 8e 01 0e 94  	<unknown>
    147c: 8d 20        	and	r8, r13
    147e: 00 23        	tst	r16
    1480: 09 f0        	breq	.+2
    1482: b6 cf        	rjmp	.-148
    1484: 49 e0        	ldi	r20, 0x9
    1486: 50 e0        	ldi	r21, 0x0
    1488: 9e 01 27 5f  	<unknown>
    148c: 3f 4f        	sbci	r19, 0xff
    148e: 8e 01 0e 94  	<unknown>
    1492: 1c 35        	cpi	r17, 0x5c
    1494: 01 2b        	or	r16, r17
    1496: 09 f4        	brne	.+2
    1498: ab cf        	rjmp	.-170
    149a: 00 91 81 06  	<unknown>
    149e: 00 31        	cpi	r16, 0x10
    14a0: 61 f4        	brne	.+24
    14a2: 0d 91        	ld	r16, X+
    14a4: 1c 91        	ld	r17, X
    14a6: 11 97 0e 7f  	<unknown>
    14aa: 42 e3        	ldi	r20, 0x32
    14ac: 1b d0        	rcall	.+54
    14ae: 44 2d        	mov	r20, r4
    14b0: 46 19        	sub	r20, r6
    14b2: 1c d0        	rcall	.+56
    14b4: 44 2d        	mov	r20, r4
    14b6: 1f d0        	rcall	.+62
    14b8: 0e c0        	rjmp	.+28
    14ba: 44 e0        	ldi	r20, 0x4
    14bc: 0d 91        	ld	r16, X+
    14be: 1c 91        	ld	r17, X
    14c0: 11 97 0e 94  	<unknown>
    14c4: db 31        	cpi	r29, 0x1b
    14c6: 44 e6        	ldi	r20, 0x64
    14c8: 0d d0        	rcall	.+26
    14ca: 0d 91        	ld	r16, X+
    14cc: 11 97 0f 70  	<unknown>
    14d0: 19 d0        	rcall	.+50
    14d2: 80 0f        	add	r24, r16
    14d4: 91 1f        	adc	r25, r17
    14d6: 8d 93        	st	X+, r24
    14d8: 9c 93        	st	X, r25
    14da: 01 e0        	ldi	r16, 0x1
    14dc: 62 96 e7 e0  	<unknown>
    14e0: 0c 94 fd 34  	<unknown>
    14e4: 50 e0        	ldi	r21, 0x0
    14e6: 05 d0        	rcall	.+10
    14e8: c8 01 08 95  	<unknown>
    14ec: 50 40        	sbci	r21, 0x0
    14ee: 04 e6        	ldi	r16, 0x64
    14f0: 10 e0        	ldi	r17, 0x0
    14f2: 0c 94 cd 31  	<unknown>
    14f6: 50 e0        	ldi	r21, 0x0
    14f8: 0e 94 f9 31  	<unknown>
    14fc: 80 0f        	add	r24, r16
    14fe: 91 1f        	adc	r25, r17
    1500: 49 97 08 95  	<unknown>
    1504: f5 df        	rcall	.-22
    1506: 40 e1        	ldi	r20, 0x10
    1508: 0c 94 f9 31  	<unknown>
    150c: 0b d0        	rcall	.+22
    150e: 49 f0        	breq	.+18
    1510: 97 9a        	sbi	0x12, 0x7
    1512: 8f 9a        	sbi	0x11, 0x7
    1514: 82 9b        	sbis	0x10, 0x2
    1516: 02 c0        	rjmp	.+4
    1518: 01 e0        	ldi	r16, 0x1
    151a: 01 c0        	rjmp	.+2
    151c: 00 e0        	ldi	r16, 0x0
    151e: 00 93 89 06  	<unknown>
    1522: 08 95        	ret
    1524: 16 df        	rcall	.-468
    1526: 04 eb        	ldi	r16, 0xb4
    1528: 16 df        	rcall	.-468
    152a: 0b d0        	rcall	.+22
    152c: 00 23        	tst	r16
    152e: 11 f4        	brne	.+4
    1530: 01 e0        	ldi	r16, 0x1
    1532: 01 c0        	rjmp	.+2
    1534: 00 e0        	ldi	r16, 0x0
    1536: 00 93 7f 06  	<unknown>
    153a: 0b df        	rcall	.-490
    153c: 04 e4        	ldi	r16, 0x44
    153e: 0b df        	rcall	.-490
    1540: 02 c0        	rjmp	.+4
    1542: 0c 94 81 06  	<unknown>
    1546: 00 91 7f 06  	<unknown>
    154a: 42 cf        	rjmp	.-380
    154c: 0e 94 ed 34  	<unknown>
    1550: 40 2e        	mov	r4, r16
    1552: 81 2f        	mov	r24, r17
    1554: 0f ef        	ldi	r16, 0xff
    1556: 40 16        	cp	r4, r16
    1558: e1 f5        	brne	.+120
    155a: 00 e0        	ldi	r16, 0x0
    155c: 00 93 8b 06  	<unknown>
    1560: 00 93 8a 06  	<unknown>
    1564: ef e7        	ldi	r30, 0x7f
    1566: f6 e0        	ldi	r31, 0x6
    1568: 04 85        	ldd	r16, Z+4
    156a: 03 95        	inc	r16
    156c: 04 87        	std	Z+4, r16
    156e: be de        	rcall	.-644
    1570: 00 23        	tst	r16
    1572: 99 f5        	brne	.+102
    1574: 00 ef        	ldi	r16, 0xf0
    1576: ef de        	rcall	.-546
    1578: 00 e0        	ldi	r16, 0x0
    157a: 00 93 8d 06  	<unknown>
    157e: e1 df        	rcall	.-62
    1580: 00 93 8c 06  	<unknown>
    1584: de df        	rcall	.-68
    1586: 30 2f        	mov	r19, r16
    1588: 20 91 8d 06  	<unknown>
    158c: 02 2f        	mov	r16, r18
    158e: 06 95        	lsr	r16
    1590: 06 95        	lsr	r16
    1592: 06 95        	lsr	r16
    1594: 10 e0        	ldi	r17, 0x0
    1596: ef e7        	ldi	r30, 0x7f
    1598: f6 e0        	ldi	r31, 0x6
    159a: e0 0f        	add	r30, r16
    159c: f1 1f        	adc	r31, r17
    159e: 42 2f        	mov	r20, r18
    15a0: 47 70        	andi	r20, 0x7
    15a2: 01 e0        	ldi	r16, 0x1
    15a4: 0e 94 ba 31  	<unknown>
    15a8: 10 91 8c 06  	<unknown>
    15ac: 13 17        	cp	r17, r19
    15ae: 31 f5        	brne	.+76
    15b0: 42 2f        	mov	r20, r18
    15b2: 50 e0        	ldi	r21, 0x0
    15b4: 54 2c        	mov	r5, r4
    15b6: 55 0c        	lsl	r5
    15b8: 55 08        	sbc	r5, r5
    15ba: 42 16        	cp	r4, r18
    15bc: 55 06        	cpc	r5, r21
    15be: 94 f4        	brge	.+36
    15c0: 42 2e        	mov	r4, r18
    15c2: 80 e0        	ldi	r24, 0x0
    15c4: 18 2f        	mov	r17, r24
    15c6: 04 2d        	mov	r16, r4
    15c8: c1 df        	rcall	.-126
    15ca: 83 95        	inc	r24
    15cc: 82 30        	cpi	r24, 0x2
    15ce: 28 f4        	brsh	.+10
    15d0: f9 cf        	rjmp	.-14
    15d2: 00 91 8b 06  	<unknown>
    15d6: 05 31        	cpi	r16, 0x15
    15d8: 28 f2        	brlo	.-118
    15da: 00 91 8a 06  	<unknown>
    15de: e6 e0        	ldi	r30, 0x6
    15e0: 0c 94 fe 34  	<unknown>
    15e4: 80 93 8c 06  	<unknown>
    15e8: 54 2c        	mov	r5, r4
    15ea: 55 0c        	lsl	r5
    15ec: 55 08        	sbc	r5, r5
    15ee: 44 15        	cp	r20, r4
    15f0: 55 05        	cpc	r21, r5
    15f2: 21 f0        	breq	.+8
    15f4: 12 81        	ldd	r17, Z+2
    15f6: 10 23        	and	r17, r16
    15f8: 10 93 8c 06  	<unknown>
    15fc: 10 91 8c 06  	<unknown>
    1600: 11 23        	tst	r17
    1602: 19 f0        	breq	.+6
    1604: 22 81        	ldd	r18, Z+2
    1606: 20 2b        	or	r18, r16
    1608: 03 c0        	rjmp	.+6
    160a: 00 95        	com	r16
    160c: 22 81        	ldd	r18, Z+2
    160e: 20 23        	and	r18, r16
    1610: 22 83        	std	Z+2, r18
    1612: 01 2f        	mov	r16, r17
    1614: 0e 94 75 06  	<unknown>
    1618: ef e7        	ldi	r30, 0x7f
    161a: f6 e0        	ldi	r31, 0x6
    161c: 06 85        	ldd	r16, Z+6
    161e: 03 95        	inc	r16
    1620: 06 87        	std	Z+6, r16
    1622: 00 34        	cpi	r16, 0x40
    1624: 08 f4        	brsh	.+2
    1626: ab cf        	rjmp	.-170
    1628: 03 85        	ldd	r16, Z+3
    162a: 11 81        	ldd	r17, Z+1
    162c: 01 17        	cp	r16, r17
    162e: 11 f4        	brne	.+4
    1630: 0d e3        	ldi	r16, 0x3d
    1632: 04 87        	std	Z+4, r16
    1634: 04 85        	ldd	r16, Z+4
    1636: 0a 95        	dec	r16
    1638: 04 87        	std	Z+4, r16
    163a: 03 85        	ldd	r16, Z+3
    163c: 03 95        	inc	r16
    163e: 03 87        	std	Z+3, r16
    1640: cc cf        	rjmp	.-104
    1642: 03 d0        	rcall	.+6
    1644: 09 f0        	breq	.+2
    1646: ff c0        	rjmp	.+510
    1648: 0b c0        	rjmp	.+22
    164a: 06 e1        	ldi	r16, 0x16
    164c: 10 e0        	ldi	r17, 0x0
    164e: 0e 94 3e 35  	<unknown>
    1652: 20 2f        	mov	r18, r16
    1654: 21 2b        	or	r18, r17
    1656: 08 95        	ret
    1658: 06 c0        	rjmp	.+12
    165a: f7 df        	rcall	.-18
    165c: 09 f0        	breq	.+2
    165e: 1f c0        	rjmp	.+62
    1660: 00 e0        	ldi	r16, 0x0
    1662: 10 e0        	ldi	r17, 0x0
    1664: 08 95        	ret
    1666: 16 d0        	rcall	.+44
    1668: 21 f0        	breq	.+8
    166a: 08 2f        	mov	r16, r24
    166c: 0e 94 7f 11  	<unknown>
    1670: 0e d0        	rcall	.+28
    1672: 89 91        	ld	r24, Y+
    1674: 99 91        	ld	r25, Y+
    1676: 08 95        	ret
    1678: 03 e1        	ldi	r16, 0x13
    167a: e8 df        	rcall	.-48
    167c: 09 f0        	breq	.+2
    167e: 8c c1        	rjmp	.+792
    1680: ef cf        	rjmp	.-34
    1682: 08 d0        	rcall	.+16
    1684: 19 f0        	breq	.+6
    1686: 08 2f        	mov	r16, r24
    1688: a0 d1        	rcall	.+832
    168a: 01 d0        	rcall	.+2
    168c: f2 cf        	rjmp	.-28
    168e: 8c 01 0c 94  	<unknown>
    1692: 76 31        	cpi	r23, 0x16
    1694: 9a 93        	st	-Y, r25
    1696: 8a 93        	st	-Y, r24
    1698: c8 01 01 2b  	<unknown>
    169c: 08 95        	ret
    169e: f5 d0        	rcall	.+490
    16a0: 00 e8        	ldi	r16, 0x80
    16a2: 11 e0        	ldi	r17, 0x1
    16a4: da d0        	rcall	.+436
    16a6: 3f d0        	rcall	.+126
    16a8: e9 d0        	rcall	.+466
    16aa: 04 e6        	ldi	r16, 0x64
    16ac: e1 d0        	rcall	.+450
    16ae: 1d 93        	st	X+, r17
    16b0: d9 c0        	rjmp	.+434
    16b2: 08 80        	ldd	r0, Y+0
    16b4: 19 80        	ldd	r1, Y+1
    16b6: 2a 80        	ldd	r2, Y+2
    16b8: 3b 80        	ldd	r3, Y+3
    16ba: f8 01 42 83  	<unknown>
    16be: 53 83        	std	Z+3, r21
    16c0: 64 83        	std	Z+4, r22
    16c2: 75 83        	std	Z+5, r23
    16c4: 06 82        	std	Z+6, r0
    16c6: 17 82        	std	Z+7, r1
    16c8: 20 86        	std	Z+0, r2
    16ca: 31 86        	std	Z+1, r3
    16cc: 24 96 08 95  	<unknown>
    16d0: b7 d0        	rcall	.+366
    16d2: 56 d1        	rcall	.+684
    16d4: f1 c0        	rjmp	.+482
    16d6: f8 01 02 85  	<unknown>
    16da: 13 85        	ldd	r17, Z+3
    16dc: 24 85        	ldd	r18, Z+4
    16de: 35 85        	ldd	r19, Z+5
    16e0: 08 95        	ret
    16e2: f8 01 22 8b  	<unknown>
    16e6: 33 8b        	std	Z+3, r19
    16e8: 08 95        	ret
    16ea: 7f d1        	rcall	.+766
    16ec: 1c d0        	rcall	.+56
    16ee: 11 e0        	ldi	r17, 0x1
    16f0: 07 e0        	ldi	r16, 0x7
    16f2: 50 d2        	rcall	.+1184
    16f4: 1a 96 0d 91  	<unknown>
    16f8: 1d 91        	ld	r17, X+
    16fa: 2d 91        	ld	r18, X+
    16fc: 3c 91        	ld	r19, X
    16fe: 15 96 3a 93  	<unknown>
    1702: 2a 93        	st	-Y, r18
    1704: 28 d2        	rcall	.+1104
    1706: 06 e8        	ldi	r16, 0x86
    1708: 11 e0        	ldi	r17, 0x1
    170a: 36 d2        	rcall	.+1132
    170c: 24 96 2c d2  	<unknown>
    1710: 53 97 01 2b  	<unknown>
    1714: 10 e0        	ldi	r17, 0x0
    1716: 11 f4        	brne	.+4
    1718: 2a d2        	rcall	.+1108
    171a: 03 c0        	rjmp	.+6
    171c: 3a d2        	rcall	.+1140
    171e: 52 96 23 d2  	<unknown>
    1722: 2a d2        	rcall	.+1108
    1724: a2 c0        	rjmp	.+324
    1726: 0c 94 43 0f  	<unknown>
    172a: 8a d0        	rcall	.+276
    172c: 42 2f        	mov	r20, r18
    172e: 21 30        	cpi	r18, 0x1
    1730: 49 f4        	brne	.+18
    1732: d2 df        	rcall	.-92
    1734: 73 d0        	rcall	.+230
    1736: 0c f0        	brlt	.+2
    1738: 49 c0        	rjmp	.+146
    173a: 0f 5f        	subi	r16, 0xff
    173c: 1f 4f        	sbci	r17, 0xff
    173e: 2f 4f        	sbci	r18, 0xff
    1740: 3f 4f        	sbci	r19, 0xff
    1742: 43 c0        	rjmp	.+134
    1744: 24 30        	cpi	r18, 0x4
    1746: 61 f4        	brne	.+24
    1748: 02 81        	ldd	r16, Z+2
    174a: 13 81        	ldd	r17, Z+3
    174c: 24 81        	ldd	r18, Z+4
    174e: 35 81        	ldd	r19, Z+5
    1750: 12 d1        	rcall	.+548
    1752: 65 d0        	rcall	.+202
    1754: dc f5        	brge	.+118
    1756: 80 01 91 01  	<unknown>
    175a: 01 50        	subi	r16, 0x1
    175c: 10 40        	sbci	r17, 0x0
    175e: 33 c0        	rjmp	.+102
    1760: 21 38        	cpi	r18, 0x81
    1762: 39 f4        	brne	.+14
    1764: b9 df        	rcall	.-142
    1766: 06 5f        	subi	r16, 0xf6
    1768: 56 d0        	rcall	.+172
    176a: 84 f5        	brge	.+96
    176c: b5 df        	rcall	.-150
    176e: 06 5f        	subi	r16, 0xf6
    1770: e5 cf        	rjmp	.-54
    1772: 24 38        	cpi	r18, 0x84
    1774: 49 f4        	brne	.+18
    1776: 43 d0        	rcall	.+134
    1778: af df        	rcall	.-162
    177a: 0a 50        	subi	r16, 0xa
    177c: 10 40        	sbci	r17, 0x0
    177e: 44 d0        	rcall	.+136
    1780: 2c f5        	brge	.+74
    1782: aa df        	rcall	.-172
    1784: 0a 50        	subi	r16, 0xa
    1786: ea cf        	rjmp	.-44
    1788: 23 30        	cpi	r18, 0x3
    178a: 39 f4        	brne	.+14
    178c: a5 df        	rcall	.-182
    178e: 0c 59        	subi	r16, 0x9c
    1790: 42 d0        	rcall	.+132
    1792: e4 f4        	brge	.+56
    1794: a1 df        	rcall	.-190
    1796: 0c 59        	subi	r16, 0x9c
    1798: d1 cf        	rjmp	.-94
    179a: 22 30        	cpi	r18, 0x2
    179c: 31 f4        	brne	.+12
    179e: 2f d0        	rcall	.+94
    17a0: 4b d0        	rcall	.+150
    17a2: 32 d0        	rcall	.+100
    17a4: 9c f4        	brge	.+38
    17a6: 48 d0        	rcall	.+144
    17a8: 0e c0        	rjmp	.+28
    17aa: 23 38        	cpi	r18, 0x83
    17ac: 29 f4        	brne	.+10
    17ae: 40 d0        	rcall	.+128
    17b0: 33 d0        	rcall	.+102
    17b2: 64 f4        	brge	.+24
    17b4: 3d d0        	rcall	.+122
    17b6: c3 cf        	rjmp	.-122
    17b8: 22 38        	cpi	r18, 0x82
    17ba: 41 f4        	brne	.+16
    17bc: 20 d0        	rcall	.+64
    17be: 34 d0        	rcall	.+104
    17c0: 23 d0        	rcall	.+70
    17c2: 24 f4        	brge	.+8
    17c4: 31 d0        	rcall	.+98
    17c6: 20 40        	sbci	r18, 0x0
    17c8: 30 40        	sbci	r19, 0x0
    17ca: 14 d0        	rcall	.+40
    17cc: 04 2f        	mov	r16, r20
    17ce: 0f 70        	andi	r16, 0xf
    17d0: 11 f4        	brne	.+4
    17d2: 01 e0        	ldi	r16, 0x1
    17d4: 0e c0        	rjmp	.+28
    17d6: 45 30        	cpi	r20, 0x5
    17d8: 31 f4        	brne	.+12
    17da: 06 85        	ldd	r16, Z+6
    17dc: 17 85        	ldd	r17, Z+7
    17de: 20 89        	ldd	r18, Z+0
    17e0: 31 89        	ldd	r19, Z+1
    17e2: 08 d0        	rcall	.+16
    17e4: f6 cf        	rjmp	.-20
    17e6: 4f 3f        	cpi	r20, 0xff
    17e8: 19 f0        	breq	.+6
    17ea: 8f 01 df 01  	<unknown>
    17ee: cd d0        	rcall	.+410
    17f0: 00 e0        	ldi	r16, 0x0
    17f2: 3b c0        	rjmp	.+118
    17f4: 02 87        	std	Z+2, r16
    17f6: 13 87        	std	Z+3, r17
    17f8: 24 87        	std	Z+4, r18
    17fa: 35 87        	std	Z+5, r19
    17fc: 08 95        	ret
    17fe: 02 80        	ldd	r0, Z+2
    1800: 13 80        	ldd	r1, Z+3
    1802: 24 80        	ldd	r2, Z+4
    1804: 35 80        	ldd	r3, Z+5
    1806: 08 95        	ret
    1808: 20 40        	sbci	r18, 0x0
    180a: 30 40        	sbci	r19, 0x0
    180c: 00 16        	cp	r0, r16
    180e: 11 06        	cpc	r1, r17
    1810: 22 06        	cpc	r2, r18
    1812: 33 06        	cpc	r3, r19
    1814: 08 95        	ret
    1816: 1f 4f        	sbci	r17, 0xff
    1818: 2f 4f        	sbci	r18, 0xff
    181a: 3f 4f        	sbci	r19, 0xff
    181c: 9f d0        	rcall	.+318
    181e: 00 15        	cp	r16, r0
    1820: 11 05        	cpc	r17, r1
    1822: 22 05        	cpc	r18, r2
    1824: 33 05        	cpc	r19, r3
    1826: 08 95        	ret
    1828: 57 df        	rcall	.-338
    182a: 08 5e        	subi	r16, 0xe8
    182c: 13 40        	sbci	r17, 0x3
    182e: 08 95        	ret
    1830: 53 df        	rcall	.-346
    1832: 08 51        	subi	r16, 0x18
    1834: 1c 4f        	sbci	r17, 0xfc
    1836: 08 95        	ret
    1838: 4f df        	rcall	.-354
    183a: 04 56        	subi	r16, 0x64
    183c: 10 40        	sbci	r17, 0x0
    183e: 08 95        	ret
    1840: 92 d0        	rcall	.+292
    1842: f8 01 08 95  	<unknown>
    1846: 21 d0        	rcall	.+66
    1848: 02 e8        	ldi	r16, 0x82
    184a: 11 e0        	ldi	r17, 0x1
    184c: 06 d0        	rcall	.+12
    184e: 16 d0        	rcall	.+44
    1850: 09 e0        	ldi	r16, 0x9
    1852: 0e d0        	rcall	.+28
    1854: 1c 93        	st	X, r17
    1856: 11 96 05 c0  	<unknown>
    185a: 54 96 0d 93  	<unknown>
    185e: 1c 93        	st	X, r17
    1860: 53 97 08 95  	<unknown>
    1864: 1c 93        	st	X, r17
    1866: 53 97 8d 01  	<unknown>
    186a: a9 91        	ld	r26, Y+
    186c: b9 91        	ld	r27, Y+
    186e: 08 95        	ret
    1870: 0d 93        	st	X+, r16
    1872: 1d 93        	st	X+, r17
    1874: 1d 93        	st	X+, r17
    1876: 1c 93        	st	X, r17
    1878: 19 96 08 95  	<unknown>
    187c: f1 de        	rcall	.-542
    187e: 0d 93        	st	X+, r16
    1880: 0d 93        	st	X+, r16
    1882: 0d 93        	st	X+, r16
    1884: 0c 93        	st	X, r16
    1886: 11 96 08 95  	<unknown>
    188a: 6d d0        	rcall	.+218
    188c: d8 01 0c 94  	<unknown>
    1890: 75 11        	cpse	r23, r5
    1892: 50 e0        	ldi	r21, 0x0
    1894: f8 01 22 83  	<unknown>
    1898: 53 83        	std	Z+3, r21
    189a: 54 83        	std	Z+4, r21
    189c: 55 83        	std	Z+5, r21
    189e: 36 83        	std	Z+6, r19
    18a0: 57 83        	std	Z+7, r21
    18a2: 50 87        	std	Z+0, r21
    18a4: 51 87        	std	Z+1, r21
    18a6: 08 95        	ret
    18a8: 5e d0        	rcall	.+188
    18aa: 50 e0        	ldi	r21, 0x0
    18ac: 70 e0        	ldi	r23, 0x0
    18ae: f8 01 22 87  	<unknown>
    18b2: 53 87        	std	Z+3, r21
    18b4: 54 87        	std	Z+4, r21
    18b6: 55 87        	std	Z+5, r21
    18b8: 42 85        	ldd	r20, Z+2
    18ba: 53 85        	ldd	r21, Z+3
    18bc: 64 85        	ldd	r22, Z+4
    18be: 46 87        	std	Z+6, r20
    18c0: 57 87        	std	Z+7, r21
    18c2: 60 8b        	std	Z+0, r22
    18c4: 71 8b        	std	Z+1, r23
    18c6: d8 01 60 d0  	<unknown>
    18ca: cf cf        	rjmp	.-98
    18cc: b9 df        	rcall	.-142
    18ce: 22 8b        	std	Z+2, r18
    18d0: 33 8b        	std	Z+3, r19
    18d2: f9 cf        	rjmp	.-14
    18d4: 8a d0        	rcall	.+276
    18d6: 53 96 51 d1  	<unknown>
    18da: 51 d2        	rcall	.+1186
    18dc: 11 e0        	ldi	r17, 0x1
    18de: 4d 91        	ld	r20, X+
    18e0: 18 96 04 2f  	<unknown>
    18e4: 00 5d        	subi	r16, 0xd0
    18e6: 50 d2        	rcall	.+1184
    18e8: 1c 91        	ld	r17, X
    18ea: 0e 91        	ld	r16, -X
    18ec: 50 c1        	rjmp	.+672
    18ee: 3b d0        	rcall	.+118
    18f0: 2f 70        	andi	r18, 0xf
    18f2: 21 30        	cpi	r18, 0x1
    18f4: 89 f4        	brne	.+34
    18f6: f8 01 42 85  	<unknown>
    18fa: 53 85        	ldd	r21, Z+3
    18fc: 64 85        	ldd	r22, Z+4
    18fe: 75 85        	ldd	r23, Z+5
    1900: 2d d0        	rcall	.+90
    1902: 34 d0        	rcall	.+104
    1904: 2c f4        	brge	.+10
    1906: 4f 5f        	subi	r20, 0xff
    1908: 5f 4f        	sbci	r21, 0xff
    190a: 6f 4f        	sbci	r22, 0xff
    190c: 7f 4f        	sbci	r23, 0xff
    190e: 38 d0        	rcall	.+112
    1910: d8 01 3b d0  	<unknown>
    1914: 00 e0        	ldi	r16, 0x0
    1916: a9 cf        	rjmp	.-174
    1918: 24 30        	cpi	r18, 0x4
    191a: 79 f4        	brne	.+30
    191c: f8 01 42 81  	<unknown>
    1920: 53 81        	ldd	r21, Z+3
    1922: 64 81        	ldd	r22, Z+4
    1924: 75 81        	ldd	r23, Z+5
    1926: 27 d0        	rcall	.+78
    1928: 21 d0        	rcall	.+66
    192a: 94 f7        	brge	.-28
    192c: a0 01 b1 01  	<unknown>
    1930: 41 50        	subi	r20, 0x1
    1932: 50 40        	sbci	r21, 0x0
    1934: 60 40        	sbci	r22, 0x0
    1936: 70 40        	sbci	r23, 0x0
    1938: ea cf        	rjmp	.-44
    193a: 25 30        	cpi	r18, 0x5
    193c: 41 f4        	brne	.+16
    193e: f8 01 46 85  	<unknown>
    1942: 57 85        	ldd	r21, Z+7
    1944: 60 89        	ldd	r22, Z+0
    1946: 71 89        	ldd	r23, Z+1
    1948: 1b d0        	rcall	.+54
    194a: 01 e0        	ldi	r16, 0x1
    194c: e4 cf        	rjmp	.-56
    194e: 22 23        	tst	r18
    1950: e1 f3        	breq	.-8
    1952: 23 30        	cpi	r18, 0x3
    1954: d1 f3        	breq	.-12
    1956: 22 30        	cpi	r18, 0x2
    1958: e9 f6        	brne	.-70
    195a: f7 cf        	rjmp	.-18
    195c: 06 80        	ldd	r0, Z+6
    195e: 17 80        	ldd	r1, Z+7
    1960: 20 84        	ldd	r2, Z+0
    1962: 31 84        	ldd	r3, Z+1
    1964: 08 95        	ret
    1966: ba 93        	st	-Y, r27
    1968: aa 93        	st	-Y, r26
    196a: 08 95        	ret
    196c: 40 15        	cp	r20, r0
    196e: 51 05        	cpc	r21, r1
    1970: 62 05        	cpc	r22, r2
    1972: 73 05        	cpc	r23, r3
    1974: 08 95        	ret
    1976: 02 84        	ldd	r0, Z+2
    1978: 13 84        	ldd	r1, Z+3
    197a: 24 84        	ldd	r2, Z+4
    197c: 35 84        	ldd	r3, Z+5
    197e: 08 95        	ret
    1980: 42 87        	std	Z+2, r20
    1982: 53 87        	std	Z+3, r21
    1984: 64 87        	std	Z+4, r22
    1986: 75 87        	std	Z+5, r23
    1988: 08 95        	ret
    198a: 54 96 ed 91  	<unknown>
    198e: fc 91        	ld	r31, X
    1990: 25 91 f4 91  	<unknown>
    1994: e2 2f        	mov	r30, r18
    1996: 09 94 78 df  	<unknown>
    199a: 21 d0        	rcall	.+66
    199c: 18 97 f2 d1  	<unknown>
    19a0: c2 de        	rcall	.-636
    19a2: 03 e0        	ldi	r16, 0x3
    19a4: 0d 93        	st	X+, r16
    19a6: 01 e0        	ldi	r16, 0x1
    19a8: 0c 93        	st	X, r16
    19aa: 17 97 0c 93  	<unknown>
    19ae: 15 96 00 e0  	<unknown>
    19b2: 0c 93        	st	X, r16
    19b4: 0e 93        	st	-X, r16
    19b6: 0e 93        	st	-X, r16
    19b8: 0e 93        	st	-X, r16
    19ba: 0e 93        	st	-X, r16
    19bc: 19 96 0d 93  	<unknown>
    19c0: 0d 93        	st	X+, r16
    19c2: 0c 93        	st	X, r16
    19c4: 50 97 8d 01  	<unknown>
    19c8: 50 cf        	rjmp	.-352
    19ca: 0f d0        	rcall	.+30
    19cc: 08 d0        	rcall	.+16
    19ce: 52 97 10 e0  	<unknown>
    19d2: 0c e0        	ldi	r16, 0xc
    19d4: d9 d1        	rcall	.+946
    19d6: 8d 01 0e 94  	<unknown>
    19da: 7f 11        	cpse	r23, r15
    19dc: 46 cf        	rjmp	.-372
    19de: 04 e8        	ldi	r16, 0x84
    19e0: 11 e0        	ldi	r17, 0x1
    19e2: 51 96 0d 93  	<unknown>
    19e6: 1c 93        	st	X, r17
    19e8: 08 95        	ret
    19ea: bd df        	rcall	.-134
    19ec: d8 01 08 95  	<unknown>
    19f0: ba df        	rcall	.-140
    19f2: 64 97 d8 01  	<unknown>
    19f6: 7a 93        	st	-Y, r23
    19f8: 6a 93        	st	-Y, r22
    19fa: 5a 93        	st	-Y, r21
    19fc: 4a 93        	st	-Y, r20
    19fe: 27 ea        	ldi	r18, 0xa7
    1a00: 31 e0        	ldi	r19, 0x1
    1a02: 8e 01 0c 5f  	<unknown>
    1a06: 1f 4f        	sbci	r17, 0xff
    1a08: 0e 94 b5 35  	<unknown>
    1a0c: 24 96 09 81  	<unknown>
    1a10: 00 53        	subi	r16, 0x30
    1a12: 14 96 0d 93  	<unknown>
    1a16: 0b 81        	ldd	r16, Y+3
    1a18: 00 53        	subi	r16, 0x30
    1a1a: 0d 93        	st	X+, r16
    1a1c: 0c 81        	ldd	r16, Y+4
    1a1e: 00 53        	subi	r16, 0x30
    1a20: 0d 93        	st	X+, r16
    1a22: 0f 81        	ldd	r16, Y+7
    1a24: 00 53        	subi	r16, 0x30
    1a26: 0d 93        	st	X+, r16
    1a28: 08 85        	ldd	r16, Y+0
    1a2a: 00 53        	subi	r16, 0x30
    1a2c: 0c 93        	st	X, r16
    1a2e: 15 97 00 e0  	<unknown>
    1a32: 0c 93        	st	X, r16
    1a34: 0e 93        	st	-X, r16
    1a36: 12 97 08 81  	<unknown>
    1a3a: 0d 32        	cpi	r16, 0x2d
    1a3c: 21 f4        	brne	.+8
    1a3e: 01 e0        	ldi	r16, 0x1
    1a40: 12 96 0c 93  	<unknown>
    1a44: 12 97 0e 81  	<unknown>
    1a48: 0d 32        	cpi	r16, 0x2d
    1a4a: 21 f4        	brne	.+8
    1a4c: 01 e0        	ldi	r16, 0x1
    1a4e: 13 96 0c 93  	<unknown>
    1a52: 13 97 02 d0  	<unknown>
    1a56: 64 96 08 cf  	<unknown>
    1a5a: 8d 01 51 96  	<unknown>
    1a5e: 96 cf        	rjmp	.-212
    1a60: 0e 94 ef 34  	<unknown>
    1a64: d8 01 f8 01  	<unknown>
    1a68: 44 81        	ldd	r20, Z+4
    1a6a: 50 e0        	ldi	r21, 0x0
    1a6c: 04 e6        	ldi	r16, 0x64
    1a6e: 40 d0        	rcall	.+128
    1a70: b8 01 45 81  	<unknown>
    1a74: 0a e0        	ldi	r16, 0xa
    1a76: 3c d0        	rcall	.+120
    1a78: 60 0f        	add	r22, r16
    1a7a: 71 1f        	adc	r23, r17
    1a7c: 06 81        	ldd	r16, Z+6
    1a7e: 10 e0        	ldi	r17, 0x0
    1a80: 06 0f        	add	r16, r22
    1a82: 17 1f        	adc	r17, r23
    1a84: 21 2f        	mov	r18, r17
    1a86: 22 0f        	lsl	r18
    1a88: 22 0b        	sbc	r18, r18
    1a8a: 32 2f        	mov	r19, r18
    1a8c: 0e 94 a8 32  	<unknown>
    1a90: 40 e0        	ldi	r20, 0x0
    1a92: 68 ec        	ldi	r22, 0xc8
    1a94: 72 e4        	ldi	r23, 0x42
    1a96: 0e 94 e1 33  	<unknown>
    1a9a: fd 01 42 81  	<unknown>
    1a9e: 44 23        	tst	r20
    1aa0: 31 f0        	breq	.+12
    1aa2: 40 e0        	ldi	r20, 0x0
    1aa4: 50 e0        	ldi	r21, 0x0
    1aa6: 60 e8        	ldi	r22, 0x80
    1aa8: 7f eb        	ldi	r23, 0xbf
    1aaa: 0e 94 68 33  	<unknown>
    1aae: fd 01 57 81  	<unknown>
    1ab2: 4a e0        	ldi	r20, 0xa
    1ab4: 54 9f 40 85  	<unknown>
    1ab8: 80 2d        	mov	r24, r0
    1aba: 84 0f        	add	r24, r20
    1abc: 43 81        	ldd	r20, Z+3
    1abe: 44 23        	tst	r20
    1ac0: 59 f0        	breq	.+22
    1ac2: 48 2f        	mov	r20, r24
    1ac4: 8a 95        	dec	r24
    1ac6: 44 23        	tst	r20
    1ac8: 59 f0        	breq	.+22
    1aca: 0d d0        	rcall	.+26
    1acc: 0e 94 e1 33  	<unknown>
    1ad0: f8 cf        	rjmp	.-16
    1ad2: 09 d0        	rcall	.+18
    1ad4: 0e 94 68 33  	<unknown>
    1ad8: 48 2f        	mov	r20, r24
    1ada: 8a 95        	dec	r24
    1adc: 44 23        	tst	r20
    1ade: c9 f7        	brne	.-14
    1ae0: e4 e0        	ldi	r30, 0x4
    1ae2: 0c 94 00 35  	<unknown>
    1ae6: 40 e0        	ldi	r20, 0x0
    1ae8: 50 e0        	ldi	r21, 0x0
    1aea: 60 e2        	ldi	r22, 0x20
    1aec: 71 e4        	ldi	r23, 0x41
    1aee: 08 95        	ret
    1af0: 10 e0        	ldi	r17, 0x0
    1af2: 0c 94 cd 31  	<unknown>
    1af6: f8 01 27 87  	<unknown>
    1afa: 30 8b        	std	Z+0, r19
    1afc: 08 95        	ret
    1afe: 75 df        	rcall	.-278
    1b00: 1b 96 3c d0  	<unknown>
    1b04: 0c 91        	ld	r16, X
    1b06: 16 96 29 d0  	<unknown>
    1b0a: 46 d0        	rcall	.+140
    1b0c: 0c 91        	ld	r16, X
    1b0e: 10 e0        	ldi	r17, 0x0
    1b10: 39 d0        	rcall	.+114
    1b12: 38 d0        	rcall	.+112
    1b14: 16 96 1f d0  	<unknown>
    1b18: 09 e9        	ldi	r16, 0x99
    1b1a: 11 e0        	ldi	r17, 0x1
    1b1c: 2d d0        	rcall	.+90
    1b1e: 2a 96 11 e0  	<unknown>
    1b22: 0c 91        	ld	r16, X
    1b24: 17 97 0a 5f  	<unknown>
    1b28: 35 d0        	rcall	.+106
    1b2a: 0c 91        	ld	r16, X
    1b2c: 1c 96 16 d0  	<unknown>
    1b30: 33 d0        	rcall	.+102
    1b32: 1a d0        	rcall	.+52
    1b34: 50 97 01 2b  	<unknown>
    1b38: 10 e0        	ldi	r17, 0x0
    1b3a: 11 f4        	brne	.+4
    1b3c: 18 d0        	rcall	.+48
    1b3e: 04 c0        	rjmp	.+8
    1b40: 28 d0        	rcall	.+80
    1b42: 1f 96 11 d0  	<unknown>
    1b46: 50 97 17 d0  	<unknown>
    1b4a: 11 e0        	ldi	r17, 0x1
    1b4c: 1a 96 0c 91  	<unknown>
    1b50: 2e 91        	ld	r18, -X
    1b52: 02 0f        	add	r16, r18
    1b54: 1c c0        	rjmp	.+56
    1b56: 1a 93        	st	-Y, r17
    1b58: 0a 93        	st	-Y, r16
    1b5a: 08 95        	ret
    1b5c: 00 23        	tst	r16
    1b5e: 11 f0        	breq	.+4
    1b60: 0d e2        	ldi	r16, 0x2d
    1b62: 08 95        	ret
    1b64: 0b e2        	ldi	r16, 0x2b
    1b66: 08 95        	ret
    1b68: 0d 91        	ld	r16, X+
    1b6a: 1c 91        	ld	r17, X
    1b6c: 08 95        	ret
    1b6e: 01 e0        	ldi	r16, 0x1
    1b70: 11 d0        	rcall	.+34
    1b72: 0a e8        	ldi	r16, 0x8a
    1b74: 11 e0        	ldi	r17, 0x1
    1b76: 08 95        	ret
    1b78: 0c 94 70 35  	<unknown>
    1b7c: 1c 91        	ld	r17, X
    1b7e: 0e 91        	ld	r16, -X
    1b80: 18 97 08 c0  	<unknown>
    1b84: e8 df        	rcall	.-48
    1b86: 0e 91        	ld	r16, -X
    1b88: e6 df        	rcall	.-52
    1b8a: 0e 91        	ld	r16, -X
    1b8c: 08 95        	ret
    1b8e: 02 d0        	rcall	.+4
    1b90: 6c ce        	rjmp	.-808
    1b92: 00 e0        	ldi	r16, 0x0
    1b94: 0c 94 29 0f  	<unknown>
    1b98: 10 e0        	ldi	r17, 0x0
    1b9a: 0c 94 b4 20  	<unknown>
    1b9e: 0e 94 ee 34  	<unknown>
    1ba2: d8 01 42 2e  	<unknown>
    1ba6: 92 2f        	mov	r25, r18
    1ba8: 9f 70        	andi	r25, 0xf
    1baa: f8 01 06 85  	<unknown>
    1bae: 00 23        	tst	r16
    1bb0: 09 f0        	breq	.+2
    1bb2: 90 c0        	rjmp	.+288
    1bb4: 93 30        	cpi	r25, 0x3
    1bb6: 61 f4        	brne	.+24
    1bb8: e1 85        	ldd	r30, Z+1
    1bba: f0 e0        	ldi	r31, 0x0
    1bbc: e3 55        	subi	r30, 0x53
    1bbe: fe 4f        	sbci	r31, 0xfe
    1bc0: 04 91 ea 2f  	<unknown>
    1bc4: f1 2f        	mov	r31, r17
    1bc6: 01 87        	std	Z+1, r16
    1bc8: 0a 2f        	mov	r16, r26
    1bca: 48 df        	rcall	.-368
    1bcc: db d0        	rcall	.+438
    1bce: c4 c0        	rjmp	.+392
    1bd0: 92 30        	cpi	r25, 0x2
    1bd2: 29 f4        	brne	.+10
    1bd4: e1 85        	ldd	r30, Z+1
    1bd6: f0 e0        	ldi	r31, 0x0
    1bd8: ea 54        	subi	r30, 0x4a
    1bda: fe 4f        	sbci	r31, 0xfe
    1bdc: f1 cf        	rjmp	.-30
    1bde: 94 30        	cpi	r25, 0x4
    1be0: 19 f0        	breq	.+6
    1be2: 91 30        	cpi	r25, 0x1
    1be4: 09 f0        	breq	.+2
    1be6: 6f c0        	rjmp	.+222
    1be8: 01 85        	ldd	r16, Z+1
    1bea: 00 23        	tst	r16
    1bec: 69 f0        	breq	.+26
    1bee: 0a 95        	dec	r16
    1bf0: 89 f0        	breq	.+34
    1bf2: 02 50        	subi	r16, 0x2
    1bf4: 89 f0        	breq	.+34
    1bf6: 0a 95        	dec	r16
    1bf8: 89 f0        	breq	.+34
    1bfa: 02 50        	subi	r16, 0x2
    1bfc: 89 f0        	breq	.+34
    1bfe: 0a 95        	dec	r16
    1c00: a1 f0        	breq	.+40
    1c02: 0a 95        	dec	r16
    1c04: a1 f0        	breq	.+40
    1c06: 14 c0        	rjmp	.+40
    1c08: 02 81        	ldd	r16, Z+2
    1c0a: 03 95        	inc	r16
    1c0c: 01 70        	andi	r16, 0x1
    1c0e: 02 83        	std	Z+2, r16
    1c10: b6 d0        	rcall	.+364
    1c12: 0e c0        	rjmp	.+28
    1c14: 84 81        	ldd	r24, Z+4
    1c16: 0c c0        	rjmp	.+24
    1c18: 85 81        	ldd	r24, Z+5
    1c1a: 0a c0        	rjmp	.+20
    1c1c: 86 81        	ldd	r24, Z+6
    1c1e: 08 c0        	rjmp	.+16
    1c20: 03 81        	ldd	r16, Z+3
    1c22: 03 95        	inc	r16
    1c24: 01 70        	andi	r16, 0x1
    1c26: 03 83        	std	Z+3, r16
    1c28: f3 cf        	rjmp	.-26
    1c2a: 87 81        	ldd	r24, Z+7
    1c2c: 01 c0        	rjmp	.+2
    1c2e: 80 85        	ldd	r24, Z+0
    1c30: 8d 01 fd 01  	<unknown>
    1c34: 21 89        	ldd	r18, Z+1
    1c36: f2 89        	ldd	r31, Z+2
    1c38: e2 2f        	mov	r30, r18
    1c3a: aa de        	rcall	.-684
    1c3c: fd 01 01 85  	<unknown>
    1c40: 00 23        	tst	r16
    1c42: 09 f4        	brne	.+2
    1c44: 40 c0        	rjmp	.+128
    1c46: 06 30        	cpi	r16, 0x6
    1c48: f1 f1        	breq	.+124
    1c4a: fb dc        	rcall	.-1546
    1c4c: fd 01 04 87  	<unknown>
    1c50: 15 87        	std	Z+5, r17
    1c52: 01 85        	ldd	r16, Z+1
    1c54: 01 30        	cpi	r16, 0x1
    1c56: 21 f4        	brne	.+8
    1c58: 39 e0        	ldi	r19, 0x9
    1c5a: 21 e0        	ldi	r18, 0x1
    1c5c: 04 85        	ldd	r16, Z+4
    1c5e: 19 de        	rcall	.-974
    1c60: fd 01 01 85  	<unknown>
    1c64: 07 30        	cpi	r16, 0x7
    1c66: 11 f4        	brne	.+4
    1c68: 33 e0        	ldi	r19, 0x3
    1c6a: 7f d0        	rcall	.+254
    1c6c: fd 01 07 81  	<unknown>
    1c70: 03 30        	cpi	r16, 0x3
    1c72: 29 f4        	brne	.+10
    1c74: 01 85        	ldd	r16, Z+1
    1c76: 08 30        	cpi	r16, 0x8
    1c78: 31 f4        	brne	.+12
    1c7a: 38 e0        	ldi	r19, 0x8
    1c7c: 76 d0        	rcall	.+236
    1c7e: fd 01 07 81  	<unknown>
    1c82: 03 30        	cpi	r16, 0x3
    1c84: 79 f4        	brne	.+30
    1c86: 00 85        	ldd	r16, Z+0
    1c88: 08 30        	cpi	r16, 0x8
    1c8a: 61 f4        	brne	.+24
    1c8c: 01 85        	ldd	r16, Z+1
    1c8e: 01 30        	cpi	r16, 0x1
    1c90: 19 f4        	brne	.+6
    1c92: 33 e0        	ldi	r19, 0x3
    1c94: 21 e0        	ldi	r18, 0x1
    1c96: 6a d0        	rcall	.+212
    1c98: fd 01 01 85  	<unknown>
    1c9c: 03 30        	cpi	r16, 0x3
    1c9e: 11 f4        	brne	.+4
    1ca0: 34 e0        	ldi	r19, 0x4
    1ca2: 63 d0        	rcall	.+198
    1ca4: fd 01 33 85  	<unknown>
    1ca8: 22 85        	ldd	r18, Z+2
    1caa: 01 85        	ldd	r16, Z+1
    1cac: 20 0f        	add	r18, r16
    1cae: 5a d0        	rcall	.+180
    1cb0: 0d de        	rcall	.-998
    1cb2: 28 2f        	mov	r18, r24
    1cb4: fd 01 56 d0  	<unknown>
    1cb8: f7 dd        	rcall	.-1042
    1cba: 24 2d        	mov	r18, r4
    1cbc: fd 01 50 d0  	<unknown>
    1cc0: 01 e0        	ldi	r16, 0x1
    1cc2: fd 01 06 87  	<unknown>
    1cc6: 99 23        	tst	r25
    1cc8: 19 f0        	breq	.+6
    1cca: 95 30        	cpi	r25, 0x5
    1ccc: 09 f0        	breq	.+2
    1cce: 44 c0        	rjmp	.+136
    1cd0: 01 e0        	ldi	r16, 0x1
    1cd2: 43 c0        	rjmp	.+134
    1cd4: 45 d0        	rcall	.+138
    1cd6: 01 30        	cpi	r16, 0x1
    1cd8: f9 f5        	brne	.+126
    1cda: 00 e0        	ldi	r16, 0x0
    1cdc: fd 01 06 87  	<unknown>
    1ce0: 01 85        	ldd	r16, Z+1
    1ce2: 0a 95        	dec	r16
    1ce4: 49 f0        	breq	.+18
    1ce6: 02 50        	subi	r16, 0x2
    1ce8: 51 f0        	breq	.+20
    1cea: 0a 95        	dec	r16
    1cec: 59 f0        	breq	.+22
    1cee: 03 50        	subi	r16, 0x3
    1cf0: 61 f0        	breq	.+24
    1cf2: 0a 95        	dec	r16
    1cf4: 69 f0        	breq	.+26
    1cf6: 0e c0        	rjmp	.+28
    1cf8: 3b d0        	rcall	.+118
    1cfa: 04 83        	std	Z+4, r16
    1cfc: 0b c0        	rjmp	.+22
    1cfe: 38 d0        	rcall	.+112
    1d00: 05 83        	std	Z+5, r16
    1d02: 08 c0        	rjmp	.+16
    1d04: 35 d0        	rcall	.+106
    1d06: 06 83        	std	Z+6, r16
    1d08: 05 c0        	rjmp	.+10
    1d0a: 32 d0        	rcall	.+100
    1d0c: 07 83        	std	Z+7, r16
    1d0e: 02 c0        	rjmp	.+4
    1d10: 2f d0        	rcall	.+94
    1d12: 00 87        	std	Z+0, r16
    1d14: fb 2f        	mov	r31, r27
    1d16: 07 81        	ldd	r16, Z+7
    1d18: 03 30        	cpi	r16, 0x3
    1d1a: d1 f4        	brne	.+52
    1d1c: 00 85        	ldd	r16, Z+0
    1d1e: 09 30        	cpi	r16, 0x9
    1d20: 18 f0        	brlo	.+6
    1d22: 08 e0        	ldi	r16, 0x8
    1d24: 00 87        	std	Z+0, r16
    1d26: 02 c0        	rjmp	.+4
    1d28: 08 30        	cpi	r16, 0x8
    1d2a: 91 f4        	brne	.+36
    1d2c: 04 81        	ldd	r16, Z+4
    1d2e: 03 30        	cpi	r16, 0x3
    1d30: 21 f4        	brne	.+8
    1d32: 05 81        	ldd	r16, Z+5
    1d34: 04 30        	cpi	r16, 0x4
    1d36: 21 f4        	brne	.+8
    1d38: 09 c0        	rjmp	.+18
    1d3a: 04 30        	cpi	r16, 0x4
    1d3c: 18 f4        	brsh	.+6
    1d3e: 08 c0        	rjmp	.+16
    1d40: 05 30        	cpi	r16, 0x5
    1d42: 30 f0        	brlo	.+12
    1d44: 03 e0        	ldi	r16, 0x3
    1d46: 04 83        	std	Z+4, r16
    1d48: 04 e0        	ldi	r16, 0x4
    1d4a: 05 83        	std	Z+5, r16
    1d4c: 00 e0        	ldi	r16, 0x0
    1d4e: 06 83        	std	Z+6, r16
    1d50: 09 d0        	rcall	.+18
    1d52: 82 dc        	rcall	.-1788
    1d54: 17 d0        	rcall	.+46
    1d56: 81 de        	rcall	.-766
    1d58: 00 e0        	ldi	r16, 0x0
    1d5a: e5 e0        	ldi	r30, 0x5
    1d5c: 0c 94 ff 34  	<unknown>
    1d60: 01 d0        	rcall	.+2
    1d62: c5 cd        	rjmp	.-1142
    1d64: 04 85        	ldd	r16, Z+4
    1d66: 15 85        	ldd	r17, Z+5
    1d68: 08 95        	ret
    1d6a: 20 e0        	ldi	r18, 0x0
    1d6c: fb df        	rcall	.-10
    1d6e: 91 cd        	rjmp	.-1246
    1d70: 1c 96 ed 91  	<unknown>
    1d74: fc 91        	ld	r31, X
    1d76: 1d 97 02 85  	<unknown>
    1d7a: fd 01 08 95  	<unknown>
    1d7e: 10 e0        	ldi	r17, 0x0
    1d80: 0f e0        	ldi	r16, 0xf
    1d82: 02 c0        	rjmp	.+4
    1d84: 10 e0        	ldi	r17, 0x0
    1d86: 0e e0        	ldi	r16, 0xe
    1d88: 0c 94 70 0f  	<unknown>
    1d8c: c1 98        	cbi	0x18, 0x1
    1d8e: c2 98        	cbi	0x18, 0x2
    1d90: 0f ef        	ldi	r16, 0xff
    1d92: 07 bb        	out	0x17, r16
    1d94: 08 b3        	in	r16, 0x18
    1d96: 0f 70        	andi	r16, 0xf
    1d98: 08 bb        	out	0x18, r16
    1d9a: 05 ea        	ldi	r16, 0xa5
    1d9c: 1e e0        	ldi	r17, 0xe
    1d9e: 01 50        	subi	r16, 0x1
    1da0: 10 40        	sbci	r17, 0x0
    1da2: e9 f7        	brne	.-6
    1da4: 00 c0        	rjmp	.+0
    1da6: 00 00        	nop
    1da8: 08 b3        	in	r16, 0x18
    1daa: 00 63        	ori	r16, 0x30
    1dac: 08 bb        	out	0x18, r16
    1dae: 1e d0        	rcall	.+60
    1db0: 01 ee        	ldi	r16, 0xe1
    1db2: 14 e0        	ldi	r17, 0x4
    1db4: 01 50        	subi	r16, 0x1
    1db6: 10 40        	sbci	r17, 0x0
    1db8: e9 f7        	brne	.-6
    1dba: 00 c0        	rjmp	.+0
    1dbc: 00 00        	nop
    1dbe: 10 d0        	rcall	.+32
    1dc0: 0f d0        	rcall	.+30
    1dc2: 08 b3        	in	r16, 0x18
    1dc4: 0f 70        	andi	r16, 0xf
    1dc6: 08 bb        	out	0x18, r16
    1dc8: c5 9a        	sbi	0x18, 0x5
    1dca: 0a d0        	rcall	.+20
    1dcc: 10 e0        	ldi	r17, 0x0
    1dce: 0a e2        	ldi	r16, 0x2a
    1dd0: 4a d0        	rcall	.+148
    1dd2: 10 e0        	ldi	r17, 0x0
    1dd4: 0c e0        	ldi	r16, 0xc
    1dd6: 47 d0        	rcall	.+142
    1dd8: 10 e0        	ldi	r17, 0x0
    1dda: 06 e0        	ldi	r16, 0x6
    1ddc: 44 d0        	rcall	.+136
    1dde: 53 c0        	rjmp	.+166
    1de0: 05 d0        	rcall	.+10
    1de2: 02 e4        	ldi	r16, 0x42
    1de4: 0a 95        	dec	r16
    1de6: f1 f7        	brne	.-4
    1de8: 00 c0        	rjmp	.+0
    1dea: 08 95        	ret
    1dec: c0 9a        	sbi	0x18, 0x0
    1dee: 03 e0        	ldi	r16, 0x3
    1df0: 0a 95        	dec	r16
    1df2: f1 f7        	brne	.-4
    1df4: 00 00        	nop
    1df6: c0 98        	cbi	0x18, 0x0
    1df8: 08 95        	ret
    1dfa: 17 b3        	in	r17, 0x17
    1dfc: 1f ef        	ldi	r17, 0xff
    1dfe: 17 bb        	out	0x17, r17
    1e00: c1 98        	cbi	0x18, 0x1
    1e02: 18 b3        	in	r17, 0x18
    1e04: 1f 70        	andi	r17, 0xf
    1e06: 18 bb        	out	0x18, r17
    1e08: 10 2f        	mov	r17, r16
    1e0a: 10 7f        	andi	r17, 0xf0
    1e0c: 28 b3        	in	r18, 0x18
    1e0e: 21 2b        	or	r18, r17
    1e10: 28 bb        	out	0x18, r18
    1e12: c0 9a        	sbi	0x18, 0x0
    1e14: c0 98        	cbi	0x18, 0x0
    1e16: 18 b3        	in	r17, 0x18
    1e18: 1f 70        	andi	r17, 0xf
    1e1a: 18 bb        	out	0x18, r17
    1e1c: 02 95        	swap	r16
    1e1e: 00 7f        	andi	r16, 0xf0
    1e20: 18 b3        	in	r17, 0x18
    1e22: 10 2b        	or	r17, r16
    1e24: 18 bb        	out	0x18, r17
    1e26: c0 9a        	sbi	0x18, 0x0
    1e28: e6 cf        	rjmp	.-52
    1e2a: 07 b3        	in	r16, 0x17
    1e2c: 0f 70        	andi	r16, 0xf
    1e2e: 07 bb        	out	0x17, r16
    1e30: 08 b3        	in	r16, 0x18
    1e32: 00 6f        	ori	r16, 0xf0
    1e34: 08 bb        	out	0x18, r16
    1e36: c1 9a        	sbi	0x18, 0x1
    1e38: c0 9a        	sbi	0x18, 0x0
    1e3a: 00 00        	nop
    1e3c: 06 b3        	in	r16, 0x16
    1e3e: c0 98        	cbi	0x18, 0x0
    1e40: c0 9a        	sbi	0x18, 0x0
    1e42: 00 00        	nop
    1e44: 16 b3        	in	r17, 0x16
    1e46: 10 7f        	andi	r17, 0xf0
    1e48: 12 95        	swap	r17
    1e4a: c0 98        	cbi	0x18, 0x0
    1e4c: 00 7f        	andi	r16, 0xf0
    1e4e: 01 2b        	or	r16, r17
    1e50: 08 95        	ret
    1e52: 11 23        	tst	r17
    1e54: 19 f0        	breq	.+6
    1e56: 1a 95        	dec	r17
    1e58: 21 f0        	breq	.+8
    1e5a: 08 95        	ret
    1e5c: 10 e0        	ldi	r17, 0x0
    1e5e: 00 58        	subi	r16, 0x80
    1e60: 02 c0        	rjmp	.+4
    1e62: 10 e0        	ldi	r17, 0x0
    1e64: 00 54        	subi	r16, 0x40
    1e66: 3c c0        	rjmp	.+120
    1e68: 9a 93        	st	-Y, r25
    1e6a: 8a 93        	st	-Y, r24
    1e6c: c8 01 12 2f  	<unknown>
    1e70: f0 df        	rcall	.-32
    1e72: 04 c0        	rjmp	.+8
    1e74: 11 e0        	ldi	r17, 0x1
    1e76: 00 e2        	ldi	r16, 0x20
    1e78: f6 df        	rcall	.-20
    1e7a: 83 95        	inc	r24
    1e7c: 98 17        	cp	r25, r24
    1e7e: d0 f7        	brsh	.-12
    1e80: 89 91        	ld	r24, Y+
    1e82: 99 91        	ld	r25, Y+
    1e84: 08 95        	ret
    1e86: 10 e0        	ldi	r17, 0x0
    1e88: 01 e0        	ldi	r16, 0x1
    1e8a: ed df        	rcall	.-38
    1e8c: 0d ee        	ldi	r16, 0xed
    1e8e: 12 e0        	ldi	r17, 0x2
    1e90: 01 50        	subi	r16, 0x1
    1e92: 10 40        	sbci	r17, 0x0
    1e94: e9 f7        	brne	.-6
    1e96: 00 c0        	rjmp	.+0
    1e98: 00 00        	nop
    1e9a: 08 95        	ret
    1e9c: 11 e0        	ldi	r17, 0x1
    1e9e: 65 d0        	rcall	.+202
    1ea0: 04 91 e1 cf  	<unknown>
    1ea4: 05 d0        	rcall	.+10
    1ea6: fa df        	rcall	.-12
    1ea8: a3 95        	inc	r26
    1eaa: a0 34        	cpi	r26, 0x40
    1eac: e0 f3        	brlo	.-8
    1eae: 4a c0        	rjmp	.+148
    1eb0: 0e 94 ef 34  	<unknown>
    1eb4: c8 01 10 e0  	<unknown>
    1eb8: 00 e4        	ldi	r16, 0x40
    1eba: 12 d0        	rcall	.+36
    1ebc: a0 e0        	ldi	r26, 0x0
    1ebe: 08 95        	ret
    1ec0: 44 d0        	rcall	.+136
    1ec2: c8 01 10 e0  	<unknown>
    1ec6: 22 0f        	lsl	r18
    1ec8: 22 0f        	lsl	r18
    1eca: 22 0f        	lsl	r18
    1ecc: 2f 77        	andi	r18, 0x7f
    1ece: 20 64        	ori	r18, 0x40
    1ed0: 02 2f        	mov	r16, r18
    1ed2: c9 df        	rcall	.-110
    1ed4: a0 e0        	ldi	r26, 0x0
    1ed6: e2 df        	rcall	.-60
    1ed8: a3 95        	inc	r26
    1eda: a8 30        	cpi	r26, 0x8
    1edc: e0 f3        	brlo	.-8
    1ede: 32 c0        	rjmp	.+100
    1ee0: 12 d0        	rcall	.+36
    1ee2: 49 f0        	breq	.+18
    1ee4: 08 3a        	cpi	r16, 0xa8
    1ee6: 28 f0        	brlo	.+10
    1ee8: f0 e0        	ldi	r31, 0x0
    1eea: e0 2f        	mov	r30, r16
    1eec: e9 5e        	subi	r30, 0xe9
    1eee: fe 4f        	sbci	r31, 0xfe
    1ef0: 04 91 c2 9a  	<unknown>
    1ef4: 01 c0        	rjmp	.+2
    1ef6: c2 98        	cbi	0x18, 0x2
    1ef8: 0b c0        	rjmp	.+22
    1efa: 05 d0        	rcall	.+10
    1efc: 11 f0        	breq	.+4
    1efe: c2 9a        	sbi	0x18, 0x2
    1f00: 01 c0        	rjmp	.+2
    1f02: c2 98        	cbi	0x18, 0x2
    1f04: 05 c0        	rjmp	.+10
    1f06: 21 e0        	ldi	r18, 0x1
    1f08: 20 93 8e 06  	<unknown>
    1f0c: 11 23        	tst	r17
    1f0e: 08 95        	ret
    1f10: 74 df        	rcall	.-280
    1f12: c2 98        	cbi	0x18, 0x2
    1f14: 03 d0        	rcall	.+6
    1f16: 07 fb        	bst	r16, 0x7
    1f18: ee f3        	brts	.-6
    1f1a: 08 95        	ret
    1f1c: 86 cf        	rjmp	.-244
    1f1e: c2 9a        	sbi	0x18, 0x2
    1f20: fd df        	rcall	.-6
    1f22: c2 98        	cbi	0x18, 0x2
    1f24: 08 95        	ret
    1f26: 11 d0        	rcall	.+34
    1f28: 00 e6        	ldi	r16, 0x60
    1f2a: 10 e0        	ldi	r17, 0x0
    1f2c: 0e 94 3c 35  	<unknown>
    1f30: c1 df        	rcall	.-126
    1f32: 01 c0        	rjmp	.+2
    1f34: 1f d0        	rcall	.+62
    1f36: f3 df        	rcall	.-26
    1f38: 18 d0        	rcall	.+48
    1f3a: 00 83        	std	Z+0, r16
    1f3c: a3 95        	inc	r26
    1f3e: a0 36        	cpi	r26, 0x60
    1f40: c8 f3        	brlo	.-14
    1f42: 8c 01 e4 e0  	<unknown>
    1f46: 0c 94 00 35  	<unknown>
    1f4a: 0c 94 ef 34  	<unknown>
    1f4e: b0 df        	rcall	.-160
    1f50: 01 c0        	rjmp	.+2
    1f52: 10 d0        	rcall	.+32
    1f54: c2 9a        	sbi	0x18, 0x2
    1f56: 09 d0        	rcall	.+18
    1f58: 00 81        	ldd	r16, Z+0
    1f5a: da df        	rcall	.-76
    1f5c: a3 95        	inc	r26
    1f5e: a0 36        	cpi	r26, 0x60
    1f60: c0 f3        	brlo	.-16
    1f62: 8c 01 0e 94  	<unknown>
    1f66: 74 31        	cpi	r23, 0x14
    1f68: ed cf        	rjmp	.-38
    1f6a: b0 e0        	ldi	r27, 0x0
    1f6c: fc 01 ea 0f  	<unknown>
    1f70: fb 1f        	adc	r31, r27
    1f72: 08 95        	ret
    1f74: a0 34        	cpi	r26, 0x40
    1f76: 11 f4        	brne	.+4
    1f78: 10 e0        	ldi	r17, 0x0
    1f7a: 03 c0        	rjmp	.+6
    1f7c: a0 35        	cpi	r26, 0x50
    1f7e: 19 f4        	brne	.+6
    1f80: 11 e0        	ldi	r17, 0x1
    1f82: 00 e0        	ldi	r16, 0x0
    1f84: 66 df        	rcall	.-308
    1f86: 08 95        	ret
    1f88: fa 93        	st	-Y, r31
    1f8a: ea 93        	st	-Y, r30
    1f8c: 0a 92        	st	-Y, r0
    1f8e: 7a 93        	st	-Y, r23
    1f90: 6a 93        	st	-Y, r22
    1f92: 5a 93        	st	-Y, r21
    1f94: 4a 93        	st	-Y, r20
    1f96: 3a 93        	st	-Y, r19
    1f98: 2a 93        	st	-Y, r18
    1f9a: 1a 93        	st	-Y, r17
    1f9c: 0a 93        	st	-Y, r16
    1f9e: 0f b6        	in	r0, 0x3f
    1fa0: db d0        	rcall	.+438
    1fa2: 0f 5f        	subi	r16, 0xff
    1fa4: 1f 4f        	sbci	r17, 0xff
    1fa6: 2f 4f        	sbci	r18, 0xff
    1fa8: 3f 4f        	sbci	r19, 0xff
    1faa: 00 87        	std	Z+0, r16
    1fac: 11 87        	std	Z+1, r17
    1fae: 22 87        	std	Z+2, r18
    1fb0: 33 87        	std	Z+3, r19
    1fb2: 44 85        	ldd	r20, Z+4
    1fb4: 55 85        	ldd	r21, Z+5
    1fb6: 66 85        	ldd	r22, Z+6
    1fb8: 77 85        	ldd	r23, Z+7
    1fba: 04 17        	cp	r16, r20
    1fbc: 15 07        	cpc	r17, r21
    1fbe: 26 07        	cpc	r18, r22
    1fc0: 37 07        	cpc	r19, r23
    1fc2: 40 f4        	brsh	.+16
    1fc4: 4c ee        	ldi	r20, 0xec
    1fc6: 52 e0        	ldi	r21, 0x2
    1fc8: 0e 94 86 31  	<unknown>
    1fcc: 00 23        	tst	r16
    1fce: 11 f0        	breq	.+4
    1fd0: 8d 9a        	sbi	0x11, 0x5
    1fd2: 01 c0        	rjmp	.+2
    1fd4: 8d 98        	cbi	0x11, 0x5
    1fd6: 0f be        	out	0x3f, r0
    1fd8: 09 91        	ld	r16, Y+
    1fda: 19 91        	ld	r17, Y+
    1fdc: 29 91        	ld	r18, Y+
    1fde: 39 91        	ld	r19, Y+
    1fe0: 49 91        	ld	r20, Y+
    1fe2: 59 91        	ld	r21, Y+
    1fe4: 69 91        	ld	r22, Y+
    1fe6: 79 91        	ld	r23, Y+
    1fe8: 09 90        	ld	r0, Y+
    1fea: e9 91        	ld	r30, Y+
    1fec: f9 91        	ld	r31, Y+
    1fee: 18 95        	reti
    1ff0: ac df        	rcall	.-168
    1ff2: ef e8        	ldi	r30, 0x8f
    1ff4: f6 e0        	ldi	r31, 0x6
    1ff6: 80 85        	ldd	r24, Z+0
    1ff8: 91 85        	ldd	r25, Z+1
    1ffa: a2 85        	ldd	r26, Z+2
    1ffc: b3 85        	ldd	r27, Z+3
    1ffe: 40 2f        	mov	r20, r16
    2000: 50 e0        	ldi	r21, 0x0
    2002: 06 e0        	ldi	r16, 0x6
    2004: 10 e0        	ldi	r17, 0x0
    2006: 0e 94 cd 31  	<unknown>
    200a: 21 2f        	mov	r18, r17
    200c: 22 0f        	lsl	r18
    200e: 22 0b        	sbc	r18, r18
    2010: 80 0f        	add	r24, r16
    2012: 91 1f        	adc	r25, r17
    2014: a2 1f        	adc	r26, r18
    2016: b2 1f        	adc	r27, r18
    2018: 84 87        	std	Z+4, r24
    201a: 95 87        	std	Z+5, r25
    201c: a6 87        	std	Z+6, r26
    201e: b7 87        	std	Z+7, r27
    2020: 91 cf        	rjmp	.-222
    2022: ef e8        	ldi	r30, 0x8f
    2024: f6 e0        	ldi	r31, 0x6
    2026: 0d e3        	ldi	r16, 0x3d
    2028: 10 e0        	ldi	r17, 0x0
    202a: 00 83        	std	Z+0, r16
    202c: 11 83        	std	Z+1, r17
    202e: 12 83        	std	Z+2, r17
    2030: 13 83        	std	Z+3, r17
    2032: 06 e0        	ldi	r16, 0x6
    2034: 04 83        	std	Z+4, r16
    2036: 15 83        	std	Z+5, r17
    2038: 16 83        	std	Z+6, r17
    203a: 17 83        	std	Z+7, r17
    203c: 08 95        	ret
    203e: 9a 93        	st	-Y, r25
    2040: 8a 93        	st	-Y, r24
    2042: 48 d0        	rcall	.+144
    2044: c8 01 46 d0  	<unknown>
    2048: 80 1b        	sub	r24, r16
    204a: 91 0b        	sbc	r25, r17
    204c: 83 30        	cpi	r24, 0x3
    204e: 20 e0        	ldi	r18, 0x0
    2050: 92 07        	cpc	r25, r18
    2052: f4 f5        	brge	.+124
    2054: 8e 3f        	cpi	r24, 0xfe
    2056: 9f 4f        	sbci	r25, 0xff
    2058: dc f1        	brlt	.+118
    205a: 02 36        	cpi	r16, 0x62
    205c: 23 e0        	ldi	r18, 0x3
    205e: 12 07        	cpc	r17, r18
    2060: 28 f0        	brlo	.+10
    2062: 04 38        	cpi	r16, 0x84
    2064: 12 07        	cpc	r17, r18
    2066: 10 f4        	brsh	.+4
    2068: 00 e0        	ldi	r16, 0x0
    206a: 33 c0        	rjmp	.+102
    206c: 09 34        	cpi	r16, 0x49
    206e: 12 07        	cpc	r17, r18
    2070: 28 f0        	brlo	.+10
    2072: 01 36        	cpi	r16, 0x61
    2074: 12 07        	cpc	r17, r18
    2076: 10 f4        	brsh	.+4
    2078: 01 e0        	ldi	r16, 0x1
    207a: 2b c0        	rjmp	.+86
    207c: 01 32        	cpi	r16, 0x21
    207e: 12 07        	cpc	r17, r18
    2080: 28 f0        	brlo	.+10
    2082: 08 34        	cpi	r16, 0x48
    2084: 12 07        	cpc	r17, r18
    2086: 10 f4        	brsh	.+4
    2088: 02 e0        	ldi	r16, 0x2
    208a: 23 c0        	rjmp	.+70
    208c: 09 3f        	cpi	r16, 0xf9
    208e: 22 e0        	ldi	r18, 0x2
    2090: 12 07        	cpc	r17, r18
    2092: 30 f0        	brlo	.+12
    2094: 0c 30        	cpi	r16, 0xc
    2096: 23 e0        	ldi	r18, 0x3
    2098: 12 07        	cpc	r17, r18
    209a: 10 f4        	brsh	.+4
    209c: 03 e0        	ldi	r16, 0x3
    209e: 19 c0        	rjmp	.+50
    20a0: 0f 39        	cpi	r16, 0x9f
    20a2: 22 e0        	ldi	r18, 0x2
    20a4: 12 07        	cpc	r17, r18
    20a6: 28 f0        	brlo	.+10
    20a8: 02 3b        	cpi	r16, 0xb2
    20aa: 12 07        	cpc	r17, r18
    20ac: 10 f4        	brsh	.+4
    20ae: 04 e0        	ldi	r16, 0x4
    20b0: 10 c0        	rjmp	.+32
    20b2: 05 3f        	cpi	r16, 0xf5
    20b4: 21 e0        	ldi	r18, 0x1
    20b6: 12 07        	cpc	r17, r18
    20b8: 30 f0        	brlo	.+12
    20ba: 08 30        	cpi	r16, 0x8
    20bc: 22 e0        	ldi	r18, 0x2
    20be: 12 07        	cpc	r17, r18
    20c0: 10 f4        	brsh	.+4
    20c2: 05 e0        	ldi	r16, 0x5
    20c4: 06 c0        	rjmp	.+12
    20c6: 0e 31        	cpi	r16, 0x1e
    20c8: 10 40        	sbci	r17, 0x0
    20ca: 10 f4        	brsh	.+4
    20cc: 06 e0        	ldi	r16, 0x6
    20ce: 01 c0        	rjmp	.+2
    20d0: 0f ef        	ldi	r16, 0xff
    20d2: d6 ce        	rjmp	.-596
    20d4: 01 e0        	ldi	r16, 0x1
    20d6: 0c 94 d1 06  	<unknown>
    20da: 0e 94 e7 34  	<unknown>
    20de: af df        	rcall	.-162
    20e0: 80 2f        	mov	r24, r16
    20e2: 3a d0        	rcall	.+116
    20e4: a8 01 b9 01  	<unknown>
    20e8: 4e 5f        	subi	r20, 0xfe
    20ea: 5f 4f        	sbci	r21, 0xff
    20ec: 6f 4f        	sbci	r22, 0xff
    20ee: 7f 4f        	sbci	r23, 0xff
    20f0: 00 8c        	ldd	r0, Z+0
    20f2: 80 15        	cp	r24, r0
    20f4: 49 f0        	breq	.+18
    20f6: 80 8f        	std	Z+0, r24
    20f8: 23 d0        	rcall	.+70
    20fa: 04 8b        	std	Z+4, r16
    20fc: 15 8b        	std	Z+5, r17
    20fe: 26 8b        	std	Z+6, r18
    2100: 37 8b        	std	Z+7, r19
    2102: 23 d0        	rcall	.+70
    2104: 08 2f        	mov	r16, r24
    2106: 19 c0        	rjmp	.+50
    2108: 00 80        	ldd	r0, Z+0
    210a: 11 80        	ldd	r1, Z+1
    210c: 22 80        	ldd	r2, Z+2
    210e: 33 80        	ldd	r3, Z+3
    2110: 44 88        	ldd	r4, Z+4
    2112: 55 88        	ldd	r5, Z+5
    2114: 66 88        	ldd	r6, Z+6
    2116: 77 88        	ldd	r7, Z+7
    2118: 26 d0        	rcall	.+76
    211a: 70 f4        	brsh	.+28
    211c: 04 80        	ldd	r0, Z+4
    211e: 15 80        	ldd	r1, Z+5
    2120: 26 80        	ldd	r2, Z+6
    2122: 37 80        	ldd	r3, Z+7
    2124: 40 88        	ldd	r4, Z+0
    2126: 51 88        	ldd	r5, Z+1
    2128: 62 88        	ldd	r6, Z+2
    212a: 73 88        	ldd	r7, Z+3
    212c: 1c d0        	rcall	.+56
    212e: 20 f4        	brsh	.+8
    2130: 07 d0        	rcall	.+14
    2132: 0b d0        	rcall	.+22
    2134: 80 68        	ori	r24, 0x80
    2136: e6 cf        	rjmp	.-52
    2138: 0f ef        	ldi	r16, 0xff
    213a: ec e0        	ldi	r30, 0xc
    213c: 0c 94 f8 34  	<unknown>
    2140: 00 8b        	std	Z+0, r16
    2142: 11 8b        	std	Z+1, r17
    2144: 22 8b        	std	Z+2, r18
    2146: 33 8b        	std	Z+3, r19
    2148: 08 95        	ret
    214a: 8f 3f        	cpi	r24, 0xff
    214c: 21 f0        	breq	.+8
    214e: 44 87        	std	Z+4, r20
    2150: 55 87        	std	Z+5, r21
    2152: 66 87        	std	Z+6, r22
    2154: 77 87        	std	Z+7, r23
    2156: 08 95        	ret
    2158: ef e8        	ldi	r30, 0x8f
    215a: f6 e0        	ldi	r31, 0x6
    215c: 00 85        	ldd	r16, Z+0
    215e: 11 85        	ldd	r17, Z+1
    2160: 22 85        	ldd	r18, Z+2
    2162: 33 85        	ldd	r19, Z+3
    2164: 08 95        	ret
    2166: 48 01 59 01  	<unknown>
    216a: 84 18        	sub	r8, r4
    216c: 95 08        	sbc	r9, r5
    216e: a6 08        	sbc	r10, r6
    2170: b7 08        	sbc	r11, r7
    2172: 08 14        	cp	r0, r8
    2174: 19 04        	cpc	r1, r9
    2176: 2a 04        	cpc	r2, r10
    2178: 3b 04        	cpc	r3, r11
    217a: 08 95        	ret
    217c: 08 e0        	ldi	r16, 0x8
    217e: 10 e0        	ldi	r17, 0x0
    2180: 0e 94 3e 35  	<unknown>
    2184: 20 2f        	mov	r18, r16
    2186: 21 2b        	or	r18, r17
    2188: 09 f0        	breq	.+2
    218a: 11 c0        	rjmp	.+34
    218c: 00 e0        	ldi	r16, 0x0
    218e: 10 e0        	ldi	r17, 0x0
    2190: 08 95        	ret
    2192: 9a 93        	st	-Y, r25
    2194: 8a 93        	st	-Y, r24
    2196: c8 01 01 2b  	<unknown>
    219a: 31 f0        	breq	.+12
    219c: 08 2f        	mov	r16, r24
    219e: 0e 94 7f 11  	<unknown>
    21a2: 8c 01 0e 94  	<unknown>
    21a6: 76 31        	cpi	r23, 0x16
    21a8: 89 91        	ld	r24, Y+
    21aa: 99 91        	ld	r25, Y+
    21ac: 08 95        	ret
    21ae: ba 93        	st	-Y, r27
    21b0: aa 93        	st	-Y, r26
    21b2: d8 01 0e 94  	<unknown>
    21b6: 75 11        	cpse	r23, r5
    21b8: 0e 94 43 0f  	<unknown>
    21bc: 20 e0        	ldi	r18, 0x0
    21be: 07 e1        	ldi	r16, 0x17
    21c0: 12 e0        	ldi	r17, 0x2
    21c2: 11 d0        	rcall	.+34
    21c4: 21 e0        	ldi	r18, 0x1
    21c6: 0f e1        	ldi	r16, 0x1f
    21c8: 12 e0        	ldi	r17, 0x2
    21ca: 0d d0        	rcall	.+26
    21cc: 22 e0        	ldi	r18, 0x2
    21ce: 07 e2        	ldi	r16, 0x27
    21d0: 12 e0        	ldi	r17, 0x2
    21d2: 09 d0        	rcall	.+18
    21d4: 4f d0        	rcall	.+158
    21d6: 14 97 01 e0  	<unknown>
    21da: 0c 93        	st	X, r16
    21dc: 12 97 8d 01  	<unknown>
    21e0: a9 91        	ld	r26, Y+
    21e2: b9 91        	ld	r27, Y+
    21e4: 08 95        	ret
    21e6: 0c 94 60 0f  	<unknown>
    21ea: f8 01 23 83  	<unknown>
    21ee: 34 83        	std	Z+4, r19
    21f0: 45 83        	std	Z+5, r20
    21f2: 19 c0        	rjmp	.+50
    21f4: 23 95        	inc	r18
    21f6: 29 f0        	breq	.+10
    21f8: 2a 95        	dec	r18
    21fa: 21 f0        	breq	.+8
    21fc: 2a 95        	dec	r18
    21fe: 19 f0        	breq	.+6
    2200: 08 95        	ret
    2202: 02 c0        	rjmp	.+4
    2204: 10 c0        	rjmp	.+32
    2206: 10 c0        	rjmp	.+32
    2208: 27 d0        	rcall	.+78
    220a: 41 f0        	breq	.+16
    220c: 34 2f        	mov	r19, r20
    220e: 24 2f        	mov	r18, r20
    2210: 2c 7f        	andi	r18, 0xfc
    2212: 3a 95        	dec	r19
    2214: 33 70        	andi	r19, 0x3
    2216: 23 2b        	or	r18, r19
    2218: 27 83        	std	Z+7, r18
    221a: 05 c0        	rjmp	.+10
    221c: 26 81        	ldd	r18, Z+6
    221e: 22 23        	tst	r18
    2220: 11 f0        	breq	.+4
    2222: 2a 95        	dec	r18
    2224: 26 83        	std	Z+6, r18
    2226: 2d c0        	rjmp	.+90
    2228: 9a 93        	st	-Y, r25
    222a: 8a 93        	st	-Y, r24
    222c: 15 d0        	rcall	.+42
    222e: 41 f4        	brne	.+16
    2230: 34 2f        	mov	r19, r20
    2232: 24 2f        	mov	r18, r20
    2234: 2c 7f        	andi	r18, 0xfc
    2236: 33 95        	inc	r19
    2238: 33 70        	andi	r19, 0x3
    223a: 23 2b        	or	r18, r19
    223c: 27 83        	std	Z+7, r18
    223e: 0a c0        	rjmp	.+20
    2240: 26 81        	ldd	r18, Z+6
    2242: 30 e0        	ldi	r19, 0x0
    2244: 85 81        	ldd	r24, Z+5
    2246: 90 e0        	ldi	r25, 0x0
    2248: 02 97 28 17  	<unknown>
    224c: 39 07        	cpc	r19, r25
    224e: 14 f4        	brge	.+4
    2250: 23 95        	inc	r18
    2252: 26 83        	std	Z+6, r18
    2254: e8 df        	rcall	.-48
    2256: a8 cf        	rjmp	.-176
    2258: f8 01 47 81  	<unknown>
    225c: 24 2f        	mov	r18, r20
    225e: 23 70        	andi	r18, 0x3
    2260: 08 95        	ret
    2262: f8 01 26 81  	<unknown>
    2266: 07 81        	ldd	r16, Z+7
    2268: 03 70        	andi	r16, 0x3
    226a: 02 0f        	add	r16, r18
    226c: 08 95        	ret
    226e: e4 e0        	ldi	r30, 0x4
    2270: 0c 94 00 35  	<unknown>
    2274: 17 96 0c 91  	<unknown>
    2278: 0c 7f        	andi	r16, 0xfc
    227a: 0c 93        	st	X, r16
    227c: 00 e0        	ldi	r16, 0x0
    227e: 0e 93        	st	-X, r16
    2280: 08 95        	ret
    2282: 0e 94 ef 34  	<unknown>
    2286: d8 01 0e 94  	<unknown>
    228a: 43 0f        	add	r20, r19
    228c: 80 e0        	ldi	r24, 0x0
    228e: 18 2f        	mov	r17, r24
    2290: 00 e0        	ldi	r16, 0x0
    2292: 0e 94 29 0f  	<unknown>
    2296: fd 01 07 81  	<unknown>
    229a: 03 70        	andi	r16, 0x3
    229c: 08 17        	cp	r16, r24
    229e: 11 e0        	ldi	r17, 0x1
    22a0: 11 f4        	brne	.+4
    22a2: 00 e0        	ldi	r16, 0x0
    22a4: 01 c0        	rjmp	.+2
    22a6: 00 e2        	ldi	r16, 0x20
    22a8: 0e 94 70 0f  	<unknown>
    22ac: fd 01 23 81  	<unknown>
    22b0: 34 81        	ldd	r19, Z+4
    22b2: 46 81        	ldd	r20, Z+6
    22b4: 50 e0        	ldi	r21, 0x0
    22b6: 48 0f        	add	r20, r24
    22b8: 55 1f        	rol	r21
    22ba: 01 e1        	ldi	r16, 0x11
    22bc: 10 e0        	ldi	r17, 0x0
    22be: 0e 94 cd 31  	<unknown>
    22c2: 02 0f        	add	r16, r18
    22c4: 13 1f        	adc	r17, r19
    22c6: 0e 94 70 35  	<unknown>
    22ca: 83 95        	inc	r24
    22cc: 82 30        	cpi	r24, 0x2
    22ce: f8 f2        	brlo	.-66
    22d0: ce cf        	rjmp	.-100
    22d2: f8 01 22 83  	<unknown>
    22d6: 22 23        	tst	r18
    22d8: 09 f0        	breq	.+2
    22da: a5 df        	rcall	.-182
    22dc: 08 95        	ret
    22de: f8 01 02 81  	<unknown>
    22e2: 08 95        	ret
    22e4: a9 91        	ld	r26, Y+
    22e6: b9 91        	ld	r27, Y+
    22e8: 08 95        	ret
    22ea: ba 93        	st	-Y, r27
    22ec: aa 93        	st	-Y, r26
    22ee: d8 01 0e 94  	<unknown>
    22f2: 93 0f        	add	r25, r19
    22f4: 0d 93        	st	X+, r16
    22f6: 1c 93        	st	X, r17
    22f8: 11 97 8d 01  	<unknown>
    22fc: f3 cf        	rjmp	.-26
    22fe: f8 01 00 81  	<unknown>
    2302: 11 81        	ldd	r17, Z+1
    2304: 0c 94 a7 0f  	<unknown>
    2308: 20 e0        	ldi	r18, 0x0
    230a: f8 01 24 a3  	<unknown>
    230e: 08 95        	ret
    2310: 08 95        	ret
    2312: 50 e0        	ldi	r21, 0x0
    2314: 02 0f        	add	r16, r18
    2316: 15 1f        	adc	r17, r21
    2318: 33 23        	tst	r19
    231a: f8 01 25 a1  	<unknown>
    231e: 39 f0        	breq	.+14
    2320: 22 23        	tst	r18
    2322: 59 f4        	brne	.+22
    2324: 21 e0        	ldi	r18, 0x1
    2326: 25 a3 0a e0  	<unknown>
    232a: 0c 94 f8 0f  	<unknown>
    232e: 22 23        	tst	r18
    2330: 21 f0        	breq	.+8
    2332: 55 a3 03 e0  	<unknown>
    2336: 0e 94 f8 0f  	<unknown>
    233a: 08 95        	ret
    233c: 0e 94 ee 34  	<unknown>
    2340: 4f b6        	in	r4, 0x3f
    2342: f8 94        	cli
    2344: d8 01 92 2f  	<unknown>
    2348: 80 e0        	ldi	r24, 0x0
    234a: 30 e0        	ldi	r19, 0x0
    234c: 28 d1        	rcall	.+592
    234e: e8 f3        	brlo	.-6
    2350: 94 96 9c 93  	<unknown>
    2354: 4f be        	out	0x3f, r4
    2356: e5 e0        	ldi	r30, 0x5
    2358: 0c 94 ff 34  	<unknown>
    235c: f8 01 04 a1  	<unknown>
    2360: 08 95        	ret
    2362: 30 e0        	ldi	r19, 0x0
    2364: 02 0f        	add	r16, r18
    2366: 13 1f        	adc	r17, r19
    2368: f8 01 05 a1  	<unknown>
    236c: 08 95        	ret
    236e: 3f b7        	in	r19, 0x3f
    2370: f8 94        	cli
    2372: 3b d0        	rcall	.+118
    2374: 3f bf        	out	0x3f, r19
    2376: 08 95        	ret
    2378: 3f b7        	in	r19, 0x3f
    237a: f8 94        	cli
    237c: 06 d0        	rcall	.+12
    237e: 02 e0        	ldi	r16, 0x2
    2380: 20 9f 40 0d  	<unknown>
    2384: 51 1d        	adc	r21, r1
    2386: 37 d0        	rcall	.+110
    2388: f5 cf        	rjmp	.-22
    238a: 4d e2        	ldi	r20, 0x2d
    238c: 50 e0        	ldi	r21, 0x0
    238e: 08 95        	ret
    2390: 6f b7        	in	r22, 0x3f
    2392: 03 d0        	rcall	.+6
    2394: 07 d0        	rcall	.+14
    2396: 6f bf        	out	0x3f, r22
    2398: 08 95        	ret
    239a: f8 94        	cli
    239c: 8a 01 32 e0  	<unknown>
    23a0: 23 9f 08 95  	<unknown>
    23a4: 45 e1        	ldi	r20, 0x15
    23a6: 50 e0        	ldi	r21, 0x0
    23a8: 40 0d        	add	r20, r0
    23aa: 51 1d        	adc	r21, r1
    23ac: 0c 94 a4 31  	<unknown>
    23b0: 6f b7        	in	r22, 0x3f
    23b2: f8 94        	cli
    23b4: 8a 01 e9 df  	<unknown>
    23b8: 32 e0        	ldi	r19, 0x2
    23ba: 23 9f f5 df  	<unknown>
    23be: eb cf        	rjmp	.-42
    23c0: 7b 2f        	mov	r23, r27
    23c2: 2a 2e        	mov	r2, r26
    23c4: 6f b7        	in	r22, 0x3f
    23c6: f8 94        	cli
    23c8: d8 01 01 e0  	<unknown>
    23cc: 30 e0        	ldi	r19, 0x0
    23ce: ea 2f        	mov	r30, r26
    23d0: f1 2f        	mov	r31, r17
    23d2: e2 0f        	add	r30, r18
    23d4: f3 1f        	adc	r31, r19
    23d6: 00 8f        	std	Z+0, r16
    23d8: 08 d0        	rcall	.+16
    23da: a0 0d        	add	r26, r0
    23dc: b1 1d        	adc	r27, r1
    23de: 0d 93        	st	X+, r16
    23e0: 1c 93        	st	X, r17
    23e2: 6f bf        	out	0x3f, r22
    23e4: a2 2d        	mov	r26, r2
    23e6: b7 2f        	mov	r27, r23
    23e8: 08 95        	ret
    23ea: 02 e0        	ldi	r16, 0x2
    23ec: 20 9f 45 e1  	<unknown>
    23f0: 50 e0        	ldi	r21, 0x0
    23f2: 40 0d        	add	r20, r0
    23f4: 51 1d        	adc	r21, r1
    23f6: 0c 94 89 31  	<unknown>
    23fa: 0e 94 f0 34  	<unknown>
    23fe: c8 01 a0 e0  	<unknown>
    2402: 2a 2f        	mov	r18, r26
    2404: 8c 01 dc df  	<unknown>
    2408: a3 95        	inc	r26
    240a: ac 30        	cpi	r26, 0xc
    240c: d0 f3        	brlo	.-12
    240e: e3 e0        	ldi	r30, 0x3
    2410: 0c 94 01 35  	<unknown>
    2414: 02 2f        	mov	r16, r18
    2416: 04 50        	subi	r16, 0x4
    2418: 50 f0        	brlo	.+20
    241a: 04 50        	subi	r16, 0x4
    241c: 78 f0        	brlo	.+30
    241e: d1 f0        	breq	.+52
    2420: 0a 95        	dec	r16
    2422: c1 f0        	breq	.+48
    2424: 0a 95        	dec	r16
    2426: f1 f0        	breq	.+60
    2428: 0a 95        	dec	r16
    242a: 11 f1        	breq	.+68
    242c: 08 95        	ret
    242e: 47 e0        	ldi	r20, 0x7
    2430: 42 1b        	sub	r20, r18
    2432: 24 d0        	rcall	.+72
    2434: 91 f0        	breq	.+36
    2436: 15 b3        	in	r17, 0x15
    2438: 10 2b        	or	r17, r16
    243a: 12 c0        	rjmp	.+36
    243c: 4b e0        	ldi	r20, 0xb
    243e: 42 1b        	sub	r20, r18
    2440: 1d d0        	rcall	.+58
    2442: 19 f0        	breq	.+6
    2444: 1b b3        	in	r17, 0x1b
    2446: 10 2b        	or	r17, r16
    2448: 03 c0        	rjmp	.+6
    244a: 00 95        	com	r16
    244c: 1b b3        	in	r17, 0x1b
    244e: 10 23        	and	r17, r16
    2450: 1b bb        	out	0x1b, r17
    2452: 08 95        	ret
    2454: 26 50        	subi	r18, 0x6
    2456: 42 2f        	mov	r20, r18
    2458: ec cf        	rjmp	.-40
    245a: 00 95        	com	r16
    245c: 15 b3        	in	r17, 0x15
    245e: 10 23        	and	r17, r16
    2460: 15 bb        	out	0x15, r17
    2462: 08 95        	ret
    2464: 33 23        	tst	r19
    2466: 11 f0        	breq	.+4
    2468: 93 9a        	sbi	0x12, 0x3
    246a: 08 95        	ret
    246c: 93 98        	cbi	0x12, 0x3
    246e: 08 95        	ret
    2470: 33 23        	tst	r19
    2472: 11 f0        	breq	.+4
    2474: 96 9a        	sbi	0x12, 0x6
    2476: 08 95        	ret
    2478: 96 98        	cbi	0x12, 0x6
    247a: 08 95        	ret
    247c: 2a d0        	rcall	.+84
    247e: 33 23        	tst	r19
    2480: 08 95        	ret
    2482: 02 2f        	mov	r16, r18
    2484: 04 50        	subi	r16, 0x4
    2486: 50 f0        	brlo	.+20
    2488: 04 50        	subi	r16, 0x4
    248a: 78 f0        	brlo	.+30
    248c: a1 f0        	breq	.+40
    248e: 0a 95        	dec	r16
    2490: 91 f0        	breq	.+36
    2492: 0a 95        	dec	r16
    2494: a1 f0        	breq	.+40
    2496: 0a 95        	dec	r16
    2498: a9 f0        	breq	.+42
    249a: 16 c0        	rjmp	.+44
    249c: 35 b3        	in	r19, 0x15
    249e: 47 e0        	ldi	r20, 0x7
    24a0: 42 1b        	sub	r20, r18
    24a2: 14 d0        	rcall	.+40
    24a4: 89 f0        	breq	.+34
    24a6: 01 e0        	ldi	r16, 0x1
    24a8: 08 95        	ret
    24aa: 3b b3        	in	r19, 0x1b
    24ac: 4b e0        	ldi	r20, 0xb
    24ae: 42 1b        	sub	r20, r18
    24b0: 0d d0        	rcall	.+26
    24b2: c9 f7        	brne	.-14
    24b4: 09 c0        	rjmp	.+18
    24b6: 35 b3        	in	r19, 0x15
    24b8: 26 50        	subi	r18, 0x6
    24ba: 42 2f        	mov	r20, r18
    24bc: f9 cf        	rjmp	.-14
    24be: 93 99        	sbic	0x12, 0x3
    24c0: f2 cf        	rjmp	.-28
    24c2: 02 c0        	rjmp	.+4
    24c4: 96 99        	sbic	0x12, 0x6
    24c6: ef cf        	rjmp	.-34
    24c8: 00 e0        	ldi	r16, 0x0
    24ca: 08 95        	ret
    24cc: 02 d0        	rcall	.+4
    24ce: 30 23        	and	r19, r16
    24d0: 08 95        	ret
    24d2: 01 e0        	ldi	r16, 0x1
    24d4: 10 e0        	ldi	r17, 0x0
    24d6: 0c 94 d5 31  	<unknown>
    24da: 0e 94 ef 34  	<unknown>
    24de: bf b7        	in	r27, 0x3f
    24e0: f8 94        	cli
    24e2: c8 01 a0 e0  	<unknown>
    24e6: 4a e0        	ldi	r20, 0xa
    24e8: 50 e0        	ldi	r21, 0x0
    24ea: 2a 2f        	mov	r18, r26
    24ec: 8c 01 50 df  	<unknown>
    24f0: 40 e0        	ldi	r20, 0x0
    24f2: 50 e0        	ldi	r21, 0x0
    24f4: 2a 2f        	mov	r18, r26
    24f6: 8c 01 5b df  	<unknown>
    24fa: a3 95        	inc	r26
    24fc: ac 30        	cpi	r26, 0xc
    24fe: 98 f3        	brlo	.-26
    2500: bf bf        	out	0x3f, r27
    2502: e4 e0        	ldi	r30, 0x4
    2504: 0c 94 00 35  	<unknown>
    2508: 0e 94 ee 34  	<unknown>
    250c: 4f b6        	in	r4, 0x3f
    250e: f8 94        	cli
    2510: d8 01 f8 01  	<unknown>
    2514: 04 a1 00 23  	<unknown>
    2518: 09 f0        	breq	.+2
    251a: 40 c0        	rjmp	.+128
    251c: 80 e0        	ldi	r24, 0x0
    251e: 02 e0        	ldi	r16, 0x2
    2520: 80 9f 80 01  	<unknown>
    2524: bd 01 60 0d  	<unknown>
    2528: 71 1d        	adc	r23, r1
    252a: fb 01 20 81  	<unknown>
    252e: 31 81        	ldd	r19, Z+1
    2530: 21 50        	subi	r18, 0x1
    2532: 30 40        	sbci	r19, 0x0
    2534: 20 83        	std	Z+0, r18
    2536: 31 83        	std	Z+1, r19
    2538: 90 e0        	ldi	r25, 0x0
    253a: 9d 01 28 0f  	<unknown>
    253e: 39 1f        	adc	r19, r25
    2540: 40 81        	ldd	r20, Z+0
    2542: 51 81        	ldd	r21, Z+1
    2544: 45 2b        	or	r20, r21
    2546: 19 f5        	brne	.+70
    2548: 45 e1        	ldi	r20, 0x15
    254a: 24 2e        	mov	r2, r20
    254c: 40 e0        	ldi	r20, 0x0
    254e: 34 2e        	mov	r3, r20
    2550: 20 0c        	add	r2, r0
    2552: 31 1c        	adc	r3, r1
    2554: f9 01 40 8d  	<unknown>
    2558: 44 23        	tst	r20
    255a: 91 f0        	breq	.+36
    255c: 45 e1        	ldi	r20, 0x15
    255e: 04 2e        	mov	r0, r20
    2560: 40 e0        	ldi	r20, 0x0
    2562: 14 2e        	mov	r1, r20
    2564: 00 0e        	add	r0, r16
    2566: 11 1e        	adc	r1, r17
    2568: a0 01 48 5e  	<unknown>
    256c: 5f 4f        	sbci	r21, 0xff
    256e: 43 df        	rcall	.-378
    2570: 01 2b        	or	r16, r17
    2572: 41 f0        	breq	.+16
    2574: 90 8f        	std	Z+0, r25
    2576: 08 e1        	ldi	r16, 0x18
    2578: 00 0e        	add	r0, r16
    257a: 19 1e        	adc	r1, r25
    257c: a0 01 03 c0  	<unknown>
    2580: 01 e0        	ldi	r16, 0x1
    2582: 00 8f        	std	Z+0, r16
    2584: a1 01 37 df  	<unknown>
    2588: fb 01 00 83  	<unknown>
    258c: 11 83        	std	Z+1, r17
    258e: f9 01 00 8d  	<unknown>
    2592: 15 a1 01 23  	<unknown>
    2596: 30 2f        	mov	r19, r16
    2598: 02 d0        	rcall	.+4
    259a: 08 f2        	brlo	.-126
    259c: db ce        	rjmp	.-586
    259e: 28 2f        	mov	r18, r24
    25a0: 8d 01 38 df  	<unknown>
    25a4: 83 95        	inc	r24
    25a6: 8c 30        	cpi	r24, 0xc
    25a8: 08 95        	ret
    25aa: 00 23        	tst	r16
    25ac: 61 f0        	breq	.+24
    25ae: 0e 94 be 10  	<unknown>
    25b2: e8 ea        	ldi	r30, 0xa8
    25b4: f6 e0        	ldi	r31, 0x6
    25b6: 00 83        	std	Z+0, r16
    25b8: 11 83        	std	Z+1, r17
    25ba: 48 e1        	ldi	r20, 0x18
    25bc: 20 e4        	ldi	r18, 0x40
    25be: 32 e0        	ldi	r19, 0x2
    25c0: 0e 94 f5 10  	<unknown>
    25c4: 1e c0        	rjmp	.+60
    25c6: 2b d0        	rcall	.+86
    25c8: 0e 94 6f 11  	<unknown>
    25cc: 00 23        	tst	r16
    25ce: d9 f0        	breq	.+54
    25d0: 2b d0        	rcall	.+86
    25d2: 01 30        	cpi	r16, 0x1
    25d4: 11 f4        	brne	.+4
    25d6: 2f ef        	ldi	r18, 0xff
    25d8: 33 d0        	rcall	.+102
    25da: 26 d0        	rcall	.+76
    25dc: 04 30        	cpi	r16, 0x4
    25de: 11 f4        	brne	.+4
    25e0: 21 e0        	ldi	r18, 0x1
    25e2: 2e d0        	rcall	.+92
    25e4: 21 d0        	rcall	.+66
    25e6: 39 f4        	brne	.+14
    25e8: 0e 94 43 0f  	<unknown>
    25ec: 20 e0        	ldi	r18, 0x0
    25ee: 25 d0        	rcall	.+74
    25f0: 1f d0        	rcall	.+62
    25f2: 01 e0        	ldi	r16, 0x1
    25f4: 28 d0        	rcall	.+80
    25f6: 18 d0        	rcall	.+48
    25f8: 05 30        	cpi	r16, 0x5
    25fa: 79 f4        	brne	.+30
    25fc: 10 d0        	rcall	.+32
    25fe: 0e 94 c9 10  	<unknown>
    2602: 01 e0        	ldi	r16, 0x1
    2604: 08 95        	ret
    2606: 14 d0        	rcall	.+40
    2608: 00 e0        	ldi	r16, 0x0
    260a: 1d d0        	rcall	.+58
    260c: 01 30        	cpi	r16, 0x1
    260e: 29 f4        	brne	.+10
    2610: 74 d0        	rcall	.+232
    2612: 0e 94 fd 11  	<unknown>
    2616: 21 e0        	ldi	r18, 0x1
    2618: 10 d0        	rcall	.+32
    261a: 00 e0        	ldi	r16, 0x0
    261c: 08 95        	ret
    261e: e8 ea        	ldi	r30, 0xa8
    2620: f6 e0        	ldi	r31, 0x6
    2622: 00 81        	ldd	r16, Z+0
    2624: 11 81        	ldd	r17, Z+1
    2626: 08 95        	ret
    2628: 00 91 39 07  	<unknown>
    262c: 0f 70        	andi	r16, 0xf
    262e: 08 95        	ret
    2630: f6 df        	rcall	.-20
    2632: 0e 94 31 11  	<unknown>
    2636: 10 2f        	mov	r17, r16
    2638: 08 95        	ret
    263a: f1 df        	rcall	.-30
    263c: 0c 94 69 11  	<unknown>
    2640: ee df        	rcall	.-36
    2642: 0c 94 fa 10  	<unknown>
    2646: 0e 94 f0 34  	<unknown>
    264a: af b7        	in	r26, 0x3f
    264c: f8 94        	cli
    264e: 81 2f        	mov	r24, r17
    2650: 91 2f        	mov	r25, r17
    2652: 9c 50        	subi	r25, 0xc
    2654: 00 23        	tst	r16
    2656: 79 f1        	breq	.+94
    2658: 0e 94 2d 0b  	<unknown>
    265c: ed e7        	ldi	r30, 0x7d
    265e: f6 e0        	ldi	r31, 0x6
    2660: 00 83        	std	Z+0, r16
    2662: 11 83        	std	Z+1, r17
    2664: 8c 30        	cpi	r24, 0xc
    2666: 0f ef        	ldi	r16, 0xff
    2668: 20 e0        	ldi	r18, 0x0
    266a: 2a 93        	st	-Y, r18
    266c: 2a 93        	st	-Y, r18
    266e: 0a 93        	st	-Y, r16
    2670: 0a 93        	st	-Y, r16
    2672: 10 f4        	brsh	.+4
    2674: 41 e0        	ldi	r20, 0x1
    2676: 01 c0        	rjmp	.+2
    2678: 40 e0        	ldi	r20, 0x0
    267a: 50 e0        	ldi	r21, 0x0
    267c: 60 e0        	ldi	r22, 0x0
    267e: 70 e0        	ldi	r23, 0x0
    2680: 00 81        	ldd	r16, Z+0
    2682: 11 81        	ldd	r17, Z+1
    2684: 0e 94 59 0b  	<unknown>
    2688: 2f e2        	ldi	r18, 0x2f
    268a: 32 e0        	ldi	r19, 0x2
    268c: 39 d0        	rcall	.+114
    268e: 0e 94 71 0b  	<unknown>
    2692: 8c 30        	cpi	r24, 0xc
    2694: 20 f4        	brsh	.+8
    2696: 30 d0        	rcall	.+96
    2698: 0e 94 b7 11  	<unknown>
    269c: 04 c0        	rjmp	.+8
    269e: 29 2f        	mov	r18, r25
    26a0: 2c d0        	rcall	.+88
    26a2: 0e 94 bc 11  	<unknown>
    26a6: a8 01 60 e0  	<unknown>
    26aa: 70 e0        	ldi	r23, 0x0
    26ac: 29 d0        	rcall	.+82
    26ae: 0e 94 68 0b  	<unknown>
    26b2: 01 e0        	ldi	r16, 0x1
    26b4: 1d c0        	rjmp	.+58
    26b6: 20 91 39 07  	<unknown>
    26ba: 22 d0        	rcall	.+68
    26bc: 0e 94 95 0b  	<unknown>
    26c0: 01 30        	cpi	r16, 0x1
    26c2: a9 f4        	brne	.+42
    26c4: 8c 30        	cpi	r24, 0xc
    26c6: 1c d0        	rcall	.+56
    26c8: 38 f4        	brsh	.+14
    26ca: 0e 94 6b 0b  	<unknown>
    26ce: a8 01 13 d0  	<unknown>
    26d2: 0e 94 c8 11  	<unknown>
    26d6: 07 c0        	rjmp	.+14
    26d8: 0e 94 6b 0b  	<unknown>
    26dc: a8 01 29 2f  	<unknown>
    26e0: 0c d0        	rcall	.+24
    26e2: 0e 94 d8 11  	<unknown>
    26e6: 0c d0        	rcall	.+24
    26e8: 0e 94 33 0b  	<unknown>
    26ec: e2 cf        	rjmp	.-60
    26ee: 00 e0        	ldi	r16, 0x0
    26f0: af bf        	out	0x3f, r26
    26f2: e3 e0        	ldi	r30, 0x3
    26f4: 0c 94 01 35  	<unknown>
    26f8: 28 2f        	mov	r18, r24
    26fa: 07 e4        	ldi	r16, 0x47
    26fc: 17 e0        	ldi	r17, 0x7
    26fe: 08 95        	ret
    2700: ed e7        	ldi	r30, 0x7d
    2702: f6 e0        	ldi	r31, 0x6
    2704: 8e cf        	rjmp	.-228
    2706: 00 e0        	ldi	r16, 0x0
    2708: 10 e0        	ldi	r17, 0x0
    270a: 08 95        	ret
    270c: 9a 93        	st	-Y, r25
    270e: 8a 93        	st	-Y, r24
    2710: c8 01 01 2b  	<unknown>
    2714: 31 f0        	breq	.+12
    2716: 08 2f        	mov	r16, r24
    2718: 0e 94 7f 11  	<unknown>
    271c: 8c 01 0e 94  	<unknown>
    2720: 76 31        	cpi	r23, 0x16
    2722: 89 91        	ld	r24, Y+
    2724: 99 91        	ld	r25, Y+
    2726: 08 95        	ret
    2728: 03 d0        	rcall	.+6
    272a: 09 f0        	breq	.+2
    272c: 02 c1        	rjmp	.+516
    272e: eb cf        	rjmp	.-42
    2730: 00 e1        	ldi	r16, 0x10
    2732: 10 e0        	ldi	r17, 0x0
    2734: 0e 94 3e 35  	<unknown>
    2738: 20 2f        	mov	r18, r16
    273a: 21 2b        	or	r18, r17
    273c: 08 95        	ret
    273e: 45 d0        	rcall	.+138
    2740: d8 01 0e 94  	<unknown>
    2744: 75 11        	cpse	r23, r5
    2746: 08 ed        	ldi	r16, 0xd8
    2748: 13 e0        	ldi	r17, 0x3
    274a: 1e 96 0d 93  	<unknown>
    274e: 1c 93        	st	X, r17
    2750: 1d 97 0e 94  	<unknown>
    2754: 43 0f        	add	r20, r19
    2756: 00 e0        	ldi	r16, 0x0
    2758: 10 e0        	ldi	r17, 0x0
    275a: 0d 93        	st	X+, r16
    275c: 0d 93        	st	X+, r16
    275e: 0d 93        	st	X+, r16
    2760: 0c 93        	st	X, r16
    2762: 11 96 04 e6  	<unknown>
    2766: 0d 93        	st	X+, r16
    2768: 1d 93        	st	X+, r17
    276a: 1d 93        	st	X+, r17
    276c: 1c 93        	st	X, r17
    276e: 19 97 fa c0  	<unknown>
    2772: 0c 94 7f 11  	<unknown>
    2776: ff c0        	rjmp	.+510
    2778: 08 80        	ldd	r0, Y+0
    277a: 19 80        	ldd	r1, Y+1
    277c: 2a 80        	ldd	r2, Y+2
    277e: 3b 80        	ldd	r3, Y+3
    2780: f8 01 42 83  	<unknown>
    2784: 53 83        	std	Z+3, r21
    2786: 64 83        	std	Z+4, r22
    2788: 75 83        	std	Z+5, r23
    278a: 06 82        	std	Z+6, r0
    278c: 17 82        	std	Z+7, r1
    278e: 20 86        	std	Z+0, r2
    2790: 31 86        	std	Z+1, r3
    2792: 24 96 08 95  	<unknown>
    2796: 19 d0        	rcall	.+50
    2798: f8 01 42 87  	<unknown>
    279c: 53 87        	std	Z+3, r21
    279e: 64 87        	std	Z+4, r22
    27a0: 75 87        	std	Z+5, r23
    27a2: ea c0        	rjmp	.+468
    27a4: 0e d0        	rcall	.+28
    27a6: 0c 90        	ld	r0, X
    27a8: 11 24        	clr	r1
    27aa: 08 82        	std	Y+0, r0
    27ac: 19 82        	std	Y+1, r1
    27ae: 1a 82        	std	Y+2, r1
    27b0: 1b 82        	std	Y+3, r1
    27b2: 03 d0        	rcall	.+6
    27b4: 0c 93        	st	X, r16
    27b6: 24 96 d7 c0  	<unknown>
    27ba: 9e 01 09 d0  	<unknown>
    27be: 08 81        	ldd	r16, Y+0
    27c0: 08 95        	ret
    27c2: 03 d0        	rcall	.+6
    27c4: 24 97 d9 01  	<unknown>
    27c8: 08 95        	ret
    27ca: ba 93        	st	-Y, r27
    27cc: aa 93        	st	-Y, r26
    27ce: 08 95        	ret
    27d0: 0e 94 eb 34  	<unknown>
    27d4: b8 01 d9 01  	<unknown>
    27d8: 25 2f        	mov	r18, r21
    27da: 22 0f        	lsl	r18
    27dc: 22 0b        	sbc	r18, r18
    27de: 41 30        	cpi	r20, 0x1
    27e0: e0 e0        	ldi	r30, 0x0
    27e2: 5e 07        	cpc	r21, r30
    27e4: 74 f1        	brlt	.+92
    27e6: 9f d0        	rcall	.+318
    27e8: ea 2f        	mov	r30, r26
    27ea: f3 2f        	mov	r31, r19
    27ec: 40 80        	ldd	r4, Z+0
    27ee: 51 80        	ldd	r5, Z+1
    27f0: 62 80        	ldd	r6, Z+2
    27f2: 73 80        	ldd	r7, Z+3
    27f4: 39 d0        	rcall	.+114
    27f6: 04 14        	cp	r0, r4
    27f8: 15 04        	cpc	r1, r5
    27fa: 26 04        	cpc	r2, r6
    27fc: 37 04        	cpc	r3, r7
    27fe: 6c f0        	brlt	.+26
    2800: 0d 90        	ld	r0, X+
    2802: 1d 90        	ld	r1, X+
    2804: 2d 90        	ld	r2, X+
    2806: 3c 90        	ld	r3, X
    2808: 04 0e        	add	r0, r20
    280a: 15 1e        	adc	r1, r21
    280c: 22 1e        	adc	r2, r18
    280e: 32 1e        	adc	r3, r18
    2810: 3c 92        	st	X, r3
    2812: 2e 92        	st	-X, r2
    2814: 1e 92        	st	-X, r1
    2816: 0e 92        	st	-X, r0
    2818: 05 c0        	rjmp	.+10
    281a: 0d 92        	st	X+, r0
    281c: 1d 92        	st	X+, r1
    281e: 2d 92        	st	X+, r2
    2820: 3c 92        	st	X, r3
    2822: 13 97 0d 91  	<unknown>
    2826: 1d 91        	ld	r17, X+
    2828: 2d 91        	ld	r18, X+
    282a: 3c 91        	ld	r19, X
    282c: fb 01 02 87  	<unknown>
    2830: 13 87        	std	Z+3, r17
    2832: 24 87        	std	Z+4, r18
    2834: 35 87        	std	Z+5, r19
    2836: 8b 01 db 01  	<unknown>
    283a: a1 d0        	rcall	.+322
    283c: e8 e0        	ldi	r30, 0x8
    283e: 0c 94 fc 34  	<unknown>
    2842: 55 23        	tst	r21
    2844: c2 f7        	brpl	.-16
    2846: f8 01 02 80  	<unknown>
    284a: 13 80        	ldd	r1, Z+3
    284c: 24 80        	ldd	r2, Z+4
    284e: 35 80        	ldd	r3, Z+5
    2850: 4d 90        	ld	r4, X+
    2852: 5d 90        	ld	r5, X+
    2854: 6d 90        	ld	r6, X+
    2856: 7c 90        	ld	r7, X
    2858: 13 97 06 d0  	<unknown>
    285c: 40 14        	cp	r4, r0
    285e: 51 04        	cpc	r5, r1
    2860: 62 04        	cpc	r6, r2
    2862: 73 04        	cpc	r7, r3
    2864: 6c f6        	brge	.-102
    2866: d9 cf        	rjmp	.-78
    2868: 44 0e        	add	r4, r20
    286a: 55 1e        	adc	r5, r21
    286c: 62 1e        	adc	r6, r18
    286e: 72 1e        	adc	r7, r18
    2870: 08 95        	ret
    2872: 04 d0        	rcall	.+8
    2874: 8c 01 0e 94  	<unknown>
    2878: 70 35        	cpi	r23, 0x50
    287a: 53 cf        	rjmp	.-346
    287c: 9a 93        	st	-Y, r25
    287e: 8a 93        	st	-Y, r24
    2880: c9 01 20 e0  	<unknown>
    2884: 1f e0        	ldi	r17, 0xf
    2886: 00 e0        	ldi	r16, 0x0
    2888: 0e 94 34 0f  	<unknown>
    288c: 10 e0        	ldi	r17, 0x0
    288e: 70 c0        	rjmp	.+224
    2890: 0e 94 ef 34  	<unknown>
    2894: 48 d0        	rcall	.+144
    2896: eb d0        	rcall	.+470
    2898: 98 f4        	brsh	.+38
    289a: 00 15        	cp	r16, r0
    289c: 11 05        	cpc	r17, r1
    289e: 22 05        	cpc	r18, r2
    28a0: 33 05        	cpc	r19, r3
    28a2: 70 f4        	brsh	.+28
    28a4: dd d0        	rcall	.+442
    28a6: 44 e0        	ldi	r20, 0x4
    28a8: 0e 94 2d 32  	<unknown>
    28ac: 08 1a        	sub	r0, r24
    28ae: 19 0a        	sbc	r1, r25
    28b0: 2a 0a        	sbc	r2, r26
    28b2: 3b 0a        	sbc	r3, r27
    28b4: a0 01 b1 01  	<unknown>
    28b8: 0e 94 3d 32  	<unknown>
    28bc: 90 2f        	mov	r25, r16
    28be: 08 c0        	rjmp	.+16
    28c0: 00 16        	cp	r0, r16
    28c2: 11 06        	cpc	r1, r17
    28c4: 22 06        	cpc	r2, r18
    28c6: 33 06        	cpc	r3, r19
    28c8: 10 f0        	brlo	.+4
    28ca: 9f e0        	ldi	r25, 0xf
    28cc: 01 c0        	rjmp	.+2
    28ce: 90 e0        	ldi	r25, 0x0
    28d0: 4e d0        	rcall	.+156
    28d2: 80 e0        	ldi	r24, 0x0
    28d4: 02 c0        	rjmp	.+4
    28d6: 88 23        	tst	r24
    28d8: 21 f4        	brne	.+8
    28da: 11 e0        	ldi	r17, 0x1
    28dc: 01 e0        	ldi	r16, 0x1
    28de: 41 d0        	rcall	.+130
    28e0: 02 c0        	rjmp	.+4
    28e2: 8f 30        	cpi	r24, 0xf
    28e4: 28 f0        	brlo	.+10
    28e6: 8f 30        	cpi	r24, 0xf
    28e8: 31 f4        	brne	.+12
    28ea: 11 e0        	ldi	r17, 0x1
    28ec: 05 e0        	ldi	r16, 0x5
    28ee: 02 c0        	rjmp	.+4
    28f0: 11 e0        	ldi	r17, 0x1
    28f2: 03 e0        	ldi	r16, 0x3
    28f4: 36 d0        	rcall	.+108
    28f6: 83 95        	inc	r24
    28f8: 98 17        	cp	r25, r24
    28fa: 68 f7        	brsh	.-38
    28fc: 80 31        	cpi	r24, 0x10
    28fe: 80 f4        	brsh	.+32
    2900: 88 23        	tst	r24
    2902: 19 f4        	brne	.+6
    2904: 11 e0        	ldi	r17, 0x1
    2906: 00 e0        	ldi	r16, 0x0
    2908: 08 c0        	rjmp	.+16
    290a: 8f 30        	cpi	r24, 0xf
    290c: 18 f4        	brsh	.+6
    290e: 11 e0        	ldi	r17, 0x1
    2910: 02 e0        	ldi	r16, 0x2
    2912: 03 c0        	rjmp	.+6
    2914: 19 f4        	brne	.+6
    2916: 11 e0        	ldi	r17, 0x1
    2918: 04 e0        	ldi	r16, 0x4
    291a: 23 d0        	rcall	.+70
    291c: 83 95        	inc	r24
    291e: ee cf        	rjmp	.-36
    2920: e4 e0        	ldi	r30, 0x4
    2922: 0c 94 00 35  	<unknown>
    2926: f8 01 06 80  	<unknown>
    292a: 17 80        	ldd	r1, Z+7
    292c: 20 84        	ldd	r2, Z+0
    292e: 31 84        	ldd	r3, Z+1
    2930: 08 95        	ret
    2932: 4b df        	rcall	.-362
    2934: d8 01 03 df  	<unknown>
    2938: 0c ed        	ldi	r16, 0xdc
    293a: 13 e0        	ldi	r17, 0x3
    293c: 1e 96 0d 93  	<unknown>
    2940: 1c 93        	st	X, r17
    2942: 1f 97 00 ee  	<unknown>
    2946: 13 e0        	ldi	r17, 0x3
    2948: 0e 94 52 0f  	<unknown>
    294c: 10 d0        	rcall	.+32
    294e: 11 e0        	ldi	r17, 0x1
    2950: 00 e0        	ldi	r16, 0x0
    2952: 07 d0        	rcall	.+14
    2954: 11 e0        	ldi	r17, 0x1
    2956: 0f e0        	ldi	r16, 0xf
    2958: 0c d0        	rcall	.+24
    295a: 11 e0        	ldi	r17, 0x1
    295c: 05 e0        	ldi	r16, 0x5
    295e: 01 d0        	rcall	.+2
    2960: 02 c0        	rjmp	.+4
    2962: 0c 94 70 0f  	<unknown>
    2966: 8d 01 a9 91  	<unknown>
    296a: b9 91        	ld	r27, Y+
    296c: 08 95        	ret
    296e: 11 e0        	ldi	r17, 0x1
    2970: 00 e0        	ldi	r16, 0x0
    2972: 0c 94 29 0f  	<unknown>
    2976: 29 df        	rcall	.-430
    2978: d8 01 01 d0  	<unknown>
    297c: f5 cf        	rjmp	.-22
    297e: 1e 96 ed 91  	<unknown>
    2982: fc 91        	ld	r31, X
    2984: 25 91 f4 91  	<unknown>
    2988: e2 2f        	mov	r30, r18
    298a: 09 94 0e 94  	<unknown>
    298e: ea 34        	cpi	r30, 0x4a
    2990: 8f b6        	in	r8, 0x3f
    2992: f8 94        	cli
    2994: f8 01 6b d0  	<unknown>
    2998: 30 f5        	brsh	.+76
    299a: 46 80        	ldd	r4, Z+6
    299c: 57 80        	ldd	r5, Z+7
    299e: 60 84        	ldd	r6, Z+0
    29a0: 71 84        	ldd	r7, Z+1
    29a2: 04 15        	cp	r16, r4
    29a4: 15 05        	cpc	r17, r5
    29a6: 26 05        	cpc	r18, r6
    29a8: 37 05        	cpc	r19, r7
    29aa: f8 f4        	brsh	.+62
    29ac: 59 d0        	rcall	.+178
    29ae: 4f e2        	ldi	r20, 0x2f
    29b0: 50 e0        	ldi	r21, 0x0
    29b2: 60 e0        	ldi	r22, 0x0
    29b4: 70 e0        	ldi	r23, 0x0
    29b6: 0e 94 0d 32  	<unknown>
    29ba: 48 1a        	sub	r4, r24
    29bc: 59 0a        	sbc	r5, r25
    29be: 6a 0a        	sbc	r6, r26
    29c0: 7b 0a        	sbc	r7, r27
    29c2: a2 01 b3 01  	<unknown>
    29c6: 0e 94 3d 32  	<unknown>
    29ca: 80 2f        	mov	r24, r16
    29cc: 0d 32        	cpi	r16, 0x2d
    29ce: 78 f4        	brsh	.+30
    29d0: 25 e0        	ldi	r18, 0x5
    29d2: 08 e0        	ldi	r16, 0x8
    29d4: 14 e0        	ldi	r17, 0x4
    29d6: 49 d0        	rcall	.+146
    29d8: 8e 32        	cpi	r24, 0x2e
    29da: 71 f4        	brne	.+28
    29dc: 25 e0        	ldi	r18, 0x5
    29de: 08 e2        	ldi	r16, 0x28
    29e0: 14 e0        	ldi	r17, 0x4
    29e2: 43 d0        	rcall	.+134
    29e4: 1a c0        	rjmp	.+52
    29e6: 80 e0        	ldi	r24, 0x0
    29e8: f3 cf        	rjmp	.-26
    29ea: 8e e2        	ldi	r24, 0x2e
    29ec: f7 cf        	rjmp	.-18
    29ee: a1 f7        	brne	.-24
    29f0: 25 e0        	ldi	r18, 0x5
    29f2: 00 e2        	ldi	r16, 0x20
    29f4: 14 e0        	ldi	r17, 0x4
    29f6: f5 cf        	rjmp	.-22
    29f8: 88 23        	tst	r24
    29fa: 29 f4        	brne	.+10
    29fc: 20 e0        	ldi	r18, 0x0
    29fe: 00 ee        	ldi	r16, 0xe0
    2a00: 13 e0        	ldi	r17, 0x3
    2a02: 33 d0        	rcall	.+102
    2a04: 0f c0        	rjmp	.+30
    2a06: 81 30        	cpi	r24, 0x1
    2a08: 31 f4        	brne	.+12
    2a0a: 20 e0        	ldi	r18, 0x0
    2a0c: 00 e1        	ldi	r16, 0x10
    2a0e: 14 e0        	ldi	r17, 0x4
    2a10: 2c d0        	rcall	.+88
    2a12: 80 e0        	ldi	r24, 0x0
    2a14: 07 c0        	rjmp	.+14
    2a16: 82 30        	cpi	r24, 0x2
    2a18: 28 f0        	brlo	.+10
    2a1a: 20 e0        	ldi	r18, 0x0
    2a1c: 08 e1        	ldi	r16, 0x18
    2a1e: 14 e0        	ldi	r17, 0x4
    2a20: 24 d0        	rcall	.+72
    2a22: 82 50        	subi	r24, 0x2
    2a24: 11 e0        	ldi	r17, 0x1
    2a26: 01 e0        	ldi	r16, 0x1
    2a28: a4 df        	rcall	.-184
    2a2a: 9e e0        	ldi	r25, 0xe
    2a2c: 83 30        	cpi	r24, 0x3
    2a2e: 28 f0        	brlo	.+10
    2a30: 11 e0        	ldi	r17, 0x1
    2a32: 04 e0        	ldi	r16, 0x4
    2a34: 96 df        	rcall	.-212
    2a36: 83 50        	subi	r24, 0x3
    2a38: 0d c0        	rjmp	.+26
    2a3a: 82 30        	cpi	r24, 0x2
    2a3c: 18 f0        	brlo	.+6
    2a3e: 11 e0        	ldi	r17, 0x1
    2a40: 03 e0        	ldi	r16, 0x3
    2a42: 06 c0        	rjmp	.+12
    2a44: 88 23        	tst	r24
    2a46: 11 e0        	ldi	r17, 0x1
    2a48: 11 f0        	breq	.+4
    2a4a: 02 e0        	ldi	r16, 0x2
    2a4c: 01 c0        	rjmp	.+2
    2a4e: 01 e0        	ldi	r16, 0x1
    2a50: 88 df        	rcall	.-240
    2a52: 80 e0        	ldi	r24, 0x0
    2a54: 9a 95        	dec	r25
    2a56: 51 f7        	brne	.-44
    2a58: 8f be        	out	0x3f, r8
    2a5a: e9 e0        	ldi	r30, 0x9
    2a5c: 0c 94 fb 34  	<unknown>
    2a60: 08 1b        	sub	r16, r24
    2a62: 19 0b        	sbc	r17, r25
    2a64: 2a 0b        	sbc	r18, r26
    2a66: 3b 0b        	sbc	r19, r27
    2a68: 08 95        	ret
    2a6a: 0c 94 60 0f  	<unknown>
    2a6e: 02 85        	ldd	r16, Z+2
    2a70: 13 85        	ldd	r17, Z+3
    2a72: 24 85        	ldd	r18, Z+4
    2a74: 35 85        	ldd	r19, Z+5
    2a76: 82 81        	ldd	r24, Z+2
    2a78: 93 81        	ldd	r25, Z+3
    2a7a: a4 81        	ldd	r26, Z+4
    2a7c: b5 81        	ldd	r27, Z+5
    2a7e: 80 17        	cp	r24, r16
    2a80: 91 07        	cpc	r25, r17
    2a82: a2 07        	cpc	r26, r18
    2a84: b3 07        	cpc	r27, r19
    2a86: 08 95        	ret
    2a88: 05 e0        	ldi	r16, 0x5
    2a8a: 45 e4        	ldi	r20, 0x45
    2a8c: 50 e0        	ldi	r21, 0x0
    2a8e: 14 d0        	rcall	.+40
    2a90: 00 e0        	ldi	r16, 0x0
    2a92: 46 e4        	ldi	r20, 0x46
    2a94: 50 e0        	ldi	r21, 0x0
    2a96: 10 d0        	rcall	.+32
    2a98: 47 e4        	ldi	r20, 0x47
    2a9a: 50 e0        	ldi	r21, 0x0
    2a9c: 0d d0        	rcall	.+26
    2a9e: 05 e0        	ldi	r16, 0x5
    2aa0: 48 e4        	ldi	r20, 0x48
    2aa2: 50 e0        	ldi	r21, 0x0
    2aa4: 09 d0        	rcall	.+18
    2aa6: 00 e0        	ldi	r16, 0x0
    2aa8: 49 e4        	ldi	r20, 0x49
    2aaa: 50 e0        	ldi	r21, 0x0
    2aac: 05 d0        	rcall	.+10
    2aae: 4a e4        	ldi	r20, 0x4a
    2ab0: 50 e0        	ldi	r21, 0x0
    2ab2: 02 d0        	rcall	.+4
    2ab4: 4b e4        	ldi	r20, 0x4b
    2ab6: 50 e0        	ldi	r21, 0x0
    2ab8: 0c 94 a0 31  	<unknown>
    2abc: 00 23        	tst	r16
    2abe: 61 f0        	breq	.+24
    2ac0: 0e 94 be 10  	<unknown>
    2ac4: ea ea        	ldi	r30, 0xaa
    2ac6: f6 e0        	ldi	r31, 0x6
    2ac8: 00 83        	std	Z+0, r16
    2aca: 11 83        	std	Z+1, r17
    2acc: 47 e0        	ldi	r20, 0x7
    2ace: 22 e4        	ldi	r18, 0x42
    2ad0: 34 e0        	ldi	r19, 0x4
    2ad2: 0e 94 f5 10  	<unknown>
    2ad6: 20 c0        	rjmp	.+64
    2ad8: 2a d0        	rcall	.+84
    2ada: 0e 94 6f 11  	<unknown>
    2ade: 00 23        	tst	r16
    2ae0: e9 f0        	breq	.+58
    2ae2: 2a d0        	rcall	.+84
    2ae4: 01 30        	cpi	r16, 0x1
    2ae6: 11 f4        	brne	.+4
    2ae8: 2f ef        	ldi	r18, 0xff
    2aea: 32 d0        	rcall	.+100
    2aec: 25 d0        	rcall	.+74
    2aee: 04 30        	cpi	r16, 0x4
    2af0: 11 f4        	brne	.+4
    2af2: 21 e0        	ldi	r18, 0x1
    2af4: 2d d0        	rcall	.+90
    2af6: 20 d0        	rcall	.+64
    2af8: 31 f4        	brne	.+12
    2afa: 20 e0        	ldi	r18, 0x0
    2afc: 26 d0        	rcall	.+76
    2afe: 20 d0        	rcall	.+64
    2b00: 01 e0        	ldi	r16, 0x1
    2b02: 29 d0        	rcall	.+82
    2b04: 12 c0        	rjmp	.+36
    2b06: 00 91 39 07  	<unknown>
    2b0a: 05 30        	cpi	r16, 0x5
    2b0c: 11 f0        	breq	.+4
    2b0e: 05 38        	cpi	r16, 0x85
    2b10: 61 f4        	brne	.+24
    2b12: 0d d0        	rcall	.+26
    2b14: 0e 94 c9 10  	<unknown>
    2b18: 01 e0        	ldi	r16, 0x1
    2b1a: 08 95        	ret
    2b1c: 11 d0        	rcall	.+34
    2b1e: 00 e0        	ldi	r16, 0x0
    2b20: 1a d0        	rcall	.+52
    2b22: 01 30        	cpi	r16, 0x1
    2b24: 11 f4        	brne	.+4
    2b26: 21 e0        	ldi	r18, 0x1
    2b28: 10 d0        	rcall	.+32
    2b2a: 00 e0        	ldi	r16, 0x0
    2b2c: 08 95        	ret
    2b2e: ea ea        	ldi	r30, 0xaa
    2b30: f6 e0        	ldi	r31, 0x6
    2b32: 00 81        	ldd	r16, Z+0
    2b34: 11 81        	ldd	r17, Z+1
    2b36: 08 95        	ret
    2b38: 00 91 39 07  	<unknown>
    2b3c: 0f 70        	andi	r16, 0xf
    2b3e: 08 95        	ret
    2b40: f6 df        	rcall	.-20
    2b42: 0e 94 31 11  	<unknown>
    2b46: 10 2f        	mov	r17, r16
    2b48: 08 95        	ret
    2b4a: f1 df        	rcall	.-30
    2b4c: 0c 94 69 11  	<unknown>
    2b50: ee df        	rcall	.-36
    2b52: 0c 94 fa 10  	<unknown>
    2b56: 0e 94 f0 34  	<unknown>
    2b5a: af b7        	in	r26, 0x3f
    2b5c: f8 94        	cli
    2b5e: 30 e0        	ldi	r19, 0x0
    2b60: 85 e4        	ldi	r24, 0x45
    2b62: 90 e0        	ldi	r25, 0x0
    2b64: 81 0f        	add	r24, r17
    2b66: 93 1f        	adc	r25, r19
    2b68: 00 23        	tst	r16
    2b6a: e9 f0        	breq	.+58
    2b6c: 0e 94 2d 0b  	<unknown>
    2b70: ec ea        	ldi	r30, 0xac
    2b72: f6 e0        	ldi	r31, 0x6
    2b74: 00 83        	std	Z+0, r16
    2b76: 11 83        	std	Z+1, r17
    2b78: 20 e3        	ldi	r18, 0x30
    2b7a: 34 e0        	ldi	r19, 0x4
    2b7c: 0e 94 71 0b  	<unknown>
    2b80: ac 01 0e 94  	<unknown>
    2b84: 86 31        	cpi	r24, 0x16
    2b86: 40 2f        	mov	r20, r16
    2b88: 23 d0        	rcall	.+70
    2b8a: 0e 94 68 0b  	<unknown>
    2b8e: 0e e1        	ldi	r16, 0x1e
    2b90: 10 e0        	ldi	r17, 0x0
    2b92: 1a 93        	st	-Y, r17
    2b94: 1a 93        	st	-Y, r17
    2b96: 1a 93        	st	-Y, r17
    2b98: 0a 93        	st	-Y, r16
    2b9a: 40 e0        	ldi	r20, 0x0
    2b9c: 19 d0        	rcall	.+50
    2b9e: 0e 94 59 0b  	<unknown>
    2ba2: 01 e0        	ldi	r16, 0x1
    2ba4: 11 c0        	rjmp	.+34
    2ba6: 20 91 39 07  	<unknown>
    2baa: 15 d0        	rcall	.+42
    2bac: 0e 94 95 0b  	<unknown>
    2bb0: 01 30        	cpi	r16, 0x1
    2bb2: 49 f4        	brne	.+18
    2bb4: 10 d0        	rcall	.+32
    2bb6: 0e 94 6b 0b  	<unknown>
    2bba: ac 01 7d df  	<unknown>
    2bbe: 0b d0        	rcall	.+22
    2bc0: 0e 94 33 0b  	<unknown>
    2bc4: ee cf        	rjmp	.-36
    2bc6: 00 e0        	ldi	r16, 0x0
    2bc8: af bf        	out	0x3f, r26
    2bca: e3 e0        	ldi	r30, 0x3
    2bcc: 0c 94 01 35  	<unknown>
    2bd0: 50 e0        	ldi	r21, 0x0
    2bd2: 60 e0        	ldi	r22, 0x0
    2bd4: 70 e0        	ldi	r23, 0x0
    2bd6: ec ea        	ldi	r30, 0xac
    2bd8: f6 e0        	ldi	r31, 0x6
    2bda: ab cf        	rjmp	.-170
    2bdc: 5d 9b        	sbis	0xb, 0x5
    2bde: fe cf        	rjmp	.-4
    2be0: 0c b9        	out	0xc, r16
    2be2: 08 95        	ret
    2be4: 5f 99        	sbic	0xb, 0x7
    2be6: 02 c0        	rjmp	.+4
    2be8: 00 e0        	ldi	r16, 0x0
    2bea: 08 95        	ret
    2bec: 2c b1        	in	r18, 0xc
    2bee: f8 01 20 83  	<unknown>
    2bf2: 01 e0        	ldi	r16, 0x1
    2bf4: 08 95        	ret
    2bf6: 0c e0        	ldi	r16, 0xc
    2bf8: 09 b9        	out	0x9, r16
    2bfa: 02 e0        	ldi	r16, 0x2
    2bfc: 0b b9        	out	0xb, r16
    2bfe: 08 e1        	ldi	r16, 0x18
    2c00: 0a b9        	out	0xa, r16
    2c02: 0e e8        	ldi	r16, 0x8e
    2c04: 00 bd        	out	0x20, r16
    2c06: 08 95        	ret
    2c08: 0e 94 ec 34  	<unknown>
    2c0c: 6f b6        	in	r6, 0x3f
    2c0e: f8 94        	cli
    2c10: c8 01 29 01  	<unknown>
    2c14: a0 e0        	ldi	r26, 0x0
    2c16: b0 e0        	ldi	r27, 0x0
    2c18: 07 c0        	rjmp	.+14
    2c1a: ac 01 4a 0f  	<unknown>
    2c1e: 5b 1f        	adc	r21, r27
    2c20: 0e 94 86 31  	<unknown>
    2c24: db df        	rcall	.-74
    2c26: 11 96 a4 15  	<unknown>
    2c2a: b5 05        	cpc	r27, r5
    2c2c: b0 f3        	brlo	.-20
    2c2e: 6f be        	out	0x3f, r6
    2c30: e7 e0        	ldi	r30, 0x7
    2c32: 0c 94 fd 34  	<unknown>
    2c36: 0e 94 ed 34  	<unknown>
    2c3a: d8 01 29 01  	<unknown>
    2c3e: 80 e0        	ldi	r24, 0x0
    2c40: 90 e0        	ldi	r25, 0x0
    2c42: 06 c0        	rjmp	.+12
    2c44: fd 01 e8 0f  	<unknown>
    2c48: f9 1f        	adc	r31, r25
    2c4a: 00 81        	ldd	r16, Z+0
    2c4c: c7 df        	rcall	.-114
    2c4e: 01 96 84 15  	<unknown>
    2c52: 95 05        	cpc	r25, r5
    2c54: b8 f3        	brlo	.-18
    2c56: e6 e0        	ldi	r30, 0x6
    2c58: 0c 94 fe 34  	<unknown>
    2c5c: 19 2e        	mov	r1, r25
    2c5e: 28 2e        	mov	r2, r24
    2c60: 7f b7        	in	r23, 0x3f
    2c62: f8 94        	cli
    2c64: 60 2f        	mov	r22, r16
    2c66: 80 e0        	ldi	r24, 0x0
    2c68: 90 e0        	ldi	r25, 0x0
    2c6a: 0a c0        	rjmp	.+20
    2c6c: 5f 9b        	sbis	0xb, 0x7
    2c6e: fe cf        	rjmp	.-4
    2c70: 0c b1        	in	r16, 0xc
    2c72: 46 2f        	mov	r20, r22
    2c74: 51 2f        	mov	r21, r17
    2c76: 48 0f        	add	r20, r24
    2c78: 59 1f        	adc	r21, r25
    2c7a: 0e 94 a0 31  	<unknown>
    2c7e: 01 96 82 17  	<unknown>
    2c82: 93 07        	cpc	r25, r19
    2c84: 98 f3        	brlo	.-26
    2c86: 01 e0        	ldi	r16, 0x1
    2c88: 7f bf        	out	0x3f, r23
    2c8a: 82 2d        	mov	r24, r2
    2c8c: 91 2d        	mov	r25, r1
    2c8e: 08 95        	ret
    2c90: 59 2f        	mov	r21, r25
    2c92: 68 2f        	mov	r22, r24
    2c94: 80 e0        	ldi	r24, 0x0
    2c96: 90 e0        	ldi	r25, 0x0
    2c98: 08 c0        	rjmp	.+16
    2c9a: 5f 9b        	sbis	0xb, 0x7
    2c9c: fe cf        	rjmp	.-4
    2c9e: 4c b1        	in	r20, 0xc
    2ca0: f8 01 e8 0f  	<unknown>
    2ca4: f9 1f        	adc	r31, r25
    2ca6: 40 83        	std	Z+0, r20
    2ca8: 01 96 82 17  	<unknown>
    2cac: 93 07        	cpc	r25, r19
    2cae: a8 f3        	brlo	.-22
    2cb0: 01 e0        	ldi	r16, 0x1
    2cb2: 86 2f        	mov	r24, r22
    2cb4: 95 2f        	mov	r25, r21
    2cb6: 08 95        	ret
    2cb8: 0a e0        	ldi	r16, 0xa
    2cba: 10 e0        	ldi	r17, 0x0
    2cbc: 0e 94 3e 35  	<unknown>
    2cc0: 20 2f        	mov	r18, r16
    2cc2: 21 2b        	or	r18, r17
    2cc4: 09 f0        	breq	.+2
    2cc6: 11 c0        	rjmp	.+34
    2cc8: 00 e0        	ldi	r16, 0x0
    2cca: 10 e0        	ldi	r17, 0x0
    2ccc: 08 95        	ret
    2cce: 9a 93        	st	-Y, r25
    2cd0: 8a 93        	st	-Y, r24
    2cd2: c8 01 01 2b  	<unknown>
    2cd6: 31 f0        	breq	.+12
    2cd8: 08 2f        	mov	r16, r24
    2cda: 0e 94 7f 11  	<unknown>
    2cde: 8c 01 0e 94  	<unknown>
    2ce2: 76 31        	cpi	r23, 0x16
    2ce4: 89 91        	ld	r24, Y+
    2ce6: 99 91        	ld	r25, Y+
    2ce8: 08 95        	ret
    2cea: ba 93        	st	-Y, r27
    2cec: aa 93        	st	-Y, r26
    2cee: d8 01 0e 94  	<unknown>
    2cf2: 75 11        	cpse	r23, r5
    2cf4: 00 e0        	ldi	r16, 0x0
    2cf6: 19 96 0c 93  	<unknown>
    2cfa: 19 97 8d 01  	<unknown>
    2cfe: a9 91        	ld	r26, Y+
    2d00: b9 91        	ld	r27, Y+
    2d02: 08 95        	ret
    2d04: 0e 94 ed 34  	<unknown>
    2d08: 28 01 5f d0  	<unknown>
    2d0c: d8 01 5d d0  	<unknown>
    2d10: c8 01 f2 01  	<unknown>
    2d14: 05 81        	ldd	r16, Z+5
    2d16: 5d d0        	rcall	.+186
    2d18: 04 81        	ldd	r16, Z+4
    2d1a: 5c d0        	rcall	.+184
    2d1c: 03 81        	ldd	r16, Z+3
    2d1e: 5a d0        	rcall	.+180
    2d20: 29 eb        	ldi	r18, 0xb9
    2d22: 34 e0        	ldi	r19, 0x4
    2d24: 8d 01 0e 94  	<unknown>
    2d28: b5 35        	cpi	r27, 0x55
    2d2a: 26 96 f2 01  	<unknown>
    2d2e: 00 85        	ldd	r16, Z+0
    2d30: 50 d0        	rcall	.+160
    2d32: 07 81        	ldd	r16, Z+7
    2d34: 4f d0        	rcall	.+158
    2d36: 06 81        	ldd	r16, Z+6
    2d38: 4d d0        	rcall	.+154
    2d3a: 28 ec        	ldi	r18, 0xc8
    2d3c: 34 e0        	ldi	r19, 0x4
    2d3e: 8c 01 0e 94  	<unknown>
    2d42: b5 35        	cpi	r27, 0x55
    2d44: 26 96 82 99  	<unknown>
    2d48: 26 c0        	rjmp	.+76
    2d4a: f2 01 02 81  	<unknown>
    2d4e: 0f 70        	andi	r16, 0xf
    2d50: 03 30        	cpi	r16, 0x3
    2d52: 09 f1        	breq	.+66
    2d54: 02 30        	cpi	r16, 0x2
    2d56: f9 f0        	breq	.+62
    2d58: 01 85        	ldd	r16, Z+1
    2d5a: 00 23        	tst	r16
    2d5c: 59 f0        	breq	.+22
    2d5e: 0a 95        	dec	r16
    2d60: 59 f0        	breq	.+22
    2d62: 0a 95        	dec	r16
    2d64: 61 f0        	breq	.+24
    2d66: 0a 95        	dec	r16
    2d68: 61 f0        	breq	.+24
    2d6a: 0a 95        	dec	r16
    2d6c: 61 f0        	breq	.+24
    2d6e: 0a 95        	dec	r16
    2d70: 61 f0        	breq	.+24
    2d72: 11 c0        	rjmp	.+34
    2d74: 38 d0        	rcall	.+112
    2d76: 0d c0        	rjmp	.+26
    2d78: 36 d0        	rcall	.+108
    2d7a: 0d 5f        	subi	r16, 0xfd
    2d7c: 09 c0        	rjmp	.+18
    2d7e: 33 d0        	rcall	.+102
    2d80: 06 c0        	rjmp	.+12
    2d82: 2b d0        	rcall	.+86
    2d84: 06 c0        	rjmp	.+12
    2d86: 29 d0        	rcall	.+82
    2d88: f8 cf        	rjmp	.-16
    2d8a: 44 e0        	ldi	r20, 0x4
    2d8c: 27 d0        	rcall	.+78
    2d8e: 0a 5f        	subi	r16, 0xfa
    2d90: 1f 4f        	sbci	r17, 0xff
    2d92: 0e 94 33 35  	<unknown>
    2d96: 10 e0        	ldi	r17, 0x0
    2d98: 08 e0        	ldi	r16, 0x8
    2d9a: 0e 94 29 0f  	<unknown>
    2d9e: 8d 01 0e 94  	<unknown>
    2da2: 5d 35        	cpi	r21, 0x5d
    2da4: 11 e0        	ldi	r17, 0x1
    2da6: 06 e0        	ldi	r16, 0x6
    2da8: 0e 94 29 0f  	<unknown>
    2dac: 8c 01 0e 94  	<unknown>
    2db0: 5d 35        	cpi	r21, 0x5d
    2db2: 00 e0        	ldi	r16, 0x0
    2db4: 00 93 35 07  	<unknown>
    2db8: 8d 01 0e 94  	<unknown>
    2dbc: 74 31        	cpi	r23, 0x14
    2dbe: 8c 01 0e 94  	<unknown>
    2dc2: 74 31        	cpi	r23, 0x14
    2dc4: e6 e0        	ldi	r30, 0x6
    2dc6: 0c 94 fe 34  	<unknown>
    2dca: 05 e1        	ldi	r16, 0x15
    2dcc: 10 e0        	ldi	r17, 0x0
    2dce: 0c 94 3c 35  	<unknown>
    2dd2: 10 e0        	ldi	r17, 0x0
    2dd4: 1a 93        	st	-Y, r17
    2dd6: 0a 93        	st	-Y, r16
    2dd8: 08 95        	ret
    2dda: 42 e0        	ldi	r20, 0x2
    2ddc: 50 e0        	ldi	r21, 0x0
    2dde: 20 e2        	ldi	r18, 0x20
    2de0: 30 e0        	ldi	r19, 0x0
    2de2: 8c 01 08 95  	<unknown>
    2de6: 42 e0        	ldi	r20, 0x2
    2de8: 50 e0        	ldi	r21, 0x0
    2dea: 20 e2        	ldi	r18, 0x20
    2dec: 30 e0        	ldi	r19, 0x0
    2dee: 8d 01 08 95  	<unknown>
    2df2: f8 01 2f 70  	<unknown>
    2df6: 22 83        	std	Z+2, r18
    2df8: 03 81        	ldd	r16, Z+3
    2dfa: 08 31        	cpi	r16, 0x18
    2dfc: 10 f0        	brlo	.+4
    2dfe: 00 e0        	ldi	r16, 0x0
    2e00: 03 83        	std	Z+3, r16
    2e02: 04 81        	ldd	r16, Z+4
    2e04: 0c 33        	cpi	r16, 0x3c
    2e06: 10 f0        	brlo	.+4
    2e08: 00 e0        	ldi	r16, 0x0
    2e0a: 04 83        	std	Z+4, r16
    2e0c: 05 81        	ldd	r16, Z+5
    2e0e: 0c 33        	cpi	r16, 0x3c
    2e10: 10 f0        	brlo	.+4
    2e12: 00 e0        	ldi	r16, 0x0
    2e14: 05 83        	std	Z+5, r16
    2e16: 06 81        	ldd	r16, Z+6
    2e18: 00 32        	cpi	r16, 0x20
    2e1a: 10 f0        	brlo	.+4
    2e1c: 01 e0        	ldi	r16, 0x1
    2e1e: 06 83        	std	Z+6, r16
    2e20: 07 81        	ldd	r16, Z+7
    2e22: 0d 30        	cpi	r16, 0xd
    2e24: 10 f0        	brlo	.+4
    2e26: 01 e0        	ldi	r16, 0x1
    2e28: 07 83        	std	Z+7, r16
    2e2a: 00 85        	ldd	r16, Z+0
    2e2c: 04 36        	cpi	r16, 0x64
    2e2e: 10 f0        	brlo	.+4
    2e30: 00 e0        	ldi	r16, 0x0
    2e32: 00 87        	std	Z+0, r16
    2e34: 02 2f        	mov	r16, r18
    2e36: 22 30        	cpi	r18, 0x2
    2e38: 21 f4        	brne	.+8
    2e3a: 11 85        	ldd	r17, Z+1
    2e3c: 1a 95        	dec	r17
    2e3e: 11 87        	std	Z+1, r17
    2e40: 91 c0        	rjmp	.+290
    2e42: 23 30        	cpi	r18, 0x3
    2e44: 19 f4        	brne	.+6
    2e46: 11 85        	ldd	r17, Z+1
    2e48: 13 95        	inc	r17
    2e4a: f9 cf        	rjmp	.-14
    2e4c: 24 30        	cpi	r18, 0x4
    2e4e: 19 f0        	breq	.+6
    2e50: 21 30        	cpi	r18, 0x1
    2e52: 09 f0        	breq	.+2
    2e54: 87 c0        	rjmp	.+270
    2e56: 11 85        	ldd	r17, Z+1
    2e58: 11 23        	tst	r17
    2e5a: 71 f0        	breq	.+28
    2e5c: 1a 95        	dec	r17
    2e5e: 11 f1        	breq	.+68
    2e60: 1a 95        	dec	r17
    2e62: b1 f1        	breq	.+108
    2e64: 1a 95        	dec	r17
    2e66: 09 f4        	brne	.+2
    2e68: 47 c0        	rjmp	.+142
    2e6a: 1a 95        	dec	r17
    2e6c: 09 f4        	brne	.+2
    2e6e: 56 c0        	rjmp	.+172
    2e70: 1a 95        	dec	r17
    2e72: 09 f4        	brne	.+2
    2e74: 65 c0        	rjmp	.+202
    2e76: 76 c0        	rjmp	.+236
    2e78: 21 30        	cpi	r18, 0x1
    2e7a: 49 f4        	brne	.+18
    2e7c: 13 81        	ldd	r17, Z+3
    2e7e: 13 95        	inc	r17
    2e80: 13 83        	std	Z+3, r17
    2e82: 18 31        	cpi	r17, 0x18
    2e84: 08 f4        	brsh	.+2
    2e86: 6e c0        	rjmp	.+220
    2e88: 10 e0        	ldi	r17, 0x0
    2e8a: 13 83        	std	Z+3, r17
    2e8c: 6b c0        	rjmp	.+214
    2e8e: 24 30        	cpi	r18, 0x4
    2e90: 09 f0        	breq	.+2
    2e92: 68 c0        	rjmp	.+208
    2e94: 13 81        	ldd	r17, Z+3
    2e96: 1a 95        	dec	r17
    2e98: 13 83        	std	Z+3, r17
    2e9a: 1f 3f        	cpi	r17, 0xff
    2e9c: 09 f0        	breq	.+2
    2e9e: 62 c0        	rjmp	.+196
    2ea0: 17 e1        	ldi	r17, 0x17
    2ea2: f3 cf        	rjmp	.-26
    2ea4: 21 30        	cpi	r18, 0x1
    2ea6: 49 f4        	brne	.+18
    2ea8: 14 81        	ldd	r17, Z+4
    2eaa: 13 95        	inc	r17
    2eac: 14 83        	std	Z+4, r17
    2eae: 1c 33        	cpi	r17, 0x3c
    2eb0: 08 f4        	brsh	.+2
    2eb2: 58 c0        	rjmp	.+176
    2eb4: 10 e0        	ldi	r17, 0x0
    2eb6: 14 83        	std	Z+4, r17
    2eb8: 55 c0        	rjmp	.+170
    2eba: 24 30        	cpi	r18, 0x4
    2ebc: 09 f0        	breq	.+2
    2ebe: 52 c0        	rjmp	.+164
    2ec0: 14 81        	ldd	r17, Z+4
    2ec2: 1a 95        	dec	r17
    2ec4: 14 83        	std	Z+4, r17
    2ec6: 1f 3f        	cpi	r17, 0xff
    2ec8: 09 f0        	breq	.+2
    2eca: 4c c0        	rjmp	.+152
    2ecc: 1b e3        	ldi	r17, 0x3b
    2ece: f3 cf        	rjmp	.-26
    2ed0: 21 30        	cpi	r18, 0x1
    2ed2: 49 f4        	brne	.+18
    2ed4: 15 81        	ldd	r17, Z+5
    2ed6: 13 95        	inc	r17
    2ed8: 15 83        	std	Z+5, r17
    2eda: 1c 33        	cpi	r17, 0x3c
    2edc: 08 f4        	brsh	.+2
    2ede: 42 c0        	rjmp	.+132
    2ee0: 10 e0        	ldi	r17, 0x0
    2ee2: 15 83        	std	Z+5, r17
    2ee4: 3f c0        	rjmp	.+126
    2ee6: 24 30        	cpi	r18, 0x4
    2ee8: e9 f5        	brne	.+122
    2eea: 15 81        	ldd	r17, Z+5
    2eec: 1a 95        	dec	r17
    2eee: 15 83        	std	Z+5, r17
    2ef0: 1f 3f        	cpi	r17, 0xff
    2ef2: c1 f5        	brne	.+112
    2ef4: 1b e3        	ldi	r17, 0x3b
    2ef6: f5 cf        	rjmp	.-22
    2ef8: 21 30        	cpi	r18, 0x1
    2efa: 41 f4        	brne	.+16
    2efc: 16 81        	ldd	r17, Z+6
    2efe: 13 95        	inc	r17
    2f00: 16 83        	std	Z+6, r17
    2f02: 10 32        	cpi	r17, 0x20
    2f04: 78 f1        	brlo	.+94
    2f06: 11 e0        	ldi	r17, 0x1
    2f08: 16 83        	std	Z+6, r17
    2f0a: 2c c0        	rjmp	.+88
    2f0c: 24 30        	cpi	r18, 0x4
    2f0e: 51 f5        	brne	.+84
    2f10: 16 81        	ldd	r17, Z+6
    2f12: 1a 95        	dec	r17
    2f14: 16 83        	std	Z+6, r17
    2f16: 31 f5        	brne	.+76
    2f18: 1f e1        	ldi	r17, 0x1f
    2f1a: f6 cf        	rjmp	.-20
    2f1c: 21 30        	cpi	r18, 0x1
    2f1e: 41 f4        	brne	.+16
    2f20: 17 81        	ldd	r17, Z+7
    2f22: 13 95        	inc	r17
    2f24: 17 83        	std	Z+7, r17
    2f26: 1d 30        	cpi	r17, 0xd
    2f28: e8 f0        	brlo	.+58
    2f2a: 11 e0        	ldi	r17, 0x1
    2f2c: 17 83        	std	Z+7, r17
    2f2e: 1a c0        	rjmp	.+52
    2f30: 24 30        	cpi	r18, 0x4
    2f32: c1 f4        	brne	.+48
    2f34: 17 81        	ldd	r17, Z+7
    2f36: 1a 95        	dec	r17
    2f38: 17 83        	std	Z+7, r17
    2f3a: a1 f4        	brne	.+40
    2f3c: 1c e0        	ldi	r17, 0xc
    2f3e: f6 cf        	rjmp	.-20
    2f40: 21 30        	cpi	r18, 0x1
    2f42: 39 f4        	brne	.+14
    2f44: 10 85        	ldd	r17, Z+0
    2f46: 13 95        	inc	r17
    2f48: 10 87        	std	Z+0, r17
    2f4a: 14 36        	cpi	r17, 0x64
    2f4c: 58 f0        	brlo	.+22
    2f4e: 10 e0        	ldi	r17, 0x0
    2f50: 08 c0        	rjmp	.+16
    2f52: 24 30        	cpi	r18, 0x4
    2f54: 39 f4        	brne	.+14
    2f56: 10 85        	ldd	r17, Z+0
    2f58: 1a 95        	dec	r17
    2f5a: 10 87        	std	Z+0, r17
    2f5c: 1f 3f        	cpi	r17, 0xff
    2f5e: 11 f4        	brne	.+4
    2f60: 13 e6        	ldi	r17, 0x63
    2f62: 10 87        	std	Z+0, r17
    2f64: 21 85        	ldd	r18, Z+1
    2f66: 25 36        	cpi	r18, 0x65
    2f68: 10 f0        	brlo	.+4
    2f6a: 15 e0        	ldi	r17, 0x5
    2f6c: 03 c0        	rjmp	.+6
    2f6e: 26 30        	cpi	r18, 0x6
    2f70: 10 f0        	brlo	.+4
    2f72: 10 e0        	ldi	r17, 0x0
    2f74: 11 87        	std	Z+1, r17
    2f76: 10 91 35 07  	<unknown>
    2f7a: 11 23        	tst	r17
    2f7c: 11 f4        	brne	.+4
    2f7e: 0f 3f        	cpi	r16, 0xff
    2f80: 11 f0        	breq	.+4
    2f82: 8f 01 bf de  	<unknown>
    2f86: 08 95        	ret
    2f88: 9e d5        	rcall	.+2876
    2f8a: 80 2f        	mov	r24, r16
    2f8c: 8f 71        	andi	r24, 0x1f
    2f8e: e8 2f        	mov	r30, r24
    2f90: 8e d5        	rcall	.+2844
    2f92: 08 ed        	ldi	r16, 0xd8
    2f94: 14 e0        	ldi	r17, 0x4
    2f96: 9a d5        	rcall	.+2868
    2f98: 08 2f        	mov	r16, r24
    2f9a: 10 e0        	ldi	r17, 0x0
    2f9c: 45 e1        	ldi	r20, 0x15
    2f9e: 50 e0        	ldi	r21, 0x0
    2fa0: 3b d5        	rcall	.+2678
    2fa2: 0e 94 cf 1f  	<unknown>
    2fa6: c9 d7        	rcall	.+3986
    2fa8: d1 f0        	breq	.+52
    2faa: 1e d5        	rcall	.+2620
    2fac: 0f 77        	andi	r16, 0x7f
    2fae: 7e d5        	rcall	.+2812
    2fb0: 0d ed        	ldi	r16, 0xdd
    2fb2: 14 e0        	ldi	r17, 0x4
    2fb4: 8b d5        	rcall	.+2838
    2fb6: ac 01 18 d0  	<unknown>
    2fba: 0f 73        	andi	r16, 0x3f
    2fbc: 10 e0        	ldi	r17, 0x0
    2fbe: f7 d4        	rcall	.+2542
    2fc0: 1a d5        	rcall	.+2612
    2fc2: 0f 71        	andi	r16, 0x1f
    2fc4: f4 d4        	rcall	.+2536
    2fc6: 0b d5        	rcall	.+2582
    2fc8: 0f 73        	andi	r16, 0x3f
    2fca: f1 d4        	rcall	.+2530
    2fcc: 06 96 07 d5  	<unknown>
    2fd0: 0f 71        	andi	r16, 0x1f
    2fd2: ed d4        	rcall	.+2522
    2fd4: 02 ee        	ldi	r16, 0xe2
    2fd6: 14 e0        	ldi	r17, 0x4
    2fd8: 65 d5        	rcall	.+2762
    2fda: 28 96 03 c0  	<unknown>
    2fde: 06 ef        	ldi	r16, 0xf6
    2fe0: 14 e0        	ldi	r17, 0x4
    2fe2: 60 d5        	rcall	.+2752
    2fe4: 89 91        	ld	r24, Y+
    2fe6: 99 91        	ld	r25, Y+
    2fe8: 08 95        	ret
    2fea: 49 5f        	subi	r20, 0xf9
    2fec: 98 c7        	rjmp	.+3888
    2fee: 8a 93        	st	-Y, r24
    2ff0: 80 2f        	mov	r24, r16
    2ff2: d6 d4        	rcall	.+2476
    2ff4: 00 91 b4 06  	<unknown>
    2ff8: 08 0f        	add	r16, r24
    2ffa: 0f 71        	andi	r16, 0x1f
    2ffc: 00 93 b4 06  	<unknown>
    3000: 32 d5        	rcall	.+2660
    3002: 04 e0        	ldi	r16, 0x4
    3004: 15 e0        	ldi	r17, 0x5
    3006: 65 d5        	rcall	.+2762
    3008: 00 91 b4 06  	<unknown>
    300c: bd df        	rcall	.-134
    300e: 89 91        	ld	r24, Y+
    3010: 08 95        	ret
    3012: 00 e0        	ldi	r16, 0x0
    3014: 00 93 b4 06  	<unknown>
    3018: ea cf        	rjmp	.-44
    301a: 0e 94 e5 34  	<unknown>
    301e: df b6        	in	r13, 0x3f
    3020: f8 94        	cli
    3022: a8 97 c0 2e  	<unknown>
    3026: ae ea        	ldi	r26, 0xae
    3028: b6 e0        	ldi	r27, 0x6
    302a: ab d4        	rcall	.+2390
    302c: b7 d7        	rcall	.+3950
    302e: 50 90 b7 06  	<unknown>
    3032: 4c 2c        	mov	r4, r12
    3034: 0f e0        	ldi	r16, 0xf
    3036: 40 22        	and	r4, r16
    3038: 00 91 b6 06  	<unknown>
    303c: e0 ef        	ldi	r30, 0xf0
    303e: fb e0        	ldi	r31, 0xb
    3040: 0c 94 93 34  	<unknown>
    3044: 04 2d        	mov	r16, r4
    3046: 44 20        	tst	r4
    3048: 91 f0        	breq	.+36
    304a: 0a 95        	dec	r16
    304c: 59 f0        	breq	.+22
    304e: 0a 95        	dec	r16
    3050: 49 f0        	breq	.+18
    3052: 0a 95        	dec	r16
    3054: 51 f0        	breq	.+20
    3056: 0a 95        	dec	r16
    3058: 41 f0        	breq	.+16
    305a: 0a 95        	dec	r16
    305c: 09 f0        	breq	.+2
    305e: d8 c3        	rjmp	.+1968
    3060: 01 e0        	ldi	r16, 0x1
    3062: d7 c3        	rjmp	.+1966
    3064: 0f ef        	ldi	r16, 0xff
    3066: c3 df        	rcall	.-122
    3068: d3 c3        	rjmp	.+1958
    306a: 01 e0        	ldi	r16, 0x1
    306c: fc cf        	rjmp	.-8
    306e: 24 d5        	rcall	.+2632
    3070: 08 e2        	ldi	r16, 0x28
    3072: 15 e0        	ldi	r17, 0x5
    3074: 2b d5        	rcall	.+2646
    3076: fc d4        	rcall	.+2552
    3078: 19 f0        	breq	.+6
    307a: 05 e3        	ldi	r16, 0x35
    307c: 15 e0        	ldi	r17, 0x5
    307e: 02 c0        	rjmp	.+4
    3080: 06 e4        	ldi	r16, 0x46
    3082: 15 e0        	ldi	r17, 0x5
    3084: 0f d5        	rcall	.+2590
    3086: 01 e0        	ldi	r16, 0x1
    3088: 69 d4        	rcall	.+2258
    308a: c2 c3        	rjmp	.+1924
    308c: 64 d4        	rcall	.+2248
    308e: 11 f4        	brne	.+4
    3090: 7b d4        	rcall	.+2294
    3092: 64 d4        	rcall	.+2248
    3094: 04 2d        	mov	r16, r4
    3096: 44 20        	tst	r4
    3098: a9 f0        	breq	.+42
    309a: 01 50        	subi	r16, 0x1
    309c: 10 f0        	brlo	.+4
    309e: 04 50        	subi	r16, 0x4
    30a0: 08 f0        	brlo	.+2
    30a2: b6 c3        	rjmp	.+1900
    30a4: bb d4        	rcall	.+2422
    30a6: 0e 94 82 20  	<unknown>
    30aa: 10 e8        	ldi	r17, 0x80
    30ac: 01 27        	eor	r16, r17
    30ae: 2d 5f        	subi	r18, 0xfd
    30b0: 15 d7        	rcall	.+3626
    30b2: de d4        	rcall	.+2492
    30b4: 21 f0        	breq	.+8
    30b6: 05 e3        	ldi	r16, 0x35
    30b8: 15 e0        	ldi	r17, 0x5
    30ba: f4 d4        	rcall	.+2536
    30bc: a9 c3        	rjmp	.+1874
    30be: 06 e4        	ldi	r16, 0x46
    30c0: 15 e0        	ldi	r17, 0x5
    30c2: fb cf        	rjmp	.-10
    30c4: f9 d4        	rcall	.+2546
    30c6: 07 e5        	ldi	r16, 0x57
    30c8: 15 e0        	ldi	r17, 0x5
    30ca: 00 d5        	rcall	.+2560
    30cc: 10 e0        	ldi	r17, 0x0
    30ce: 03 e0        	ldi	r16, 0x3
    30d0: 65 d4        	rcall	.+2250
    30d2: 01 e6        	ldi	r16, 0x61
    30d4: 15 e0        	ldi	r17, 0x5
    30d6: e6 d4        	rcall	.+2508
    30d8: cc d4        	rcall	.+2456
    30da: e9 f0        	breq	.+58
    30dc: 0e 94 5c 16  	<unknown>
    30e0: 0d 93        	st	X+, r16
    30e2: 1c 93        	st	X, r17
    30e4: 11 97 02 e0  	<unknown>
    30e8: 39 d4        	rcall	.+2162
    30ea: 22 e5        	ldi	r18, 0x52
    30ec: 30 e0        	ldi	r19, 0x0
    30ee: d1 d4        	rcall	.+2466
    30f0: cb d4        	rcall	.+2454
    30f2: 03 83        	std	Z+3, r16
    30f4: 9e d4        	rcall	.+2364
    30f6: 56 d4        	rcall	.+2220
    30f8: 2d e4        	ldi	r18, 0x4d
    30fa: 30 e0        	ldi	r19, 0x0
    30fc: ae d4        	rcall	.+2396
    30fe: 25 e5        	ldi	r18, 0x55
    3100: 30 e0        	ldi	r19, 0x0
    3102: bc d4        	rcall	.+2424
    3104: 13 d4        	rcall	.+2086
    3106: 2f e4        	ldi	r18, 0x4f
    3108: 30 e0        	ldi	r19, 0x0
    310a: c3 d4        	rcall	.+2438
    310c: 0f 77        	andi	r16, 0x7f
    310e: ed 91        	ld	r30, X+
    3110: fc 91        	ld	r31, X
    3112: 00 87        	std	Z+0, r16
    3114: 7d c3        	rjmp	.+1786
    3116: 00 e0        	ldi	r16, 0x0
    3118: 21 d4        	rcall	.+2114
    311a: a5 cf        	rjmp	.-182
    311c: 16 d4        	rcall	.+2092
    311e: 31 f4        	brne	.+12
    3120: 0d 91        	ld	r16, X+
    3122: 1c 91        	ld	r17, X
    3124: 0e 94 67 16  	<unknown>
    3128: 2f d4        	rcall	.+2142
    312a: ae cf        	rjmp	.-164
    312c: cc 20        	tst	r12
    312e: 09 f0        	breq	.+2
    3130: 6f c3        	rjmp	.+1758
    3132: 03 e0        	ldi	r16, 0x3
    3134: 13 d4        	rcall	.+2086
    3136: 10 e0        	ldi	r17, 0x0
    3138: 31 d4        	rcall	.+2146
    313a: 07 e6        	ldi	r16, 0x67
    313c: 15 e0        	ldi	r17, 0x5
    313e: b2 d4        	rcall	.+2404
    3140: 94 d4        	rcall	.+2344
    3142: 00 7e        	andi	r16, 0xe0
    3144: fe d3        	rcall	.+2044
    3146: 4a 5f        	subi	r20, 0xfa
    3148: 3d d4        	rcall	.+2170
    314a: eb d3        	rcall	.+2006
    314c: c8 d6        	rcall	.+3472
    314e: a9 01 4f 5f  	<unknown>
    3152: 3f d4        	rcall	.+2174
    3154: 4f 5f        	subi	r20, 0xff
    3156: 33 d4        	rcall	.+2150
    3158: 47 5f        	subi	r20, 0xf7
    315a: 36 d4        	rcall	.+2156
    315c: 47 5f        	subi	r20, 0xf7
    315e: 3d d4        	rcall	.+2170
    3160: 00 7f        	andi	r16, 0xf0
    3162: 17 81        	ldd	r17, Z+7
    3164: 1f 70        	andi	r17, 0xf
    3166: 29 d4        	rcall	.+2130
    3168: cf d7        	rcall	.+3998
    316a: 10 85        	ldd	r17, Z+0
    316c: 1f 77        	andi	r17, 0x7f
    316e: 2f d4        	rcall	.+2142
    3170: 4d 5f        	subi	r20, 0xfd
    3172: de d6        	rcall	.+3516
    3174: b6 d6        	rcall	.+3436
    3176: 0f 71        	andi	r16, 0x1f
    3178: 11 97 03 83  	<unknown>
    317c: 23 e5        	ldi	r18, 0x53
    317e: 30 e0        	ldi	r19, 0x0
    3180: 88 d4        	rcall	.+2320
    3182: 10 d4        	rcall	.+2080
    3184: 24 e5        	ldi	r18, 0x54
    3186: 30 e0        	ldi	r19, 0x0
    3188: 68 d4        	rcall	.+2256
    318a: 26 e5        	ldi	r18, 0x56
    318c: 30 e0        	ldi	r19, 0x0
    318e: 76 d4        	rcall	.+2284
    3190: 02 95        	swap	r16
    3192: cc d3        	rcall	.+1944
    3194: 2e e4        	ldi	r18, 0x4e
    3196: 30 e0        	ldi	r19, 0x0
    3198: b8 cf        	rjmp	.-144
    319a: d7 d3        	rcall	.+1966
    319c: 09 f2        	breq	.-126
    319e: cc 20        	tst	r12
    31a0: 09 f0        	breq	.+2
    31a2: 36 c3        	rjmp	.+1644
    31a4: 3b d4        	rcall	.+2166
    31a6: 4b 5f        	subi	r20, 0xfb
    31a8: 9c d7        	rcall	.+3896
    31aa: cb d3        	rcall	.+1942
    31ac: 4b 5f        	subi	r20, 0xfb
    31ae: 07 d4        	rcall	.+2062
    31b0: 1c df        	rcall	.-456
    31b2: b7 d3        	rcall	.+1902
    31b4: a9 01 49 5f  	<unknown>
    31b8: 02 d4        	rcall	.+2052
    31ba: 48 5f        	subi	r20, 0xf8
    31bc: 0a d4        	rcall	.+2068
    31be: 48 5f        	subi	r20, 0xf8
    31c0: fe d3        	rcall	.+2044
    31c2: 46 5f        	subi	r20, 0xf6
    31c4: 01 d4        	rcall	.+2050
    31c6: 46 5f        	subi	r20, 0xf6
    31c8: 08 d4        	rcall	.+2064
    31ca: 0f 70        	andi	r16, 0xf
    31cc: 17 81        	ldd	r17, Z+7
    31ce: 12 95        	swap	r17
    31d0: 10 7f        	andi	r17, 0xf0
    31d2: f3 d3        	rcall	.+2022
    31d4: 77 d7        	rcall	.+3822
    31d6: 10 85        	ldd	r17, Z+0
    31d8: 1f 77        	andi	r17, 0x7f
    31da: 01 2b        	or	r16, r17
    31dc: 2e 5f        	subi	r18, 0xfe
    31de: 7e d6        	rcall	.+3324
    31e0: 04 e0        	ldi	r16, 0x4
    31e2: bc d3        	rcall	.+1912
    31e4: 8f 01 0e 94  	<unknown>
    31e8: 67 16        	cp	r6, r23
    31ea: 12 c3        	rjmp	.+1572
    31ec: a8 d3        	rcall	.+1872
    31ee: 19 f4        	brne	.+6
    31f0: 95 d3        	rcall	.+1834
    31f2: 03 95        	inc	r16
    31f4: 04 c0        	rjmp	.+8
    31f6: 9e d3        	rcall	.+1852
    31f8: 19 f4        	brne	.+6
    31fa: 90 d3        	rcall	.+1824
    31fc: 0a 95        	dec	r16
    31fe: 07 83        	std	Z+7, r16
    3200: 8d d3        	rcall	.+1818
    3202: 03 70        	andi	r16, 0x3
    3204: 07 83        	std	Z+7, r16
    3206: bb d3        	rcall	.+1910
    3208: 19 f0        	breq	.+6
    320a: 96 d3        	rcall	.+1836
    320c: 09 f0        	breq	.+2
    320e: 7c c0        	rjmp	.+248
    3210: 00 91 b5 06  	<unknown>
    3214: 00 23        	tst	r16
    3216: 41 f0        	breq	.+16
    3218: 0a 95        	dec	r16
    321a: f1 f0        	breq	.+60
    321c: 0a 95        	dec	r16
    321e: 41 f1        	breq	.+80
    3220: 0a 95        	dec	r16
    3222: 09 f4        	brne	.+2
    3224: 57 c0        	rjmp	.+174
    3226: 70 c0        	rjmp	.+224
    3228: aa d3        	rcall	.+1876
    322a: 61 f4        	brne	.+24
    322c: e0 d3        	rcall	.+1984
    322e: 1b 30        	cpi	r17, 0xb
    3230: 08 f0        	brlo	.+2
    3232: 6a c0        	rjmp	.+212
    3234: 10 2f        	mov	r17, r16
    3236: 00 78        	andi	r16, 0x80
    3238: 13 95        	inc	r17
    323a: 1f 77        	andi	r17, 0x7f
    323c: 01 2b        	or	r16, r17
    323e: ac 01 44 5f  	<unknown>
    3242: 60 c0        	rjmp	.+192
    3244: 79 d3        	rcall	.+1778
    3246: 09 f0        	breq	.+2
    3248: 5f c0        	rjmp	.+190
    324a: d1 d3        	rcall	.+1954
    324c: 09 f4        	brne	.+2
    324e: 5c c0        	rjmp	.+184
    3250: 10 2f        	mov	r17, r16
    3252: 00 78        	andi	r16, 0x80
    3254: 1a 95        	dec	r17
    3256: f1 cf        	rjmp	.-30
    3258: 92 d3        	rcall	.+1828
    325a: 21 f4        	brne	.+8
    325c: c0 d3        	rcall	.+1920
    325e: 00 5c        	subi	r16, 0xc0
    3260: ac 01 51 c0  	<unknown>
    3264: 69 d3        	rcall	.+1746
    3266: 09 f0        	breq	.+2
    3268: 4f c0        	rjmp	.+158
    326a: b9 d3        	rcall	.+1906
    326c: 00 54        	subi	r16, 0x40
    326e: f8 cf        	rjmp	.-16
    3270: 20 e0        	ldi	r18, 0x0
    3272: 01 e0        	ldi	r16, 0x1
    3274: c0 16        	cp	r12, r16
    3276: 19 f0        	breq	.+6
    3278: 01 e8        	ldi	r16, 0x81
    327a: c0 16        	cp	r12, r16
    327c: 19 f4        	brne	.+6
    327e: 5a d6        	rcall	.+3252
    3280: 03 95        	inc	r16
    3282: bc d3        	rcall	.+1912
    3284: 04 e0        	ldi	r16, 0x4
    3286: c0 16        	cp	r12, r16
    3288: 31 f0        	breq	.+12
    328a: 04 e8        	ldi	r16, 0x84
    328c: c0 16        	cp	r12, r16
    328e: 31 f4        	brne	.+12
    3290: 51 d6        	rcall	.+3234
    3292: 00 23        	tst	r16
    3294: 49 f0        	breq	.+18
    3296: 4e d6        	rcall	.+3228
    3298: 0a 95        	dec	r16
    329a: b0 d3        	rcall	.+1888
    329c: 4b d6        	rcall	.+3222
    329e: 00 32        	cpi	r16, 0x20
    32a0: 18 f0        	brlo	.+6
    32a2: 48 d6        	rcall	.+3216
    32a4: 0f 71        	andi	r16, 0x1f
    32a6: aa d3        	rcall	.+1876
    32a8: 45 d6        	rcall	.+3210
    32aa: 10 e0        	ldi	r17, 0x0
    32ac: 43 e0        	ldi	r20, 0x3
    32ae: 0e 94 d5 31  	<unknown>
    32b2: 40 ef        	ldi	r20, 0xf0
    32b4: 52 e0        	ldi	r21, 0x2
    32b6: 40 0f        	add	r20, r16
    32b8: 51 1f        	adc	r21, r17
    32ba: ed d3        	rcall	.+2010
    32bc: 00 23        	tst	r16
    32be: 09 f0        	breq	.+2
    32c0: 20 e2        	ldi	r18, 0x20
    32c2: 66 d6        	rcall	.+3276
    32c4: 19 f0        	breq	.+6
    32c6: 8d d3        	rcall	.+1818
    32c8: 99 d3        	rcall	.+1842
    32ca: 20 e2        	ldi	r18, 0x20
    32cc: 23 95        	inc	r18
    32ce: 20 32        	cpi	r18, 0x20
    32d0: d8 f4        	brsh	.+54
    32d2: cf cf        	rjmp	.-98
    32d4: 01 e0        	ldi	r16, 0x1
    32d6: c0 16        	cp	r12, r16
    32d8: 49 f0        	breq	.+18
    32da: 04 e0        	ldi	r16, 0x4
    32dc: c0 16        	cp	r12, r16
    32de: 31 f0        	breq	.+12
    32e0: 01 e8        	ldi	r16, 0x81
    32e2: c0 16        	cp	r12, r16
    32e4: 19 f0        	breq	.+6
    32e6: 04 e8        	ldi	r16, 0x84
    32e8: c0 16        	cp	r12, r16
    32ea: 21 f4        	brne	.+8
    32ec: 84 d3        	rcall	.+1800
    32ee: 10 e2        	ldi	r17, 0x20
    32f0: 01 27        	eor	r16, r17
    32f2: 1c d6        	rcall	.+3128
    32f4: 4d d6        	rcall	.+3226
    32f6: 41 f0        	breq	.+16
    32f8: 1d d6        	rcall	.+3130
    32fa: 02 30        	cpi	r16, 0x2
    32fc: 28 f0        	brlo	.+10
    32fe: 71 d3        	rcall	.+1762
    3300: ac 01 45 5f  	<unknown>
    3304: 5f 4f        	sbci	r21, 0xff
    3306: 02 d6        	rcall	.+3076
    3308: 02 d3        	rcall	.+1540
    330a: 09 f4        	brne	.+2
    330c: 65 c0        	rjmp	.+202
    330e: 0c 96 66 d3  	<unknown>
    3312: 0f 77        	andi	r16, 0x7f
    3314: 80 2f        	mov	r24, r16
    3316: d5 d3        	rcall	.+1962
    3318: 2d e6        	ldi	r18, 0x6d
    331a: 35 e0        	ldi	r19, 0x5
    331c: 8e 01 0e 5f  	<unknown>
    3320: fa d2        	rcall	.+1524
    3322: 22 96 86 d3  	<unknown>
    3326: 94 d3        	rcall	.+1832
    3328: 39 f0        	breq	.+14
    332a: 0a 95        	dec	r16
    332c: 51 f0        	breq	.+20
    332e: 0a 95        	dec	r16
    3330: 51 f0        	breq	.+20
    3332: 0a 95        	dec	r16
    3334: 51 f0        	breq	.+20
    3336: 0e c0        	rjmp	.+28
    3338: 01 e0        	ldi	r16, 0x1
    333a: 0f 87        	std	Y+7, r16
    333c: 00 e0        	ldi	r16, 0x0
    333e: 08 8b        	std	Y+0, r16
    3340: 09 c0        	rjmp	.+18
    3342: 02 e0        	ldi	r16, 0x2
    3344: fa cf        	rjmp	.-12
    3346: 09 ea        	ldi	r16, 0xa9
    3348: f8 cf        	rjmp	.-16
    334a: 2f e7        	ldi	r18, 0x7f
    334c: 35 e0        	ldi	r19, 0x5
    334e: 8e 01 01 5f  	<unknown>
    3352: e1 d2        	rcall	.+1474
    3354: 27 e5        	ldi	r18, 0x57
    3356: 30 e0        	ldi	r19, 0x0
    3358: 9c d3        	rcall	.+1848
    335a: 80 2f        	mov	r24, r16
    335c: 90 e0        	ldi	r25, 0x0
    335e: 8f 71        	andi	r24, 0x1f
    3360: b1 d3        	rcall	.+1890
    3362: 21 e8        	ldi	r18, 0x81
    3364: 35 e0        	ldi	r19, 0x5
    3366: 8e 01 0a 5e  	<unknown>
    336a: d5 d2        	rcall	.+1450
    336c: 22 96 21 e5  	<unknown>
    3370: 30 e0        	ldi	r19, 0x0
    3372: 5c d3        	rcall	.+1720
    3374: 29 f0        	breq	.+10
    3376: 24 e9        	ldi	r18, 0x94
    3378: 35 e0        	ldi	r19, 0x5
    337a: 8e 01 01 5e  	<unknown>
    337e: cb d2        	rcall	.+1430
    3380: 82 99        	sbic	0x10, 0x2
    3382: 1f c0        	rjmp	.+62
    3384: dc d2        	rcall	.+1464
    3386: e9 f0        	breq	.+58
    3388: d5 d2        	rcall	.+1450
    338a: d9 f0        	breq	.+54
    338c: 00 91 b5 06  	<unknown>
    3390: 00 23        	tst	r16
    3392: 39 f0        	breq	.+14
    3394: 0a 95        	dec	r16
    3396: 41 f0        	breq	.+16
    3398: 0a 95        	dec	r16
    339a: 51 f0        	breq	.+20
    339c: 0a 95        	dec	r16
    339e: 59 f0        	breq	.+22
    33a0: 10 c0        	rjmp	.+32
    33a2: 2f d3        	rcall	.+1630
    33a4: 07 5f        	subi	r16, 0xf7
    33a6: 0a c0        	rjmp	.+20
    33a8: 41 e0        	ldi	r20, 0x1
    33aa: 2c d3        	rcall	.+1624
    33ac: 01 5f        	subi	r16, 0xf1
    33ae: 06 c0        	rjmp	.+12
    33b0: 28 d3        	rcall	.+1616
    33b2: 05 5e        	subi	r16, 0xe5
    33b4: 03 c0        	rjmp	.+6
    33b6: 41 e0        	ldi	r20, 0x1
    33b8: 25 d3        	rcall	.+1610
    33ba: 0d 5d        	subi	r16, 0xdd
    33bc: 1f 4f        	sbci	r17, 0xff
    33be: 0e 94 33 35  	<unknown>
    33c2: 51 d3        	rcall	.+1698
    33c4: 8e 01 0e 94  	<unknown>
    33c8: 5d 35        	cpi	r21, 0x5d
    33ca: e6 d2        	rcall	.+1484
    33cc: 8e 01 0c 5e  	<unknown>
    33d0: 1f 4f        	sbci	r17, 0xff
    33d2: 0e 94 5d 35  	<unknown>
    33d6: dc d2        	rcall	.+1464
    33d8: cc 20        	tst	r12
    33da: a9 f4        	brne	.+42
    33dc: e1 d2        	rcall	.+1474
    33de: d1 d2        	rcall	.+1442
    33e0: e3 d5        	rcall	.+3014
    33e2: a9 01 4b 5f  	<unknown>
    33e6: ee d2        	rcall	.+1500
    33e8: 14 e0        	ldi	r17, 0x4
    33ea: 01 9f 02 e0  	<unknown>
    33ee: 10 22        	and	r1, r16
    33f0: 39 f4        	brne	.+14
    33f2: 05 e0        	ldi	r16, 0x5
    33f4: b3 d2        	rcall	.+1382
    33f6: 75 d5        	rcall	.+2794
    33f8: 00 72        	andi	r16, 0x20
    33fa: 21 f0        	breq	.+8
    33fc: 07 e0        	ldi	r16, 0x7
    33fe: 01 c0        	rjmp	.+2
    3400: 08 e0        	ldi	r16, 0x8
    3402: ac d2        	rcall	.+1368
    3404: b8 d2        	rcall	.+1392
    3406: a7 d2        	rcall	.+1358
    3408: 09 f0        	breq	.+2
    340a: 02 c2        	rjmp	.+1028
    340c: 8d ce        	rjmp	.-742
    340e: b7 d2        	rcall	.+1390
    3410: 11 f0        	breq	.+4
    3412: 92 d2        	rcall	.+1316
    3414: 41 f4        	brne	.+16
    3416: c4 d2        	rcall	.+1416
    3418: 28 d3        	rcall	.+1616
    341a: 10 e2        	ldi	r17, 0x20
    341c: 01 27        	eor	r16, r17
    341e: 2a 5f        	subi	r18, 0xfa
    3420: 5d d5        	rcall	.+2746
    3422: a9 d2        	rcall	.+1362
    3424: 02 c0        	rjmp	.+4
    3426: 55 20        	tst	r5
    3428: c9 f0        	breq	.+50
    342a: 22 e5        	ldi	r18, 0x52
    342c: 30 e0        	ldi	r19, 0x0
    342e: fe d2        	rcall	.+1532
    3430: 10 e0        	ldi	r17, 0x0
    3432: 00 e0        	ldi	r16, 0x0
    3434: 49 f0        	breq	.+18
    3436: b2 d2        	rcall	.+1380
    3438: 0a e9        	ldi	r16, 0x9a
    343a: 15 e0        	ldi	r17, 0x5
    343c: 33 d3        	rcall	.+1638
    343e: 55 d3        	rcall	.+1706
    3440: ab d2        	rcall	.+1366
    3442: 0a ea        	ldi	r16, 0xaa
    3444: 15 e0        	ldi	r17, 0x5
    3446: 06 c0        	rjmp	.+12
    3448: a9 d2        	rcall	.+1362
    344a: 0a eb        	ldi	r16, 0xba
    344c: 15 e0        	ldi	r17, 0x5
    344e: 41 d3        	rcall	.+1666
    3450: 05 ec        	ldi	r16, 0xc5
    3452: 15 e0        	ldi	r17, 0x5
    3454: 27 d3        	rcall	.+1614
    3456: 00 e0        	ldi	r16, 0x0
    3458: 00 93 b7 06  	<unknown>
    345c: cc 20        	tst	r12
    345e: 99 f6        	brne	.-90
    3460: 04 d3        	rcall	.+1544
    3462: 00 72        	andi	r16, 0x20
    3464: 21 f0        	breq	.+8
    3466: 06 e0        	ldi	r16, 0x6
    3468: 79 d2        	rcall	.+1266
    346a: 9a d2        	rcall	.+1332
    346c: cb cf        	rjmp	.-106
    346e: 07 e0        	ldi	r16, 0x7
    3470: 75 d2        	rcall	.+1258
    3472: a9 01 43 5f  	<unknown>
    3476: 57 d5        	rcall	.+2734
    3478: 11 2e        	mov	r1, r17
    347a: fd 01 02 83  	<unknown>
    347e: 13 83        	std	Z+3, r17
    3480: a9 01 35 d5  	<unknown>
    3484: 71 2f        	mov	r23, r17
    3486: 04 83        	std	Z+4, r16
    3488: 15 83        	std	Z+5, r17
    348a: 2b d5        	rcall	.+2646
    348c: 00 72        	andi	r16, 0x20
    348e: 09 f4        	brne	.+2
    3490: b9 cf        	rjmp	.-142
    3492: 11 20        	tst	r1
    3494: 22 f4        	brpl	.+8
    3496: 00 e0        	ldi	r16, 0x0
    3498: 02 83        	std	Z+2, r16
    349a: 03 83        	std	Z+3, r16
    349c: 04 c0        	rjmp	.+8
    349e: 04 e0        	ldi	r16, 0x4
    34a0: 10 16        	cp	r1, r16
    34a2: 0c f0        	brlt	.+2
    34a4: 63 d2        	rcall	.+1222
    34a6: 77 23        	tst	r23
    34a8: 22 f4        	brpl	.+8
    34aa: 00 e0        	ldi	r16, 0x0
    34ac: 04 83        	std	Z+4, r16
    34ae: 05 83        	std	Z+5, r16
    34b0: a9 cf        	rjmp	.-174
    34b2: 74 30        	cpi	r23, 0x4
    34b4: 0c f4        	brge	.+2
    34b6: a6 cf        	rjmp	.-180
    34b8: 54 d2        	rcall	.+1192
    34ba: a4 cf        	rjmp	.-184
    34bc: 32 d5        	rcall	.+2660
    34be: a0 2f        	mov	r26, r16
    34c0: 39 d2        	rcall	.+1138
    34c2: 59 f0        	breq	.+22
    34c4: 3c d2        	rcall	.+1144
    34c6: 59 f4        	brne	.+22
    34c8: a3 95        	inc	r26
    34ca: af 71        	andi	r26, 0x1f
    34cc: 0a 2f        	mov	r16, r26
    34ce: 10 e0        	ldi	r17, 0x0
    34d0: 0d 96 ac 01  	<unknown>
    34d4: 1a d2        	rcall	.+1076
    34d6: 4f d2        	rcall	.+1182
    34d8: 04 c0        	rjmp	.+8
    34da: aa 95        	dec	r26
    34dc: f6 cf        	rjmp	.-20
    34de: 55 20        	tst	r5
    34e0: e9 f0        	breq	.+58
    34e2: c1 d2        	rcall	.+1410
    34e4: 8a 2f        	mov	r24, r26
    34e6: 90 e0        	ldi	r25, 0x0
    34e8: 01 96 ac d2  	<unknown>
    34ec: 41 f4        	brne	.+16
    34ee: 0f ec        	ldi	r16, 0xcf
    34f0: 15 e0        	ldi	r17, 0x5
    34f2: f3 d2        	rcall	.+1510
    34f4: db d2        	rcall	.+1462
    34f6: 0f ed        	ldi	r16, 0xdf
    34f8: 15 e0        	ldi	r17, 0x5
    34fa: d4 d2        	rcall	.+1448
    34fc: 24 96 a2 d2  	<unknown>
    3500: 00 34        	cpi	r16, 0x40
    3502: 49 f4        	brne	.+18
    3504: 0c ee        	ldi	r16, 0xec
    3506: 15 e0        	ldi	r17, 0x5
    3508: e8 d2        	rcall	.+1488
    350a: 80 2f        	mov	r24, r16
    350c: da d2        	rcall	.+1460
    350e: 0c ef        	ldi	r16, 0xfc
    3510: 15 e0        	ldi	r17, 0x5
    3512: c8 d2        	rcall	.+1424
    3514: 24 96 00 e0  	<unknown>
    3518: 00 93 b7 06  	<unknown>
    351c: cc 20        	tst	r12
    351e: 09 f0        	breq	.+2
    3520: 72 cf        	rjmp	.-284
    3522: 08 e0        	ldi	r16, 0x8
    3524: 1b d2        	rcall	.+1078
    3526: 3c d2        	rcall	.+1144
    3528: 73 c1        	rjmp	.+742
    352a: 29 d2        	rcall	.+1106
    352c: 11 f0        	breq	.+4
    352e: 04 d2        	rcall	.+1032
    3530: 19 f4        	brne	.+6
    3532: f4 d1        	rcall	.+1000
    3534: 03 95        	inc	r16
    3536: 07 83        	std	Z+7, r16
    3538: fd 01 17 81  	<unknown>
    353c: 11 70        	andi	r17, 0x1
    353e: 17 83        	std	Z+7, r17
    3540: f9 d1        	rcall	.+1010
    3542: 19 f0        	breq	.+6
    3544: fc d1        	rcall	.+1016
    3546: 09 f0        	breq	.+2
    3548: 58 c0        	rjmp	.+176
    354a: 22 d5        	rcall	.+2628
    354c: 19 f0        	breq	.+6
    354e: 00 24        	clr	r0
    3550: 03 94        	inc	r0
    3552: 02 c0        	rjmp	.+4
    3554: 0a e0        	ldi	r16, 0xa
    3556: 00 2e        	mov	r0, r16
    3558: 11 23        	tst	r17
    355a: 11 f4        	brne	.+4
    355c: 32 96 01 c0  	<unknown>
    3560: 34 96 c7 fa  	<unknown>
    3564: 16 f4        	brtc	.+4
    3566: 0a e0        	ldi	r16, 0xa
    3568: 00 9e e9 d1  	<unknown>
    356c: 31 f4        	brne	.+12
    356e: 11 24        	clr	r1
    3570: 00 81        	ldd	r16, Z+0
    3572: 11 81        	ldd	r17, Z+1
    3574: 00 0d        	add	r16, r0
    3576: 11 1d        	adc	r17, r1
    3578: 06 c0        	rjmp	.+12
    357a: dc d1        	rcall	.+952
    357c: 31 f4        	brne	.+12
    357e: 00 81        	ldd	r16, Z+0
    3580: 11 81        	ldd	r17, Z+1
    3582: 00 19        	sub	r16, r0
    3584: 10 40        	sbci	r17, 0x0
    3586: 00 83        	std	Z+0, r16
    3588: 11 83        	std	Z+1, r17
    358a: fd 01 24 81  	<unknown>
    358e: 35 81        	ldd	r19, Z+5
    3590: 05 96 25 d2  	<unknown>
    3594: 00 72        	andi	r16, 0x20
    3596: a1 f0        	breq	.+40
    3598: 34 30        	cpi	r19, 0x4
    359a: 14 f0        	brlt	.+4
    359c: e2 d1        	rcall	.+964
    359e: 05 c0        	rjmp	.+10
    35a0: 33 23        	tst	r19
    35a2: 1a f4        	brpl	.+6
    35a4: 00 e0        	ldi	r16, 0x0
    35a6: 04 83        	std	Z+4, r16
    35a8: 05 83        	std	Z+5, r16
    35aa: 13 81        	ldd	r17, Z+3
    35ac: 14 30        	cpi	r17, 0x4
    35ae: 14 f0        	brlt	.+4
    35b0: dd d1        	rcall	.+954
    35b2: 23 c0        	rjmp	.+70
    35b4: 11 23        	tst	r17
    35b6: 0a f5        	brpl	.+66
    35b8: 00 e0        	ldi	r16, 0x0
    35ba: 02 83        	std	Z+2, r16
    35bc: 03 83        	std	Z+3, r16
    35be: 1d c0        	rjmp	.+58
    35c0: 25 3d        	cpi	r18, 0xd5
    35c2: 00 e3        	ldi	r16, 0x30
    35c4: 30 07        	cpc	r19, r16
    35c6: 1c f0        	brlt	.+6
    35c8: 04 ed        	ldi	r16, 0xd4
    35ca: 10 e3        	ldi	r17, 0x30
    35cc: 05 c0        	rjmp	.+10
    35ce: 24 38        	cpi	r18, 0x84
    35d0: 3a 4e        	sbci	r19, 0xea
    35d2: 24 f4        	brge	.+8
    35d4: 04 e8        	ldi	r16, 0x84
    35d6: 1a ee        	ldi	r17, 0xea
    35d8: 04 83        	std	Z+4, r16
    35da: 15 83        	std	Z+5, r17
    35dc: 02 81        	ldd	r16, Z+2
    35de: 13 81        	ldd	r17, Z+3
    35e0: 05 3d        	cpi	r16, 0xd5
    35e2: 20 e3        	ldi	r18, 0x30
    35e4: 12 07        	cpc	r17, r18
    35e6: 14 f0        	brlt	.+4
    35e8: 04 ed        	ldi	r16, 0xd4
    35ea: 05 c0        	rjmp	.+10
    35ec: 04 38        	cpi	r16, 0x84
    35ee: 2a ee        	ldi	r18, 0xea
    35f0: 1a 4e        	sbci	r17, 0xea
    35f2: 1c f4        	brge	.+6
    35f4: 04 e8        	ldi	r16, 0x84
    35f6: 02 83        	std	Z+2, r16
    35f8: 23 83        	std	Z+3, r18
    35fa: 89 d1        	rcall	.+786
    35fc: 09 f4        	brne	.+2
    35fe: 84 c0        	rjmp	.+264
    3600: 32 d2        	rcall	.+1124
    3602: 09 e0        	ldi	r16, 0x9
    3604: 16 e0        	ldi	r17, 0x6
    3606: 65 d2        	rcall	.+1226
    3608: 0c e0        	ldi	r16, 0xc
    360a: 16 e0        	ldi	r17, 0x6
    360c: 4b d2        	rcall	.+1174
    360e: 80 e0        	ldi	r24, 0x0
    3610: e4 e1        	ldi	r30, 0x14
    3612: f5 e0        	ldi	r31, 0x5
    3614: 8e 01 44 e1  	<unknown>
    3618: 50 e0        	ldi	r21, 0x0
    361a: 0e 94 d8 34  	<unknown>
    361e: 88 23        	tst	r24
    3620: fd 01 19 f4  	<unknown>
    3624: 62 81        	ldd	r22, Z+2
    3626: 73 81        	ldd	r23, Z+3
    3628: 02 c0        	rjmp	.+4
    362a: 64 81        	ldd	r22, Z+4
    362c: 75 81        	ldd	r23, Z+5
    362e: 82 99        	sbic	0x10, 0x2
    3630: 05 c0        	rjmp	.+10
    3632: 00 91 b5 06  	<unknown>
    3636: 08 17        	cp	r16, r24
    3638: 09 f4        	brne	.+2
    363a: 59 c0        	rjmp	.+178
    363c: a2 d1        	rcall	.+836
    363e: e7 d1        	rcall	.+974
    3640: 22 2e        	mov	r2, r18
    3642: 20 e0        	ldi	r18, 0x0
    3644: 32 2e        	mov	r3, r18
    3646: 20 0e        	add	r2, r16
    3648: 31 1e        	adc	r3, r17
    364a: 8b 01 27 2f  	<unknown>
    364e: 22 0f        	lsl	r18
    3650: 22 0b        	sbc	r18, r18
    3652: 32 2f        	mov	r19, r18
    3654: 0e 94 a8 32  	<unknown>
    3658: 48 01 59 01  	<unknown>
    365c: a1 01 4b 5f  	<unknown>
    3660: 44 d4        	rcall	.+2184
    3662: b9 f1        	breq	.+110
    3664: 0b e0        	ldi	r16, 0xb
    3666: 20 0e        	add	r2, r16
    3668: 00 e0        	ldi	r16, 0x0
    366a: 30 1e        	adc	r3, r16
    366c: a1 01 13 d2  	<unknown>
    3670: e0 2f        	mov	r30, r16
    3672: 00 0f        	lsl	r16
    3674: 14 e0        	ldi	r17, 0x4
    3676: 01 9f 60 e0  	<unknown>
    367a: 70 e0        	ldi	r23, 0x0
    367c: 60 0d        	add	r22, r0
    367e: 71 1d        	adc	r23, r1
    3680: 3d d1        	rcall	.+634
    3682: 97 d2        	rcall	.+1326
    3684: f0 e0        	ldi	r31, 0x0
    3686: 40 e1        	ldi	r20, 0x10
    3688: 50 e0        	ldi	r21, 0x0
    368a: 4e 0f        	add	r20, r30
    368c: 5f 1f        	adc	r21, r31
    368e: 03 d2        	rcall	.+1030
    3690: fa 93        	st	-Y, r31
    3692: 0a 93        	st	-Y, r16
    3694: 6c 5f        	subi	r22, 0xfc
    3696: 7f 4f        	sbci	r23, 0xff
    3698: 31 d1        	rcall	.+610
    369a: a2 01 b3 01  	<unknown>
    369e: 0e 94 4b 33  	<unknown>
    36a2: a8 01 b9 01  	<unknown>
    36a6: 00 e0        	ldi	r16, 0x0
    36a8: 10 e0        	ldi	r17, 0x0
    36aa: 20 e8        	ldi	r18, 0x80
    36ac: 3a e3        	ldi	r19, 0x3a
    36ae: 0e 94 68 33  	<unknown>
    36b2: a4 01 b5 01  	<unknown>
    36b6: 0e 94 68 33  	<unknown>
    36ba: a2 01 b3 01  	<unknown>
    36be: 0e 94 07 33  	<unknown>
    36c2: 73 d1        	rcall	.+742
    36c4: 2f e0        	ldi	r18, 0xf
    36c6: 36 e0        	ldi	r19, 0x6
    36c8: 8e 01 0a 5f  	<unknown>
    36cc: 24 d1        	rcall	.+584
    36ce: 26 96 0e c0  	<unknown>
    36d2: 40 e0        	ldi	r20, 0x0
    36d4: 50 e0        	ldi	r21, 0x0
    36d6: 68 ec        	ldi	r22, 0xc8
    36d8: 72 e4        	ldi	r23, 0x42
    36da: 08 2d        	mov	r16, r8
    36dc: 0e 94 e1 33  	<unknown>
    36e0: 64 d1        	rcall	.+712
    36e2: 28 e1        	ldi	r18, 0x18
    36e4: 36 e0        	ldi	r19, 0x6
    36e6: 8e 01 0c 5f  	<unknown>
    36ea: 15 d1        	rcall	.+554
    36ec: 24 96 18 2f  	<unknown>
    36f0: 02 e0        	ldi	r16, 0x2
    36f2: 54 d1        	rcall	.+680
    36f4: 8e 01 5b d1  	<unknown>
    36f8: 05 e2        	ldi	r16, 0x25
    36fa: 16 e0        	ldi	r17, 0x6
    36fc: e7 d1        	rcall	.+974
    36fe: 83 95        	inc	r24
    3700: 82 30        	cpi	r24, 0x2
    3702: 08 f4        	brsh	.+2
    3704: 85 cf        	rjmp	.-246
    3706: 44 d1        	rcall	.+648
    3708: cc 20        	tst	r12
    370a: 09 f0        	breq	.+2
    370c: 7c ce        	rjmp	.-776
    370e: 39 d1        	rcall	.+626
    3710: 50 e0        	ldi	r21, 0x0
    3712: 7d d1        	rcall	.+762
    3714: 30 e0        	ldi	r19, 0x0
    3716: 20 0f        	add	r18, r16
    3718: 31 1f        	adc	r19, r17
    371a: fd 01 02 81  	<unknown>
    371e: 13 81        	ldd	r17, Z+3
    3720: a9 01 43 5f  	<unknown>
    3724: 5f 4f        	sbci	r21, 0xff
    3726: f1 d0        	rcall	.+482
    3728: 04 81        	ldd	r16, Z+4
    372a: 15 81        	ldd	r17, Z+5
    372c: 21 5f        	subi	r18, 0xf1
    372e: 3f 4f        	sbci	r19, 0xff
    3730: a9 01 eb d0  	<unknown>
    3734: 08 e0        	ldi	r16, 0x8
    3736: 00 87        	std	Z+0, r16
    3738: f6 ce        	rjmp	.-532
    373a: 21 d1        	rcall	.+578
    373c: 11 f0        	breq	.+4
    373e: fc d0        	rcall	.+504
    3740: 49 f4        	brne	.+18
    3742: 52 d1        	rcall	.+676
    3744: 10 e8        	ldi	r17, 0x80
    3746: 01 27        	eor	r16, r17
    3748: 0c 96 dd d3  	<unknown>
    374c: 01 e0        	ldi	r16, 0x1
    374e: 00 93 35 07  	<unknown>
    3752: 02 c0        	rjmp	.+4
    3754: dc d0        	rcall	.+440
    3756: 79 f0        	breq	.+30
    3758: 86 d1        	rcall	.+780
    375a: 08 e2        	ldi	r16, 0x28
    375c: 16 e0        	ldi	r17, 0x6
    375e: b9 d1        	rcall	.+882
    3760: 28 e5        	ldi	r18, 0x58
    3762: 30 e0        	ldi	r19, 0x0
    3764: 88 d1        	rcall	.+784
    3766: 19 f4        	brne	.+6
    3768: 09 e3        	ldi	r16, 0x39
    376a: 16 e0        	ldi	r17, 0x6
    376c: 02 c0        	rjmp	.+4
    376e: 0a e4        	ldi	r16, 0x4a
    3770: 16 e0        	ldi	r17, 0x6
    3772: 98 d1        	rcall	.+816
    3774: 0d d1        	rcall	.+538
    3776: cc 20        	tst	r12
    3778: 09 f0        	breq	.+2
    377a: 4a c0        	rjmp	.+148
    377c: 09 e0        	ldi	r16, 0x9
    377e: d2 ce        	rjmp	.-604
    3780: 03 e0        	ldi	r16, 0x3
    3782: c0 16        	cp	r12, r16
    3784: 51 f4        	brne	.+20
    3786: e0 d3        	rcall	.+1984
    3788: 00 5c        	subi	r16, 0xc0
    378a: ac 01 13 d1  	<unknown>
    378e: 14 d2        	rcall	.+1064
    3790: ac 01 90 d4  	<unknown>
    3794: 00 93 b8 06  	<unknown>
    3798: 08 c0        	rjmp	.+16
    379a: 02 e0        	ldi	r16, 0x2
    379c: c0 16        	cp	r12, r16
    379e: 19 f4        	brne	.+6
    37a0: d3 d3        	rcall	.+1958
    37a2: 00 54        	subi	r16, 0x40
    37a4: f2 cf        	rjmp	.-28
    37a6: cc 20        	tst	r12
    37a8: b1 f0        	breq	.+44
    37aa: 5d d1        	rcall	.+698
    37ac: 4e d1        	rcall	.+668
    37ae: 39 f0        	breq	.+14
    37b0: 0a 95        	dec	r16
    37b2: 41 f0        	breq	.+16
    37b4: 0a 95        	dec	r16
    37b6: 49 f0        	breq	.+18
    37b8: 0a 95        	dec	r16
    37ba: 51 f0        	breq	.+20
    37bc: 0c c0        	rjmp	.+24
    37be: 0b e5        	ldi	r16, 0x5b
    37c0: 16 e0        	ldi	r17, 0x6
    37c2: 08 c0        	rjmp	.+16
    37c4: 0b e6        	ldi	r16, 0x6b
    37c6: 16 e0        	ldi	r17, 0x6
    37c8: 05 c0        	rjmp	.+10
    37ca: 0b e7        	ldi	r16, 0x7b
    37cc: 16 e0        	ldi	r17, 0x6
    37ce: 02 c0        	rjmp	.+4
    37d0: 0b e8        	ldi	r16, 0x8b
    37d2: 16 e0        	ldi	r17, 0x6
    37d4: 67 d1        	rcall	.+718
    37d6: e0 d0        	rcall	.+448
    37d8: 80 91 b8 06  	<unknown>
    37dc: 90 e0        	ldi	r25, 0x0
    37de: 35 d1        	rcall	.+618
    37e0: 49 f0        	breq	.+18
    37e2: 0a 95        	dec	r16
    37e4: d9 f0        	breq	.+54
    37e6: 0a 95        	dec	r16
    37e8: 09 f4        	brne	.+2
    37ea: 68 c0        	rjmp	.+208
    37ec: 0a 95        	dec	r16
    37ee: 09 f4        	brne	.+2
    37f0: 73 c0        	rjmp	.+230
    37f2: 03 c0        	rjmp	.+6
    37f4: 0b e9        	ldi	r16, 0x9b
    37f6: 16 e0        	ldi	r17, 0x6
    37f8: 55 d1        	rcall	.+682
    37fa: ad d0        	rcall	.+346
    37fc: 09 f4        	brne	.+2
    37fe: 94 cc        	rjmp	.-1752
    3800: 44 20        	tst	r4
    3802: 31 f4        	brne	.+12
    3804: 2d e4        	ldi	r18, 0x4d
    3806: 30 e0        	ldi	r19, 0x0
    3808: 44 d1        	rcall	.+648
    380a: 00 7c        	andi	r16, 0xc0
    380c: 09 f4        	brne	.+2
    380e: 8c cc        	rjmp	.-1768
    3810: 00 e0        	ldi	r16, 0x0
    3812: a8 96 df be  	<unknown>
    3816: ee e0        	ldi	r30, 0xe
    3818: 0c 94 f6 34  	<unknown>
    381c: 2d e3        	ldi	r18, 0x3d
    381e: 37 e0        	ldi	r19, 0x7
    3820: 0c e0        	ldi	r16, 0xc
    3822: 3b d1        	rcall	.+630
    3824: 0c ea        	ldi	r16, 0xac
    3826: 16 e0        	ldi	r17, 0x6
    3828: 3f d1        	rcall	.+638
    382a: 39 f4        	brne	.+14
    382c: 64 d0        	rcall	.+200
    382e: 00 23        	tst	r16
    3830: 69 f0        	breq	.+26
    3832: 0a 95        	dec	r16
    3834: 00 93 b8 06  	<unknown>
    3838: 09 c0        	rjmp	.+18
    383a: a1 d0        	rcall	.+322
    383c: 39 f4        	brne	.+14
    383e: 5b d0        	rcall	.+182
    3840: 06 30        	cpi	r16, 0x6
    3842: 58 f5        	brsh	.+86
    3844: fd 01 02 85  	<unknown>
    3848: 03 95        	inc	r16
    384a: 02 87        	std	Z+2, r16
    384c: 44 20        	tst	r4
    384e: 29 f5        	brne	.+74
    3850: 98 d0        	rcall	.+304
    3852: 5d d4        	rcall	.+2234
    3854: 4f 5e        	subi	r20, 0xef
    3856: 5f 4f        	sbci	r21, 0xff
    3858: 54 d0        	rcall	.+168
    385a: 01 e0        	ldi	r16, 0x1
    385c: ad d1        	rcall	.+858
    385e: 0e 94 2d 32  	<unknown>
    3862: c0 01 d1 01  	<unknown>
    3866: 80 23        	and	r24, r16
    3868: 91 23        	and	r25, r17
    386a: a2 23        	and	r26, r18
    386c: b3 23        	and	r27, r19
    386e: 89 2b        	or	r24, r25
    3870: 8a 2b        	or	r24, r26
    3872: 8b 2b        	or	r24, r27
    3874: 49 f0        	breq	.+18
    3876: 00 95        	com	r16
    3878: 10 95        	com	r17
    387a: 20 95        	com	r18
    387c: 30 95        	com	r19
    387e: 00 21        	and	r16, r0
    3880: 11 21        	and	r17, r1
    3882: 22 21        	and	r18, r2
    3884: 33 21        	and	r19, r3
    3886: 04 c0        	rjmp	.+8
    3888: 00 29        	or	r16, r0
    388a: 11 29        	or	r17, r1
    388c: 22 29        	or	r18, r2
    388e: 33 29        	or	r19, r3
    3890: 6f 5e        	subi	r22, 0xef
    3892: 7f 4f        	sbci	r23, 0xff
    3894: ab 01 0e 94  	<unknown>
    3898: ab 31        	cpi	r26, 0x1b
    389a: 11 e0        	ldi	r17, 0x1
    389c: 0d e0        	ldi	r16, 0xd
    389e: 7e d0        	rcall	.+252
    38a0: 2d e5        	ldi	r18, 0x5d
    38a2: 30 e0        	ldi	r19, 0x0
    38a4: 6e d0        	rcall	.+220
    38a6: ca d0        	rcall	.+404
    38a8: be d0        	rcall	.+380
    38aa: 2b d0        	rcall	.+86
    38ac: 85 d3        	rcall	.+1802
    38ae: 19 f0        	breq	.+6
    38b0: 01 eb        	ldi	r16, 0xb1
    38b2: 16 e0        	ldi	r17, 0x6
    38b4: a1 cf        	rjmp	.-190
    38b6: 05 eb        	ldi	r16, 0xb5
    38b8: 16 e0        	ldi	r17, 0x6
    38ba: 9e cf        	rjmp	.-196
    38bc: 03 d1        	rcall	.+518
    38be: 09 eb        	ldi	r16, 0xb9
    38c0: 16 e0        	ldi	r17, 0x6
    38c2: 04 d1        	rcall	.+520
    38c4: 39 d0        	rcall	.+114
    38c6: 09 f4        	brne	.+2
    38c8: b1 cf        	rjmp	.-158
    38ca: 59 d0        	rcall	.+178
    38cc: 09 f0        	breq	.+2
    38ce: be cf        	rjmp	.-132
    38d0: 12 d0        	rcall	.+36
    38d2: 0e 31        	cpi	r16, 0x1e
    38d4: 10 f7        	brsh	.-60
    38d6: b6 cf        	rjmp	.-148
    38d8: 21 ed        	ldi	r18, 0xd1
    38da: 36 e0        	ldi	r19, 0x6
    38dc: 09 e0        	ldi	r16, 0x9
    38de: dd d0        	rcall	.+442
    38e0: 08 ec        	ldi	r16, 0xc8
    38e2: 16 e0        	ldi	r17, 0x6
    38e4: e1 d0        	rcall	.+450
    38e6: 09 f4        	brne	.+2
    38e8: a1 cf        	rjmp	.-190
    38ea: 49 d0        	rcall	.+146
    38ec: 09 f0        	breq	.+2
    38ee: ae cf        	rjmp	.-164
    38f0: 02 d0        	rcall	.+4
    38f2: 0b 30        	cpi	r16, 0xb
    38f4: ef cf        	rjmp	.-34
    38f6: 00 91 b8 06  	<unknown>
    38fa: 08 95        	ret
    38fc: ab 01 0c 94  	<unknown>
    3900: 8e 31        	cpi	r24, 0x1e
    3902: 41 d3        	rcall	.+1666
    3904: 40 91 b8 06  	<unknown>
    3908: 08 95        	ret
    390a: 0c 94 a4 31  	<unknown>
    390e: 00 91 35 07  	<unknown>
    3912: 00 23        	tst	r16
    3914: 08 95        	ret
    3916: 1f 4f        	sbci	r17, 0xff
    3918: 0c 94 b5 35  	<unknown>
    391c: fd 01 07 81  	<unknown>
    3920: 08 95        	ret
    3922: 00 7c        	andi	r16, 0xc0
    3924: 14 81        	ldd	r17, Z+4
    3926: 1f 73        	andi	r17, 0x3f
    3928: 01 2b        	or	r16, r17
    392a: 08 95        	ret
    392c: 0f 70        	andi	r16, 0xf
    392e: ad d0        	rcall	.+346
    3930: 07 83        	std	Z+7, r16
    3932: 08 95        	ret
    3934: 02 e0        	ldi	r16, 0x2
    3936: 01 c0        	rjmp	.+2
    3938: 04 e0        	ldi	r16, 0x4
    393a: 40 16        	cp	r4, r16
    393c: 08 95        	ret
    393e: 03 e0        	ldi	r16, 0x3
    3940: fc cf        	rjmp	.-8
    3942: ed 91        	ld	r30, X+
    3944: fc 91        	ld	r31, X
    3946: 13 81        	ldd	r17, Z+3
    3948: 41 c0        	rjmp	.+130
    394a: 2c 2d        	mov	r18, r12
    394c: 0d 91        	ld	r16, X+
    394e: 1c 91        	ld	r17, X
    3950: 11 97 0e 94  	<unknown>
    3954: f9 16        	cp	r15, r25
    3956: 05 e0        	ldi	r16, 0x5
    3958: c0 16        	cp	r12, r16
    395a: 08 95        	ret
    395c: 00 93 b6 06  	<unknown>
    3960: 08 95        	ret
    3962: 0f ef        	ldi	r16, 0xff
    3964: 13 e0        	ldi	r17, 0x3
    3966: 04 83        	std	Z+4, r16
    3968: 15 83        	std	Z+5, r17
    396a: 08 95        	ret
    396c: 0f ef        	ldi	r16, 0xff
    396e: 13 e0        	ldi	r17, 0x3
    3970: 02 83        	std	Z+2, r16
    3972: 13 83        	std	Z+3, r17
    3974: 08 95        	ret
    3976: 01 e0        	ldi	r16, 0x1
    3978: 00 93 b7 06  	<unknown>
    397c: 08 95        	ret
    397e: 01 e0        	ldi	r16, 0x1
    3980: dc cf        	rjmp	.-72
    3982: 40 91 b4 06  	<unknown>
    3986: 08 95        	ret
    3988: 00 e0        	ldi	r16, 0x0
    398a: 31 db        	rcall	.-2462
    398c: 00 e0        	ldi	r16, 0x0
    398e: 08 95        	ret
    3990: 00 e0        	ldi	r16, 0x0
    3992: 00 93 35 07  	<unknown>
    3996: 08 95        	ret
    3998: 11 e0        	ldi	r17, 0x1
    399a: 00 e0        	ldi	r16, 0x0
    399c: 0c 94 29 0f  	<unknown>
    39a0: 0c 94 43 0f  	<unknown>
    39a4: 5e d0        	rcall	.+188
    39a6: 04 83        	std	Z+4, r16
    39a8: 08 95        	ret
    39aa: 3a 93        	st	-Y, r19
    39ac: 2a 93        	st	-Y, r18
    39ae: 1a 93        	st	-Y, r17
    39b0: 0a 93        	st	-Y, r16
    39b2: 08 95        	ret
    39b4: 4f 5f        	subi	r20, 0xff
    39b6: bc d2        	rcall	.+1400
    39b8: e9 cf        	rjmp	.-46
    39ba: 09 d0        	rcall	.+18
    39bc: 4c 5f        	subi	r20, 0xfc
    39be: b8 d2        	rcall	.+1392
    39c0: a9 01 08 95  	<unknown>
    39c4: fc df        	rcall	.-8
    39c6: 67 c0        	rjmp	.+206
    39c8: 8c d3        	rcall	.+1816
    39ca: 16 81        	ldd	r17, Z+6
    39cc: 1f 71        	andi	r17, 0x1f
    39ce: 01 2b        	or	r16, r17
    39d0: f7 cf        	rjmp	.-18
    39d2: 92 d3        	rcall	.+1828
    39d4: 15 81        	ldd	r17, Z+5
    39d6: 1f 73        	andi	r17, 0x3f
    39d8: fa cf        	rjmp	.-12
    39da: f1 df        	rcall	.-30
    39dc: 9f c2        	rjmp	.+1342
    39de: ac 01 5a c0  	<unknown>
    39e2: a8 d2        	rcall	.+1360
    39e4: 01 70        	andi	r16, 0x1
    39e6: 08 95        	ret
    39e8: ac 01 44 5f  	<unknown>
    39ec: 98 c2        	rjmp	.+1328
    39ee: fc df        	rcall	.-8
    39f0: 10 2f        	mov	r17, r16
    39f2: 1f 77        	andi	r17, 0x7f
    39f4: 08 95        	ret
    39f6: ac 01 4b 5f  	<unknown>
    39fa: 91 c2        	rjmp	.+1314
    39fc: ac 01 45 5f  	<unknown>
    3a00: 97 c2        	rjmp	.+1326
    3a02: 42 e0        	ldi	r20, 0x2
    3a04: 50 e0        	ldi	r21, 0x0
    3a06: 20 e2        	ldi	r18, 0x20
    3a08: 30 e0        	ldi	r19, 0x0
    3a0a: 8e 01 08 95  	<unknown>
    3a0e: 05 e1        	ldi	r16, 0x15
    3a10: 10 e0        	ldi	r17, 0x0
    3a12: 02 d0        	rcall	.+4
    3a14: 2c e4        	ldi	r18, 0x4c
    3a16: 08 95        	ret
    3a18: 0c 94 cd 31  	<unknown>
    3a1c: 40 91 b4 06  	<unknown>
    3a20: 0d d0        	rcall	.+26
    3a22: 2c e4        	ldi	r18, 0x4c
    3a24: 30 e0        	ldi	r19, 0x0
    3a26: 20 0f        	add	r18, r16
    3a28: 31 1f        	adc	r19, r17
    3a2a: ca cf        	rjmp	.-108
    3a2c: 32 d0        	rcall	.+100
    3a2e: 00 72        	andi	r16, 0x20
    3a30: 08 95        	ret
    3a32: 02 d0        	rcall	.+4
    3a34: 45 d2        	rcall	.+1162
    3a36: 2f c0        	rjmp	.+94
    3a38: 40 91 b4 06  	<unknown>
    3a3c: 50 e0        	ldi	r21, 0x0
    3a3e: 05 e1        	ldi	r16, 0x15
    3a40: 10 e0        	ldi	r17, 0x0
    3a42: ea cf        	rjmp	.-44
    3a44: f6 df        	rcall	.-20
    3a46: 00 7c        	andi	r16, 0xc0
    3a48: 08 95        	ret
    3a4a: 2d e4        	ldi	r18, 0x4d
    3a4c: 30 e0        	ldi	r19, 0x0
    3a4e: 21 d0        	rcall	.+66
    3a50: 14 e0        	ldi	r17, 0x4
    3a52: 01 9f 01 2d  	<unknown>
    3a56: 11 20        	tst	r1
    3a58: 08 95        	ret
    3a5a: 1b d0        	rcall	.+54
    3a5c: 02 d0        	rcall	.+4
    3a5e: 05 83        	std	Z+5, r16
    3a60: 08 95        	ret
    3a62: 0f 73        	andi	r16, 0x3f
    3a64: 12 c0        	rjmp	.+36
    3a66: 10 e0        	ldi	r17, 0x0
    3a68: 36 c0        	rjmp	.+108
    3a6a: d8 df        	rcall	.-80
    3a6c: 4a 5f        	subi	r20, 0xfa
    3a6e: 57 c2        	rjmp	.+1198
    3a70: 31 d0        	rcall	.+98
    3a72: 2f e4        	ldi	r18, 0x4f
    3a74: 30 e0        	ldi	r19, 0x0
    3a76: 0d d0        	rcall	.+26
    3a78: 00 78        	andi	r16, 0x80
    3a7a: 08 95        	ret
    3a7c: 0a d0        	rcall	.+20
    3a7e: 04 d0        	rcall	.+8
    3a80: 06 83        	std	Z+6, r16
    3a82: 20 e5        	ldi	r18, 0x50
    3a84: 30 e0        	ldi	r19, 0x0
    3a86: 05 c0        	rjmp	.+10
    3a88: 0f 71        	andi	r16, 0x1f
    3a8a: ed 91        	ld	r30, X+
    3a8c: fc 91        	ld	r31, X
    3a8e: 11 97 08 95  	<unknown>
    3a92: d2 df        	rcall	.-92
    3a94: c8 df        	rcall	.-112
    3a96: 0c 94 86 31  	<unknown>
    3a9a: 10 e0        	ldi	r17, 0x0
    3a9c: ac 01 bc df  	<unknown>
    3aa0: 02 0f        	add	r16, r18
    3aa2: 13 1f        	adc	r17, r19
    3aa4: 0c 94 70 35  	<unknown>
    3aa8: fd df        	rcall	.-6
    3aaa: 46 cf        	rjmp	.-372
    3aac: e0 2f        	mov	r30, r16
    3aae: f0 e0        	ldi	r31, 0x0
    3ab0: 31 96 fa 93  	<unknown>
    3ab4: ea 93        	st	-Y, r30
    3ab6: 08 95        	ret
    3ab8: 0e 94 43 0f  	<unknown>
    3abc: d4 df        	rcall	.-88
    3abe: 80 91 b4 06  	<unknown>
    3ac2: 90 e0        	ldi	r25, 0x0
    3ac4: 01 96 9a 93  	<unknown>
    3ac8: 8a 93        	st	-Y, r24
    3aca: 08 95        	ret
    3acc: eb df        	rcall	.-42
    3ace: 22 96 08 95  	<unknown>
    3ad2: e8 df        	rcall	.-48
    3ad4: 11 e0        	ldi	r17, 0x1
    3ad6: 00 e0        	ldi	r16, 0x0
    3ad8: 61 cf        	rjmp	.-318
    3ada: e4 df        	rcall	.-56
    3adc: 06 d0        	rcall	.+12
    3ade: fa df        	rcall	.-12
    3ae0: 9a 93        	st	-Y, r25
    3ae2: 8a 93        	st	-Y, r24
    3ae4: 27 e5        	ldi	r18, 0x57
    3ae6: 30 e0        	ldi	r19, 0x0
    3ae8: d4 cf        	rjmp	.-88
    3aea: 21 e0        	ldi	r18, 0x1
    3aec: 1f e0        	ldi	r17, 0xf
    3aee: 00 e0        	ldi	r16, 0x0
    3af0: 0c 94 34 0f  	<unknown>
    3af4: 0e 94 ea 34  	<unknown>
    3af8: 81 2e        	mov	r8, r17
    3afa: a2 2f        	mov	r26, r18
    3afc: e3 2f        	mov	r30, r19
    3afe: 94 2f        	mov	r25, r20
    3b00: 85 2f        	mov	r24, r21
    3b02: 5a d0        	rcall	.+180
    3b04: 40 e1        	ldi	r20, 0x10
    3b06: 5e e0        	ldi	r21, 0xe
    3b08: 60 e0        	ldi	r22, 0x0
    3b0a: 70 e0        	ldi	r23, 0x0
    3b0c: 46 d0        	rcall	.+140
    3b0e: 51 d0        	rcall	.+162
    3b10: 08 2d        	mov	r16, r8
    3b12: 52 d0        	rcall	.+164
    3b14: 4c e3        	ldi	r20, 0x3c
    3b16: 50 e0        	ldi	r21, 0x0
    3b18: 42 d0        	rcall	.+132
    3b1a: 10 e0        	ldi	r17, 0x0
    3b1c: 4a 0e        	add	r4, r26
    3b1e: 57 1e        	adc	r5, r23
    3b20: 67 1e        	adc	r6, r23
    3b22: 77 1e        	adc	r7, r23
    3b24: 0e 2f        	mov	r16, r30
    3b26: 01 50        	subi	r16, 0x1
    3b28: 10 40        	sbci	r17, 0x0
    3b2a: 21 2f        	mov	r18, r17
    3b2c: 22 0f        	lsl	r18
    3b2e: 22 0b        	sbc	r18, r18
    3b30: 32 2f        	mov	r19, r18
    3b32: 40 e8        	ldi	r20, 0x80
    3b34: 51 e5        	ldi	r21, 0x51
    3b36: 61 e0        	ldi	r22, 0x1
    3b38: 32 d0        	rcall	.+100
    3b3a: a1 e0        	ldi	r26, 0x1
    3b3c: 08 c0        	rjmp	.+16
    3b3e: f0 e0        	ldi	r31, 0x0
    3b40: ea 2f        	mov	r30, r26
    3b42: e0 57        	subi	r30, 0x70
    3b44: f8 4f        	sbci	r31, 0xf8
    3b46: 04 91 37 d0  	<unknown>
    3b4a: 29 d0        	rcall	.+82
    3b4c: a3 95        	inc	r26
    3b4e: a9 17        	cp	r26, r25
    3b50: b0 f3        	brlo	.-20
    3b52: 93 30        	cpi	r25, 0x3
    3b54: 39 f4        	brne	.+14
    3b56: 08 2f        	mov	r16, r24
    3b58: 03 70        	andi	r16, 0x3
    3b5a: 21 f4        	brne	.+8
    3b5c: 44 0e        	add	r4, r20
    3b5e: 55 1e        	adc	r5, r21
    3b60: 66 1e        	adc	r6, r22
    3b62: 77 1e        	adc	r7, r23
    3b64: 08 2f        	mov	r16, r24
    3b66: 28 d0        	rcall	.+80
    3b68: 4d e6        	ldi	r20, 0x6d
    3b6a: 51 e0        	ldi	r21, 0x1
    3b6c: 60 e0        	ldi	r22, 0x0
    3b6e: 15 d0        	rcall	.+42
    3b70: 86 95        	lsr	r24
    3b72: 86 95        	lsr	r24
    3b74: 08 0f        	add	r16, r24
    3b76: 17 1f        	adc	r17, r23
    3b78: 27 1f        	adc	r18, r23
    3b7a: 37 1f        	adc	r19, r23
    3b7c: 40 e8        	ldi	r20, 0x80
    3b7e: 51 e5        	ldi	r21, 0x51
    3b80: 61 e0        	ldi	r22, 0x1
    3b82: 0b d0        	rcall	.+22
    3b84: a8 01 b9 01  	<unknown>
    3b88: 82 01 93 01  	<unknown>
    3b8c: 04 0f        	add	r16, r20
    3b8e: 15 1f        	adc	r17, r21
    3b90: 26 1f        	adc	r18, r22
    3b92: 37 1f        	adc	r19, r23
    3b94: e9 e0        	ldi	r30, 0x9
    3b96: 0c 94 fb 34  	<unknown>
    3b9a: 0c 94 0d 32  	<unknown>
    3b9e: 0e 94 0d 32  	<unknown>
    3ba2: 40 0e        	add	r4, r16
    3ba4: 51 1e        	adc	r5, r17
    3ba6: 62 1e        	adc	r6, r18
    3ba8: 73 1e        	adc	r7, r19
    3baa: 08 95        	ret
    3bac: 1a 2f        	mov	r17, r26
    3bae: 0b 2f        	mov	r16, r27
    3bb0: f4 d1        	rcall	.+1000
    3bb2: 28 01 39 01  	<unknown>
    3bb6: 08 95        	ret
    3bb8: 10 e0        	ldi	r17, 0x0
    3bba: 20 e0        	ldi	r18, 0x0
    3bbc: 30 e0        	ldi	r19, 0x0
    3bbe: 08 95        	ret
    3bc0: 0e 94 e3 34  	<unknown>
    3bc4: 0f b7        	in	r16, 0x3f
    3bc6: 0a 93        	st	-Y, r16
    3bc8: f8 94        	cli
    3bca: 22 97 00 e0  	<unknown>
    3bce: 08 83        	std	Y+0, r16
    3bd0: 40 91 b9 06  	<unknown>
    3bd4: e3 d1        	rcall	.+966
    3bd6: b1 d1        	rcall	.+866
    3bd8: 09 f4        	brne	.+2
    3bda: 51 c1        	rjmp	.+674
    3bdc: e7 e2        	ldi	r30, 0x27
    3bde: f7 e0        	ldi	r31, 0x7
    3be0: 02 81        	ldd	r16, Z+2
    3be2: b0 2f        	mov	r27, r16
    3be4: bf 70        	andi	r27, 0xf
    3be6: 00 73        	andi	r16, 0x30
    3be8: 02 95        	swap	r16
    3bea: 1a e0        	ldi	r17, 0xa
    3bec: 01 9f b0 0d  	<unknown>
    3bf0: 01 81        	ldd	r16, Z+1
    3bf2: a0 2f        	mov	r26, r16
    3bf4: af 70        	andi	r26, 0xf
    3bf6: 00 77        	andi	r16, 0x70
    3bf8: 02 95        	swap	r16
    3bfa: 01 9f a0 0d  	<unknown>
    3bfe: 20 81        	ldd	r18, Z+0
    3c00: 2f 70        	andi	r18, 0xf
    3c02: 00 81        	ldd	r16, Z+0
    3c04: 00 77        	andi	r16, 0x70
    3c06: 02 95        	swap	r16
    3c08: 01 9f 20 0d  	<unknown>
    3c0c: 29 83        	std	Y+1, r18
    3c0e: 04 81        	ldd	r16, Z+4
    3c10: 60 2f        	mov	r22, r16
    3c12: 6f 70        	andi	r22, 0xf
    3c14: 00 73        	andi	r16, 0x30
    3c16: 02 95        	swap	r16
    3c18: 01 9f 60 0d  	<unknown>
    3c1c: 75 81        	ldd	r23, Z+5
    3c1e: 7f 70        	andi	r23, 0xf
    3c20: 15 81        	ldd	r17, Z+5
    3c22: 14 fb        	bst	r17, 0x4
    3c24: 10 e0        	ldi	r17, 0x0
    3c26: 10 f9        	bld	r17, 0x0
    3c28: 0a e0        	ldi	r16, 0xa
    3c2a: 10 9f 70 0d  	<unknown>
    3c2e: 55 24        	clr	r5
    3c30: 66 24        	clr	r6
    3c32: 77 24        	clr	r7
    3c34: 44 24        	clr	r4
    3c36: 43 94        	inc	r4
    3c38: 02 e0        	ldi	r16, 0x2
    3c3a: c0 2e        	mov	r12, r16
    3c3c: dd 24        	clr	r13
    3c3e: ee 24        	clr	r14
    3c40: ff 24        	clr	r15
    3c42: 03 e0        	ldi	r16, 0x3
    3c44: 80 2e        	mov	r8, r16
    3c46: 99 24        	clr	r9
    3c48: aa 24        	clr	r10
    3c4a: bb 24        	clr	r11
    3c4c: 7d d1        	rcall	.+762
    3c4e: 10 2f        	mov	r17, r16
    3c50: 3c d1        	rcall	.+632
    3c52: 51 f0        	breq	.+20
    3c54: 0a 95        	dec	r16
    3c56: 09 f4        	brne	.+2
    3c58: 47 c0        	rjmp	.+142
    3c5a: 0a 95        	dec	r16
    3c5c: 09 f4        	brne	.+2
    3c5e: 6b c0        	rjmp	.+214
    3c60: 0a 95        	dec	r16
    3c62: 09 f4        	brne	.+2
    3c64: 91 c0        	rjmp	.+290
    3c66: 28 c0        	rjmp	.+80
    3c68: 06 81        	ldd	r16, Z+6
    3c6a: 50 2f        	mov	r21, r16
    3c6c: 5f 70        	andi	r21, 0xf
    3c6e: 02 95        	swap	r16
    3c70: 0f 70        	andi	r16, 0xf
    3c72: 1a e0        	ldi	r17, 0xa
    3c74: 01 9f 50 0d  	<unknown>
    3c78: 47 2f        	mov	r20, r23
    3c7a: 36 2f        	mov	r19, r22
    3c7c: 97 df        	rcall	.-210
    3c7e: ac 01 4d 5f  	<unknown>
    3c82: 48 d1        	rcall	.+656
    3c84: 25 d1        	rcall	.+586
    3c86: 47 5f        	subi	r20, 0xf7
    3c88: 34 d1        	rcall	.+616
    3c8a: 61 d1        	rcall	.+706
    3c8c: 56 2f        	mov	r21, r22
    3c8e: 61 2f        	mov	r22, r17
    3c90: 75 2f        	mov	r23, r21
    3c92: 60 d1        	rcall	.+704
    3c94: 32 d1        	rcall	.+612
    3c96: 68 01 79 01  	<unknown>
    3c9a: ac 01 4e 5f  	<unknown>
    3c9e: 3a d1        	rcall	.+628
    3ca0: 02 95        	swap	r16
    3ca2: 16 d1        	rcall	.+556
    3ca4: 46 5f        	subi	r20, 0xf6
    3ca6: 25 d1        	rcall	.+586
    3ca8: 4a d1        	rcall	.+660
    3caa: 56 2f        	mov	r21, r22
    3cac: 61 2f        	mov	r22, r17
    3cae: 75 2f        	mov	r23, r21
    3cb0: 57 d1        	rcall	.+686
    3cb2: 23 d1        	rcall	.+582
    3cb4: 48 01 59 01  	<unknown>
    3cb8: 4c 14        	cp	r4, r12
    3cba: 5d 04        	cpc	r5, r13
    3cbc: 6e 04        	cpc	r6, r14
    3cbe: 7f 04        	cpc	r7, r15
    3cc0: f8 f1        	brlo	.+126
    3cc2: 48 14        	cp	r4, r8
    3cc4: 59 04        	cpc	r5, r9
    3cc6: 6a 04        	cpc	r6, r10
    3cc8: 7b 04        	cpc	r7, r11
    3cca: d0 f5        	brsh	.+116
    3ccc: 33 d1        	rcall	.+614
    3cce: 20 2f        	mov	r18, r16
    3cd0: 30 e0        	ldi	r19, 0x0
    3cd2: 5e d1        	rcall	.+700
    3cd4: 09 f4        	brne	.+2
    3cd6: 5f c0        	rjmp	.+190
    3cd8: 21 70        	andi	r18, 0x1
    3cda: 22 0f        	lsl	r18
    3cdc: f9 01 ed 58  	<unknown>
    3ce0: f9 4f        	sbci	r31, 0xf9
    3ce2: 24 81        	ldd	r18, Z+4
    3ce4: 35 81        	ldd	r19, Z+5
    3ce6: 5e c0        	rjmp	.+188
    3ce8: 4b d1        	rcall	.+662
    3cea: 43 81        	ldd	r20, Z+3
    3cec: 47 70        	andi	r20, 0x7
    3cee: 4a 95        	dec	r20
    3cf0: 63 d1        	rcall	.+710
    3cf2: 31 f1        	breq	.+76
    3cf4: 50 e0        	ldi	r21, 0x0
    3cf6: 40 e0        	ldi	r20, 0x0
    3cf8: 30 e0        	ldi	r19, 0x0
    3cfa: 29 81        	ldd	r18, Y+1
    3cfc: 57 df        	rcall	.-338
    3cfe: 30 e0        	ldi	r19, 0x0
    3d00: 26 d1        	rcall	.+588
    3d02: 28 d1        	rcall	.+592
    3d04: 47 d1        	rcall	.+654
    3d06: 68 01 79 01  	<unknown>
    3d0a: 30 e0        	ldi	r19, 0x0
    3d0c: 18 d1        	rcall	.+560
    3d0e: 28 d1        	rcall	.+592
    3d10: 41 d1        	rcall	.+642
    3d12: 48 01 59 01  	<unknown>
    3d16: 8c 14        	cp	r8, r12
    3d18: 9d 04        	cpc	r9, r13
    3d1a: ae 04        	cpc	r10, r14
    3d1c: bf 04        	cpc	r11, r15
    3d1e: 60 f6        	brsh	.-104
    3d20: 40 16        	cp	r4, r16
    3d22: 51 06        	cpc	r5, r17
    3d24: 62 06        	cpc	r6, r18
    3d26: 73 06        	cpc	r7, r19
    3d28: 88 f2        	brlo	.-94
    3d2a: c4 14        	cp	r12, r4
    3d2c: d5 04        	cpc	r13, r5
    3d2e: e6 04        	cpc	r14, r6
    3d30: f7 04        	cpc	r15, r7
    3d32: 10 f6        	brsh	.-124
    3d34: cb cf        	rjmp	.-106
    3d36: 24 d1        	rcall	.+584
    3d38: 6a 95        	dec	r22
    3d3a: 46 2f        	mov	r20, r22
    3d3c: 3d d1        	rcall	.+634
    3d3e: d1 f6        	brne	.-76
    3d40: e7 d0        	rcall	.+462
    3d42: 00 38        	cpi	r16, 0x80
    3d44: 69 f4        	brne	.+26
    3d46: 57 de        	rcall	.-850
    3d48: 00 7c        	andi	r16, 0xc0
    3d4a: 00 34        	cpi	r16, 0x40
    3d4c: 19 f4        	brne	.+6
    3d4e: 10 e0        	ldi	r17, 0x0
    3d50: 10 93 37 07  	<unknown>
    3d54: 00 23        	tst	r16
    3d56: 21 f0        	breq	.+8
    3d58: 4e de        	rcall	.-868
    3d5a: 0f 73        	andi	r16, 0x3f
    3d5c: 05 96 d3 d0  	<unknown>
    3d60: 40 91 b9 06  	<unknown>
    3d64: 6b de        	rcall	.-810
    3d66: ac d0        	rcall	.+344
    3d68: 44 5f        	subi	r20, 0xf4
    3d6a: d9 d0        	rcall	.+434
    3d6c: 20 2f        	mov	r18, r16
    3d6e: 2f 77        	andi	r18, 0x7f
    3d70: 30 e0        	ldi	r19, 0x0
    3d72: e9 eb        	ldi	r30, 0xb9
    3d74: f6 e0        	ldi	r31, 0x6
    3d76: e2 0f        	add	r30, r18
    3d78: f3 1f        	adc	r31, r19
    3d7a: 00 78        	andi	r16, 0x80
    3d7c: 08 81        	ldd	r16, Y+0
    3d7e: 11 81        	ldd	r17, Z+1
    3d80: 09 f0        	breq	.+2
    3d82: 7b c0        	rjmp	.+246
    3d84: 10 2b        	or	r17, r16
    3d86: 7a c0        	rjmp	.+244
    3d88: fb d0        	rcall	.+502
    3d8a: 7a 95        	dec	r23
    3d8c: 47 2f        	mov	r20, r23
    3d8e: 14 d1        	rcall	.+552
    3d90: 09 f0        	breq	.+2
    3d92: b0 cf        	rjmp	.-160
    3d94: d5 cf        	rjmp	.-86
    3d96: 22 0f        	lsl	r18
    3d98: 33 1f        	rol	r19
    3d9a: f9 01 e9 53  	<unknown>
    3d9e: f9 4f        	sbci	r31, 0xf9
    3da0: 20 81        	ldd	r18, Z+0
    3da2: 31 81        	ldd	r19, Z+1
    3da4: be d0        	rcall	.+380
    3da6: b8 01 ac 01  	<unknown>
    3daa: a1 d0        	rcall	.+322
    3dac: d8 01 ac 01  	<unknown>
    3db0: 4a 5f        	subi	r20, 0xfa
    3db2: 9b d0        	rcall	.+310
    3db4: 59 f0        	breq	.+22
    3db6: 02 e0        	ldi	r16, 0x2
    3db8: 60 9f f0 01  	<unknown>
    3dbc: e9 53        	subi	r30, 0x39
    3dbe: f9 4f        	sbci	r31, 0xf9
    3dc0: a0 81        	ldd	r26, Z+0
    3dc2: b1 81        	ldd	r27, Z+1
    3dc4: bd 01 62 53  	<unknown>
    3dc8: 70 40        	sbci	r23, 0x0
    3dca: d2 96 08 de  	<unknown>
    3dce: 10 2f        	mov	r17, r16
    3dd0: 4d ee        	ldi	r20, 0xed
    3dd2: 52 e0        	ldi	r21, 0x2
    3dd4: 60 de        	rcall	.-832
    3dd6: 00 23        	tst	r16
    3dd8: 29 f4        	brne	.+10
    3dda: 01 2f        	mov	r16, r17
    3ddc: 00 7c        	andi	r16, 0xc0
    3dde: 00 38        	cpi	r16, 0x80
    3de0: 09 f0        	breq	.+2
    3de2: be cf        	rjmp	.-132
    3de4: 72 d0        	rcall	.+228
    3de6: 39 f0        	breq	.+14
    3de8: 0a 95        	dec	r16
    3dea: c9 f0        	breq	.+50
    3dec: 0a 95        	dec	r16
    3dee: 41 f1        	breq	.+80
    3df0: 0a 95        	dec	r16
    3df2: 91 f0        	breq	.+36
    3df4: b5 cf        	rjmp	.-150
    3df6: ee d0        	rcall	.+476
    3df8: 11 f0        	breq	.+4
    3dfa: 00 20        	tst	r0
    3dfc: 19 f0        	breq	.+6
    3dfe: 00 20        	tst	r0
    3e00: 09 f4        	brne	.+2
    3e02: ae cf        	rjmp	.-164
    3e04: 62 17        	cp	r22, r18
    3e06: 73 07        	cpc	r23, r19
    3e08: 3c f4        	brge	.+14
    3e0a: 2a 17        	cp	r18, r26
    3e0c: 3b 07        	cpc	r19, r27
    3e0e: 0c f0        	brlt	.+2
    3e10: a7 cf        	rjmp	.-178
    3e12: ad d0        	rcall	.+346
    3e14: 09 f4        	brne	.+2
    3e16: a4 cf        	rjmp	.-184
    3e18: 01 e0        	ldi	r16, 0x1
    3e1a: 08 83        	std	Y+0, r16
    3e1c: a1 cf        	rjmp	.-190
    3e1e: da d0        	rcall	.+436
    3e20: 11 f0        	breq	.+4
    3e22: 00 20        	tst	r0
    3e24: 19 f0        	breq	.+6
    3e26: 00 20        	tst	r0
    3e28: 09 f4        	brne	.+2
    3e2a: 9a cf        	rjmp	.-204
    3e2c: 2a 17        	cp	r18, r26
    3e2e: 3b 07        	cpc	r19, r27
    3e30: 9c f7        	brge	.-26
    3e32: 62 17        	cp	r22, r18
    3e34: 73 07        	cpc	r23, r19
    3e36: 0c f0        	brlt	.+2
    3e38: 93 cf        	rjmp	.-218
    3e3a: 99 d0        	rcall	.+306
    3e3c: 69 f7        	brne	.-38
    3e3e: 90 cf        	rjmp	.-224
    3e40: da dd        	rcall	.-1100
    3e42: 10 2f        	mov	r17, r16
    3e44: 10 7c        	andi	r17, 0xc0
    3e46: 31 f4        	brne	.+12
    3e48: 0f 73        	andi	r16, 0x3f
    3e4a: 00 64        	ori	r16, 0x40
    3e4c: 6f d0        	rcall	.+222
    3e4e: 01 e0        	ldi	r16, 0x1
    3e50: 00 93 37 07  	<unknown>
    3e54: 05 96 5c d0  	<unknown>
    3e58: 00 34        	cpi	r16, 0x40
    3e5a: 09 f0        	breq	.+2
    3e5c: 81 cf        	rjmp	.-254
    3e5e: 0e 94 1f 10  	<unknown>
    3e62: 00 23        	tst	r16
    3e64: 09 f0        	breq	.+2
    3e66: 7c cf        	rjmp	.-264
    3e68: 40 91 b9 06  	<unknown>
    3e6c: 9d d0        	rcall	.+314
    3e6e: 2b 5f        	subi	r18, 0xfb
    3e70: 35 d0        	rcall	.+106
    3e72: 00 e0        	ldi	r16, 0x0
    3e74: 00 93 37 07  	<unknown>
    3e78: 73 cf        	rjmp	.-282
    3e7a: 10 23        	and	r17, r16
    3e7c: 11 83        	std	Z+1, r17
    3e7e: e9 eb        	ldi	r30, 0xb9
    3e80: f6 e0        	ldi	r31, 0x6
    3e82: 00 81        	ldd	r16, Z+0
    3e84: 03 95        	inc	r16
    3e86: 00 83        	std	Z+0, r16
    3e88: 00 32        	cpi	r16, 0x20
    3e8a: a0 f0        	brlo	.+40
    3e8c: 80 e0        	ldi	r24, 0x0
    3e8e: 90 e0        	ldi	r25, 0x0
    3e90: a9 eb        	ldi	r26, 0xb9
    3e92: b6 e0        	ldi	r27, 0x6
    3e94: a8 0f        	add	r26, r24
    3e96: b9 1f        	adc	r27, r25
    3e98: fd 01 31 81  	<unknown>
    3e9c: 28 2f        	mov	r18, r24
    3e9e: 07 e4        	ldi	r16, 0x47
    3ea0: 17 e0        	ldi	r17, 0x7
    3ea2: 0e 94 89 11  	<unknown>
    3ea6: fd 01 91 83  	<unknown>
    3eaa: 83 95        	inc	r24
    3eac: 8c 30        	cpi	r24, 0xc
    3eae: 78 f3        	brlo	.-34
    3eb0: 90 93 b9 06  	<unknown>
    3eb4: 22 96 09 91  	<unknown>
    3eb8: 0f bf        	out	0x3f, r16
    3eba: e0 e1        	ldi	r30, 0x10
    3ebc: 0c 94 f4 34  	<unknown>
    3ec0: 4c e4        	ldi	r20, 0x4c
    3ec2: 50 e0        	ldi	r21, 0x0
    3ec4: 40 0f        	add	r20, r16
    3ec6: 51 1f        	adc	r21, r17
    3ec8: 08 95        	ret
    3eca: 04 e0        	ldi	r16, 0x4
    3ecc: 10 9f c2 cd  	<unknown>
    3ed0: 0f 70        	andi	r16, 0xf
    3ed2: 51 2f        	mov	r21, r17
    3ed4: 10 2f        	mov	r17, r16
    3ed6: 25 2f        	mov	r18, r21
    3ed8: ac 01 08 95  	<unknown>
    3edc: 3f 4f        	sbci	r19, 0xff
    3ede: a9 01 15 c0  	<unknown>
    3ee2: 2b 5f        	subi	r18, 0xfb
    3ee4: 3f 4f        	sbci	r19, 0xff
    3ee6: a9 01 d6 cd  	<unknown>
    3eea: 19 d0        	rcall	.+50
    3eec: a0 cd        	rjmp	.-1216
    3eee: 41 5f        	subi	r20, 0xf1
    3ef0: 1a c0        	rjmp	.+52
    3ef2: 06 d0        	rcall	.+12
    3ef4: 30 2f        	mov	r19, r16
    3ef6: 62 2f        	mov	r22, r18
    3ef8: 08 95        	ret
    3efa: 02 d0        	rcall	.+4
    3efc: ab 01 4d c0  	<unknown>
    3f00: 0e d0        	rcall	.+28
    3f02: 0f 71        	andi	r16, 0x1f
    3f04: 08 95        	ret
    3f06: ac 01 01 c0  	<unknown>
    3f0a: ab 01 0c 94  	<unknown>
    3f0e: a0 31        	cpi	r26, 0x10
    3f10: 66 dd        	rcall	.-1332
    3f12: 99 cd        	rjmp	.-1230
    3f14: 04 d0        	rcall	.+8
    3f16: 0f 77        	andi	r16, 0x7f
    3f18: 10 2f        	mov	r17, r16
    3f1a: ac 01 4c 5f  	<unknown>
    3f1e: 5f 4f        	sbci	r21, 0xff
    3f20: ba cd        	rjmp	.-1164
    3f22: ac 01 43 5f  	<unknown>
    3f26: 5f 4f        	sbci	r21, 0xff
    3f28: 0c 94 89 31  	<unknown>
    3f2c: ac 01 4b 5f  	<unknown>
    3f30: 5f 4f        	sbci	r21, 0xff
    3f32: ec cf        	rjmp	.-40
    3f34: ac 01 45 5f  	<unknown>
    3f38: f2 cf        	rjmp	.-28
    3f3a: ac 01 e5 c0  	<unknown>
    3f3e: ac 01 48 5f  	<unknown>
    3f42: 37 d0        	rcall	.+110
    3f44: 20 2f        	mov	r18, r16
    3f46: 08 95        	ret
    3f48: ac 01 4f 5f  	<unknown>
    3f4c: e8 cf        	rjmp	.-48
    3f4e: fc df        	rcall	.-8
    3f50: 0f 73        	andi	r16, 0x3f
    3f52: f8 cf        	rjmp	.-16
    3f54: 44 dd        	rcall	.-1400
    3f56: 0f 73        	andi	r16, 0x3f
    3f58: 10 2f        	mov	r17, r16
    3f5a: ac 01 4a 5f  	<unknown>
    3f5e: 08 95        	ret
    3f60: ac 01 49 5f  	<unknown>
    3f64: 26 d0        	rcall	.+76
    3f66: 10 2f        	mov	r17, r16
    3f68: ac 01 4b 5f  	<unknown>
    3f6c: 08 95        	ret
    3f6e: 0c 96 36 dd  	<unknown>
    3f72: 0f 77        	andi	r16, 0x7f
    3f74: 20 2f        	mov	r18, r16
    3f76: 07 e4        	ldi	r16, 0x47
    3f78: 17 e0        	ldi	r17, 0x7
    3f7a: 0e 94 b1 11  	<unknown>
    3f7e: c9 cc        	rjmp	.-1646
    3f80: ac 01 4f 5e  	<unknown>
    3f84: 5f 4f        	sbci	r21, 0xff
    3f86: 0e 94 8e 31  	<unknown>
    3f8a: 08 01 19 01  	<unknown>
    3f8e: 08 95        	ret
    3f90: 32 dd        	rcall	.-1436
    3f92: 4d cd        	rjmp	.-1382
    3f94: b5 df        	rcall	.-150
    3f96: 50 e0        	ldi	r21, 0x0
    3f98: 40 e0        	ldi	r20, 0x0
    3f9a: ac cd        	rjmp	.-1192
    3f9c: 4f dd        	rcall	.-1378
    3f9e: 8c e4        	ldi	r24, 0x4c
    3fa0: 90 e0        	ldi	r25, 0x0
    3fa2: 80 0f        	add	r24, r16
    3fa4: 91 1f        	adc	r25, r17
    3fa6: 08 95        	ret
    3fa8: 3b dd        	rcall	.-1418
    3faa: 4b 5f        	subi	r20, 0xfb
    3fac: 02 d0        	rcall	.+4
    3fae: 00 68        	ori	r16, 0x80
    3fb0: 08 95        	ret
    3fb2: b5 df        	rcall	.-150
    3fb4: 0f 73        	andi	r16, 0x3f
    3fb6: 08 95        	ret
    3fb8: 01 e0        	ldi	r16, 0x1
    3fba: 10 e0        	ldi	r17, 0x0
    3fbc: 20 e0        	ldi	r18, 0x0
    3fbe: 30 e0        	ldi	r19, 0x0
    3fc0: 0e 94 2d 32  	<unknown>
    3fc4: 00 22        	and	r0, r16
    3fc6: 11 22        	and	r1, r17
    3fc8: 22 22        	and	r2, r18
    3fca: 33 22        	and	r3, r19
    3fcc: 01 28        	or	r0, r1
    3fce: 02 28        	or	r0, r2
    3fd0: 03 28        	or	r0, r3
    3fd2: 08 95        	ret
    3fd4: 10 dd        	rcall	.-1504
    3fd6: 00 2e        	mov	r0, r16
    3fd8: 00 e2        	ldi	r16, 0x20
    3fda: 00 22        	and	r0, r16
    3fdc: ab df        	rcall	.-170
    3fde: f0 e0        	ldi	r31, 0x0
    3fe0: e0 2f        	mov	r30, r16
    3fe2: e9 5f        	subi	r30, 0xf9
    3fe4: f8 4f        	sbci	r31, 0xf8
    3fe6: 00 81        	ldd	r16, Z+0
    3fe8: 94 cc        	rjmp	.-1752
    3fea: 2f b6        	in	r2, 0x3f
    3fec: f8 94        	cli
    3fee: e0 e0        	ldi	r30, 0x0
    3ff0: 4e 2f        	mov	r20, r30
    3ff2: 8d d0        	rcall	.+282
    3ff4: 4a 5f        	subi	r20, 0xfa
    3ff6: 75 d0        	rcall	.+234
    3ff8: ab 01 4a 5f  	<unknown>
    3ffc: 70 d0        	rcall	.+224
    3ffe: 00 7c        	andi	r16, 0xc0
    4000: 55 d0        	rcall	.+170
    4002: 77 d0        	rcall	.+238
    4004: 4f 5f        	subi	r20, 0xff
    4006: 73 d0        	rcall	.+230
    4008: 00 7e        	andi	r16, 0xe0
    400a: 5e d0        	rcall	.+188
    400c: 49 5f        	subi	r20, 0xf9
    400e: 71 d0        	rcall	.+226
    4010: 49 5f        	subi	r20, 0xf9
    4012: 5d d0        	rcall	.+186
    4014: 6e d0        	rcall	.+220
    4016: 48 5f        	subi	r20, 0xf8
    4018: 73 d0        	rcall	.+230
    401a: 76 d0        	rcall	.+236
    401c: 6f d0        	rcall	.+222
    401e: 52 d0        	rcall	.+164
    4020: ab 01 4e 5f  	<unknown>
    4024: 61 d0        	rcall	.+194
    4026: 00 7e        	andi	r16, 0xe0
    4028: 01 60        	ori	r16, 0x1
    402a: ab 01 47 5f  	<unknown>
    402e: 68 d0        	rcall	.+208
    4030: 46 5f        	subi	r20, 0xf6
    4032: 57 d0        	rcall	.+174
    4034: 01 60        	ori	r16, 0x1
    4036: ab 01 46 5f  	<unknown>
    403a: 7a df        	rcall	.-268
    403c: 01 e1        	ldi	r16, 0x11
    403e: ab 01 4c 5f  	<unknown>
    4042: b9 dc        	rcall	.-1678
    4044: ab 01 44 5f  	<unknown>
    4048: 73 df        	rcall	.-282
    404a: 10 e0        	ldi	r17, 0x0
    404c: ab 01 43 5f  	<unknown>
    4050: 35 d0        	rcall	.+106
    4052: 41 5f        	subi	r20, 0xf1
    4054: 33 d0        	rcall	.+102
    4056: 45 5f        	subi	r20, 0xf5
    4058: 42 d0        	rcall	.+132
    405a: 00 6c        	ori	r16, 0xc0
    405c: 27 d0        	rcall	.+78
    405e: 3d d0        	rcall	.+122
    4060: a9 dc        	rcall	.-1710
    4062: 20 e0        	ldi	r18, 0x0
    4064: 30 e0        	ldi	r19, 0x0
    4066: ab 01 25 d0  	<unknown>
    406a: ab 01 4b d0  	<unknown>
    406e: 0f 77        	andi	r16, 0x7f
    4070: 45 d0        	rcall	.+138
    4072: 4b 5f        	subi	r20, 0xfb
    4074: 2f d0        	rcall	.+94
    4076: 29 d0        	rcall	.+82
    4078: 4e 5f        	subi	r20, 0xfe
    407a: 51 df        	rcall	.-350
    407c: 00 68        	ori	r16, 0x80
    407e: ab 01 4e 5f  	<unknown>
    4082: 35 d0        	rcall	.+106
    4084: 0f 73        	andi	r16, 0x3f
    4086: 00 68        	ori	r16, 0x80
    4088: 1f d0        	rcall	.+62
    408a: 4a 5f        	subi	r20, 0xfa
    408c: 23 d0        	rcall	.+70
    408e: 4a 5f        	subi	r20, 0xfa
    4090: 1e d0        	rcall	.+60
    4092: 23 d0        	rcall	.+70
    4094: 48 5f        	subi	r20, 0xf8
    4096: 28 d0        	rcall	.+80
    4098: 0f 71        	andi	r16, 0x1f
    409a: 67 5f        	subi	r22, 0xf7
    409c: 7f 4f        	sbci	r23, 0xff
    409e: 35 df        	rcall	.-406
    40a0: e3 95        	inc	r30
    40a2: e0 32        	cpi	r30, 0x20
    40a4: 08 f4        	brsh	.+2
    40a6: a4 cf        	rjmp	.-184
    40a8: 2f be        	out	0x3f, r2
    40aa: 08 95        	ret
    40ac: 2e df        	rcall	.-420
    40ae: ab 01 4f 5f  	<unknown>
    40b2: 08 95        	ret
    40b4: 4f 5e        	subi	r20, 0xef
    40b6: 5f 4f        	sbci	r21, 0xff
    40b8: 0c 94 ab 31  	<unknown>
    40bc: 5f 4f        	sbci	r21, 0xff
    40be: 0e 94 a4 31  	<unknown>
    40c2: 18 c0        	rjmp	.+48
    40c4: 4e 5f        	subi	r20, 0xfe
    40c6: 21 c0        	rjmp	.+66
    40c8: ab 01 4b 5f  	<unknown>
    40cc: 19 c0        	rjmp	.+50
    40ce: 18 d0        	rcall	.+48
    40d0: 48 5f        	subi	r20, 0xf8
    40d2: 08 95        	ret
    40d4: 24 df        	rcall	.-440
    40d6: 0f 7d        	andi	r16, 0xdf
    40d8: 0d c0        	rjmp	.+26
    40da: 6b df        	rcall	.-298
    40dc: 0b c0        	rjmp	.+22
    40de: 10 d0        	rcall	.+32
    40e0: da cc        	rjmp	.-1612
    40e2: 1d df        	rcall	.-454
    40e4: 00 7e        	andi	r16, 0xe0
    40e6: 08 95        	ret
    40e8: 0b d0        	rcall	.+22
    40ea: 47 5f        	subi	r20, 0xf7
    40ec: 18 cf        	rjmp	.-464
    40ee: 08 d0        	rcall	.+16
    40f0: 83 cc        	rjmp	.-1786
    40f2: 02 d0        	rcall	.+4
    40f4: ab 01 08 95  	<unknown>
    40f8: 12 df        	rcall	.-476
    40fa: a5 cc        	rjmp	.-1718
    40fc: ab 01 4d 5f  	<unknown>
    4100: 17 df        	rcall	.-466
    4102: f8 cf        	rjmp	.-16
    4104: 4d 5f        	subi	r20, 0xfd
    4106: 0b cf        	rjmp	.-490
    4108: 4d 5f        	subi	r20, 0xfd
    410a: 09 df        	rcall	.-494
    410c: b5 cc        	rjmp	.-1686
    410e: 96 dc        	rcall	.-1748
    4110: 6c e4        	ldi	r22, 0x4c
    4112: 70 e0        	ldi	r23, 0x0
    4114: 60 0f        	add	r22, r16
    4116: 71 1f        	adc	r23, r17
    4118: ed cf        	rjmp	.-38
    411a: 08 01 50 e0  	<unknown>
    411e: 60 e0        	ldi	r22, 0x0
    4120: 18 c0        	rjmp	.+48
    4122: 30 e0        	ldi	r19, 0x0
    4124: 25 2e        	mov	r2, r21
    4126: 20 fa        	bst	r2, 0x0
    4128: 22 24        	clr	r2
    412a: 20 f8        	bld	r2, 0x0
    412c: 56 95        	lsr	r21
    412e: 70 e0        	ldi	r23, 0x0
    4130: f0 01 e6 0f  	<unknown>
    4134: f7 1f        	adc	r31, r23
    4136: 00 81        	ldd	r16, Z+0
    4138: 10 e0        	ldi	r17, 0x0
    413a: 43 2f        	mov	r20, r19
    413c: 0e 94 db 31  	<unknown>
    4140: 01 70        	andi	r16, 0x1
    4142: 02 25        	eor	r16, r2
    4144: 11 f0        	breq	.+4
    4146: 0c e8        	ldi	r16, 0x8c
    4148: 50 27        	eor	r21, r16
    414a: 33 95        	inc	r19
    414c: 38 30        	cpi	r19, 0x8
    414e: 50 f3        	brlo	.-44
    4150: 63 95        	inc	r22
    4152: 62 17        	cp	r22, r18
    4154: 30 f3        	brlo	.-52
    4156: 05 2f        	mov	r16, r21
    4158: 08 95        	ret
    415a: 72 d7        	rcall	.+3812
    415c: 0e 94 84 11  	<unknown>
    4160: 01 e6        	ldi	r16, 0x61
    4162: 16 e0        	ldi	r17, 0x6
    4164: 0c 94 1d 31  	<unknown>
    4168: 9a 93        	st	-Y, r25
    416a: 8a 93        	st	-Y, r24
    416c: c8 01 11 e0  	<unknown>
    4170: bf d3        	rcall	.+1918
    4172: 8c 01 89 91  	<unknown>
    4176: 99 91        	ld	r25, Y+
    4178: 08 95        	ret
    417a: 01 b3        	in	r16, 0x11
    417c: 08 64        	ori	r16, 0x48
    417e: 01 bb        	out	0x11, r16
    4180: 04 b3        	in	r16, 0x14
    4182: 0c 6f        	ori	r16, 0xfc
    4184: 04 bb        	out	0x14, r16
    4186: 0a b3        	in	r16, 0x1a
    4188: 00 6f        	ori	r16, 0xf0
    418a: 0a bb        	out	0x1a, r16
    418c: 09 e6        	ldi	r16, 0x69
    418e: 03 bf        	out	0x33, r16
    4190: bb 9a        	sbi	0x17, 0x3
    4192: 0f b5        	in	r16, 0x2f
    4194: 01 6f        	ori	r16, 0xf1
    4196: 0f bd        	out	0x2f, r16
    4198: 0e b5        	in	r16, 0x2e
    419a: 01 60        	ori	r16, 0x1
    419c: 0e bd        	out	0x2e, r16
    419e: 00 e8        	ldi	r16, 0x80
    41a0: 0a bd        	out	0x2a, r16
    41a2: 05 b5        	in	r16, 0x25
    41a4: 04 60        	ori	r16, 0x4
    41a6: 05 bd        	out	0x25, r16
    41a8: 09 b7        	in	r16, 0x39
    41aa: 00 64        	ori	r16, 0x40
    41ac: 09 bf        	out	0x39, r16
    41ae: 05 b7        	in	r16, 0x35
    41b0: 01 61        	ori	r16, 0x11
    41b2: 05 bf        	out	0x35, r16
    41b4: 0b b7        	in	r16, 0x3b
    41b6: 00 64        	ori	r16, 0x40
    41b8: 0b bf        	out	0x3b, r16
    41ba: 08 95        	ret
    41bc: 0e 94 e5 34  	<unknown>
    41c0: 61 97 db df  	<unknown>
    41c4: 0e 94 c6 0e  	<unknown>
    41c8: 0e 94 fb 15  	<unknown>
    41cc: 0e 94 ca 06  	<unknown>
    41d0: 0e 94 11 10  	<unknown>
    41d4: 07 e0        	ldi	r16, 0x7
    41d6: a0 2e        	mov	r10, r16
    41d8: 07 e0        	ldi	r16, 0x7
    41da: b0 2e        	mov	r11, r16
    41dc: 99 d3        	rcall	.+1842
    41de: 30 d7        	rcall	.+3680
    41e0: 0e 94 fd 11  	<unknown>
    41e4: 0e 94 1f 10  	<unknown>
    41e8: 05 30        	cpi	r16, 0x5
    41ea: f9 f5        	brne	.+126
    41ec: 01 e0        	ldi	r16, 0x1
    41ee: 4c ee        	ldi	r20, 0xec
    41f0: 52 e0        	ldi	r21, 0x2
    41f2: 0e 94 f2 29  	<unknown>
    41f6: 0e 94 f0 29  	<unknown>
    41fa: 06 e9        	ldi	r16, 0x96
    41fc: 4e ee        	ldi	r20, 0xee
    41fe: 52 e0        	ldi	r21, 0x2
    4200: 0e 94 f2 29  	<unknown>
    4204: 4f ee        	ldi	r20, 0xef
    4206: 52 e0        	ldi	r21, 0x2
    4208: 0e 94 f2 29  	<unknown>
    420c: 09 e6        	ldi	r16, 0x69
    420e: 08 bd        	out	0x28, r16
    4210: 0c bf        	out	0x3c, r16
    4212: 8c 9a        	sbi	0x11, 0x4
    4214: 10 e0        	ldi	r17, 0x0
    4216: 03 e0        	ldi	r16, 0x3
    4218: 0e 94 76 29  	<unknown>
    421c: 0d e9        	ldi	r16, 0x9d
    421e: 17 e0        	ldi	r17, 0x7
    4220: 0e 94 71 29  	<unknown>
    4224: 0e 94 96 29  	<unknown>
    4228: 07 ea        	ldi	r16, 0xa7
    422a: 17 e0        	ldi	r17, 0x7
    422c: 74 d6        	rcall	.+3304
    422e: 50 d3        	rcall	.+1696
    4230: 0e 94 f5 1f  	<unknown>
    4234: 0e 94 e7 06  	<unknown>
    4238: 0e 94 44 15  	<unknown>
    423c: 01 d7        	rcall	.+3586
    423e: 0e 94 6d 12  	<unknown>
    4242: 20 e0        	ldi	r18, 0x0
    4244: 60 e0        	ldi	r22, 0x0
    4246: 30 e0        	ldi	r19, 0x0
    4248: 89 01 0e 94  	<unknown>
    424c: 89 29        	or	r24, r9
    424e: 0e 94 83 29  	<unknown>
    4252: 46 0f        	add	r20, r22
    4254: 53 1f        	adc	r21, r19
    4256: 00 e0        	ldi	r16, 0x0
    4258: 0e 94 f2 29  	<unknown>
    425c: 63 95        	inc	r22
    425e: 68 30        	cpi	r22, 0x8
    4260: 90 f3        	brlo	.-28
    4262: 23 95        	inc	r18
    4264: 20 32        	cpi	r18, 0x20
    4266: 70 f3        	brlo	.-36
    4268: 8c 98        	cbi	0x11, 0x4
    426a: f5 01 00 a1  	<unknown>
    426e: 07 fd        	sbrc	r16, 0x7
    4270: 07 c0        	rjmp	.+14
    4272: 07 a1 03 71  	<unknown>
    4276: 00 31        	cpi	r16, 0x10
    4278: 19 f4        	brne	.+6
    427a: 02 a1 06 ff  	<unknown>
    427e: 0d c0        	rjmp	.+26
    4280: 00 a1 0f 77  	<unknown>
    4284: 00 a3 07 a1  	<unknown>
    4288: 0c 7f        	andi	r16, 0xfc
    428a: 07 a3 00 61  	<unknown>
    428e: 07 a3 02 a1  	<unknown>
    4292: 0f 7b        	andi	r16, 0xbf
    4294: 02 a3 a1 d5  	<unknown>
    4298: 1b d3        	rcall	.+1590
    429a: 80 e0        	ldi	r24, 0x0
    429c: 31 e1        	ldi	r19, 0x11
    429e: 83 9f 20 2d  	<unknown>
    42a2: 28 5f        	subi	r18, 0xf8
    42a4: 8e 01 35 d3  	<unknown>
    42a8: 0e 94 74 29  	<unknown>
    42ac: 08 81        	ldd	r16, Y+0
    42ae: 00 23        	tst	r16
    42b0: 41 f4        	brne	.+16
    42b2: 28 e9        	ldi	r18, 0x98
    42b4: 3b e0        	ldi	r19, 0xb
    42b6: 48 2f        	mov	r20, r24
    42b8: 50 e0        	ldi	r21, 0x0
    42ba: 01 e1        	ldi	r16, 0x11
    42bc: 8b d5        	rcall	.+2838
    42be: 29 d6        	rcall	.+3154
    42c0: 0c c0        	rjmp	.+24
    42c2: a0 e0        	ldi	r26, 0x0
    42c4: fe 01 b0 e0  	<unknown>
    42c8: ea 0f        	add	r30, r26
    42ca: fb 1f        	adc	r31, r27
    42cc: 00 81        	ldd	r16, Z+0
    42ce: 00 23        	tst	r16
    42d0: 21 f0        	breq	.+8
    42d2: b4 d6        	rcall	.+3432
    42d4: a3 95        	inc	r26
    42d6: a0 31        	cpi	r26, 0x10
    42d8: a8 f3        	brlo	.-22
    42da: 83 95        	inc	r24
    42dc: 82 30        	cpi	r24, 0x2
    42de: f0 f2        	brlo	.-68
    42e0: 0e 94 4c 2a  	<unknown>
    42e4: 8c 98        	cbi	0x11, 0x4
    42e6: 0e 94 fa 2c  	<unknown>
    42ea: d9 f0        	breq	.+54
    42ec: 2f ef        	ldi	r18, 0xff
    42ee: 8c 9a        	sbi	0x11, 0x4
    42f0: 10 e0        	ldi	r17, 0x0
    42f2: 08 c0        	rjmp	.+16
    42f4: 08 bd        	out	0x28, r16
    42f6: 43 ec        	ldi	r20, 0xc3
    42f8: 59 e0        	ldi	r21, 0x9
    42fa: 41 50        	subi	r20, 0x1
    42fc: 50 40        	sbci	r21, 0x0
    42fe: e9 f7        	brne	.-6
    4300: 00 c0        	rjmp	.+0
    4302: 00 00        	nop
    4304: 13 95        	inc	r17
    4306: 59 f0        	breq	.+22
    4308: 01 2f        	mov	r16, r17
    430a: 0f 73        	andi	r16, 0x3f
    430c: 09 f4        	brne	.+2
    430e: 20 95        	com	r18
    4310: 01 2f        	mov	r16, r17
    4312: 00 0f        	lsl	r16
    4314: 00 0f        	lsl	r16
    4316: 22 23        	tst	r18
    4318: 69 f3        	breq	.-38
    431a: 00 95        	com	r16
    431c: eb cf        	rjmp	.-42
    431e: 0e 94 f4 29  	<unknown>
    4322: 0e 94 94 13  	<unknown>
    4326: d8 01 25 eb  	<unknown>
    432a: 37 e0        	ldi	r19, 0x7
    432c: 0e 94 39 14  	<unknown>
    4330: 00 e2        	ldi	r16, 0x20
    4332: 0e 94 ea 29  	<unknown>
    4336: ef d2        	rcall	.+1502
    4338: 8d 01 0e 94  	<unknown>
    433c: bc 13        	cpse	r27, r28
    433e: eb d2        	rcall	.+1494
    4340: 95 d2        	rcall	.+1322
    4342: 90 e0        	ldi	r25, 0x0
    4344: 20 e0        	ldi	r18, 0x0
    4346: 09 2f        	mov	r16, r25
    4348: dd d7        	rcall	.+4026
    434a: 30 e0        	ldi	r19, 0x0
    434c: 42 0f        	add	r20, r18
    434e: 53 1f        	adc	r21, r19
    4350: bb d7        	rcall	.+3958
    4352: 02 d3        	rcall	.+1540
    4354: 23 95        	inc	r18
    4356: 28 30        	cpi	r18, 0x8
    4358: b0 f3        	brlo	.-20
    435a: 8e d2        	rcall	.+1308
    435c: 29 f0        	breq	.+10
    435e: ae d7        	rcall	.+3932
    4360: 22 e0        	ldi	r18, 0x2
    4362: 92 9f f0 01  	<unknown>
    4366: 7d d2        	rcall	.+1274
    4368: 49 2f        	mov	r20, r25
    436a: 50 e0        	ldi	r21, 0x0
    436c: 4f 5f        	subi	r20, 0xff
    436e: 5f 4f        	sbci	r21, 0xff
    4370: 65 2f        	mov	r22, r21
    4372: 66 0f        	lsl	r22
    4374: 66 0b        	sbc	r22, r22
    4376: 76 2f        	mov	r23, r22
    4378: 79 d2        	rcall	.+1266
    437a: 93 95        	inc	r25
    437c: 90 32        	cpi	r25, 0x20
    437e: 10 f3        	brlo	.-60
    4380: 0a 2f        	mov	r16, r26
    4382: 0b 2b        	or	r16, r27
    4384: 31 f0        	breq	.+12
    4386: 8d 01 0e 94  	<unknown>
    438a: b9 13        	cpse	r27, r25
    438c: 8d 01 0e 94  	<unknown>
    4390: 76 31        	cpi	r23, 0x16
    4392: 83 e0        	ldi	r24, 0x3
    4394: 01 e0        	ldi	r16, 0x1
    4396: 0e 94 f8 0f  	<unknown>
    439a: 0f e4        	ldi	r16, 0x4f
    439c: 13 ec        	ldi	r17, 0xc3
    439e: 01 50        	subi	r16, 0x1
    43a0: 10 40        	sbci	r17, 0x0
    43a2: e9 f7        	brne	.-6
    43a4: 00 c0        	rjmp	.+0
    43a6: 00 00        	nop
    43a8: 8a 95        	dec	r24
    43aa: a1 f7        	brne	.-24
    43ac: 0e 94 f6 2c  	<unknown>
    43b0: 00 93 3c 07  	<unknown>
    43b4: 78 94        	sei
    43b6: 33 c0        	rjmp	.+102
    43b8: 0b e8        	ldi	r16, 0x8b
    43ba: 18 e0        	ldi	r17, 0x8
    43bc: ac d5        	rcall	.+2904
    43be: 40 e1        	ldi	r20, 0x10
    43c0: 50 e0        	ldi	r21, 0x0
    43c2: 48 0d        	add	r20, r8
    43c4: 59 1d        	adc	r21, r9
    43c6: 80 d7        	rcall	.+3840
    43c8: 37 d6        	rcall	.+3182
    43ca: 44 d2        	rcall	.+1160
    43cc: 8c 01 a3 d5  	<unknown>
    43d0: 28 96 01 e0  	<unknown>
    43d4: 80 0e        	add	r8, r16
    43d6: 00 e0        	ldi	r16, 0x0
    43d8: 90 1e        	adc	r9, r16
    43da: 02 e0        	ldi	r16, 0x2
    43dc: 80 16        	cp	r8, r16
    43de: 00 e0        	ldi	r16, 0x0
    43e0: 90 06        	cpc	r9, r16
    43e2: 08 f4        	brsh	.+2
    43e4: a6 c1        	rjmp	.+844
    43e6: 00 91 3b 07  	<unknown>
    43ea: 0c 15        	cp	r16, r12
    43ec: 50 f0        	brlo	.+20
    43ee: dd 20        	tst	r13
    43f0: 41 f4        	brne	.+16
    43f2: 0e 94 f6 2c  	<unknown>
    43f6: 00 93 3f 07  	<unknown>
    43fa: 4c d2        	rcall	.+1176
    43fc: 10 f0        	brlo	.+4
    43fe: 00 e0        	ldi	r16, 0x0
    4400: 05 ab 10 d6  	<unknown>
    4404: 29 f4        	brne	.+10
    4406: 01 e0        	ldi	r16, 0x1
    4408: cd d2        	rcall	.+1434
    440a: 01 e0        	ldi	r16, 0x1
    440c: 00 93 3a 07  	<unknown>
    4410: 06 d6        	rcall	.+3084
    4412: 00 23        	tst	r16
    4414: 19 f4        	brne	.+6
    4416: 04 e6        	ldi	r16, 0x64
    4418: 0e 94 f7 2c  	<unknown>
    441c: c6 d4        	rcall	.+2444
    441e: f5 01 06 a9  	<unknown>
    4422: 03 95        	inc	r16
    4424: 06 ab 03 70  	<unknown>
    4428: 0e 94 d1 06  	<unknown>
    442c: 42 d7        	rcall	.+3716
    442e: 0e 94 5e 2a  	<unknown>
    4432: f8 94        	cli
    4434: f4 d5        	rcall	.+3048
    4436: 06 30        	cpi	r16, 0x6
    4438: 19 f0        	breq	.+6
    443a: 0e 94 fa 2c  	<unknown>
    443e: 21 f5        	brne	.+72
    4440: 0e 94 93 0f  	<unknown>
    4444: c8 01 69 d5  	<unknown>
    4448: 0d eb        	ldi	r16, 0xbd
    444a: 17 e0        	ldi	r17, 0x7
    444c: 64 d5        	rcall	.+2760
    444e: 8c 9a        	sbi	0x11, 0x4
    4450: 06 ee        	ldi	r16, 0xe6
    4452: 08 bd        	out	0x28, r16
    4454: 00 e0        	ldi	r16, 0x0
    4456: c4 d7        	rcall	.+3976
    4458: 78 94        	sei
    445a: 0c c0        	rjmp	.+24
    445c: 92 d4        	rcall	.+2340
    445e: 41 f0        	breq	.+16
    4460: 57 d2        	rcall	.+1198
    4462: 11 e0        	ldi	r17, 0x1
    4464: 04 e0        	ldi	r16, 0x4
    4466: 7c d2        	rcall	.+1272
    4468: 0e ec        	ldi	r16, 0xce
    446a: 17 e0        	ldi	r17, 0x7
    446c: 14 d5        	rcall	.+2600
    446e: 9d d4        	rcall	.+2362
    4470: 0e 94 e0 1d  	<unknown>
    4474: 1e d7        	rcall	.+3644
    4476: 06 30        	cpi	r16, 0x6
    4478: 89 f7        	brne	.-30
    447a: f8 94        	cli
    447c: 01 e0        	ldi	r16, 0x1
    447e: b0 d7        	rcall	.+3936
    4480: b3 d7        	rcall	.+3942
    4482: 8c 01 0e 94  	<unknown>
    4486: a7 0f        	add	r26, r23
    4488: 78 94        	sei
    448a: 00 91 38 07  	<unknown>
    448e: 00 23        	tst	r16
    4490: 81 f5        	brne	.+96
    4492: 1f d7        	rcall	.+3646
    4494: 0a 95        	dec	r16
    4496: 19 f0        	breq	.+6
    4498: 0a 95        	dec	r16
    449a: e9 f0        	breq	.+58
    449c: 2a c0        	rjmp	.+84
    449e: 20 91 3e 07  	<unknown>
    44a2: 30 e0        	ldi	r19, 0x0
    44a4: 0f ef        	ldi	r16, 0xff
    44a6: f9 01 e9 5f  	<unknown>
    44aa: f8 4f        	sbci	r31, 0xf8
    44ac: 00 83        	std	Z+0, r16
    44ae: 08 81        	ldd	r16, Y+0
    44b0: 19 81        	ldd	r17, Y+1
    44b2: 22 0f        	lsl	r18
    44b4: 33 1f        	rol	r19
    44b6: f9 01 d4 d1  	<unknown>
    44ba: 90 e2        	ldi	r25, 0x20
    44bc: 05 c0        	rjmp	.+10
    44be: f7 d6        	rcall	.+3566
    44c0: db d1        	rcall	.+950
    44c2: b9 f4        	brne	.+46
    44c4: 99 23        	tst	r25
    44c6: a9 f0        	breq	.+42
    44c8: ef d1        	rcall	.+990
    44ca: 37 d2        	rcall	.+1134
    44cc: f0 f3        	brlo	.-4
    44ce: d4 d1        	rcall	.+936
    44d0: b1 f7        	brne	.-20
    44d2: f6 d1        	rcall	.+1004
    44d4: f5 cf        	rjmp	.-22
    44d6: f4 d1        	rcall	.+1000
    44d8: 90 e2        	ldi	r25, 0x20
    44da: e6 d1        	rcall	.+972
    44dc: 2e d2        	rcall	.+1116
    44de: f0 f3        	brlo	.-4
    44e0: cb d1        	rcall	.+918
    44e2: 11 f4        	brne	.+4
    44e4: ed d1        	rcall	.+986
    44e6: 01 c0        	rjmp	.+2
    44e8: e2 d6        	rcall	.+3524
    44ea: c6 d1        	rcall	.+908
    44ec: 11 f4        	brne	.+4
    44ee: 99 23        	tst	r25
    44f0: a1 f7        	brne	.-24
    44f2: 47 d4        	rcall	.+2190
    44f4: 09 f0        	breq	.+2
    44f6: 0c d2        	rcall	.+1048
    44f8: 0e 94 e0 1d  	<unknown>
    44fc: 00 91 3a 07  	<unknown>
    4500: 00 23        	tst	r16
    4502: 21 f0        	breq	.+8
    4504: 0a 95        	dec	r16
    4506: 09 f4        	brne	.+2
    4508: 90 c1        	rjmp	.+800
    450a: 89 cf        	rjmp	.-238
    450c: f8 94        	cli
    450e: 00 91 3c 07  	<unknown>
    4512: 10 e0        	ldi	r17, 0x0
    4514: 45 e4        	ldi	r20, 0x45
    4516: 50 e0        	ldi	r21, 0x0
    4518: 40 0f        	add	r20, r16
    451a: 51 1f        	adc	r21, r17
    451c: d5 d6        	rcall	.+3498
    451e: c0 2e        	mov	r12, r16
    4520: dd 24        	clr	r13
    4522: d3 94        	inc	r13
    4524: d3 d6        	rcall	.+3494
    4526: 45 e4        	ldi	r20, 0x45
    4528: 50 e0        	ldi	r21, 0x0
    452a: 48 0f        	add	r20, r24
    452c: 59 1f        	adc	r21, r25
    452e: cc d6        	rcall	.+3480
    4530: 00 23        	tst	r16
    4532: 09 f0        	breq	.+2
    4534: dd 24        	clr	r13
    4536: 01 96 87 30  	<unknown>
    453a: 91 07        	cpc	r25, r17
    453c: a0 f3        	brlo	.-24
    453e: 78 94        	sei
    4540: dd 20        	tst	r13
    4542: c1 f0        	breq	.+48
    4544: 6c d5        	rcall	.+2776
    4546: 0f 70        	andi	r16, 0xf
    4548: 04 30        	cpi	r16, 0x4
    454a: 31 f4        	brne	.+12
    454c: 10 93 3f 07  	<unknown>
    4550: a1 d1        	rcall	.+834
    4552: 70 f0        	brlo	.+28
    4554: 15 ab 0c c0  	<unknown>
    4558: 01 30        	cpi	r16, 0x1
    455a: 51 f4        	brne	.+20
    455c: 10 93 3f 07  	<unknown>
    4560: f5 01 05 a9  	<unknown>
    4564: 0a 95        	dec	r16
    4566: 05 ab 0f 3f  	<unknown>
    456a: 11 f4        	brne	.+4
    456c: 06 e0        	ldi	r16, 0x6
    456e: 05 ab 10 93  	<unknown>
    4572: 3b 07        	cpc	r19, r27
    4574: cc 20        	tst	r12
    4576: 19 f4        	brne	.+6
    4578: dd 20        	tst	r13
    457a: 09 f4        	brne	.+2
    457c: 3a cf        	rjmp	.-396
    457e: 00 91 3f 07  	<unknown>
    4582: 10 91 35 07  	<unknown>
    4586: 20 91 3c 07  	<unknown>
    458a: 22 23        	tst	r18
    458c: 91 f0        	breq	.+36
    458e: 2a 95        	dec	r18
    4590: a9 f0        	breq	.+42
    4592: 2a 95        	dec	r18
    4594: 09 f4        	brne	.+2
    4596: 48 c0        	rjmp	.+144
    4598: 2a 95        	dec	r18
    459a: 09 f4        	brne	.+2
    459c: 7f c0        	rjmp	.+254
    459e: 2a 95        	dec	r18
    45a0: 09 f4        	brne	.+2
    45a2: 98 c0        	rjmp	.+304
    45a4: 2a 95        	dec	r18
    45a6: 09 f4        	brne	.+2
    45a8: a6 c0        	rjmp	.+332
    45aa: 2a 95        	dec	r18
    45ac: 09 f4        	brne	.+2
    45ae: bc c0        	rjmp	.+376
    45b0: 1a cf        	rjmp	.-460
    45b2: 00 23        	tst	r16
    45b4: 19 f4        	brne	.+6
    45b6: 03 eb        	ldi	r16, 0xb3
    45b8: 18 e0        	ldi	r17, 0x8
    45ba: 04 c0        	rjmp	.+8
    45bc: 00 23        	tst	r16
    45be: 19 f4        	brne	.+6
    45c0: 03 ef        	ldi	r16, 0xf3
    45c2: 18 e0        	ldi	r17, 0x8
    45c4: 41 d1        	rcall	.+642
    45c6: 82 d6        	rcall	.+3332
    45c8: 08 c0        	rjmp	.+16
    45ca: 04 ee        	ldi	r16, 0xe4
    45cc: 17 e0        	ldi	r17, 0x7
    45ce: a3 d4        	rcall	.+2374
    45d0: 01 96 84 30  	<unknown>
    45d4: 83 d6        	rcall	.+3334
    45d6: 08 f0        	brlo	.+2
    45d8: 06 cf        	rjmp	.-500
    45da: 91 d1        	rcall	.+802
    45dc: 82 9b        	sbis	0x10, 0x2
    45de: 0c c0        	rjmp	.+24
    45e0: 28 2f        	mov	r18, r24
    45e2: 00 91 3c 07  	<unknown>
    45e6: 00 0f        	lsl	r16
    45e8: 00 0f        	lsl	r16
    45ea: 20 0f        	add	r18, r16
    45ec: 0e 94 b0 2c  	<unknown>
    45f0: 19 f0        	breq	.+6
    45f2: 82 d1        	rcall	.+772
    45f4: 0c 5f        	subi	r16, 0xfc
    45f6: 01 c0        	rjmp	.+2
    45f8: 7f d1        	rcall	.+766
    45fa: 7a d1        	rcall	.+756
    45fc: 00 91 3c 07  	<unknown>
    4600: 14 e0        	ldi	r17, 0x4
    4602: 01 9f 8c 01  	<unknown>
    4606: 00 0d        	add	r16, r0
    4608: 11 1d        	adc	r17, r1
    460a: f8 01 e9 5f  	<unknown>
    460e: f8 4f        	sbci	r31, 0xf8
    4610: 20 81        	ldd	r18, Z+0
    4612: 22 23        	tst	r18
    4614: d1 f2        	breq	.-76
    4616: 0e 94 6c 2c  	<unknown>
    461a: f8 01 e9 53  	<unknown>
    461e: f9 4f        	sbci	r31, 0xf9
    4620: 00 81        	ldd	r16, Z+0
    4622: 11 81        	ldd	r17, Z+1
    4624: 02 d5        	rcall	.+2564
    4626: d4 cf        	rjmp	.-88
    4628: 11 23        	tst	r17
    462a: 09 f4        	brne	.+2
    462c: dc ce        	rjmp	.-584
    462e: 00 23        	tst	r16
    4630: 19 f4        	brne	.+6
    4632: 03 e3        	ldi	r16, 0x33
    4634: 19 e0        	ldi	r17, 0x9
    4636: 08 d1        	rcall	.+528
    4638: 49 d6        	rcall	.+3218
    463a: 08 c0        	rjmp	.+16
    463c: 04 ee        	ldi	r16, 0xe4
    463e: 17 e0        	ldi	r17, 0x7
    4640: 6a d4        	rcall	.+2260
    4642: 01 96 84 30  	<unknown>
    4646: 4a d6        	rcall	.+3220
    4648: 08 f0        	brlo	.+2
    464a: cd ce        	rjmp	.-614
    464c: 58 d1        	rcall	.+688
    464e: 82 9b        	sbis	0x10, 0x2
    4650: 0e c0        	rjmp	.+28
    4652: 28 2f        	mov	r18, r24
    4654: 28 5f        	subi	r18, 0xf8
    4656: 0e 94 b0 2c  	<unknown>
    465a: 49 f0        	breq	.+18
    465c: 08 2f        	mov	r16, r24
    465e: 09 2b        	or	r16, r25
    4660: 11 e0        	ldi	r17, 0x1
    4662: 11 f4        	brne	.+4
    4664: 04 e0        	ldi	r16, 0x4
    4666: 0c c0        	rjmp	.+24
    4668: 02 e0        	ldi	r16, 0x2
    466a: 44 d1        	rcall	.+648
    466c: 09 c0        	rjmp	.+18
    466e: 08 2f        	mov	r16, r24
    4670: 09 2b        	or	r16, r25
    4672: 11 e0        	ldi	r17, 0x1
    4674: 11 f4        	brne	.+4
    4676: 00 e0        	ldi	r16, 0x0
    4678: 03 c0        	rjmp	.+6
    467a: 06 e0        	ldi	r16, 0x6
    467c: 3b d1        	rcall	.+630
    467e: 0c 5f        	subi	r16, 0xfc
    4680: 37 d1        	rcall	.+622
    4682: f5 01 e8 0f  	<unknown>
    4686: f9 1f        	adc	r31, r25
    4688: 00 85        	ldd	r16, Z+0
    468a: 00 23        	tst	r16
    468c: b9 f2        	breq	.-82
    468e: 2b d1        	rcall	.+598
    4690: e9 53        	subi	r30, 0x39
    4692: f9 4f        	sbci	r31, 0xf9
    4694: 00 89        	ldd	r16, Z+0
    4696: 11 89        	ldd	r17, Z+1
    4698: c8 d4        	rcall	.+2448
    469a: d3 cf        	rjmp	.-90
    469c: 11 23        	tst	r17
    469e: 09 f4        	brne	.+2
    46a0: a2 ce        	rjmp	.-700
    46a2: 10 e0        	ldi	r17, 0x0
    46a4: 00 e0        	ldi	r16, 0x0
    46a6: 5c d1        	rcall	.+696
    46a8: 0c ee        	ldi	r16, 0xec
    46aa: 17 e0        	ldi	r17, 0x7
    46ac: f4 d3        	rcall	.+2024
    46ae: 4a d3        	rcall	.+1684
    46b0: 23 d6        	rcall	.+3142
    46b2: 02 0f        	add	r16, r18
    46b4: 13 1f        	adc	r17, r19
    46b6: 3c d6        	rcall	.+3192
    46b8: 7c d3        	rcall	.+1784
    46ba: 0b ef        	ldi	r16, 0xfb
    46bc: 17 e0        	ldi	r17, 0x7
    46be: 2b d4        	rcall	.+2134
    46c0: 9f d3        	rcall	.+1854
    46c2: 27 d4        	rcall	.+2126
    46c4: 61 d3        	rcall	.+1730
    46c6: 7a d3        	rcall	.+1780
    46c8: 00 e0        	ldi	r16, 0x0
    46ca: 18 e0        	ldi	r17, 0x8
    46cc: 24 d4        	rcall	.+2120
    46ce: 22 96 6c d3  	<unknown>
    46d2: 89 ce        	rjmp	.-750
    46d4: 11 23        	tst	r17
    46d6: 09 f4        	brne	.+2
    46d8: 86 ce        	rjmp	.-756
    46da: f8 d5        	rcall	.+3056
    46dc: 05 d6        	rcall	.+3082
    46de: 03 d1        	rcall	.+518
    46e0: 23 d1        	rcall	.+582
    46e2: c7 d0        	rcall	.+398
    46e4: 08 e0        	ldi	r16, 0x8
    46e6: 18 e0        	ldi	r17, 0x8
    46e8: a4 d4        	rcall	.+2376
    46ea: 01 96 82 30  	<unknown>
    46ee: f6 d5        	rcall	.+3052
    46f0: 08 f0        	brlo	.+2
    46f2: 79 ce        	rjmp	.-782
    46f4: f3 cf        	rjmp	.-26
    46f6: 11 23        	tst	r17
    46f8: 09 f4        	brne	.+2
    46fa: 75 ce        	rjmp	.-790
    46fc: e7 d5        	rcall	.+3022
    46fe: f4 d5        	rcall	.+3048
    4700: 8c 01 0d d1  	<unknown>
    4704: d6 d3        	rcall	.+1964
    4706: 9e d0        	rcall	.+316
    4708: 8d d3        	rcall	.+1818
    470a: 60 e8        	ldi	r22, 0x80
    470c: 7a e3        	ldi	r23, 0x3a
    470e: 9a d0        	rcall	.+308
    4710: 3a 93        	st	-Y, r19
    4712: 2a 93        	st	-Y, r18
    4714: ae d0        	rcall	.+348
    4716: 09 e1        	ldi	r16, 0x19
    4718: 18 e0        	ldi	r17, 0x8
    471a: bd d3        	rcall	.+1914
    471c: 01 96 82 30  	<unknown>
    4720: dd d5        	rcall	.+3002
    4722: 08 f0        	brlo	.+2
    4724: 60 ce        	rjmp	.-832
    4726: eb cf        	rjmp	.-42
    4728: 11 23        	tst	r17
    472a: 09 f4        	brne	.+2
    472c: 5c ce        	rjmp	.-840
    472e: 88 24        	clr	r8
    4730: 99 24        	clr	r9
    4732: 43 e0        	ldi	r20, 0x3
    4734: 84 01 0e 94  	<unknown>
    4738: d5 31        	cpi	r29, 0x15
    473a: 40 e0        	ldi	r20, 0x0
    473c: 50 e0        	ldi	r21, 0x0
    473e: b0 d0        	rcall	.+352
    4740: c8 01 d9 01  	<unknown>
    4744: 44 e0        	ldi	r20, 0x4
    4746: 50 e0        	ldi	r21, 0x0
    4748: 84 01 0e 94  	<unknown>
    474c: 6c 2c        	mov	r6, r12
    474e: 0e 94 6c 2c  	<unknown>
    4752: 0e 94 6c 2c  	<unknown>
    4756: a4 d0        	rcall	.+328
    4758: ac 01 bd 01  	<unknown>
    475c: 0e 94 4b 33  	<unknown>
    4760: a8 01 b9 01  	<unknown>
    4764: 00 e0        	ldi	r16, 0x0
    4766: 10 e0        	ldi	r17, 0x0
    4768: 20 e8        	ldi	r18, 0x80
    476a: 3a e3        	ldi	r19, 0x3a
    476c: 6b d0        	rcall	.+214
    476e: 28 01 39 01  	<unknown>
    4772: 84 01 d4 d0  	<unknown>
    4776: a2 01 b3 01  	<unknown>
    477a: 64 d0        	rcall	.+200
    477c: ac 01 bd 01  	<unknown>
    4780: 0e 94 07 33  	<unknown>
    4784: 28 01 39 01  	<unknown>
    4788: 42 e1        	ldi	r20, 0x12
    478a: 50 e0        	ldi	r21, 0x0
    478c: 48 0d        	add	r20, r8
    478e: 59 1d        	adc	r21, r9
    4790: 9b d5        	rcall	.+2870
    4792: 00 23        	tst	r16
    4794: 59 f0        	breq	.+22
    4796: 0a 95        	dec	r16
    4798: 61 f0        	breq	.+24
    479a: 02 50        	subi	r16, 0x2
    479c: 81 f0        	breq	.+32
    479e: 0a 95        	dec	r16
    47a0: 89 f0        	breq	.+34
    47a2: 0a 95        	dec	r16
    47a4: 91 f0        	breq	.+36
    47a6: 0a 95        	dec	r16
    47a8: 99 f0        	breq	.+38
    47aa: 06 c0        	rjmp	.+12
    47ac: 80 e3        	ldi	r24, 0x30
    47ae: 98 e0        	ldi	r25, 0x8
    47b0: 11 c0        	rjmp	.+34
    47b2: 8b e3        	ldi	r24, 0x3b
    47b4: 98 e0        	ldi	r25, 0x8
    47b6: 0e c0        	rjmp	.+28
    47b8: 86 e4        	ldi	r24, 0x46
    47ba: 98 e0        	ldi	r25, 0x8
    47bc: 0b c0        	rjmp	.+22
    47be: 81 e5        	ldi	r24, 0x51
    47c0: 98 e0        	ldi	r25, 0x8
    47c2: 08 c0        	rjmp	.+16
    47c4: 8c e5        	ldi	r24, 0x5c
    47c6: 98 e0        	ldi	r25, 0x8
    47c8: 05 c0        	rjmp	.+10
    47ca: 87 e6        	ldi	r24, 0x67
    47cc: 98 e0        	ldi	r25, 0x8
    47ce: 02 c0        	rjmp	.+4
    47d0: 82 e7        	ldi	r24, 0x72
    47d2: 98 e0        	ldi	r25, 0x8
    47d4: 18 2d        	mov	r17, r8
    47d6: 89 d5        	rcall	.+2834
    47d8: d4 01 11 96  	<unknown>
    47dc: 40 e2        	ldi	r20, 0x20
    47de: 5c eb        	ldi	r21, 0xbc
    47e0: 6e eb        	ldi	r22, 0xbe
    47e2: 7c e4        	ldi	r23, 0x4c
    47e4: 82 01 93 01  	<unknown>
    47e8: 2b d0        	rcall	.+86
    47ea: 30 f0        	brlo	.+12
    47ec: 47 e1        	ldi	r20, 0x17
    47ee: 57 eb        	ldi	r21, 0xb7
    47f0: 61 ed        	ldi	r22, 0xd1
    47f2: 78 e3        	ldi	r23, 0x38
    47f4: 23 d0        	rcall	.+70
    47f6: 18 f4        	brsh	.+6
    47f8: 8e d0        	rcall	.+284
    47fa: 22 d0        	rcall	.+68
    47fc: 88 f0        	brlo	.+34
    47fe: 4f e7        	ldi	r20, 0x7f
    4800: 56 e9        	ldi	r21, 0x96
    4802: 68 e1        	ldi	r22, 0x18
    4804: 7b ec        	ldi	r23, 0xcb
    4806: 1a d0        	rcall	.+52
    4808: 38 f0        	brlo	.+14
    480a: 46 e1        	ldi	r20, 0x16
    480c: 57 eb        	ldi	r21, 0xb7
    480e: 61 ed        	ldi	r22, 0xd1
    4810: 78 eb        	ldi	r23, 0xb8
    4812: 16 d0        	rcall	.+44
    4814: 08 f0        	brlo	.+2
    4816: d0 cd        	rjmp	.-1120
    4818: 7e d0        	rcall	.+252
    481a: 10 d0        	rcall	.+32
    481c: 08 f0        	brlo	.+2
    481e: cc cd        	rjmp	.-1128
    4820: 19 d0        	rcall	.+50
    4822: 0d e7        	ldi	r16, 0x7d
    4824: 18 e0        	ldi	r17, 0x8
    4826: 37 d3        	rcall	.+1646
    4828: d4 cd        	rjmp	.-1112
    482a: 00 e0        	ldi	r16, 0x0
    482c: bb d0        	rcall	.+374
    482e: 01 30        	cpi	r16, 0x1
    4830: 09 f0        	breq	.+2
    4832: f5 cd        	rjmp	.-1046
    4834: 00 e0        	ldi	r16, 0x0
    4836: 00 93 3a 07  	<unknown>
    483a: f1 cd        	rjmp	.-1054
    483c: 0c 94 6a 34  	<unknown>
    4840: 0c 94 82 34  	<unknown>
    4844: 0c 94 68 33  	<unknown>
    4848: 0e 94 52 0f  	<unknown>
    484c: 01 e0        	ldi	r16, 0x1
    484e: 00 93 3f 07  	<unknown>
    4852: 08 95        	ret
    4854: 7a 92        	st	-Y, r7
    4856: 6a 92        	st	-Y, r6
    4858: 5a 92        	st	-Y, r5
    485a: 4a 92        	st	-Y, r4
    485c: ba 93        	st	-Y, r27
    485e: aa 93        	st	-Y, r26
    4860: 08 95        	ret
    4862: e9 53        	subi	r30, 0x39
    4864: f9 4f        	sbci	r31, 0xf9
    4866: 00 83        	std	Z+0, r16
    4868: 11 83        	std	Z+1, r17
    486a: 08 95        	ret
    486c: 8d 01 0c 94  	<unknown>
    4870: cb 13        	cpse	r28, r27
    4872: b3 d5        	rcall	.+2918
    4874: fc 01 17 c5  	<unknown>
    4878: e1 e8        	ldi	r30, 0x81
    487a: f6 e0        	ldi	r31, 0x6
    487c: 00 81        	ldd	r16, Z+0
    487e: 11 81        	ldd	r17, Z+1
    4880: 22 81        	ldd	r18, Z+2
    4882: 33 81        	ldd	r19, Z+3
    4884: 44 81        	ldd	r20, Z+4
    4886: 55 81        	ldd	r21, Z+5
    4888: 66 81        	ldd	r22, Z+6
    488a: 77 81        	ldd	r23, Z+7
    488c: e7 e6        	ldi	r30, 0x67
    488e: f6 e0        	ldi	r31, 0x6
    4890: 0c 94 09 35  	<unknown>
    4894: f5 01 05 a9  	<unknown>
    4898: 03 95        	inc	r16
    489a: 05 ab 07 30  	<unknown>
    489e: 08 95        	ret
    48a0: 40 0f        	add	r20, r16
    48a2: 51 1f        	adc	r21, r17
    48a4: 0c 94 8e 31  	<unknown>
    48a8: 9a 95        	dec	r25
    48aa: f5 01 07 a9  	<unknown>
    48ae: 03 95        	inc	r16
    48b0: 07 ab 00 32  	<unknown>
    48b4: 10 f0        	brlo	.+4
    48b6: 00 e0        	ldi	r16, 0x0
    48b8: 07 ab 20 e0  	<unknown>
    48bc: 30 e0        	ldi	r19, 0x0
    48be: 08 95        	ret
    48c0: 00 e0        	ldi	r16, 0x0
    48c2: e0 91 3e 07  	<unknown>
    48c6: f0 e0        	ldi	r31, 0x0
    48c8: e9 5f        	subi	r30, 0xf9
    48ca: f8 4f        	sbci	r31, 0xf8
    48cc: 00 83        	std	Z+0, r16
    48ce: 08 95        	ret
    48d0: 88 e0        	ldi	r24, 0x8
    48d2: 00 e0        	ldi	r16, 0x0
    48d4: 08 83        	std	Y+0, r16
    48d6: 31 e0        	ldi	r19, 0x1
    48d8: 28 2f        	mov	r18, r24
    48da: 8e 01 85 d2  	<unknown>
    48de: 83 95        	inc	r24
    48e0: 8a 32        	cpi	r24, 0x2a
    48e2: b8 f3        	brlo	.-18
    48e4: 08 95        	ret
    48e6: 8c 01 00 0f  	<unknown>
    48ea: 11 1f        	rol	r17
    48ec: f8 01 08 95  	<unknown>
    48f0: 0c 94 70 0f  	<unknown>
    48f4: 0e 94 70 0f  	<unknown>
    48f8: 11 e0        	ldi	r17, 0x1
    48fa: 08 2f        	mov	r16, r24
    48fc: 08 95        	ret
    48fe: 8c 01 16 95  	<unknown>
    4902: 07 95        	ror	r16
    4904: 10 2f        	mov	r17, r16
    4906: 08 2f        	mov	r16, r24
    4908: 00 fb        	bst	r16, 0x0
    490a: 00 e0        	ldi	r16, 0x0
    490c: 03 f9        	bld	r16, 0x3
    490e: ee c4        	rjmp	.+2524
    4910: 66 d2        	rcall	.+1228
    4912: 0c 94 e9 08  	<unknown>
    4916: 86 d2        	rcall	.+1292
    4918: 60 e0        	ldi	r22, 0x0
    491a: 70 e0        	ldi	r23, 0x0
    491c: 08 95        	ret
    491e: 00 0f        	lsl	r16
    4920: 11 1f        	rol	r17
    4922: f8 01 01 d0  	<unknown>
    4926: 05 c0        	rjmp	.+10
    4928: ed 58        	subi	r30, 0x8d
    492a: f9 4f        	sbci	r31, 0xf9
    492c: 04 81        	ldd	r16, Z+4
    492e: 15 81        	ldd	r17, Z+5
    4930: 08 95        	ret
    4932: 20 e0        	ldi	r18, 0x0
    4934: 30 e0        	ldi	r19, 0x0
    4936: 0c 94 b3 32  	<unknown>
    493a: f8 94        	cli
    493c: 00 91 3e 07  	<unknown>
    4940: e1 d4        	rcall	.+2498
    4942: 42 0f        	add	r20, r18
    4944: 53 1f        	adc	r21, r19
    4946: c0 d4        	rcall	.+2432
    4948: 07 d0        	rcall	.+14
    494a: 78 94        	sei
    494c: 2f 5f        	subi	r18, 0xff
    494e: 3f 4f        	sbci	r19, 0xff
    4950: 28 30        	cpi	r18, 0x8
    4952: 00 e0        	ldi	r16, 0x0
    4954: 30 07        	cpc	r19, r16
    4956: 08 95        	ret
    4958: f9 01 ef 57  	<unknown>
    495c: f9 4f        	sbci	r31, 0xf9
    495e: b6 cf        	rjmp	.-148
    4960: c5 d4        	rcall	.+2442
    4962: 20 91 29 07  	<unknown>
    4966: 30 91 28 07  	<unknown>
    496a: 40 91 27 07  	<unknown>
    496e: 04 2f        	mov	r16, r20
    4970: 10 d0        	rcall	.+32
    4972: 40 77        	andi	r20, 0x70
    4974: 42 95        	swap	r20
    4976: 50 e0        	ldi	r21, 0x0
    4978: 0f d0        	rcall	.+30
    497a: 03 2f        	mov	r16, r19
    497c: 0a d0        	rcall	.+20
    497e: 30 77        	andi	r19, 0x70
    4980: 32 95        	swap	r19
    4982: 43 2f        	mov	r20, r19
    4984: 09 d0        	rcall	.+18
    4986: 02 2f        	mov	r16, r18
    4988: 04 d0        	rcall	.+8
    498a: 20 73        	andi	r18, 0x30
    498c: 22 95        	swap	r18
    498e: 42 2f        	mov	r20, r18
    4990: 03 c0        	rjmp	.+6
    4992: 0f 70        	andi	r16, 0xf
    4994: 60 2f        	mov	r22, r16
    4996: c1 cf        	rjmp	.-126
    4998: 0a e0        	ldi	r16, 0xa
    499a: 1c d2        	rcall	.+1080
    499c: 6c d4        	rcall	.+2264
    499e: 7a 93        	st	-Y, r23
    49a0: 6a 93        	st	-Y, r22
    49a2: 08 95        	ret
    49a4: 05 d5        	rcall	.+2570
    49a6: 59 f0        	breq	.+22
    49a8: 0e 94 be 10  	<unknown>
    49ac: fd 01 00 a7  	<unknown>
    49b0: 11 a7 4c e0  	<unknown>
    49b4: 28 e1        	ldi	r18, 0x18
    49b6: 3a e0        	ldi	r19, 0xa
    49b8: 0e 94 f5 10  	<unknown>
    49bc: 77 c0        	rjmp	.+238
    49be: 78 d0        	rcall	.+240
    49c0: 0e 94 6f 11  	<unknown>
    49c4: 00 23        	tst	r16
    49c6: 74 d0        	rcall	.+232
    49c8: 99 f5        	brne	.+102
    49ca: 0e 94 31 11  	<unknown>
    49ce: ea e0        	ldi	r30, 0xa
    49d0: fc e0        	ldi	r31, 0xc
    49d2: 0c 94 93 34  	<unknown>
    49d6: 00 e0        	ldi	r16, 0x0
    49d8: 6f d0        	rcall	.+222
    49da: 01 30        	cpi	r16, 0x1
    49dc: 21 f4        	brne	.+8
    49de: 21 e0        	ldi	r18, 0x1
    49e0: 67 d0        	rcall	.+206
    49e2: 0e 94 69 11  	<unknown>
    49e6: 00 e0        	ldi	r16, 0x0
    49e8: 62 c0        	rjmp	.+196
    49ea: 00 e0        	ldi	r16, 0x0
    49ec: 1e d2        	rcall	.+1084
    49ee: 01 30        	cpi	r16, 0x1
    49f0: d1 f7        	brne	.-12
    49f2: f5 cf        	rjmp	.-22
    49f4: 00 e0        	ldi	r16, 0x0
    49f6: 2d d3        	rcall	.+1626
    49f8: fa cf        	rjmp	.-12
    49fa: 00 e0        	ldi	r16, 0x0
    49fc: 0e 94 d5 12  	<unknown>
    4a00: f6 cf        	rjmp	.-20
    4a02: 00 e0        	ldi	r16, 0x0
    4a04: 91 d2        	rcall	.+1314
    4a06: f3 cf        	rjmp	.-26
    4a08: 00 e0        	ldi	r16, 0x0
    4a0a: f4 d4        	rcall	.+2536
    4a0c: f0 cf        	rjmp	.-32
    4a0e: 00 e0        	ldi	r16, 0x0
    4a10: 54 d2        	rcall	.+1192
    4a12: ed cf        	rjmp	.-38
    4a14: 00 e0        	ldi	r16, 0x0
    4a16: 0e 94 5e 15  	<unknown>
    4a1a: e9 cf        	rjmp	.-46
    4a1c: 00 e0        	ldi	r16, 0x0
    4a1e: 8b d4        	rcall	.+2326
    4a20: e6 cf        	rjmp	.-52
    4a22: 00 e0        	ldi	r16, 0x0
    4a24: 0f d2        	rcall	.+1054
    4a26: e3 cf        	rjmp	.-58
    4a28: 00 e0        	ldi	r16, 0x0
    4a2a: 0e 94 0b 07  	<unknown>
    4a2e: df cf        	rjmp	.-66
    4a30: 20 91 39 07  	<unknown>
    4a34: 2f 70        	andi	r18, 0xf
    4a36: 69 f0        	breq	.+26
    4a38: 2a 95        	dec	r18
    4a3a: 29 f0        	breq	.+10
    4a3c: 23 50        	subi	r18, 0x3
    4a3e: 39 f0        	breq	.+14
    4a40: 2a 95        	dec	r18
    4a42: 91 f1        	breq	.+100
    4a44: d0 cf        	rjmp	.-96
    4a46: 2f ef        	ldi	r18, 0xff
    4a48: 0e 94 fa 10  	<unknown>
    4a4c: cc cf        	rjmp	.-104
    4a4e: 21 e0        	ldi	r18, 0x1
    4a50: fb cf        	rjmp	.-10
    4a52: 0e 94 31 11  	<unknown>
    4a56: e6 e2        	ldi	r30, 0x26
    4a58: fc e0        	ldi	r31, 0xc
    4a5a: 0c 94 93 34  	<unknown>
    4a5e: 01 e0        	ldi	r16, 0x1
    4a60: 2b d0        	rcall	.+86
    4a62: 20 c0        	rjmp	.+64
    4a64: 01 e0        	ldi	r16, 0x1
    4a66: e1 d1        	rcall	.+962
    4a68: 1d c0        	rjmp	.+58
    4a6a: 01 e0        	ldi	r16, 0x1
    4a6c: f2 d2        	rcall	.+1508
    4a6e: 1a c0        	rjmp	.+52
    4a70: 01 e0        	ldi	r16, 0x1
    4a72: c0 d4        	rcall	.+2432
    4a74: 17 c0        	rjmp	.+46
    4a76: 01 e0        	ldi	r16, 0x1
    4a78: 5e d4        	rcall	.+2236
    4a7a: 14 c0        	rjmp	.+40
    4a7c: 01 e0        	ldi	r16, 0x1
    4a7e: 1d d2        	rcall	.+1082
    4a80: 11 c0        	rjmp	.+34
    4a82: 01 e0        	ldi	r16, 0x1
    4a84: 0e 94 5e 15  	<unknown>
    4a88: 0d c0        	rjmp	.+26
    4a8a: 01 e0        	ldi	r16, 0x1
    4a8c: db d1        	rcall	.+950
    4a8e: 0a c0        	rjmp	.+20
    4a90: 01 e0        	ldi	r16, 0x1
    4a92: 0e 94 0b 07  	<unknown>
    4a96: 06 c0        	rjmp	.+12
    4a98: 01 e0        	ldi	r16, 0x1
    4a9a: 46 d2        	rcall	.+1164
    4a9c: 03 c0        	rjmp	.+6
    4a9e: 01 e0        	ldi	r16, 0x1
    4aa0: 0e 94 d5 12  	<unknown>
    4aa4: 20 e0        	ldi	r18, 0x0
    4aa6: 9c cf        	rjmp	.-200
    4aa8: 0e 94 c9 10  	<unknown>
    4aac: 01 e0        	ldi	r16, 0x1
    4aae: 7d c4        	rjmp	.+2298
    4ab0: fd 01 00 a5  	<unknown>
    4ab4: 11 a5 08 95  	<unknown>
    4ab8: 0e 94 ee 34  	<unknown>
    4abc: a2 97 00 23  	<unknown>
    4ac0: 09 f0        	breq	.+2
    4ac2: ab d2        	rcall	.+1366
    4ac4: a7 e0        	ldi	r26, 0x7
    4ac6: b7 e0        	ldi	r27, 0x7
    4ac8: 90 91 39 07  	<unknown>
    4acc: 9f 70        	andi	r25, 0xf
    4ace: 92 30        	cpi	r25, 0x2
    4ad0: 21 f4        	brne	.+8
    4ad2: fd 01 01 ad  	<unknown>
    4ad6: 0a 95        	dec	r16
    4ad8: 05 c0        	rjmp	.+10
    4ada: 93 30        	cpi	r25, 0x3
    4adc: 21 f4        	brne	.+8
    4ade: fd 01 01 ad  	<unknown>
    4ae2: 03 95        	inc	r16
    4ae4: 01 af 00 91  	<unknown>
    4ae8: 40 07        	cpc	r20, r16
    4aea: 07 30        	cpi	r16, 0x7
    4aec: 38 f0        	brlo	.+14
    4aee: 0f 3f        	cpi	r16, 0xff
    4af0: 11 f0        	breq	.+4
    4af2: 00 e0        	ldi	r16, 0x0
    4af4: 01 c0        	rjmp	.+2
    4af6: 06 e0        	ldi	r16, 0x6
    4af8: 00 93 40 07  	<unknown>
    4afc: 42 d1        	rcall	.+644
    4afe: 29 f4        	brne	.+10
    4b00: 91 30        	cpi	r25, 0x1
    4b02: 19 f0        	breq	.+6
    4b04: 94 30        	cpi	r25, 0x4
    4b06: 09 f0        	breq	.+2
    4b08: 0c c1        	rjmp	.+536
    4b0a: 00 91 40 07  	<unknown>
    4b0e: 00 23        	tst	r16
    4b10: 81 f0        	breq	.+32
    4b12: 0a 95        	dec	r16
    4b14: 09 f1        	breq	.+66
    4b16: 0a 95        	dec	r16
    4b18: 81 f1        	breq	.+96
    4b1a: 0a 95        	dec	r16
    4b1c: f9 f1        	breq	.+126
    4b1e: 0a 95        	dec	r16
    4b20: 09 f4        	brne	.+2
    4b22: 52 c0        	rjmp	.+164
    4b24: 0a 95        	dec	r16
    4b26: 09 f4        	brne	.+2
    4b28: 61 c0        	rjmp	.+194
    4b2a: 0a 95        	dec	r16
    4b2c: 09 f4        	brne	.+2
    4b2e: 7d c0        	rjmp	.+250
    4b30: 98 c0        	rjmp	.+304
    4b32: 40 90 29 07  	<unknown>
    4b36: 0c d1        	rcall	.+536
    4b38: 29 f4        	brne	.+10
    4b3a: 83 95        	inc	r24
    4b3c: 88 31        	cpi	r24, 0x18
    4b3e: 40 f0        	brlo	.+16
    4b40: 80 e0        	ldi	r24, 0x0
    4b42: 06 c0        	rjmp	.+12
    4b44: 94 30        	cpi	r25, 0x4
    4b46: 21 f4        	brne	.+8
    4b48: 8a 95        	dec	r24
    4b4a: 8f 3f        	cpi	r24, 0xff
    4b4c: 09 f4        	brne	.+2
    4b4e: 87 e1        	ldi	r24, 0x17
    4b50: 10 d1        	rcall	.+544
    4b52: 40 92 29 07  	<unknown>
    4b56: 85 c0        	rjmp	.+266
    4b58: 40 90 28 07  	<unknown>
    4b5c: ee d0        	rcall	.+476
    4b5e: fc d0        	rcall	.+504
    4b60: 29 f4        	brne	.+10
    4b62: 83 95        	inc	r24
    4b64: 8c 33        	cpi	r24, 0x3c
    4b66: 28 f0        	brlo	.+10
    4b68: 80 e0        	ldi	r24, 0x0
    4b6a: 03 c0        	rjmp	.+6
    4b6c: 94 30        	cpi	r25, 0x4
    4b6e: 09 f4        	brne	.+2
    4b70: 11 d1        	rcall	.+546
    4b72: 3c d1        	rcall	.+632
    4b74: 40 92 28 07  	<unknown>
    4b78: 74 c0        	rjmp	.+232
    4b7a: 40 90 27 07  	<unknown>
    4b7e: dd d0        	rcall	.+442
    4b80: eb d0        	rcall	.+470
    4b82: 29 f4        	brne	.+10
    4b84: 83 95        	inc	r24
    4b86: 8c 33        	cpi	r24, 0x3c
    4b88: 28 f0        	brlo	.+10
    4b8a: 80 e0        	ldi	r24, 0x0
    4b8c: 03 c0        	rjmp	.+6
    4b8e: 94 30        	cpi	r25, 0x4
    4b90: 09 f4        	brne	.+2
    4b92: 00 d1        	rcall	.+512
    4b94: 2b d1        	rcall	.+598
    4b96: 40 92 27 07  	<unknown>
    4b9a: 63 c0        	rjmp	.+198
    4b9c: 00 91 2a 07  	<unknown>
    4ba0: 80 2f        	mov	r24, r16
    4ba2: 87 70        	andi	r24, 0x7
    4ba4: 91 30        	cpi	r25, 0x1
    4ba6: 29 f4        	brne	.+10
    4ba8: 83 95        	inc	r24
    4baa: 88 30        	cpi	r24, 0x8
    4bac: 38 f0        	brlo	.+14
    4bae: 81 e0        	ldi	r24, 0x1
    4bb0: 05 c0        	rjmp	.+10
    4bb2: 94 30        	cpi	r25, 0x4
    4bb4: 19 f4        	brne	.+6
    4bb6: 8a 95        	dec	r24
    4bb8: 09 f4        	brne	.+2
    4bba: 87 e0        	ldi	r24, 0x7
    4bbc: 08 7f        	andi	r16, 0xf8
    4bbe: 87 70        	andi	r24, 0x7
    4bc0: 08 2b        	or	r16, r24
    4bc2: 00 93 2a 07  	<unknown>
    4bc6: 4d c0        	rjmp	.+154
    4bc8: 40 90 2b 07  	<unknown>
    4bcc: c1 d0        	rcall	.+386
    4bce: 29 f4        	brne	.+10
    4bd0: 83 95        	inc	r24
    4bd2: 80 32        	cpi	r24, 0x20
    4bd4: 38 f0        	brlo	.+14
    4bd6: 81 e0        	ldi	r24, 0x1
    4bd8: 05 c0        	rjmp	.+10
    4bda: 94 30        	cpi	r25, 0x4
    4bdc: 19 f4        	brne	.+6
    4bde: 8a 95        	dec	r24
    4be0: 09 f4        	brne	.+2
    4be2: 8f e1        	ldi	r24, 0x1f
    4be4: c6 d0        	rcall	.+396
    4be6: 40 92 2b 07  	<unknown>
    4bea: 3b c0        	rjmp	.+118
    4bec: 40 90 2c 07  	<unknown>
    4bf0: 84 2d        	mov	r24, r4
    4bf2: 8f 70        	andi	r24, 0xf
    4bf4: 14 2d        	mov	r17, r4
    4bf6: 14 fb        	bst	r17, 0x4
    4bf8: 10 e0        	ldi	r17, 0x0
    4bfa: 10 f9        	bld	r17, 0x0
    4bfc: bf d0        	rcall	.+382
    4bfe: 29 f4        	brne	.+10
    4c00: 83 95        	inc	r24
    4c02: 8d 30        	cpi	r24, 0xd
    4c04: 38 f0        	brlo	.+14
    4c06: 81 e0        	ldi	r24, 0x1
    4c08: 05 c0        	rjmp	.+10
    4c0a: 94 30        	cpi	r25, 0x4
    4c0c: 19 f4        	brne	.+6
    4c0e: 8a 95        	dec	r24
    4c10: 09 f4        	brne	.+2
    4c12: 8c e0        	ldi	r24, 0xc
    4c14: 00 ee        	ldi	r16, 0xe0
    4c16: 40 22        	and	r4, r16
    4c18: a5 d0        	rcall	.+330
    4c1a: 4f 70        	andi	r20, 0xf
    4c1c: 44 2a        	or	r4, r20
    4c1e: a6 d0        	rcall	.+332
    4c20: 00 71        	andi	r16, 0x10
    4c22: 40 2a        	or	r4, r16
    4c24: 40 92 2c 07  	<unknown>
    4c28: 1c c0        	rjmp	.+56
    4c2a: 10 91 2d 07  	<unknown>
    4c2e: 81 2f        	mov	r24, r17
    4c30: 8f 70        	andi	r24, 0xf
    4c32: 12 95        	swap	r17
    4c34: 1f 70        	andi	r17, 0xf
    4c36: a2 d0        	rcall	.+324
    4c38: 29 f4        	brne	.+10
    4c3a: 83 95        	inc	r24
    4c3c: 84 36        	cpi	r24, 0x64
    4c3e: 40 f0        	brlo	.+16
    4c40: 80 e0        	ldi	r24, 0x0
    4c42: 06 c0        	rjmp	.+12
    4c44: 94 30        	cpi	r25, 0x4
    4c46: 21 f4        	brne	.+8
    4c48: 8a 95        	dec	r24
    4c4a: 8f 3f        	cpi	r24, 0xff
    4c4c: 09 f4        	brne	.+2
    4c4e: 83 e6        	ldi	r24, 0x63
    4c50: 89 d0        	rcall	.+274
    4c52: 44 2e        	mov	r4, r20
    4c54: 0f e0        	ldi	r16, 0xf
    4c56: 40 22        	and	r4, r16
    4c58: 89 d0        	rcall	.+274
    4c5a: 00 7f        	andi	r16, 0xf0
    4c5c: 40 2a        	or	r4, r16
    4c5e: 40 92 2d 07  	<unknown>
    4c62: 94 30        	cpi	r25, 0x4
    4c64: 11 f0        	breq	.+4
    4c66: 91 30        	cpi	r25, 0x1
    4c68: 09 f4        	brne	.+2
    4c6a: b7 d0        	rcall	.+366
    4c6c: 7a de        	rcall	.-780
    4c6e: 2c ee        	ldi	r18, 0xec
    4c70: 37 e0        	ldi	r19, 0x7
    4c72: 8e 01 09 5e  	<unknown>
    4c76: 5e d0        	rcall	.+188
    4c78: 26 96 64 d0  	<unknown>
    4c7c: 3f d3        	rcall	.+1662
    4c7e: 8e 01 06 5e  	<unknown>
    4c82: 58 d0        	rcall	.+176
    4c84: 96 d0        	rcall	.+300
    4c86: 2b ef        	ldi	r18, 0xfb
    4c88: 37 e0        	ldi	r19, 0x7
    4c8a: 8e 01 0e 5f  	<unknown>
    4c8e: 52 d0        	rcall	.+164
    4c90: b7 d0        	rcall	.+366
    4c92: 20 0f        	add	r18, r16
    4c94: 31 1f        	adc	r19, r17
    4c96: 8e 01 0d 5f  	<unknown>
    4c9a: 4c d0        	rcall	.+152
    4c9c: 75 d0        	rcall	.+234
    4c9e: 8e d0        	rcall	.+284
    4ca0: 20 e0        	ldi	r18, 0x0
    4ca2: 38 e0        	ldi	r19, 0x8
    4ca4: 8e 01 03 5f  	<unknown>
    4ca8: 45 d0        	rcall	.+138
    4caa: 22 96 82 99  	<unknown>
    4cae: 2e c0        	rjmp	.+92
    4cb0: 29 d1        	rcall	.+594
    4cb2: 61 f1        	breq	.+88
    4cb4: 04 30        	cpi	r16, 0x4
    4cb6: 51 f1        	breq	.+84
    4cb8: 00 91 40 07  	<unknown>
    4cbc: 00 23        	tst	r16
    4cbe: 69 f0        	breq	.+26
    4cc0: 0a 95        	dec	r16
    4cc2: 71 f0        	breq	.+28
    4cc4: 0a 95        	dec	r16
    4cc6: 79 f0        	breq	.+30
    4cc8: 0a 95        	dec	r16
    4cca: 81 f0        	breq	.+32
    4ccc: 0a 95        	dec	r16
    4cce: 91 f0        	breq	.+36
    4cd0: 0a 95        	dec	r16
    4cd2: 91 f0        	breq	.+36
    4cd4: 0a 95        	dec	r16
    4cd6: a1 f0        	breq	.+40
    4cd8: 19 c0        	rjmp	.+50
    4cda: 61 d0        	rcall	.+194
    4cdc: 0f 5e        	subi	r16, 0xef
    4cde: 13 c0        	rjmp	.+38
    4ce0: 5e d0        	rcall	.+188
    4ce2: 0c 5e        	subi	r16, 0xec
    4ce4: 10 c0        	rjmp	.+32
    4ce6: 5b d0        	rcall	.+182
    4ce8: 09 5e        	subi	r16, 0xe9
    4cea: 0d c0        	rjmp	.+26
    4cec: 47 e0        	ldi	r20, 0x7
    4cee: 58 d0        	rcall	.+176
    4cf0: 06 5e        	subi	r16, 0xe6
    4cf2: 09 c0        	rjmp	.+18
    4cf4: 54 d0        	rcall	.+168
    4cf6: 08 c0        	rjmp	.+16
    4cf8: 48 e0        	ldi	r20, 0x8
    4cfa: 52 d0        	rcall	.+164
    4cfc: 0d 5f        	subi	r16, 0xfd
    4cfe: 03 c0        	rjmp	.+6
    4d00: 44 e0        	ldi	r20, 0x4
    4d02: 4e d0        	rcall	.+156
    4d04: 04 5f        	subi	r16, 0xf4
    4d06: 1f 4f        	sbci	r17, 0xff
    4d08: 0e 94 33 35  	<unknown>
    4d0c: 08 d1        	rcall	.+528
    4d0e: 8e 01 0f 5e  	<unknown>
    4d12: 1f 4f        	sbci	r17, 0xff
    4d14: 0e 94 5d 35  	<unknown>
    4d18: 0c d3        	rcall	.+1560
    4d1a: 8e 01 0e 94  	<unknown>
    4d1e: 5d 35        	cpi	r21, 0x5d
    4d20: 44 d0        	rcall	.+136
    4d22: f4 d0        	rcall	.+488
    4d24: 11 f4        	brne	.+4
    4d26: 01 e0        	ldi	r16, 0x1
    4d28: 01 c0        	rjmp	.+2
    4d2a: 00 e0        	ldi	r16, 0x0
    4d2c: a2 96 e5 e0  	<unknown>
    4d30: 0c 94 ff 34  	<unknown>
    4d34: 1f 4f        	sbci	r17, 0xff
    4d36: 0c 94 b5 35  	<unknown>
    4d3a: 84 2d        	mov	r24, r4
    4d3c: 8f 70        	andi	r24, 0xf
    4d3e: 04 2d        	mov	r16, r4
    4d40: 00 77        	andi	r16, 0x70
    4d42: 08 95        	ret
    4d44: 28 e5        	ldi	r18, 0x58
    4d46: 3b e0        	ldi	r19, 0xb
    4d48: 00 91 2a 07  	<unknown>
    4d4c: 07 70        	andi	r16, 0x7
    4d4e: 08 95        	ret
    4d50: 84 2d        	mov	r24, r4
    4d52: 8f 70        	andi	r24, 0xf
    4d54: 04 2d        	mov	r16, r4
    4d56: 00 73        	andi	r16, 0x30
    4d58: 02 95        	swap	r16
    4d5a: 1a e0        	ldi	r17, 0xa
    4d5c: 01 9f 80 0d  	<unknown>
    4d60: 91 30        	cpi	r25, 0x1
    4d62: 08 95        	ret
    4d64: 4a e0        	ldi	r20, 0xa
    4d66: 08 2f        	mov	r16, r24
    4d68: 0c 94 bf 31  	<unknown>
    4d6c: fb df        	rcall	.-10
    4d6e: 02 95        	swap	r16
    4d70: 08 95        	ret
    4d72: 00 ec        	ldi	r16, 0xc0
    4d74: 3f d0        	rcall	.+126
    4d76: 00 73        	andi	r16, 0x30
    4d78: 40 2a        	or	r4, r16
    4d7a: 08 95        	ret
    4d7c: 0a e0        	ldi	r16, 0xa
    4d7e: 10 9f ee cf  	<unknown>
    4d82: 00 91 35 07  	<unknown>
    4d86: ea c5        	rjmp	.+3028
    4d88: 40 91 2d 07  	<unknown>
    4d8c: 1e d0        	rcall	.+60
    4d8e: 42 95        	swap	r20
    4d90: 4f 70        	andi	r20, 0xf
    4d92: 08 95        	ret
    4d94: 8a 95        	dec	r24
    4d96: 8f 3f        	cpi	r24, 0xff
    4d98: 09 f4        	brne	.+2
    4d9a: 8b e3        	ldi	r24, 0x3b
    4d9c: 08 95        	ret
    4d9e: 42 e0        	ldi	r20, 0x2
    4da0: 50 e0        	ldi	r21, 0x0
    4da2: 20 e2        	ldi	r18, 0x20
    4da4: 30 e0        	ldi	r19, 0x0
    4da6: 8e 01 08 95  	<unknown>
    4daa: 00 e0        	ldi	r16, 0x0
    4dac: 00 93 35 07  	<unknown>
    4db0: 08 95        	ret
    4db2: 40 91 2b 07  	<unknown>
    4db6: 09 d0        	rcall	.+18
    4db8: 40 73        	andi	r20, 0x30
    4dba: 42 95        	swap	r20
    4dbc: 50 e0        	ldi	r21, 0x0
    4dbe: 09 d0        	rcall	.+18
    4dc0: 20 0f        	add	r18, r16
    4dc2: 31 1f        	adc	r19, r17
    4dc4: 3a 93        	st	-Y, r19
    4dc6: 2a 93        	st	-Y, r18
    4dc8: 08 95        	ret
    4dca: 04 2f        	mov	r16, r20
    4dcc: 0f 70        	andi	r16, 0xf
    4dce: 20 2f        	mov	r18, r16
    4dd0: 75 cd        	rjmp	.-1302
    4dd2: 0a e0        	ldi	r16, 0xa
    4dd4: 10 e0        	ldi	r17, 0x0
    4dd6: 0c 94 cd 31  	<unknown>
    4dda: 01 d0        	rcall	.+2
    4ddc: 05 c0        	rjmp	.+10
    4dde: 38 e0        	ldi	r19, 0x8
    4de0: 20 e0        	ldi	r18, 0x0
    4de2: 07 e2        	ldi	r16, 0x27
    4de4: 17 e0        	ldi	r17, 0x7
    4de6: 08 95        	ret
    4de8: 0c 94 fa 08  	<unknown>
    4dec: 00 e8        	ldi	r16, 0x80
    4dee: 02 d0        	rcall	.+4
    4df0: 00 77        	andi	r16, 0x70
    4df2: c2 cf        	rjmp	.-124
    4df4: 40 22        	and	r4, r16
    4df6: b6 df        	rcall	.-148
    4df8: 4f 70        	andi	r20, 0xf
    4dfa: 44 2a        	or	r4, r20
    4dfc: b3 df        	rcall	.-154
    4dfe: b7 cf        	rjmp	.-146
    4e00: 22 96 2b ee  	<unknown>
    4e04: 3a e0        	ldi	r19, 0xa
    4e06: 60 91 2c 07  	<unknown>
    4e0a: 6f 70        	andi	r22, 0xf
    4e0c: 70 e0        	ldi	r23, 0x0
    4e0e: 40 91 2c 07  	<unknown>
    4e12: 44 fb        	bst	r20, 0x4
    4e14: 07 d0        	rcall	.+14
    4e16: 40 f9        	bld	r20, 0x0
    4e18: dc df        	rcall	.-72
    4e1a: 2d d2        	rcall	.+1114
    4e1c: 09 e0        	ldi	r16, 0x9
    4e1e: 10 e0        	ldi	r17, 0x0
    4e20: ab 01 d9 cf  	<unknown>
    4e24: 40 e0        	ldi	r20, 0x0
    4e26: 50 e0        	ldi	r21, 0x0
    4e28: 08 95        	ret
    4e2a: 00 23        	tst	r16
    4e2c: 19 f0        	breq	.+6
    4e2e: 0e 94 09 18  	<unknown>
    4e32: 06 c0        	rjmp	.+12
    4e34: f4 d0        	rcall	.+488
    4e36: 0e 94 0d 18  	<unknown>
    4e3a: 00 23        	tst	r16
    4e3c: 09 f0        	breq	.+2
    4e3e: 2a c3        	rjmp	.+1620
    4e40: 00 e0        	ldi	r16, 0x0
    4e42: 08 95        	ret
    4e44: ba 93        	st	-Y, r27
    4e46: aa 93        	st	-Y, r26
    4e48: 00 23        	tst	r16
    4e4a: 11 f0        	breq	.+4
    4e4c: e6 d0        	rcall	.+460
    4e4e: 21 c0        	rjmp	.+66
    4e50: 66 d0        	rcall	.+204
    4e52: a3 e7        	ldi	r26, 0x73
    4e54: b6 e0        	ldi	r27, 0x6
    4e56: 0d 91        	ld	r16, X+
    4e58: 1c 91        	ld	r17, X
    4e5a: 11 97 1f d0  	<unknown>
    4e5e: 03 e7        	ldi	r16, 0x73
    4e60: 19 e0        	ldi	r17, 0x9
    4e62: e7 d0        	rcall	.+462
    4e64: 66 d2        	rcall	.+1228
    4e66: fd 01 02 81  	<unknown>
    4e6a: 13 81        	ldd	r17, Z+3
    4e6c: b6 d2        	rcall	.+1388
    4e6e: 16 d0        	rcall	.+44
    4e70: 0e e7        	ldi	r16, 0x7e
    4e72: 19 e0        	ldi	r17, 0x9
    4e74: 10 d0        	rcall	.+32
    4e76: 1f e0        	ldi	r17, 0xf
    4e78: 38 d2        	rcall	.+1136
    4e7a: 82 9b        	sbis	0x10, 0x2
    4e7c: 03 c0        	rjmp	.+6
    4e7e: 0e e8        	ldi	r16, 0x8e
    4e80: 19 e0        	ldi	r17, 0x9
    4e82: 02 c0        	rjmp	.+4
    4e84: 00 e9        	ldi	r16, 0x90
    4e86: 19 e0        	ldi	r17, 0x9
    4e88: 46 d0        	rcall	.+140
    4e8a: 40 d0        	rcall	.+128
    4e8c: 11 f4        	brne	.+4
    4e8e: 01 e0        	ldi	r16, 0x1
    4e90: 01 c0        	rjmp	.+2
    4e92: 00 e0        	ldi	r16, 0x0
    4e94: 8a c2        	rjmp	.+1300
    4e96: 3f d0        	rcall	.+126
    4e98: 26 96 08 95  	<unknown>
    4e9c: 4a dd        	rcall	.-1388
    4e9e: 09 d0        	rcall	.+18
    4ea0: 0e 94 68 33  	<unknown>
    4ea4: 40 e0        	ldi	r20, 0x0
    4ea6: 50 ec        	ldi	r21, 0xc0
    4ea8: 6f e7        	ldi	r22, 0x7f
    4eaa: 74 e4        	ldi	r23, 0x44
    4eac: 0e 94 e1 33  	<unknown>
    4eb0: 9a c5        	rjmp	.+2868
    4eb2: b8 df        	rcall	.-144
    4eb4: 60 ea        	ldi	r22, 0xa0
    4eb6: 70 e4        	ldi	r23, 0x40
    4eb8: 08 95        	ret
    4eba: 00 23        	tst	r16
    4ebc: 21 f0        	breq	.+8
    4ebe: ad d0        	rcall	.+346
    4ec0: 0e ef        	ldi	r16, 0xfe
    4ec2: f9 d1        	rcall	.+1010
    4ec4: 07 c0        	rjmp	.+14
    4ec6: 22 d0        	rcall	.+68
    4ec8: 11 f0        	breq	.+4
    4eca: 00 23        	tst	r16
    4ecc: 09 f4        	brne	.+2
    4ece: e2 c2        	rjmp	.+1476
    4ed0: 0f 3f        	cpi	r16, 0xff
    4ed2: b9 f0        	breq	.+46
    4ed4: 17 d0        	rcall	.+46
    4ed6: 11 f0        	breq	.+4
    4ed8: 04 30        	cpi	r16, 0x4
    4eda: 31 f4        	brne	.+12
    4edc: 22 d0        	rcall	.+68
    4ede: 03 95        	inc	r16
    4ee0: 01 70        	andi	r16, 0x1
    4ee2: 4c ee        	ldi	r20, 0xec
    4ee4: 52 e0        	ldi	r21, 0x2
    4ee6: 7e d2        	rcall	.+1276
    4ee8: 1a d0        	rcall	.+52
    4eea: 01 e9        	ldi	r16, 0x91
    4eec: 18 e0        	ldi	r17, 0x8
    4eee: 20 d2        	rcall	.+1088
    4ef0: 18 d0        	rcall	.+48
    4ef2: 00 23        	tst	r16
    4ef4: 19 f0        	breq	.+6
    4ef6: 02 ea        	ldi	r16, 0xa2
    4ef8: 18 e0        	ldi	r17, 0x8
    4efa: 02 c0        	rjmp	.+4
    4efc: 0d eb        	ldi	r16, 0xbd
    4efe: 17 e0        	ldi	r17, 0x7
    4f00: 0a d0        	rcall	.+20
    4f02: 9e cf        	rjmp	.-196
    4f04: 8c d0        	rcall	.+280
    4f06: 0f 70        	andi	r16, 0xf
    4f08: 01 30        	cpi	r16, 0x1
    4f0a: 08 95        	ret
    4f0c: 88 d0        	rcall	.+272
    4f0e: 05 30        	cpi	r16, 0x5
    4f10: 08 95        	ret
    4f12: 02 0f        	add	r16, r18
    4f14: 13 1f        	adc	r17, r19
    4f16: 0c 94 70 35  	<unknown>
    4f1a: 0e 94 43 0f  	<unknown>
    4f1e: 10 e0        	ldi	r17, 0x0
    4f20: e4 c1        	rjmp	.+968
    4f22: 4c ee        	ldi	r20, 0xec
    4f24: 52 e0        	ldi	r21, 0x2
    4f26: d0 c1        	rjmp	.+928
    4f28: bb d1        	rcall	.+886
    4f2a: 44 d2        	rcall	.+1160
    4f2c: 89 f0        	breq	.+34
    4f2e: 00 e0        	ldi	r16, 0x0
    4f30: 00 93 41 07  	<unknown>
    4f34: 00 93 42 07  	<unknown>
    4f38: 70 d0        	rcall	.+224
    4f3a: 21 e0        	ldi	r18, 0x1
    4f3c: 87 d0        	rcall	.+270
    4f3e: 80 e0        	ldi	r24, 0x0
    4f40: 30 e0        	ldi	r19, 0x0
    4f42: 28 2f        	mov	r18, r24
    4f44: 80 d0        	rcall	.+256
    4f46: 83 95        	inc	r24
    4f48: 8c 30        	cpi	r24, 0xc
    4f4a: d0 f3        	brlo	.-12
    4f4c: 0e ef        	ldi	r16, 0xfe
    4f4e: b3 d1        	rcall	.+870
    4f50: 69 d0        	rcall	.+210
    4f52: 21 f4        	brne	.+8
    4f54: 20 e0        	ldi	r18, 0x0
    4f56: 7a d0        	rcall	.+244
    4f58: 01 e0        	ldi	r16, 0x1
    4f5a: 56 c0        	rjmp	.+172
    4f5c: 00 23        	tst	r16
    4f5e: 41 f4        	brne	.+16
    4f60: 56 d0        	rcall	.+172
    4f62: f9 d4        	rcall	.+2546
    4f64: 11 f4        	brne	.+4
    4f66: 31 e0        	ldi	r19, 0x1
    4f68: 01 c0        	rjmp	.+2
    4f6a: 30 e0        	ldi	r19, 0x0
    4f6c: 50 d0        	rcall	.+160
    4f6e: 6b d0        	rcall	.+214
    4f70: 56 d0        	rcall	.+172
    4f72: 0f 3f        	cpi	r16, 0xff
    4f74: 09 f4        	brne	.+2
    4f76: 47 c0        	rjmp	.+142
    4f78: 40 91 42 07  	<unknown>
    4f7c: 20 91 41 07  	<unknown>
    4f80: 30 e0        	ldi	r19, 0x0
    4f82: 24 0f        	add	r18, r20
    4f84: 33 1f        	rol	r19
    4f86: 0f 70        	andi	r16, 0xf
    4f88: 01 30        	cpi	r16, 0x1
    4f8a: 59 f4        	brne	.+22
    4f8c: 23 2b        	or	r18, r19
    4f8e: c1 f0        	breq	.+48
    4f90: 44 23        	tst	r20
    4f92: 21 f0        	breq	.+8
    4f94: db 96 04 2f  	<unknown>
    4f98: 0a 95        	dec	r16
    4f9a: 11 c0        	rjmp	.+34
    4f9c: da 96 0c 91  	<unknown>
    4fa0: fb cf        	rjmp	.-10
    4fa2: 04 30        	cpi	r16, 0x4
    4fa4: 69 f4        	brne	.+26
    4fa6: 2b 30        	cpi	r18, 0xb
    4fa8: 30 40        	sbci	r19, 0x0
    4faa: 54 f4        	brge	.+20
    4fac: 44 23        	tst	r20
    4fae: 21 f4        	brne	.+8
    4fb0: 01 e0        	ldi	r16, 0x1
    4fb2: 00 93 42 07  	<unknown>
    4fb6: 04 c0        	rjmp	.+8
    4fb8: da 96 0c 91  	<unknown>
    4fbc: 03 95        	inc	r16
    4fbe: 0c 93        	st	X, r16
    4fc0: 2c d0        	rcall	.+88
    4fc2: 80 e0        	ldi	r24, 0x0
    4fc4: 18 2f        	mov	r17, r24
    4fc6: 02 e0        	ldi	r16, 0x2
    4fc8: 91 d1        	rcall	.+802
    4fca: 20 91 41 07  	<unknown>
    4fce: 28 0f        	add	r18, r24
    4fd0: 37 d0        	rcall	.+110
    4fd2: 0e 94 41 12  	<unknown>
    4fd6: 30 d0        	rcall	.+96
    4fd8: e8 2f        	mov	r30, r24
    4fda: f0 e0        	ldi	r31, 0x0
    4fdc: 00 91 41 07  	<unknown>
    4fe0: e0 0f        	add	r30, r16
    4fe2: f1 1f        	adc	r31, r17
    4fe4: 60 d1        	rcall	.+704
    4fe6: 02 e9        	ldi	r16, 0x92
    4fe8: 19 e0        	ldi	r17, 0x9
    4fea: 23 d0        	rcall	.+70
    4fec: 83 95        	inc	r24
    4fee: 82 30        	cpi	r24, 0x2
    4ff0: 48 f3        	brlo	.-46
    4ff2: 00 91 42 07  	<unknown>
    4ff6: 00 23        	tst	r16
    4ff8: 11 f4        	brne	.+4
    4ffa: 10 e0        	ldi	r17, 0x0
    4ffc: 01 c0        	rjmp	.+2
    4ffe: 11 e0        	ldi	r17, 0x1
    5000: 74 d1        	rcall	.+744
    5002: 00 e0        	ldi	r16, 0x0
    5004: 1b d0        	rcall	.+54
    5006: 00 e0        	ldi	r16, 0x0
    5008: e4 e0        	ldi	r30, 0x4
    500a: 0c 94 00 35  	<unknown>
    500e: 20 91 41 07  	<unknown>
    5012: 00 91 42 07  	<unknown>
    5016: 20 0f        	add	r18, r16
    5018: 08 95        	ret
    501a: 0c 94 43 0f  	<unknown>
    501e: 00 91 39 07  	<unknown>
    5022: 08 95        	ret
    5024: fc df        	rcall	.-8
    5026: 0f 70        	andi	r16, 0xf
    5028: 72 cf        	rjmp	.-284
    502a: 28 d1        	rcall	.+592
    502c: dc d4        	rcall	.+2488
    502e: 0c ed        	ldi	r16, 0xdc
    5030: 17 e0        	ldi	r17, 0x7
    5032: 71 df        	rcall	.-286
    5034: 24 96 08 95  	<unknown>
    5038: 10 e0        	ldi	r17, 0x0
    503a: cf c1        	rjmp	.+926
    503c: 10 e0        	ldi	r17, 0x0
    503e: 94 c8        	rjmp	.-3800
    5040: 07 e4        	ldi	r16, 0x47
    5042: 17 e0        	ldi	r17, 0x7
    5044: 08 95        	ret
    5046: fc df        	rcall	.-8
    5048: 0c 94 0a 12  	<unknown>
    504c: f9 df        	rcall	.-14
    504e: 0c 94 9e 11  	<unknown>
    5052: 26 d1        	rcall	.+588
    5054: 22 97 ae d1  	<unknown>
    5058: 99 f1        	breq	.+102
    505a: df df        	rcall	.-66
    505c: 10 e0        	ldi	r17, 0x0
    505e: 66 d1        	rcall	.+716
    5060: 02 ea        	ldi	r16, 0xa2
    5062: 19 e0        	ldi	r17, 0x9
    5064: 3e d1        	rcall	.+636
    5066: 02 e0        	ldi	r16, 0x2
    5068: 41 d1        	rcall	.+642
    506a: 01 eb        	ldi	r16, 0xb1
    506c: 19 e0        	ldi	r17, 0x9
    506e: 53 df        	rcall	.-346
    5070: 04 e6        	ldi	r16, 0x64
    5072: 13 d1        	rcall	.+550
    5074: 3d d1        	rcall	.+634
    5076: 00 93 44 07  	<unknown>
    507a: 3e d1        	rcall	.+636
    507c: 0e 94 3c 35  	<unknown>
    5080: fd 01 02 a7  	<unknown>
    5084: 13 a7 08 d1  	<unknown>
    5088: 11 c0        	rjmp	.+34
    508a: 32 d1        	rcall	.+612
    508c: 17 d1        	rcall	.+558
    508e: 1e d1        	rcall	.+572
    5090: fc 01 ef 57  	<unknown>
    5094: f9 4f        	sbci	r31, 0xf9
    5096: 50 81        	ldd	r21, Z+0
    5098: 3f d1        	rcall	.+638
    509a: 50 83        	std	Z+0, r21
    509c: 1d d1        	rcall	.+570
    509e: c0 f3        	brlo	.-16
    50a0: 06 d1        	rcall	.+524
    50a2: e0 e8        	ldi	r30, 0x80
    50a4: f6 e0        	ldi	r31, 0x6
    50a6: 00 81        	ldd	r16, Z+0
    50a8: 03 95        	inc	r16
    50aa: 00 83        	std	Z+0, r16
    50ac: f2 d0        	rcall	.+484
    50ae: 10 91 44 07  	<unknown>
    50b2: 01 17        	cp	r16, r17
    50b4: 50 f3        	brlo	.-44
    50b6: 01 e0        	ldi	r16, 0x1
    50b8: 00 93 38 07  	<unknown>
    50bc: 0e ef        	ldi	r16, 0xfe
    50be: fb d0        	rcall	.+502
    50c0: fd 01 22 a4  	<unknown>
    50c4: 33 a4 32 a9  	<unknown>
    50c8: 25 ad 22 23  	<unknown>
    50cc: d9 f4        	brne	.+54
    50ce: 3e 3f        	cpi	r19, 0xfe
    50d0: 09 f4        	brne	.+2
    50d2: 69 c0        	rjmp	.+210
    50d4: 81 01 0e 94  	<unknown>
    50d8: 74 31        	cpi	r23, 0x14
    50da: 1f df        	rcall	.-450
    50dc: 0e eb        	ldi	r16, 0xbe
    50de: 19 e0        	ldi	r17, 0x9
    50e0: 27 d1        	rcall	.+590
    50e2: 0b ec        	ldi	r16, 0xcb
    50e4: 19 e0        	ldi	r17, 0x9
    50e6: 17 df        	rcall	.-466
    50e8: 0f e7        	ldi	r16, 0x7f
    50ea: 1a e1        	ldi	r17, 0x1a
    50ec: 26 e0        	ldi	r18, 0x6
    50ee: 01 50        	subi	r16, 0x1
    50f0: 10 40        	sbci	r17, 0x0
    50f2: 20 40        	sbci	r18, 0x0
    50f4: e1 f7        	brne	.-8
    50f6: 00 c0        	rjmp	.+0
    50f8: 00 00        	nop
    50fa: 00 e0        	ldi	r16, 0x0
    50fc: 00 93 38 07  	<unknown>
    5100: 01 e0        	ldi	r16, 0x1
    5102: b7 c0        	rjmp	.+366
    5104: 31 30        	cpi	r19, 0x1
    5106: 61 f4        	brne	.+24
    5108: c4 d0        	rcall	.+392
    510a: 10 e0        	ldi	r17, 0x0
    510c: 82 2f        	mov	r24, r18
    510e: 90 e0        	ldi	r25, 0x0
    5110: 01 97 08 17  	<unknown>
    5114: 19 07        	cpc	r17, r25
    5116: 0c f0        	brlt	.+2
    5118: 46 c0        	rjmp	.+140
    511a: 03 95        	inc	r16
    511c: be d0        	rcall	.+380
    511e: 43 c0        	rjmp	.+134
    5120: 34 30        	cpi	r19, 0x4
    5122: 29 f4        	brne	.+10
    5124: b6 d0        	rcall	.+364
    5126: 00 23        	tst	r16
    5128: f1 f1        	breq	.+124
    512a: 0a 95        	dec	r16
    512c: f7 cf        	rjmp	.-18
    512e: 33 30        	cpi	r19, 0x3
    5130: 41 f4        	brne	.+16
    5132: 04 ad 03 95  	<unknown>
    5136: 04 af 00 32  	<unknown>
    513a: a8 f1        	brlo	.+106
    513c: 00 e0        	ldi	r16, 0x0
    513e: 04 af 32 c0  	<unknown>
    5142: 32 30        	cpi	r19, 0x2
    5144: 39 f4        	brne	.+14
    5146: 04 ad 0a 95  	<unknown>
    514a: 04 af 0f 3f  	<unknown>
    514e: 59 f5        	brne	.+86
    5150: 0f e1        	ldi	r16, 0x1f
    5152: f5 cf        	rjmp	.-22
    5154: 33 23        	tst	r19
    5156: 39 f5        	brne	.+78
    5158: 00 24        	clr	r0
    515a: 03 94        	inc	r0
    515c: b7 d0        	rcall	.+366
    515e: 00 91 43 07  	<unknown>
    5162: ca d0        	rcall	.+404
    5164: 60 ef        	ldi	r22, 0xf0
    5166: 72 e0        	ldi	r23, 0x2
    5168: 86 d0        	rcall	.+268
    516a: 93 d0        	rcall	.+294
    516c: c5 d0        	rcall	.+394
    516e: f1 01 e0 0f  	<unknown>
    5172: f1 1f        	adc	r31, r17
    5174: e8 0f        	add	r30, r24
    5176: f9 1f        	adc	r31, r25
    5178: ab 01 48 0f  	<unknown>
    517c: 59 1f        	adc	r21, r25
    517e: a4 d0        	rcall	.+328
    5180: 10 81        	ldd	r17, Z+0
    5182: 01 17        	cp	r16, r17
    5184: 19 f0        	breq	.+6
    5186: 01 2f        	mov	r16, r17
    5188: 2d d1        	rcall	.+602
    518a: 00 24        	clr	r0
    518c: a5 d0        	rcall	.+330
    518e: 68 f3        	brlo	.-38
    5190: 00 20        	tst	r0
    5192: 49 f0        	breq	.+18
    5194: 9b d0        	rcall	.+310
    5196: ab 01 48 0f  	<unknown>
    519a: 59 1f        	adc	r21, r25
    519c: 23 d1        	rcall	.+582
    519e: 01 96 88 30  	<unknown>
    51a2: 90 07        	cpc	r25, r16
    51a4: c0 f3        	brlo	.-16
    51a6: 75 d0        	rcall	.+234
    51a8: 02 17        	cp	r16, r18
    51aa: 08 f0        	brlo	.+2
    51ac: 75 d0        	rcall	.+234
    51ae: 3f 3f        	cpi	r19, 0xff
    51b0: 09 f4        	brne	.+2
    51b2: 41 c0        	rjmp	.+130
    51b4: 80 e0        	ldi	r24, 0x0
    51b6: 0b c0        	rjmp	.+22
    51b8: 0d e2        	ldi	r16, 0x2d
    51ba: 40 df        	rcall	.-384
    51bc: ba d0        	rcall	.+372
    51be: e0 91 43 07  	<unknown>
    51c2: 70 d0        	rcall	.+224
    51c4: 03 ee        	ldi	r16, 0xe3
    51c6: 19 e0        	ldi	r17, 0x9
    51c8: a6 de        	rcall	.-692
    51ca: 22 96 83 95  	<unknown>
    51ce: 00 90 44 07  	<unknown>
    51d2: 80 15        	cp	r24, r0
    51d4: 80 f5        	brsh	.+96
    51d6: 91 e0        	ldi	r25, 0x1
    51d8: 9f db        	rcall	.-2242
    51da: fd 01 22 a5  	<unknown>
    51de: 33 a5 08 2f  	<unknown>
    51e2: 8c d0        	rcall	.+280
    51e4: 26 0f        	add	r18, r22
    51e6: 37 1f        	adc	r19, r23
    51e8: f9 01 20 81  	<unknown>
    51ec: 00 91 43 07  	<unknown>
    51f0: 89 d0        	rcall	.+274
    51f2: 46 0f        	add	r20, r22
    51f4: 57 1f        	adc	r21, r23
    51f6: 68 d0        	rcall	.+208
    51f8: 20 17        	cp	r18, r16
    51fa: 09 f0        	breq	.+2
    51fc: 90 e0        	ldi	r25, 0x0
    51fe: 6f 5f        	subi	r22, 0xff
    5200: 7f 4f        	sbci	r23, 0xff
    5202: 68 30        	cpi	r22, 0x8
    5204: 00 e0        	ldi	r16, 0x0
    5206: 70 07        	cpc	r23, r16
    5208: 40 f3        	brlo	.-48
    520a: 99 23        	tst	r25
    520c: 19 f0        	breq	.+6
    520e: 80 93 80 06  	<unknown>
    5212: 80 2d        	mov	r24, r0
    5214: 02 df        	rcall	.-508
    5216: 10 e0        	ldi	r17, 0x0
    5218: 0a e0        	ldi	r16, 0xa
    521a: 68 d0        	rcall	.+208
    521c: 00 91 44 07  	<unknown>
    5220: 0b df        	rcall	.-490
    5222: e0 91 80 06  	<unknown>
    5226: 3e d0        	rcall	.+124
    5228: 0a ed        	ldi	r16, 0xda
    522a: 19 e0        	ldi	r17, 0x9
    522c: 02 df        	rcall	.-508
    522e: 99 23        	tst	r25
    5230: 19 f2        	breq	.-122
    5232: 0d e4        	ldi	r16, 0x4d
    5234: c2 cf        	rjmp	.-124
    5236: 4a d0        	rcall	.+148
    5238: 6f d0        	rcall	.+222
    523a: 00 81        	ldd	r16, Z+0
    523c: fc 01 ef 57  	<unknown>
    5240: f9 4f        	sbci	r31, 0xf9
    5242: 00 83        	std	Z+0, r16
    5244: 49 d0        	rcall	.+146
    5246: c0 f3        	brlo	.-16
    5248: 44 d0        	rcall	.+136
    524a: 01 30        	cpi	r16, 0x1
    524c: 49 f4        	brne	.+18
    524e: 2f d0        	rcall	.+94
    5250: 66 de        	rcall	.-820
    5252: 08 81        	ldd	r16, Y+0
    5254: 19 81        	ldd	r17, Y+1
    5256: 12 d0        	rcall	.+36
    5258: c6 d3        	rcall	.+1932
    525a: 05 ef        	ldi	r16, 0xf5
    525c: 19 e0        	ldi	r17, 0x9
    525e: e9 de        	rcall	.-558
    5260: 55 de        	rcall	.-854
    5262: 31 f4        	brne	.+12
    5264: fd 01 02 a5  	<unknown>
    5268: 13 a5 0e 94  	<unknown>
    526c: 74 31        	cpi	r23, 0x14
    526e: 45 cf        	rjmp	.-374
    5270: 00 e0        	ldi	r16, 0x0
    5272: 22 96 c9 ce  	<unknown>
    5276: 60 0f        	add	r22, r16
    5278: 71 1f        	adc	r23, r17
    527a: 08 95        	ret
    527c: 21 2f        	mov	r18, r17
    527e: 22 0f        	lsl	r18
    5280: 22 0b        	sbc	r18, r18
    5282: 32 2f        	mov	r19, r18
    5284: 0e 94 a8 32  	<unknown>
    5288: cd dd        	rcall	.-1126
    528a: 68 ec        	ldi	r22, 0xc8
    528c: 72 e4        	ldi	r23, 0x42
    528e: 0c 94 e1 33  	<unknown>
    5292: 00 91 80 06  	<unknown>
    5296: 08 95        	ret
    5298: 00 e0        	ldi	r16, 0x0
    529a: 00 93 80 06  	<unknown>
    529e: 08 95        	ret
    52a0: 0c 94 ef 34  	<unknown>
    52a4: f0 e0        	ldi	r31, 0x0
    52a6: 31 96 fa 93  	<unknown>
    52aa: ea 93        	st	-Y, r30
    52ac: 08 95        	ret
    52ae: 0c 94 86 0a  	<unknown>
    52b2: 0e 94 6d 10  	<unknown>
    52b6: 00 93 39 07  	<unknown>
    52ba: 08 95        	ret
    52bc: 0e 94 9f 09  	<unknown>
    52c0: 0c 94 ad 09  	<unknown>
    52c4: 4c 5f        	subi	r20, 0xfc
    52c6: 5f 4f        	sbci	r21, 0xff
    52c8: 0c 94 86 31  	<unknown>
    52cc: 80 e0        	ldi	r24, 0x0
    52ce: 90 e0        	ldi	r25, 0x0
    52d0: 08 95        	ret
    52d2: 8e 01 0c 94  	<unknown>
    52d6: f2 09        	sbc	r31, r2
    52d8: 01 96 88 30  	<unknown>
    52dc: 00 e0        	ldi	r16, 0x0
    52de: 90 07        	cpc	r25, r16
    52e0: 08 95        	ret
    52e2: 19 de        	rcall	.-974
    52e4: 11 e0        	ldi	r17, 0x1
    52e6: 08 95        	ret
    52e8: 18 2f        	mov	r17, r24
    52ea: 00 e0        	ldi	r16, 0x0
    52ec: 0c 94 29 0f  	<unknown>
    52f0: 10 e0        	ldi	r17, 0x0
    52f2: 0f ef        	ldi	r16, 0xff
    52f4: 0c 94 a6 0a  	<unknown>
    52f8: 10 e0        	ldi	r17, 0x0
    52fa: 0b c0        	rjmp	.+22
    52fc: 09 d0        	rcall	.+18
    52fe: 20 0f        	add	r18, r16
    5300: 31 1f        	adc	r19, r17
    5302: 08 95        	ret
    5304: 05 d0        	rcall	.+10
    5306: 40 ef        	ldi	r20, 0xf0
    5308: 52 e0        	ldi	r21, 0x2
    530a: 40 0f        	add	r20, r16
    530c: 51 1f        	adc	r21, r17
    530e: 08 95        	ret
    5310: 10 e0        	ldi	r17, 0x0
    5312: 43 e0        	ldi	r20, 0x3
    5314: 0c 94 d5 31  	<unknown>
    5318: fd 01 22 a5  	<unknown>
    531c: 33 a5 00 91  	<unknown>
    5320: 80 06        	cpc	r8, r16
    5322: ec df        	rcall	.-40
    5324: 28 0f        	add	r18, r24
    5326: 39 1f        	adc	r19, r25
    5328: f9 01 08 95  	<unknown>
    532c: 01 e0        	ldi	r16, 0x1
    532e: de cf        	rjmp	.-68
    5330: f2 dd        	rcall	.-1052
    5332: 11 e0        	ldi	r17, 0x1
    5334: da cf        	rjmp	.-76
    5336: 3c d0        	rcall	.+120
    5338: 71 f0        	breq	.+28
    533a: 9f d0        	rcall	.+318
    533c: 2d ef        	ldi	r18, 0xfd
    533e: 39 e0        	ldi	r19, 0x9
    5340: 45 d0        	rcall	.+138
    5342: 40 e0        	ldi	r20, 0x0
    5344: b1 d0        	rcall	.+354
    5346: 08 b5        	in	r16, 0x28
    5348: 00 95        	com	r16
    534a: 00 93 45 07  	<unknown>
    534e: 40 91 45 07  	<unknown>
    5352: a8 d0        	rcall	.+336
    5354: 24 c0        	rjmp	.+72
    5356: 63 de        	rcall	.-826
    5358: 02 30        	cpi	r16, 0x2
    535a: 11 f4        	brne	.+4
    535c: 4b ef        	ldi	r20, 0xfb
    535e: 21 d0        	rcall	.+66
    5360: 5e de        	rcall	.-836
    5362: 03 30        	cpi	r16, 0x3
    5364: 11 f4        	brne	.+4
    5366: 45 e0        	ldi	r20, 0x5
    5368: 28 d0        	rcall	.+80
    536a: 59 de        	rcall	.-846
    536c: 02 38        	cpi	r16, 0x82
    536e: 11 f4        	brne	.+4
    5370: 4c ee        	ldi	r20, 0xec
    5372: 17 d0        	rcall	.+46
    5374: 54 de        	rcall	.-856
    5376: 03 38        	cpi	r16, 0x83
    5378: 11 f4        	brne	.+4
    537a: 44 e1        	ldi	r20, 0x14
    537c: 1e d0        	rcall	.+60
    537e: 00 91 45 07  	<unknown>
    5382: 10 2f        	mov	r17, r16
    5384: 10 95        	com	r17
    5386: 18 bd        	out	0x28, r17
    5388: 71 d0        	rcall	.+226
    538a: 29 f4        	brne	.+10
    538c: 4e ee        	ldi	r20, 0xee
    538e: 52 e0        	ldi	r21, 0x2
    5390: 29 d0        	rcall	.+82
    5392: 7d d0        	rcall	.+250
    5394: 05 c0        	rjmp	.+10
    5396: 15 30        	cpi	r17, 0x5
    5398: 11 f4        	brne	.+4
    539a: 26 d0        	rcall	.+76
    539c: fa cf        	rjmp	.-12
    539e: 00 e0        	ldi	r16, 0x0
    53a0: 04 c0        	rjmp	.+8
    53a2: 5f ef        	ldi	r21, 0xff
    53a4: 25 e4        	ldi	r18, 0x45
    53a6: 37 e0        	ldi	r19, 0x7
    53a8: 0b c0        	rjmp	.+22
    53aa: a9 91        	ld	r26, Y+
    53ac: b9 91        	ld	r27, Y+
    53ae: 08 95        	ret
    53b0: ba 93        	st	-Y, r27
    53b2: aa 93        	st	-Y, r26
    53b4: a7 e0        	ldi	r26, 0x7
    53b6: b7 e0        	ldi	r27, 0x7
    53b8: d1 c2        	rjmp	.+1442
    53ba: 50 e0        	ldi	r21, 0x0
    53bc: 25 e4        	ldi	r18, 0x45
    53be: 37 e0        	ldi	r19, 0x7
    53c0: 9c 96 0d 91  	<unknown>
    53c4: 1c 91        	ld	r17, X
    53c6: 9d 97 0c 94  	<unknown>
    53ca: d2 13        	cpse	r29, r18
    53cc: 11 97 0e 94  	<unknown>
    53d0: 39 14        	cp	r3, r9
    53d2: 0f ef        	ldi	r16, 0xff
    53d4: 10 e0        	ldi	r17, 0x0
    53d6: 1a 93        	st	-Y, r17
    53d8: 1a 93        	st	-Y, r17
    53da: 1a 93        	st	-Y, r17
    53dc: 0a 93        	st	-Y, r16
    53de: 08 95        	ret
    53e0: 4d ee        	ldi	r20, 0xed
    53e2: 52 e0        	ldi	r21, 0x2
    53e4: 0c 94 a0 31  	<unknown>
    53e8: 4e ee        	ldi	r20, 0xee
    53ea: 52 e0        	ldi	r21, 0x2
    53ec: 6d df        	rcall	.-294
    53ee: 00 95        	com	r16
    53f0: 08 bd        	out	0x28, r16
    53f2: 08 95        	ret
    53f4: dd df        	rcall	.-70
    53f6: 71 f0        	breq	.+28
    53f8: 40 d0        	rcall	.+128
    53fa: 29 e0        	ldi	r18, 0x9
    53fc: 3a e0        	ldi	r19, 0xa
    53fe: e6 df        	rcall	.-52
    5400: 44 e6        	ldi	r20, 0x64
    5402: 52 d0        	rcall	.+164
    5404: 0c b7        	in	r16, 0x3c
    5406: 00 95        	com	r16
    5408: 00 93 46 07  	<unknown>
    540c: 40 91 46 07  	<unknown>
    5410: 49 d0        	rcall	.+146
    5412: 2a c0        	rjmp	.+84
    5414: 04 de        	rcall	.-1016
    5416: 02 30        	cpi	r16, 0x2
    5418: 29 f4        	brne	.+10
    541a: 4d ef        	ldi	r20, 0xfd
    541c: 5f ef        	ldi	r21, 0xff
    541e: 26 e4        	ldi	r18, 0x46
    5420: 37 e0        	ldi	r19, 0x7
    5422: ce df        	rcall	.-100
    5424: fc dd        	rcall	.-1032
    5426: 03 30        	cpi	r16, 0x3
    5428: 11 f4        	brne	.+4
    542a: 43 e0        	ldi	r20, 0x3
    542c: 2c d0        	rcall	.+88
    542e: f7 dd        	rcall	.-1042
    5430: 02 38        	cpi	r16, 0x82
    5432: 29 f4        	brne	.+10
    5434: 46 ef        	ldi	r20, 0xf6
    5436: 5f ef        	ldi	r21, 0xff
    5438: 26 e4        	ldi	r18, 0x46
    543a: 37 e0        	ldi	r19, 0x7
    543c: c1 df        	rcall	.-126
    543e: ef dd        	rcall	.-1058
    5440: 03 38        	cpi	r16, 0x83
    5442: 11 f4        	brne	.+4
    5444: 4a e0        	ldi	r20, 0xa
    5446: 1f d0        	rcall	.+62
    5448: 00 91 46 07  	<unknown>
    544c: 10 2f        	mov	r17, r16
    544e: 10 95        	com	r17
    5450: 1c bf        	out	0x3c, r17
    5452: 0c d0        	rcall	.+24
    5454: 29 f4        	brne	.+10
    5456: 4f ee        	ldi	r20, 0xef
    5458: 52 e0        	ldi	r21, 0x2
    545a: c4 df        	rcall	.-120
    545c: 18 d0        	rcall	.+48
    545e: 05 c0        	rjmp	.+10
    5460: 15 30        	cpi	r17, 0x5
    5462: 11 f4        	brne	.+4
    5464: 19 d0        	rcall	.+50
    5466: fa cf        	rjmp	.-12
    5468: 00 e0        	ldi	r16, 0x0
    546a: 9f cf        	rjmp	.-194
    546c: 9c 96 2d 91  	<unknown>
    5470: 3c 91        	ld	r19, X
    5472: 10 91 39 07  	<unknown>
    5476: 11 23        	tst	r17
    5478: 08 95        	ret
    547a: 0e 94 94 13  	<unknown>
    547e: 9c 96 0d 93  	<unknown>
    5482: 1c 93        	st	X, r17
    5484: 08 95        	ret
    5486: 50 e0        	ldi	r21, 0x0
    5488: 26 e4        	ldi	r18, 0x46
    548a: 37 e0        	ldi	r19, 0x7
    548c: 99 cf        	rjmp	.-206
    548e: 89 01 0e 94  	<unknown>
    5492: 86 13        	cpse	r24, r22
    5494: 01 e0        	ldi	r16, 0x1
    5496: 08 95        	ret
    5498: 4f ee        	ldi	r20, 0xef
    549a: 52 e0        	ldi	r21, 0x2
    549c: 15 df        	rcall	.-470
    549e: 00 95        	com	r16
    54a0: 0c bf        	out	0x3c, r16
    54a2: 08 95        	ret
    54a4: 05 d0        	rcall	.+10
    54a6: e3 c9        	rjmp	.-3130
    54a8: 03 d0        	rcall	.+6
    54aa: 11 97 0c 94  	<unknown>
    54ae: bc 13        	cpse	r27, r28
    54b0: 50 e0        	ldi	r21, 0x0
    54b2: 60 e0        	ldi	r22, 0x0
    54b4: 70 e0        	ldi	r23, 0x0
    54b6: 0d 91        	ld	r16, X+
    54b8: 1c 91        	ld	r17, X
    54ba: 08 95        	ret
    54bc: f1 de        	rcall	.-542
    54be: a3 97 8e 01  	<unknown>
    54c2: 0e 94 f2 15  	<unknown>
    54c6: 01 30        	cpi	r16, 0x1
    54c8: 09 f0        	breq	.+2
    54ca: be c1        	rjmp	.+892
    54cc: 08 81        	ldd	r16, Y+0
    54ce: e2 e4        	ldi	r30, 0x42
    54d0: fc e0        	ldi	r31, 0xc
    54d2: 0c 94 93 34  	<unknown>
    54d6: fd d1        	rcall	.+1018
    54d8: 20 e4        	ldi	r18, 0x40
    54da: 30 e0        	ldi	r19, 0x0
    54dc: 07 ec        	ldi	r16, 0xc7
    54de: 16 e0        	ldi	r17, 0x6
    54e0: b1 c1        	rjmp	.+866
    54e2: f7 d1        	rcall	.+1006
    54e4: 20 e2        	ldi	r18, 0x20
    54e6: 30 e0        	ldi	r19, 0x0
    54e8: 07 e0        	ldi	r16, 0x7
    54ea: 17 e0        	ldi	r17, 0x7
    54ec: ab c1        	rjmp	.+854
    54ee: 80 e0        	ldi	r24, 0x0
    54f0: 09 81        	ldd	r16, Y+1
    54f2: 1a 81        	ldd	r17, Y+2
    54f4: f1 d1        	rcall	.+994
    54f6: 09 83        	std	Y+1, r16
    54f8: 1a 83        	std	Y+2, r17
    54fa: 28 2f        	mov	r18, r24
    54fc: 31 d2        	rcall	.+1122
    54fe: 61 f4        	brne	.+24
    5500: 9f dd        	rcall	.-1218
    5502: 0e 94 ae 11  	<unknown>
    5506: 00 23        	tst	r16
    5508: 11 f0        	breq	.+4
    550a: 24 d2        	rcall	.+1096
    550c: 29 f4        	brne	.+10
    550e: 08 81        	ldd	r16, Y+0
    5510: 0a 37        	cpi	r16, 0x7a
    5512: 29 f4        	brne	.+10
    5514: 1f d2        	rcall	.+1086
    5516: 19 f0        	breq	.+6
    5518: 09 81        	ldd	r16, Y+1
    551a: 01 60        	ori	r16, 0x1
    551c: 09 83        	std	Y+1, r16
    551e: 83 95        	inc	r24
    5520: 8c 30        	cpi	r24, 0xc
    5522: 30 f3        	brlo	.-52
    5524: 22 e0        	ldi	r18, 0x2
    5526: 3e dc        	rcall	.-1924
    5528: 0f 5f        	subi	r16, 0xff
    552a: 1f 4f        	sbci	r17, 0xff
    552c: 8b c1        	rjmp	.+790
    552e: 22 e0        	ldi	r18, 0x2
    5530: 86 c1        	rjmp	.+780
    5532: f8 94        	cli
    5534: 72 dd        	rcall	.-1308
    5536: 05 e4        	ldi	r16, 0x45
    5538: cd d1        	rcall	.+922
    553a: 02 e0        	ldi	r16, 0x2
    553c: 0a bb        	out	0x1a, r16
    553e: 10 e0        	ldi	r17, 0x0
    5540: 04 e0        	ldi	r16, 0x4
    5542: d4 de        	rcall	.-600
    5544: 04 ee        	ldi	r16, 0xe4
    5546: 1a e0        	ldi	r17, 0xa
    5548: cc de        	rcall	.-616
    554a: 05 e0        	ldi	r16, 0x5
    554c: cf de        	rcall	.-610
    554e: 0d ee        	ldi	r16, 0xed
    5550: 1a e0        	ldi	r17, 0xa
    5552: e1 dc        	rcall	.-1598
    5554: 0c 94 00 38  	<unknown>
    5558: 77 c1        	rjmp	.+750
    555a: 06 e5        	ldi	r16, 0x56
    555c: bb d1        	rcall	.+886
    555e: 8e d1        	rcall	.+796
    5560: b9 d1        	rcall	.+882
    5562: 80 e0        	ldi	r24, 0x0
    5564: 90 e0        	ldi	r25, 0x0
    5566: 8a d1        	rcall	.+788
    5568: 80 17        	cp	r24, r16
    556a: 91 07        	cpc	r25, r17
    556c: 08 f0        	brlo	.+2
    556e: 6c c1        	rjmp	.+728
    5570: fc 01 ed 52  	<unknown>
    5574: f5 4f        	sbci	r31, 0xf5
    5576: 04 91 ad d1  	<unknown>
    557a: 83 95        	inc	r24
    557c: f3 cf        	rjmp	.-26
    557e: 03 e6        	ldi	r16, 0x63
    5580: 8d d1        	rcall	.+794
    5582: 60 c1        	rjmp	.+704
    5584: 04 e5        	ldi	r16, 0x54
    5586: 8a d1        	rcall	.+788
    5588: c6 d1        	rcall	.+908
    558a: 38 e0        	ldi	r19, 0x8
    558c: 20 e0        	ldi	r18, 0x0
    558e: 07 e2        	ldi	r16, 0x27
    5590: 17 e0        	ldi	r17, 0x7
    5592: 2a dc        	rcall	.-1964
    5594: 59 c1        	rjmp	.+690
    5596: 0c e4        	ldi	r16, 0x4c
    5598: 9d d1        	rcall	.+826
    559a: 80 e0        	ldi	r24, 0x0
    559c: 48 2f        	mov	r20, r24
    559e: c2 d1        	rcall	.+900
    55a0: ac e4        	ldi	r26, 0x4c
    55a2: b0 e0        	ldi	r27, 0x0
    55a4: a0 0f        	add	r26, r16
    55a6: b1 1f        	adc	r27, r17
    55a8: ad 01 4a 5f  	<unknown>
    55ac: a8 d1        	rcall	.+848
    55ae: a4 d1        	rcall	.+840
    55b0: 4f 5f        	subi	r20, 0xff
    55b2: a1 d1        	rcall	.+834
    55b4: 4b 5f        	subi	r20, 0xfb
    55b6: a3 d1        	rcall	.+838
    55b8: 49 5f        	subi	r20, 0xf9
    55ba: 9d d1        	rcall	.+826
    55bc: 48 5f        	subi	r20, 0xf8
    55be: 9b d1        	rcall	.+822
    55c0: 47 5f        	subi	r20, 0xf7
    55c2: 9d d1        	rcall	.+826
    55c4: 46 5f        	subi	r20, 0xf6
    55c6: 9b d1        	rcall	.+822
    55c8: 7d de        	rcall	.-774
    55ca: 73 d1        	rcall	.+742
    55cc: 7b de        	rcall	.-778
    55ce: 02 95        	swap	r16
    55d0: 70 d1        	rcall	.+736
    55d2: 4d 5f        	subi	r20, 0xfd
    55d4: 99 d1        	rcall	.+818
    55d6: 4e 5f        	subi	r20, 0xfe
    55d8: 97 d1        	rcall	.+814
    55da: 44 5f        	subi	r20, 0xf4
    55dc: 95 d1        	rcall	.+810
    55de: 45 5f        	subi	r20, 0xf5
    55e0: 72 de        	rcall	.-796
    55e2: 78 d1        	rcall	.+752
    55e4: 6f d1        	rcall	.+734
    55e6: 8d 01 03 5f  	<unknown>
    55ea: 1f 4f        	sbci	r17, 0xff
    55ec: 3b d1        	rcall	.+630
    55ee: 6a d1        	rcall	.+724
    55f0: 8d 01 01 5f  	<unknown>
    55f4: 59 d1        	rcall	.+690
    55f6: 7a d1        	rcall	.+756
    55f8: ad 01 4f 5f  	<unknown>
    55fc: 5f 4f        	sbci	r21, 0xff
    55fe: 76 d1        	rcall	.+748
    5600: 24 e0        	ldi	r18, 0x4
    5602: 30 e0        	ldi	r19, 0x0
    5604: 8d 01 0f 5e  	<unknown>
    5608: 4f d1        	rcall	.+670
    560a: 4e 5f        	subi	r20, 0xfe
    560c: 86 d1        	rcall	.+780
    560e: 4d 5f        	subi	r20, 0xfd
    5610: 84 d1        	rcall	.+776
    5612: 4a 5f        	subi	r20, 0xfa
    5614: 58 de        	rcall	.-848
    5616: 10 2f        	mov	r17, r16
    5618: 10 72        	andi	r17, 0x20
    561a: 16 95        	lsr	r17
    561c: 16 95        	lsr	r17
    561e: 16 95        	lsr	r17
    5620: ad 01 44 5f  	<unknown>
    5624: 50 de        	rcall	.-864
    5626: 24 e0        	ldi	r18, 0x4
    5628: 02 9f 02 e0  	<unknown>
    562c: 10 22        	and	r1, r16
    562e: 11 29        	or	r17, r1
    5630: 15 96 ad 01  	<unknown>
    5634: 49 de        	rcall	.-878
    5636: 00 72        	andi	r16, 0x20
    5638: 02 95        	swap	r16
    563a: 06 95        	lsr	r16
    563c: 01 2b        	or	r16, r17
    563e: 4a d1        	rcall	.+660
    5640: 83 95        	inc	r24
    5642: 80 32        	cpi	r24, 0x20
    5644: 08 f0        	brlo	.+2
    5646: 00 c1        	rjmp	.+512
    5648: a9 cf        	rjmp	.-174
    564a: 07 e5        	ldi	r16, 0x57
    564c: 43 d1        	rcall	.+646
    564e: 2c e1        	ldi	r18, 0x1c
    5650: 5e d1        	rcall	.+700
    5652: 49 81        	ldd	r20, Y+1
    5654: 67 d1        	rcall	.+718
    5656: 6c e4        	ldi	r22, 0x4c
    5658: 70 e0        	ldi	r23, 0x0
    565a: 0d de        	rcall	.-998
    565c: ab 01 4a 5f  	<unknown>
    5660: 42 d1        	rcall	.+644
    5662: 1a 81        	ldd	r17, Y+2
    5664: 01 d1        	rcall	.+514
    5666: 4a 5f        	subi	r20, 0xfa
    5668: 64 d1        	rcall	.+712
    566a: 3a d1        	rcall	.+628
    566c: 1b 81        	ldd	r17, Y+3
    566e: 1f 73        	andi	r17, 0x3f
    5670: 01 2b        	or	r16, r17
    5672: 6b d1        	rcall	.+726
    5674: 00 7c        	andi	r16, 0xc0
    5676: 1c 81        	ldd	r17, Y+4
    5678: 1f 73        	andi	r17, 0x3f
    567a: f7 d0        	rcall	.+494
    567c: 4f 5f        	subi	r20, 0xff
    567e: 62 d1        	rcall	.+708
    5680: 00 7e        	andi	r16, 0xe0
    5682: 1d 81        	ldd	r17, Y+5
    5684: f1 d0        	rcall	.+482
    5686: 4b 5f        	subi	r20, 0xfb
    5688: 54 d1        	rcall	.+680
    568a: 49 5f        	subi	r20, 0xf9
    568c: 28 d1        	rcall	.+592
    568e: 1e 81        	ldd	r17, Y+6
    5690: 1f 73        	andi	r17, 0x3f
    5692: eb d0        	rcall	.+470
    5694: 49 5f        	subi	r20, 0xf9
    5696: 4d d1        	rcall	.+666
    5698: 48 5f        	subi	r20, 0xf8
    569a: 21 d1        	rcall	.+578
    569c: 1f 81        	ldd	r17, Y+7
    569e: 1f 73        	andi	r17, 0x3f
    56a0: e4 d0        	rcall	.+456
    56a2: 48 5f        	subi	r20, 0xf8
    56a4: 46 d1        	rcall	.+652
    56a6: 47 5f        	subi	r20, 0xf7
    56a8: 1e d1        	rcall	.+572
    56aa: 18 85        	ldd	r17, Y+0
    56ac: dd d0        	rcall	.+442
    56ae: 47 5f        	subi	r20, 0xf7
    56b0: 40 d1        	rcall	.+640
    56b2: 46 5f        	subi	r20, 0xf6
    56b4: 18 d1        	rcall	.+560
    56b6: 19 85        	ldd	r17, Y+1
    56b8: d7 d0        	rcall	.+430
    56ba: 46 5f        	subi	r20, 0xf6
    56bc: 5f 4f        	sbci	r21, 0xff
    56be: 92 de        	rcall	.-732
    56c0: 0a 85        	ldd	r16, Y+2
    56c2: 0f 70        	andi	r16, 0xf
    56c4: 1b 85        	ldd	r17, Y+3
    56c6: 12 95        	swap	r17
    56c8: 10 7f        	andi	r17, 0xf0
    56ca: cf d0        	rcall	.+414
    56cc: 4c 5f        	subi	r20, 0xfc
    56ce: 37 d1        	rcall	.+622
    56d0: 00 78        	andi	r16, 0x80
    56d2: 1c 85        	ldd	r17, Y+4
    56d4: 1f 77        	andi	r17, 0x7f
    56d6: c9 d0        	rcall	.+402
    56d8: 4d 5f        	subi	r20, 0xfd
    56da: 2b d1        	rcall	.+598
    56dc: 4e 5f        	subi	r20, 0xfe
    56de: f3 dd        	rcall	.-1050
    56e0: 00 78        	andi	r16, 0x80
    56e2: 1d 85        	ldd	r17, Y+5
    56e4: 1f 77        	andi	r17, 0x7f
    56e6: c1 d0        	rcall	.+386
    56e8: 4e 5f        	subi	r20, 0xfe
    56ea: 26 d1        	rcall	.+588
    56ec: 00 78        	andi	r16, 0x80
    56ee: 1e 85        	ldd	r17, Y+6
    56f0: 1f 77        	andi	r17, 0x7f
    56f2: bb d0        	rcall	.+374
    56f4: 44 5f        	subi	r20, 0xf4
    56f6: 5f 4f        	sbci	r21, 0xff
    56f8: 75 de        	rcall	.-790
    56fa: 0f 85        	ldd	r16, Y+7
    56fc: ab 01 45 5f  	<unknown>
    5700: 5f 4f        	sbci	r21, 0xff
    5702: 70 de        	rcall	.-800
    5704: 08 89        	ldd	r16, Y+0
    5706: 19 89        	ldd	r17, Y+1
    5708: ab 01 43 5f  	<unknown>
    570c: d4 d0        	rcall	.+424
    570e: 0a 89        	ldd	r16, Y+2
    5710: 1b 89        	ldd	r17, Y+3
    5712: ab 01 41 5f  	<unknown>
    5716: cf d0        	rcall	.+414
    5718: ab 01 d6 dd  	<unknown>
    571c: 0f 73        	andi	r16, 0x3f
    571e: 1c 89        	ldd	r17, Y+4
    5720: 20 e4        	ldi	r18, 0x40
    5722: 12 9f 00 29  	<unknown>
    5726: 11 d1        	rcall	.+546
    5728: 0f 73        	andi	r16, 0x3f
    572a: 1d 89        	ldd	r17, Y+5
    572c: 12 9f 00 29  	<unknown>
    5730: ab 01 4f 5f  	<unknown>
    5734: 5f 4f        	sbci	r21, 0xff
    5736: 56 de        	rcall	.-852
    5738: 0e 89        	ldd	r16, Y+6
    573a: 1f 89        	ldd	r17, Y+7
    573c: 28 8d        	ldd	r18, Y+0
    573e: 39 8d        	ldd	r19, Y+1
    5740: ab 01 4f 5e  	<unknown>
    5744: 5f 4f        	sbci	r21, 0xff
    5746: 0e 94 ab 31  	<unknown>
    574a: ab 01 4e 5f  	<unknown>
    574e: bb dd        	rcall	.-1162
    5750: 0f 77        	andi	r16, 0x7f
    5752: 1a 8d        	ldd	r17, Y+2
    5754: ea d0        	rcall	.+468
    5756: 4e 5f        	subi	r20, 0xfe
    5758: f2 d0        	rcall	.+484
    575a: 0f 77        	andi	r16, 0x7f
    575c: 1b 8d        	ldd	r17, Y+3
    575e: e5 d0        	rcall	.+458
    5760: 4d 5f        	subi	r20, 0xfd
    5762: f0 d0        	rcall	.+480
    5764: 0f 7d        	andi	r16, 0xdf
    5766: 1c 8d        	ldd	r17, Y+4
    5768: 10 fb        	bst	r17, 0x0
    576a: 10 e0        	ldi	r17, 0x0
    576c: 15 f9        	bld	r17, 0x5
    576e: 7d d0        	rcall	.+250
    5770: 4b 5f        	subi	r20, 0xfb
    5772: e2 d0        	rcall	.+452
    5774: 0f 77        	andi	r16, 0x7f
    5776: 1c 8d        	ldd	r17, Y+4
    5778: 11 fb        	bst	r17, 0x1
    577a: d8 d0        	rcall	.+432
    577c: 44 5f        	subi	r20, 0xf4
    577e: d9 d0        	rcall	.+434
    5780: 4a 5f        	subi	r20, 0xfa
    5782: a1 dd        	rcall	.-1214
    5784: 0f 7d        	andi	r16, 0xdf
    5786: 1c 8d        	ldd	r17, Y+4
    5788: 12 fb        	bst	r17, 0x2
    578a: 10 e0        	ldi	r17, 0x0
    578c: 15 f9        	bld	r17, 0x5
    578e: 01 2b        	or	r16, r17
    5790: 6a 5f        	subi	r22, 0xfa
    5792: 7f 4f        	sbci	r23, 0xff
    5794: ab 01 26 de  	<unknown>
    5798: 57 c0        	rjmp	.+174
    579a: 04 e4        	ldi	r16, 0x44
    579c: 9b d0        	rcall	.+310
    579e: 20 e0        	ldi	r18, 0x0
    57a0: 31 e0        	ldi	r19, 0x1
    57a2: 00 ef        	ldi	r16, 0xf0
    57a4: 12 e0        	ldi	r17, 0x2
    57a6: 5e d0        	rcall	.+188
    57a8: 4f c0        	rjmp	.+158
    57aa: 04 e6        	ldi	r16, 0x64
    57ac: 93 d0        	rcall	.+294
    57ae: 00 91 8e 06  	<unknown>
    57b2: 90 d0        	rcall	.+288
    57b4: 00 e0        	ldi	r16, 0x0
    57b6: 00 93 8e 06  	<unknown>
    57ba: 46 c0        	rjmp	.+140
    57bc: 08 e4        	ldi	r16, 0x48
    57be: 8a d0        	rcall	.+276
    57c0: 22 e2        	ldi	r18, 0x22
    57c2: a5 d0        	rcall	.+330
    57c4: 55 d0        	rcall	.+170
    57c6: e5 ce        	rjmp	.-566
    57c8: 08 e6        	ldi	r16, 0x68
    57ca: 84 d0        	rcall	.+264
    57cc: 51 d0        	rcall	.+162
    57ce: a1 d8        	rcall	.-3774
    57d0: 22 e2        	ldi	r18, 0x22
    57d2: a9 ce        	rjmp	.-686
    57d4: 09 e4        	ldi	r16, 0x49
    57d6: 5c d0        	rcall	.+184
    57d8: 43 d0        	rcall	.+134
    57da: 77 d0        	rcall	.+238
    57dc: 41 d0        	rcall	.+130
    57de: 6e d0        	rcall	.+220
    57e0: 3f d0        	rcall	.+126
    57e2: 39 d0        	rcall	.+114
    57e4: 3d d0        	rcall	.+122
    57e6: 30 c0        	rjmp	.+96
    57e8: 09 e6        	ldi	r16, 0x69
    57ea: 52 d0        	rcall	.+164
    57ec: 3b d0        	rcall	.+118
    57ee: 6d d0        	rcall	.+218
    57f0: 39 d0        	rcall	.+114
    57f2: 64 d0        	rcall	.+200
    57f4: 37 d0        	rcall	.+110
    57f6: 2f d0        	rcall	.+94
    57f8: d6 cf        	rjmp	.-84
    57fa: 01 e4        	ldi	r16, 0x41
    57fc: 43 d0        	rcall	.+134
    57fe: 30 d0        	rcall	.+96
    5800: 25 d0        	rcall	.+74
    5802: f0 cf        	rjmp	.-32
    5804: 01 e6        	ldi	r16, 0x61
    5806: 3e d0        	rcall	.+124
    5808: 2d d0        	rcall	.+90
    580a: 20 d0        	rcall	.+64
    580c: cc cf        	rjmp	.-104
    580e: 0b e4        	ldi	r16, 0x4b
    5810: 61 d0        	rcall	.+194
    5812: 21 e0        	ldi	r18, 0x1
    5814: 30 e0        	ldi	r19, 0x0
    5816: 09 e3        	ldi	r16, 0x39
    5818: 17 e0        	ldi	r17, 0x7
    581a: 7d d0        	rcall	.+250
    581c: 15 c0        	rjmp	.+42
    581e: 03 e5        	ldi	r16, 0x53
    5820: 59 d0        	rcall	.+178
    5822: 0e 94 93 0f  	<unknown>
    5826: c8 01 20 e6  	<unknown>
    582a: 30 e0        	ldi	r19, 0x0
    582c: 0e 94 1b 16  	<unknown>
    5830: 8c 01 0e 94  	<unknown>
    5834: 76 31        	cpi	r23, 0x16
    5836: 08 c0        	rjmp	.+16
    5838: 03 e7        	ldi	r16, 0x73
    583a: 4c d0        	rcall	.+152
    583c: 28 e0        	ldi	r18, 0x8
    583e: 30 e0        	ldi	r19, 0x0
    5840: 03 e7        	ldi	r16, 0x73
    5842: 16 e0        	ldi	r17, 0x6
    5844: 0e 94 1b 16  	<unknown>
    5848: a3 96 de cb  	<unknown>
    584c: 28 e1        	ldi	r18, 0x18
    584e: 30 e0        	ldi	r19, 0x0
    5850: 0d e2        	ldi	r16, 0x2d
    5852: 10 e0        	ldi	r17, 0x0
    5854: 08 95        	ret
    5856: 27 e0        	ldi	r18, 0x7
    5858: 30 e0        	ldi	r19, 0x0
    585a: 05 e4        	ldi	r16, 0x45
    585c: 10 e0        	ldi	r17, 0x0
    585e: 08 95        	ret
    5860: 0c 94 2e 16  	<unknown>
    5864: 0c 94 04 16  	<unknown>
    5868: 1f 71        	andi	r17, 0x1f
    586a: 01 2b        	or	r16, r17
    586c: ab 01 08 95  	<unknown>
    5870: 32 e2        	ldi	r19, 0x22
    5872: 28 e0        	ldi	r18, 0x8
    5874: 8e 01 0f 5f  	<unknown>
    5878: 1f 4f        	sbci	r17, 0xff
    587a: 08 95        	ret
    587c: e3 ed        	ldi	r30, 0xd3
    587e: fa e0        	ldi	r31, 0xa
    5880: 0c 94 da 35  	<unknown>
    5884: 27 d0        	rcall	.+78
    5886: 28 e1        	ldi	r18, 0x18
    5888: 30 e0        	ldi	r19, 0x0
    588a: 05 e1        	ldi	r16, 0x15
    588c: 10 e0        	ldi	r17, 0x0
    588e: 08 95        	ret
    5890: 21 d0        	rcall	.+66
    5892: 20 e1        	ldi	r18, 0x10
    5894: 30 e0        	ldi	r19, 0x0
    5896: 00 e0        	ldi	r16, 0x0
    5898: 10 e0        	ldi	r17, 0x0
    589a: 08 95        	ret
    589c: 1b d0        	rcall	.+54
    589e: 28 e0        	ldi	r18, 0x8
    58a0: 30 e0        	ldi	r19, 0x0
    58a2: 07 e2        	ldi	r16, 0x27
    58a4: 17 e0        	ldi	r17, 0x7
    58a6: 08 95        	ret
    58a8: 1f 4f        	sbci	r17, 0xff
    58aa: 0e 94 04 16  	<unknown>
    58ae: ad 01 08 95  	<unknown>
    58b2: 0f 70        	andi	r16, 0xf
    58b4: 26 c0        	rjmp	.+76
    58b6: 5f 4f        	sbci	r21, 0xff
    58b8: 0c 94 a4 31  	<unknown>
    58bc: 03 d0        	rcall	.+6
    58be: 02 e1        	ldi	r16, 0x12
    58c0: 10 e0        	ldi	r17, 0x0
    58c2: 08 95        	ret
    58c4: 22 e0        	ldi	r18, 0x2
    58c6: 0c 94 5e 24  	<unknown>
    58ca: fc df        	rcall	.-8
    58cc: 00 e1        	ldi	r16, 0x10
    58ce: 10 e0        	ldi	r17, 0x0
    58d0: 08 95        	ret
    58d2: 00 e2        	ldi	r16, 0x20
    58d4: 0c 94 ee 15  	<unknown>
    58d8: 00 0f        	lsl	r16
    58da: 11 1f        	rol	r17
    58dc: 08 95        	ret
    58de: 5f 4f        	sbci	r21, 0xff
    58e0: f3 dc        	rcall	.-1562
    58e2: 00 7c        	andi	r16, 0xc0
    58e4: 08 95        	ret
    58e6: ef dc        	rcall	.-1570
    58e8: 00 7e        	andi	r16, 0xe0
    58ea: 08 95        	ret
    58ec: ed dc        	rcall	.-1574
    58ee: 14 e0        	ldi	r17, 0x4
    58f0: 01 9f 01 2d  	<unknown>
    58f4: ef cf        	rjmp	.-34
    58f6: 5f 4f        	sbci	r21, 0xff
    58f8: e7 dc        	rcall	.-1586
    58fa: 0f 73        	andi	r16, 0x3f
    58fc: 02 c0        	rjmp	.+4
    58fe: e3 dc        	rcall	.-1594
    5900: 0f 71        	andi	r16, 0x1f
    5902: 0e 94 ee 15  	<unknown>
    5906: d3 cf        	rjmp	.-90
    5908: de dc        	rcall	.-1604
    590a: 0f 77        	andi	r16, 0x7f
    590c: fa cf        	rjmp	.-12
    590e: 30 e0        	ldi	r19, 0x0
    5910: 8e 01 0f 5f  	<unknown>
    5914: 1f 4f        	sbci	r17, 0xff
    5916: 0c 94 48 16  	<unknown>
    591a: d5 dc        	rcall	.-1622
    591c: 00 0f        	lsl	r16
    591e: 00 e0        	ldi	r16, 0x0
    5920: 00 1f        	rol	r16
    5922: ef cf        	rjmp	.-34
    5924: 50 e0        	ldi	r21, 0x0
    5926: 05 e1        	ldi	r16, 0x15
    5928: 55 ca        	rjmp	.-2902
    592a: 10 fb        	bst	r17, 0x0
    592c: 10 e0        	ldi	r17, 0x0
    592e: 17 f9        	bld	r17, 0x7
    5930: 9c cf        	rjmp	.-200
    5932: 5f 4f        	sbci	r21, 0xff
    5934: 57 dd        	rcall	.-1362
    5936: 9a cf        	rjmp	.-204
    5938: fc df        	rcall	.-8
    593a: 44 5f        	subi	r20, 0xf4
    593c: c4 cc        	rjmp	.-1656
    593e: f9 df        	rcall	.-14
    5940: 4d 5f        	subi	r20, 0xfd
    5942: c1 cc        	rjmp	.-1662
    5944: f6 df        	rcall	.-20
    5946: 4b 5f        	subi	r20, 0xfb
    5948: be cc        	rjmp	.-1668
    594a: ab 01 4b dd  	<unknown>
    594e: ab 01 4f 5f  	<unknown>
    5952: b9 cc        	rjmp	.-1678
    5954: 28 2f        	mov	r18, r24
    5956: 74 db        	rcall	.-2328
    5958: 0e 94 41 12  	<unknown>
    595c: 00 23        	tst	r16
    595e: 08 95        	ret
    5960: 6f db        	rcall	.-2338
    5962: 0e 94 b1 11  	<unknown>
    5966: fa cf        	rjmp	.-12
    5968: 8a 93        	st	-Y, r24
    596a: fa 93        	st	-Y, r31
    596c: ea 93        	st	-Y, r30
    596e: 3a 92        	st	-Y, r3
    5970: 2a 92        	st	-Y, r2
    5972: 1a 92        	st	-Y, r1
    5974: 0a 92        	st	-Y, r0
    5976: 7a 93        	st	-Y, r23
    5978: 6a 93        	st	-Y, r22
    597a: 5a 93        	st	-Y, r21
    597c: 4a 93        	st	-Y, r20
    597e: 33 d0        	rcall	.+102
    5980: 8f b7        	in	r24, 0x3f
    5982: 01 e0        	ldi	r16, 0x1
    5984: 00 93 35 07  	<unknown>
    5988: 82 9b        	sbis	0x10, 0x2
    598a: 0a c0        	rjmp	.+20
    598c: 00 91 3b 07  	<unknown>
    5990: 03 95        	inc	r16
    5992: 2d d0        	rcall	.+90
    5994: 01 e0        	ldi	r16, 0x1
    5996: 00 93 36 07  	<unknown>
    599a: 52 db        	rcall	.-2396
    599c: 0e 94 84 12  	<unknown>
    59a0: 00 91 37 07  	<unknown>
    59a4: 01 30        	cpi	r16, 0x1
    59a6: 49 f4        	brne	.+18
    59a8: 82 9b        	sbis	0x10, 0x2
    59aa: 02 c0        	rjmp	.+4
    59ac: 8c 98        	cbi	0x11, 0x4
    59ae: 0a c0        	rjmp	.+20
    59b0: 8c 9a        	sbi	0x11, 0x4
    59b2: 05 e0        	ldi	r16, 0x5
    59b4: 0e 94 f8 0f  	<unknown>
    59b8: 05 c0        	rjmp	.+10
    59ba: f8 94        	cli
    59bc: 1b d0        	rcall	.+54
    59be: 09 f0        	breq	.+2
    59c0: 8c 9a        	sbi	0x11, 0x4
    59c2: 78 94        	sei
    59c4: 8f bf        	out	0x3f, r24
    59c6: 09 91        	ld	r16, Y+
    59c8: 19 91        	ld	r17, Y+
    59ca: 29 91        	ld	r18, Y+
    59cc: 39 91        	ld	r19, Y+
    59ce: 49 91        	ld	r20, Y+
    59d0: 59 91        	ld	r21, Y+
    59d2: 69 91        	ld	r22, Y+
    59d4: 79 91        	ld	r23, Y+
    59d6: 09 90        	ld	r0, Y+
    59d8: 19 90        	ld	r1, Y+
    59da: 29 90        	ld	r2, Y+
    59dc: 39 90        	ld	r3, Y+
    59de: e9 91        	ld	r30, Y+
    59e0: f9 91        	ld	r31, Y+
    59e2: 89 91        	ld	r24, Y+
    59e4: 18 95        	reti
    59e6: 3a 93        	st	-Y, r19
    59e8: 2a 93        	st	-Y, r18
    59ea: f7 cc        	rjmp	.-1554
    59ec: 00 e0        	ldi	r16, 0x0
    59ee: 00 93 3b 07  	<unknown>
    59f2: 08 95        	ret
    59f4: 4d ee        	ldi	r20, 0xed
    59f6: 52 e0        	ldi	r21, 0x2
    59f8: 67 dc        	rcall	.-1842
    59fa: b0 cf        	rjmp	.-160
    59fc: 80 2f        	mov	r24, r16
    59fe: 91 2f        	mov	r25, r17
    5a00: 0e 94 36 31  	<unknown>
    5a04: 08 2f        	mov	r16, r24
    5a06: 19 2f        	mov	r17, r25
    5a08: 0c 94 d6 36  	<unknown>
    5a0c: 0e 94 e3 34  	<unknown>
    5a10: d9 d3        	rcall	.+1970
    5a12: 7a 01 5b 01  	<unknown>
    5a16: 6b 01 88 24  	<unknown>
    5a1a: 99 24        	clr	r9
    5a1c: 50 d1        	rcall	.+672
    5a1e: 57 d1        	rcall	.+686
    5a20: 20 f1        	brlo	.+72
    5a22: 60 e0        	ldi	r22, 0x0
    5a24: 70 e0        	ldi	r23, 0x0
    5a26: 0e 94 60 34  	<unknown>
    5a2a: c1 f5        	brne	.+112
    5a2c: 09 89        	ldd	r16, Y+1
    5a2e: 00 23        	tst	r16
    5a30: 09 f4        	brne	.+2
    5a32: 47 c0        	rjmp	.+142
    5a34: 8e 14        	cp	r8, r14
    5a36: 9f 04        	cpc	r9, r15
    5a38: 4c f4        	brge	.+18
    5a3a: 0c ef        	ldi	r16, 0xfc
    5a3c: 80 16        	cp	r8, r16
    5a3e: 0f ef        	ldi	r16, 0xff
    5a40: 90 06        	cpc	r9, r16
    5a42: 24 f0        	brlt	.+8
    5a44: 00 e0        	ldi	r16, 0x0
    5a46: 08 8b        	std	Y+0, r16
    5a48: e8 18        	sub	r14, r8
    5a4a: f9 08        	sbc	r15, r9
    5a4c: ae d3        	rcall	.+1884
    5a4e: 0a 89        	ldd	r16, Y+2
    5a50: 00 23        	tst	r16
    5a52: a9 f1        	breq	.+106
    5a54: 00 e0        	ldi	r16, 0x0
    5a56: 09 8b        	std	Y+1, r16
    5a58: 34 c0        	rjmp	.+104
    5a5a: 2c d1        	rcall	.+600
    5a5c: 0e 94 e1 33  	<unknown>
    5a60: b1 d3        	rcall	.+1890
    5a62: 0a e0        	ldi	r16, 0xa
    5a64: 80 0e        	add	r8, r16
    5a66: 00 e0        	ldi	r16, 0x0
    5a68: 90 1e        	adc	r9, r16
    5a6a: 47 eb        	ldi	r20, 0xb7
    5a6c: 53 e4        	ldi	r21, 0x43
    5a6e: 6a eb        	ldi	r22, 0xba
    5a70: 71 e5        	ldi	r23, 0x51
    5a72: 2c d1        	rcall	.+600
    5a74: 90 f3        	brlo	.-28
    5a76: 27 d1        	rcall	.+590
    5a78: 60 e2        	ldi	r22, 0x20
    5a7a: 71 e4        	ldi	r23, 0x41
    5a7c: 27 d1        	rcall	.+590
    5a7e: b0 f6        	brsh	.-84
    5a80: 0e 94 e1 33  	<unknown>
    5a84: 9f d3        	rcall	.+1854
    5a86: 01 e0        	ldi	r16, 0x1
    5a88: 80 0e        	add	r8, r16
    5a8a: 00 e0        	ldi	r16, 0x0
    5a8c: 90 1e        	adc	r9, r16
    5a8e: f3 cf        	rjmp	.-26
    5a90: 11 d1        	rcall	.+546
    5a92: 96 d3        	rcall	.+1836
    5a94: 06 ef        	ldi	r16, 0xf6
    5a96: 80 0e        	add	r8, r16
    5a98: 0f ef        	ldi	r16, 0xff
    5a9a: 90 1e        	adc	r9, r16
    5a9c: 40 e0        	ldi	r20, 0x0
    5a9e: 57 ee        	ldi	r21, 0xe7
    5aa0: 6b ed        	ldi	r22, 0xdb
    5aa2: 7e e2        	ldi	r23, 0x2e
    5aa4: 04 d1        	rcall	.+520
    5aa6: a0 f3        	brlo	.-24
    5aa8: 0a d1        	rcall	.+532
    5aaa: 01 d1        	rcall	.+514
    5aac: 08 f0        	brlo	.+2
    5aae: be cf        	rjmp	.-132
    5ab0: 60 e2        	ldi	r22, 0x20
    5ab2: 71 e4        	ldi	r23, 0x41
    5ab4: 85 d3        	rcall	.+1802
    5ab6: 0f ef        	ldi	r16, 0xff
    5ab8: 80 0e        	add	r8, r16
    5aba: 90 1e        	adc	r9, r16
    5abc: f5 cf        	rjmp	.-22
    5abe: 01 e0        	ldi	r16, 0x1
    5ac0: 0a 8b        	std	Y+2, r16
    5ac2: 08 89        	ldd	r16, Y+0
    5ac4: 00 23        	tst	r16
    5ac6: 19 f0        	breq	.+6
    5ac8: 66 24        	clr	r6
    5aca: 77 24        	clr	r7
    5acc: 42 c0        	rjmp	.+132
    5ace: 99 20        	tst	r9
    5ad0: da f4        	brpl	.+54
    5ad2: e8 d0        	rcall	.+464
    5ad4: 27 01 dd d0  	<unknown>
    5ad8: 66 24        	clr	r6
    5ada: 77 24        	clr	r7
    5adc: 02 c0        	rjmp	.+4
    5ade: e2 d0        	rcall	.+452
    5ae0: 64 d3        	rcall	.+1736
    5ae2: 67 d3        	rcall	.+1742
    5ae4: 86 14        	cp	r8, r6
    5ae6: 97 04        	cpc	r9, r7
    5ae8: 1c f4        	brge	.+6
    5aea: 0e 2d        	mov	r16, r14
    5aec: 0f 29        	or	r16, r15
    5aee: b9 f7        	brne	.-18
    5af0: 0f ef        	ldi	r16, 0xff
    5af2: 1f ef        	ldi	r17, 0xff
    5af4: 04 19        	sub	r16, r4
    5af6: 15 09        	sbc	r17, r5
    5af8: 80 16        	cp	r8, r16
    5afa: 91 06        	cpc	r9, r17
    5afc: 0c f4        	brge	.+2
    5afe: 73 c0        	rjmp	.+230
    5b00: 77 24        	clr	r7
    5b02: 66 24        	clr	r6
    5b04: 63 94        	inc	r6
    5b06: 25 c0        	rjmp	.+74
    5b08: 34 01 71 94  	<unknown>
    5b0c: 61 94        	neg	r6
    5b0e: 00 e0        	ldi	r16, 0x0
    5b10: 70 0a        	sbc	r7, r16
    5b12: 1f c0        	rjmp	.+62
    5b14: de d0        	rcall	.+444
    5b16: 0e 94 b5 32  	<unknown>
    5b1a: 40 2e        	mov	r4, r16
    5b1c: 21 2f        	mov	r18, r17
    5b1e: 22 0f        	lsl	r18
    5b20: 22 0b        	sbc	r18, r18
    5b22: 32 2f        	mov	r19, r18
    5b24: 0e 94 a8 32  	<unknown>
    5b28: a8 01 b9 01  	<unknown>
    5b2c: d2 d0        	rcall	.+420
    5b2e: 0e 94 4b 33  	<unknown>
    5b32: a8 01 b9 01  	<unknown>
    5b36: 00 e0        	ldi	r16, 0x0
    5b38: 10 e0        	ldi	r17, 0x0
    5b3a: 20 e2        	ldi	r18, 0x20
    5b3c: 31 e4        	ldi	r19, 0x41
    5b3e: 40 d3        	rcall	.+1664
    5b40: 04 2d        	mov	r16, r4
    5b42: 00 5d        	subi	r16, 0xd0
    5b44: b0 d0        	rcall	.+352
    5b46: 93 01 01 e0  	<unknown>
    5b4a: 15 d3        	rcall	.+1578
    5b4c: 23 2b        	or	r18, r19
    5b4e: 09 f4        	brne	.+2
    5b50: a0 d0        	rcall	.+320
    5b52: e6 14        	cp	r14, r6
    5b54: f7 04        	cpc	r15, r7
    5b56: f4 f6        	brge	.-68
    5b58: b6 d0        	rcall	.+364
    5b5a: 60 ea        	ldi	r22, 0xa0
    5b5c: 70 e4        	ldi	r23, 0x40
    5b5e: b6 d0        	rcall	.+364
    5b60: 08 f0        	brlo	.+2
    5b62: 41 c0        	rjmp	.+130
    5b64: 44 24        	clr	r4
    5b66: 43 94        	inc	r4
    5b68: c6 01 01 97  	<unknown>
    5b6c: fc 01 00 81  	<unknown>
    5b70: 0e 32        	cpi	r16, 0x2e
    5b72: 51 f0        	breq	.+20
    5b74: 04 0d        	add	r16, r4
    5b76: 00 83        	std	Z+0, r16
    5b78: 0a 33        	cpi	r16, 0x3a
    5b7a: 29 f4        	brne	.+10
    5b7c: 00 e3        	ldi	r16, 0x30
    5b7e: 00 83        	std	Z+0, r16
    5b80: 44 24        	clr	r4
    5b82: 43 94        	inc	r4
    5b84: 01 c0        	rjmp	.+2
    5b86: 44 24        	clr	r4
    5b88: 01 97 ae 16  	<unknown>
    5b8c: bf 06        	cpc	r11, r31
    5b8e: 70 f3        	brlo	.-36
    5b90: 44 20        	tst	r4
    5b92: 49 f1        	breq	.+82
    5b94: 08 89        	ldd	r16, Y+0
    5b96: 00 23        	tst	r16
    5b98: b1 f0        	breq	.+44
    5b9a: c6 01 03 c0  	<unknown>
    5b9e: fc 01 00 83  	<unknown>
    5ba2: 01 97 a8 16  	<unknown>
    5ba6: b9 06        	cpc	r11, r25
    5ba8: 50 f4        	brsh	.+20
    5baa: fc 01 32 97  	<unknown>
    5bae: 01 81        	ldd	r16, Z+1
    5bb0: 0e 32        	cpi	r16, 0x2e
    5bb2: a9 f7        	brne	.-22
    5bb4: 00 81        	ldd	r16, Z+0
    5bb6: fc 01 00 83  	<unknown>
    5bba: 01 97 f2 cf  	<unknown>
    5bbe: 01 e0        	ldi	r16, 0x1
    5bc0: 80 0e        	add	r8, r16
    5bc2: 94 1e        	adc	r9, r20
    5bc4: 0d c0        	rjmp	.+26
    5bc6: 01 e0        	ldi	r16, 0x1
    5bc8: c0 0e        	add	r12, r16
    5bca: d4 1e        	adc	r13, r20
    5bcc: c6 01 05 c0  	<unknown>
    5bd0: fc 01 02 91  	<unknown>
    5bd4: fc 01 00 83  	<unknown>
    5bd8: 01 97 a8 16  	<unknown>
    5bdc: b9 06        	cpc	r11, r25
    5bde: c0 f3        	brlo	.-16
    5be0: 01 e3        	ldi	r16, 0x31
    5be2: f5 01 00 83  	<unknown>
    5be6: 09 89        	ldd	r16, Y+1
    5be8: 00 23        	tst	r16
    5bea: 21 f4        	brne	.+8
    5bec: 0c c0        	rjmp	.+24
    5bee: 0f ef        	ldi	r16, 0xff
    5bf0: c0 0e        	add	r12, r16
    5bf2: d0 1e        	adc	r13, r16
    5bf4: f6 01 02 91  	<unknown>
    5bf8: 00 33        	cpi	r16, 0x30
    5bfa: c9 f3        	breq	.-14
    5bfc: 0e 32        	cpi	r16, 0x2e
    5bfe: 19 f4        	brne	.+6
    5c00: 0f ef        	ldi	r16, 0xff
    5c02: c0 0e        	add	r12, r16
    5c04: d0 1e        	adc	r13, r16
    5c06: 08 89        	ldd	r16, Y+0
    5c08: 00 23        	tst	r16
    5c0a: c1 f1        	breq	.+112
    5c0c: f6 01 01 93  	<unknown>
    5c10: 99 20        	tst	r9
    5c12: 3a f4        	brpl	.+14
    5c14: 0d e2        	ldi	r16, 0x2d
    5c16: 48 d0        	rcall	.+144
    5c18: 91 94        	neg	r9
    5c1a: 81 94        	neg	r8
    5c1c: 00 e0        	ldi	r16, 0x0
    5c1e: 90 0a        	sbc	r9, r16
    5c20: 02 c0        	rjmp	.+4
    5c22: 0b e2        	ldi	r16, 0x2b
    5c24: 41 d0        	rcall	.+130
    5c26: 44 24        	clr	r4
    5c28: 55 24        	clr	r5
    5c2a: 0a e0        	ldi	r16, 0xa
    5c2c: c0 0e        	add	r12, r16
    5c2e: d4 1c        	adc	r13, r4
    5c30: 01 e0        	ldi	r16, 0x1
    5c32: 8a d2        	rcall	.+1300
    5c34: 51 d0        	rcall	.+162
    5c36: 40 5d        	subi	r20, 0xd0
    5c38: f6 01 41 93  	<unknown>
    5c3c: 6f 01 4c d0  	<unknown>
    5c40: 48 01 01 2b  	<unknown>
    5c44: a9 f7        	brne	.-22
    5c46: 02 e0        	ldi	r16, 0x2
    5c48: 40 16        	cp	r4, r16
    5c4a: 00 e0        	ldi	r16, 0x0
    5c4c: 50 06        	cpc	r5, r16
    5c4e: 84 f3        	brlt	.-32
    5c50: 32 01 82 01  	<unknown>
    5c54: 17 d0        	rcall	.+46
    5c56: 20 81        	ldd	r18, Z+0
    5c58: 83 01 14 d0  	<unknown>
    5c5c: e4 0d        	add	r30, r4
    5c5e: f5 1d        	adc	r31, r5
    5c60: 3b 97 20 83  	<unknown>
    5c64: 0f ef        	ldi	r16, 0xff
    5c66: 40 0e        	add	r4, r16
    5c68: 50 1e        	adc	r5, r16
    5c6a: 01 e0        	ldi	r16, 0x1
    5c6c: 40 16        	cp	r4, r16
    5c6e: 00 e0        	ldi	r16, 0x0
    5c70: 50 06        	cpc	r5, r16
    5c72: 7c f7        	brge	.-34
    5c74: 06 ef        	ldi	r16, 0xf6
    5c76: c0 0e        	add	r12, r16
    5c78: 0f ef        	ldi	r16, 0xff
    5c7a: d0 1e        	adc	r13, r16
    5c7c: 86 01 e3 e1  	<unknown>
    5c80: 0c 94 f4 34  	<unknown>
    5c84: 11 95        	neg	r17
    5c86: 01 95        	neg	r16
    5c88: 10 40        	sbci	r17, 0x0
    5c8a: f6 01 e0 0f  	<unknown>
    5c8e: f1 1f        	adc	r31, r17
    5c90: 08 95        	ret
    5c92: 0e 2d        	mov	r16, r14
    5c94: 0f 29        	or	r16, r15
    5c96: 19 f4        	brne	.+6
    5c98: 0a 89        	ldd	r16, Y+2
    5c9a: 00 23        	tst	r16
    5c9c: 11 f0        	breq	.+4
    5c9e: 0e e2        	ldi	r16, 0x2e
    5ca0: 03 d0        	rcall	.+6
    5ca2: 08 95        	ret
    5ca4: 00 e3        	ldi	r16, 0x30
    5ca6: f6 01 01 93  	<unknown>
    5caa: 6f 01 08 95  	<unknown>
    5cae: 11 d0        	rcall	.+34
    5cb0: 0c 94 6a 34  	<unknown>
    5cb4: 49 ef        	ldi	r20, 0xf9
    5cb6: 52 e0        	ldi	r21, 0x2
    5cb8: 65 e1        	ldi	r22, 0x15
    5cba: 70 e5        	ldi	r23, 0x50
    5cbc: 08 95        	ret
    5cbe: 03 d0        	rcall	.+6
    5cc0: 60 e8        	ldi	r22, 0x80
    5cc2: 7f e3        	ldi	r23, 0x3f
    5cc4: 08 95        	ret
    5cc6: 40 e0        	ldi	r20, 0x0
    5cc8: 50 e0        	ldi	r21, 0x0
    5cca: 08 95        	ret
    5ccc: 02 d0        	rcall	.+4
    5cce: 0c 94 82 34  	<unknown>
    5cd2: 8c 01 9d 01  	<unknown>
    5cd6: 08 95        	ret
    5cd8: 4a e0        	ldi	r20, 0xa
    5cda: 50 e0        	ldi	r21, 0x0
    5cdc: 84 01 0c 94  	<unknown>
    5ce0: f9 31        	cpi	r31, 0x19
    5ce2: 0e 94 e3 34  	<unknown>
    5ce6: ef 97 ef 97  	<unknown>
    5cea: 6c 97 2a 87  	<unknown>
    5cee: 3b 87        	std	Y+3, r19
    5cf0: 48 87        	std	Y+0, r20
    5cf2: 59 87        	std	Y+1, r21
    5cf4: 78 01 6b 01  	<unknown>
    5cf8: 00 e0        	ldi	r16, 0x0
    5cfa: 0d 83        	std	Y+5, r16
    5cfc: 0e 83        	std	Y+6, r16
    5cfe: 04 c0        	rjmp	.+8
    5d00: 5b d2        	rcall	.+1206
    5d02: 1f d2        	rcall	.+1086
    5d04: 05 e2        	ldi	r16, 0x25
    5d06: 27 d2        	rcall	.+1102
    5d08: 00 e0        	ldi	r16, 0x0
    5d0a: 0c 87        	std	Y+4, r16
    5d0c: 0d 87        	std	Y+5, r16
    5d0e: 02 c0        	rjmp	.+4
    5d10: 18 d2        	rcall	.+1072
    5d12: 21 d2        	rcall	.+1090
    5d14: 0e d2        	rcall	.+1052
    5d16: 05 32        	cpi	r16, 0x25
    5d18: 49 f0        	breq	.+18
    5d1a: 00 23        	tst	r16
    5d1c: c9 f7        	brne	.-14
    5d1e: 0d 81        	ldd	r16, Y+5
    5d20: 1e 81        	ldd	r17, Y+6
    5d22: ef 96 ef 96  	<unknown>
    5d26: 6c 96 e0 e1  	<unknown>
    5d2a: aa cf        	rjmp	.-172
    5d2c: 04 91 05 32  	<unknown>
    5d30: 39 f3        	breq	.-50
    5d32: 00 e0        	ldi	r16, 0x0
    5d34: 0c 83        	std	Y+4, r16
    5d36: 0b 83        	std	Y+3, r16
    5d38: 0a 83        	std	Y+2, r16
    5d3a: 09 83        	std	Y+1, r16
    5d3c: 3e 01 04 e1  	<unknown>
    5d40: 1a d2        	rcall	.+1076
    5d42: 0a eb        	ldi	r16, 0xba
    5d44: 1b e0        	ldi	r17, 0xb
    5d46: 0a 8b        	std	Y+2, r16
    5d48: 1b 8b        	std	Y+3, r17
    5d4a: 06 c0        	rjmp	.+12
    5d4c: 09 81        	ldd	r16, Y+1
    5d4e: 00 23        	tst	r16
    5d50: 11 f4        	brne	.+4
    5d52: 04 91 09 83  	<unknown>
    5d56: 30 d2        	rcall	.+1120
    5d58: f1 d1        	rcall	.+994
    5d5a: 00 52        	subi	r16, 0x20
    5d5c: b9 f3        	breq	.-18
    5d5e: 03 50        	subi	r16, 0x3
    5d60: 59 f0        	breq	.+22
    5d62: 08 50        	subi	r16, 0x8
    5d64: b1 f3        	breq	.-20
    5d66: 02 50        	subi	r16, 0x2
    5d68: 19 f0        	breq	.+6
    5d6a: 03 50        	subi	r16, 0x3
    5d6c: 49 f0        	breq	.+18
    5d6e: 0c c0        	rjmp	.+24
    5d70: 0a 81        	ldd	r16, Y+2
    5d72: 03 95        	inc	r16
    5d74: 0a 83        	std	Y+2, r16
    5d76: ef cf        	rjmp	.-34
    5d78: 0b 81        	ldd	r16, Y+3
    5d7a: 03 95        	inc	r16
    5d7c: 0b 83        	std	Y+3, r16
    5d7e: eb cf        	rjmp	.-42
    5d80: 0c 81        	ldd	r16, Y+4
    5d82: 03 95        	inc	r16
    5d84: 0c 83        	std	Y+4, r16
    5d86: e7 cf        	rjmp	.-50
    5d88: 04 91 0a 32  	<unknown>
    5d8c: 79 f4        	brne	.+30
    5d8e: f8 d1        	rcall	.+1008
    5d90: ad 90        	ld	r10, X+
    5d92: bd 90        	ld	r11, X+
    5d94: bb d1        	rcall	.+886
    5d96: bb 20        	tst	r11
    5d98: 3a f4        	brpl	.+14
    5d9a: b1 94        	neg	r11
    5d9c: a1 94        	neg	r10
    5d9e: 00 e0        	ldi	r16, 0x0
    5da0: b0 0a        	sbc	r11, r16
    5da2: 0a 81        	ldd	r16, Y+2
    5da4: 03 95        	inc	r16
    5da6: 0a 83        	std	Y+2, r16
    5da8: 07 d2        	rcall	.+1038
    5daa: 14 c0        	rjmp	.+40
    5dac: aa 24        	clr	r10
    5dae: bb 24        	clr	r11
    5db0: 0c c0        	rjmp	.+24
    5db2: a5 d1        	rcall	.+842
    5db4: 85 01 0e 94  	<unknown>
    5db8: cd 31        	cpi	r28, 0x1d
    5dba: a2 2e        	mov	r10, r18
    5dbc: bb 24        	clr	r11
    5dbe: a0 0e        	add	r10, r16
    5dc0: b1 1e        	adc	r11, r17
    5dc2: 00 ed        	ldi	r16, 0xd0
    5dc4: a0 0e        	add	r10, r16
    5dc6: 0f ef        	ldi	r16, 0xff
    5dc8: b0 1e        	adc	r11, r16
    5dca: b8 d1        	rcall	.+880
    5dcc: 00 33        	cpi	r16, 0x30
    5dce: 10 f0        	brlo	.+4
    5dd0: 0a 33        	cpi	r16, 0x3a
    5dd2: 78 f3        	brlo	.-34
    5dd4: 0a 81        	ldd	r16, Y+2
    5dd6: 00 23        	tst	r16
    5dd8: 11 f0        	breq	.+4
    5dda: 00 e0        	ldi	r16, 0x0
    5ddc: 0c 83        	std	Y+4, r16
    5dde: ae d1        	rcall	.+860
    5de0: 0e 32        	cpi	r16, 0x2e
    5de2: f1 f4        	brne	.+60
    5de4: e9 d1        	rcall	.+978
    5de6: aa d1        	rcall	.+852
    5de8: 0a 32        	cpi	r16, 0x2a
    5dea: 31 f4        	brne	.+12
    5dec: c9 d1        	rcall	.+914
    5dee: 8d 90        	ld	r8, X+
    5df0: 9d 90        	ld	r9, X+
    5df2: 8c d1        	rcall	.+792
    5df4: e1 d1        	rcall	.+962
    5df6: 17 c0        	rjmp	.+46
    5df8: 88 24        	clr	r8
    5dfa: 99 24        	clr	r9
    5dfc: 9f d1        	rcall	.+830
    5dfe: 00 33        	cpi	r16, 0x30
    5e00: 90 f0        	brlo	.+36
    5e02: 0a 33        	cpi	r16, 0x3a
    5e04: 80 f4        	brsh	.+32
    5e06: 7b d1        	rcall	.+758
    5e08: 84 01 0e 94  	<unknown>
    5e0c: cd 31        	cpi	r28, 0x1d
    5e0e: 82 2e        	mov	r8, r18
    5e10: 99 24        	clr	r9
    5e12: 80 0e        	add	r8, r16
    5e14: 91 1e        	adc	r9, r17
    5e16: 00 ed        	ldi	r16, 0xd0
    5e18: 80 0e        	add	r8, r16
    5e1a: 0f ef        	ldi	r16, 0xff
    5e1c: 90 1e        	adc	r9, r16
    5e1e: ee cf        	rjmp	.-36
    5e20: 88 24        	clr	r8
    5e22: 8a 94        	dec	r8
    5e24: 98 2c        	mov	r9, r8
    5e26: 80 e0        	ldi	r24, 0x0
    5e28: 89 d1        	rcall	.+786
    5e2a: 0c 54        	subi	r16, 0x4c
    5e2c: 21 f0        	breq	.+8
    5e2e: 0c 51        	subi	r16, 0x1c
    5e30: 39 f0        	breq	.+14
    5e32: 04 50        	subi	r16, 0x4
    5e34: 41 f4        	brne	.+16
    5e36: 81 e0        	ldi	r24, 0x1
    5e38: e8 0e        	add	r14, r24
    5e3a: 00 e0        	ldi	r16, 0x0
    5e3c: f0 1e        	adc	r15, r16
    5e3e: 03 c0        	rjmp	.+6
    5e40: 01 e0        	ldi	r16, 0x1
    5e42: e0 0e        	add	r14, r16
    5e44: f8 1e        	adc	r15, r24
    5e46: 75 d1        	rcall	.+746
    5e48: e8 e8        	ldi	r30, 0x88
    5e4a: fc e0        	ldi	r31, 0xc
    5e4c: 0c 94 93 34  	<unknown>
    5e50: 88 23        	tst	r24
    5e52: 59 f0        	breq	.+22
    5e54: 4d 81        	ldd	r20, Y+5
    5e56: 5e 81        	ldd	r21, Y+6
    5e58: 65 2f        	mov	r22, r21
    5e5a: 66 0f        	lsl	r22
    5e5c: 66 0b        	sbc	r22, r22
    5e5e: 60 d1        	rcall	.+704
    5e60: 40 83        	std	Z+0, r20
    5e62: 51 83        	std	Z+1, r21
    5e64: 62 83        	std	Z+2, r22
    5e66: 63 83        	std	Z+3, r22
    5e68: 4f cf        	rjmp	.-354
    5e6a: 2d 81        	ldd	r18, Y+5
    5e6c: 3e 81        	ldd	r19, Y+6
    5e6e: 58 d1        	rcall	.+688
    5e70: 20 83        	std	Z+0, r18
    5e72: 31 83        	std	Z+1, r19
    5e74: 49 cf        	rjmp	.-366
    5e76: 88 d1        	rcall	.+784
    5e78: 11 96 48 d1  	<unknown>
    5e7c: 0c 8b        	std	Y+4, r16
    5e7e: 2e 01 05 e1  	<unknown>
    5e82: 62 d1        	rcall	.+708
    5e84: ff c0        	rjmp	.+510
    5e86: 7c d1        	rcall	.+760
    5e88: 6d 90        	ld	r6, X+
    5e8a: 7d 90        	ld	r7, X+
    5e8c: 3f d1        	rcall	.+638
    5e8e: 06 2d        	mov	r16, r6
    5e90: 07 29        	or	r16, r7
    5e92: 31 f4        	brne	.+12
    5e94: 0c ed        	ldi	r16, 0xdc
    5e96: 1b e0        	ldi	r17, 0xb
    5e98: 0c 87        	std	Y+4, r16
    5e9a: 1d 87        	std	Y+5, r17
    5e9c: 0d e0        	ldi	r16, 0xd
    5e9e: f0 c0        	rjmp	.+480
    5ea0: 99 20        	tst	r9
    5ea2: 22 f4        	brpl	.+8
    5ea4: 00 e1        	ldi	r16, 0x10
    5ea6: 80 2e        	mov	r8, r16
    5ea8: 07 e2        	ldi	r16, 0x27
    5eaa: 90 2e        	mov	r9, r16
    5eac: 80 e0        	ldi	r24, 0x0
    5eae: 90 e0        	ldi	r25, 0x0
    5eb0: 01 c0        	rjmp	.+2
    5eb2: 01 96 f3 01  	<unknown>
    5eb6: 01 91        	ld	r16, Z+
    5eb8: 3f 01 00 23  	<unknown>
    5ebc: 19 f0        	breq	.+6
    5ebe: 88 15        	cp	r24, r8
    5ec0: 99 05        	cpc	r25, r9
    5ec2: bc f3        	brlt	.-18
    5ec4: 76 d1        	rcall	.+748
    5ec6: 23 01 91 95  	<unknown>
    5eca: 81 95        	neg	r24
    5ecc: 90 40        	sbci	r25, 0x0
    5ece: 68 0e        	add	r6, r24
    5ed0: 79 1e        	adc	r7, r25
    5ed2: d8 c0        	rjmp	.+432
    5ed4: 0b 81        	ldd	r16, Y+3
    5ed6: 00 23        	tst	r16
    5ed8: 31 f0        	breq	.+12
    5eda: 08 2d        	mov	r16, r8
    5edc: 09 29        	or	r16, r9
    5ede: 19 f4        	brne	.+6
    5ee0: 99 24        	clr	r9
    5ee2: 88 24        	clr	r8
    5ee4: 83 94        	inc	r8
    5ee6: 0b ec        	ldi	r16, 0xcb
    5ee8: 1b e0        	ldi	r17, 0xb
    5eea: 0a 8b        	std	Y+2, r16
    5eec: 1b 8b        	std	Y+3, r17
    5eee: 08 81        	ldd	r16, Y+0
    5ef0: 00 37        	cpi	r16, 0x70
    5ef2: 39 f4        	brne	.+14
    5ef4: 45 d1        	rcall	.+650
    5ef6: 0d d1        	rcall	.+538
    5ef8: 00 e1        	ldi	r16, 0x10
    5efa: 37 d1        	rcall	.+622
    5efc: 00 e0        	ldi	r16, 0x0
    5efe: 09 83        	std	Y+1, r16
    5f00: 2c c0        	rjmp	.+88
    5f02: 3d d1        	rcall	.+634
    5f04: 21 f0        	breq	.+8
    5f06: 0d 91        	ld	r16, X+
    5f08: fe d0        	rcall	.+508
    5f0a: 5c d1        	rcall	.+696
    5f0c: 01 c0        	rjmp	.+2
    5f0e: 01 d1        	rcall	.+514
    5f10: 08 81        	ldd	r16, Y+0
    5f12: 0f 36        	cpi	r16, 0x6f
    5f14: 11 f4        	brne	.+4
    5f16: 08 e0        	ldi	r16, 0x8
    5f18: f0 cf        	rjmp	.-32
    5f1a: 05 37        	cpi	r16, 0x75
    5f1c: 69 f7        	brne	.-38
    5f1e: 0a e0        	ldi	r16, 0xa
    5f20: ec cf        	rjmp	.-40
    5f22: 2d d1        	rcall	.+602
    5f24: 4d 91        	ld	r20, X+
    5f26: 5d 91        	ld	r21, X+
    5f28: 21 f0        	breq	.+8
    5f2a: 6d 91        	ld	r22, X+
    5f2c: 7d 91        	ld	r23, X+
    5f2e: ee d0        	rcall	.+476
    5f30: 05 c0        	rjmp	.+10
    5f32: ec d0        	rcall	.+472
    5f34: 65 2f        	mov	r22, r21
    5f36: 66 0f        	lsl	r22
    5f38: 66 0b        	sbc	r22, r22
    5f3a: 76 2f        	mov	r23, r22
    5f3c: ca 01 db 01  	<unknown>
    5f40: 77 23        	tst	r23
    5f42: 4a f4        	brpl	.+18
    5f44: 0d e2        	ldi	r16, 0x2d
    5f46: 09 83        	std	Y+1, r16
    5f48: 90 95        	com	r25
    5f4a: a0 95        	com	r26
    5f4c: b0 95        	com	r27
    5f4e: 81 95        	neg	r24
    5f50: 9f 4f        	sbci	r25, 0xff
    5f52: af 4f        	sbci	r26, 0xff
    5f54: bf 4f        	sbci	r27, 0xff
    5f56: 0a e0        	ldi	r16, 0xa
    5f58: 08 d1        	rcall	.+528
    5f5a: 3e 01 09 e9  	<unknown>
    5f5e: 0b d1        	rcall	.+534
    5f60: 2e 01 09 e9  	<unknown>
    5f64: f1 d0        	rcall	.+482
    5f66: 08 2f        	mov	r16, r24
    5f68: 09 2b        	or	r16, r25
    5f6a: 0a 2b        	or	r16, r26
    5f6c: 0b 2b        	or	r16, r27
    5f6e: 11 f0        	breq	.+4
    5f70: 01 e0        	ldi	r16, 0x1
    5f72: 01 c0        	rjmp	.+2
    5f74: 00 e0        	ldi	r16, 0x0
    5f76: 0f 83        	std	Y+7, r16
    5f78: 08 2d        	mov	r16, r8
    5f7a: 09 29        	or	r16, r9
    5f7c: 19 f4        	brne	.+6
    5f7e: 0f 81        	ldd	r16, Y+7
    5f80: 00 23        	tst	r16
    5f82: b9 f0        	breq	.+46
    5f84: 0b d1        	rcall	.+534
    5f86: ea 89        	ldd	r30, Y+2
    5f88: fb 89        	ldd	r31, Y+3
    5f8a: e0 0d        	add	r30, r0
    5f8c: f1 1d        	adc	r31, r1
    5f8e: 04 91 f3 01  	<unknown>
    5f92: 02 93        	st	-Z, r16
    5f94: 3f 01 02 d1  	<unknown>
    5f98: 15 d1        	rcall	.+554
    5f9a: 01 2b        	or	r16, r17
    5f9c: 02 2b        	or	r16, r18
    5f9e: 03 2b        	or	r16, r19
    5fa0: 89 f7        	brne	.-30
    5fa2: 99 20        	tst	r9
    5fa4: 32 f4        	brpl	.+12
    5fa6: 0c 81        	ldd	r16, Y+4
    5fa8: 00 23        	tst	r16
    5faa: 19 f0        	breq	.+6
    5fac: 0e d1        	rcall	.+540
    5fae: 01 c0        	rjmp	.+2
    5fb0: f0 d0        	rcall	.+480
    5fb2: 8e 01 07 56  	<unknown>
    5fb6: 1f 4f        	sbci	r17, 0xff
    5fb8: 9d d0        	rcall	.+314
    5fba: d4 f3        	brlt	.-12
    5fbc: 0b 81        	ldd	r16, Y+3
    5fbe: 00 23        	tst	r16
    5fc0: 09 f4        	brne	.+2
    5fc2: 60 c0        	rjmp	.+192
    5fc4: 0f 81        	ldd	r16, Y+7
    5fc6: 00 23        	tst	r16
    5fc8: 09 f4        	brne	.+2
    5fca: 5c c0        	rjmp	.+184
    5fcc: 08 81        	ldd	r16, Y+0
    5fce: 08 37        	cpi	r16, 0x78
    5fd0: 11 f0        	breq	.+4
    5fd2: 08 35        	cpi	r16, 0x58
    5fd4: 49 f4        	brne	.+18
    5fd6: ed d0        	rcall	.+474
    5fd8: f3 01 08 81  	<unknown>
    5fdc: 00 83        	std	Z+0, r16
    5fde: e9 d0        	rcall	.+466
    5fe0: 00 e3        	ldi	r16, 0x30
    5fe2: f3 01 00 83  	<unknown>
    5fe6: 4e c0        	rjmp	.+156
    5fe8: 0f 36        	cpi	r16, 0x6f
    5fea: 09 f0        	breq	.+2
    5fec: 4b c0        	rjmp	.+150
    5fee: f3 01 00 81  	<unknown>
    5ff2: 00 33        	cpi	r16, 0x30
    5ff4: 09 f4        	brne	.+2
    5ff6: 46 c0        	rjmp	.+140
    5ff8: 00 e3        	ldi	r16, 0x30
    5ffa: 02 93        	st	-Z, r16
    5ffc: 3f 01 42 c0  	<unknown>
    6000: 81 e0        	ldi	r24, 0x1
    6002: 08 81        	ldd	r16, Y+0
    6004: 02 50        	subi	r16, 0x2
    6006: 08 83        	std	Y+0, r16
    6008: 08 2d        	mov	r16, r8
    600a: 09 29        	or	r16, r9
    600c: 39 f4        	brne	.+14
    600e: 99 24        	clr	r9
    6010: 88 24        	clr	r8
    6012: 83 94        	inc	r8
    6014: 08 c0        	rjmp	.+16
    6016: 00 e0        	ldi	r16, 0x0
    6018: 08 83        	std	Y+0, r16
    601a: 80 e0        	ldi	r24, 0x0
    601c: 99 20        	tst	r9
    601e: 1a f4        	brpl	.+6
    6020: 06 e0        	ldi	r16, 0x6
    6022: 80 2e        	mov	r8, r16
    6024: 99 24        	clr	r9
    6026: b0 d0        	rcall	.+352
    6028: 6e d0        	rcall	.+220
    602a: 4d de        	rcall	.-870
    602c: 60 e0        	ldi	r22, 0x0
    602e: 70 e0        	ldi	r23, 0x0
    6030: 0e 94 6a 34  	<unknown>
    6034: 28 f4        	brsh	.+10
    6036: 4d e2        	ldi	r20, 0x2d
    6038: 49 83        	std	Y+1, r20
    603a: 73 2f        	mov	r23, r19
    603c: 70 58        	subi	r23, 0x80
    603e: 37 2f        	mov	r19, r23
    6040: 3e 01 44 e1  	<unknown>
    6044: 64 0e        	add	r6, r20
    6046: 75 1e        	adc	r7, r21
    6048: 6a 0c        	add	r6, r10
    604a: 7b 1c        	adc	r7, r11
    604c: 4b 81        	ldd	r20, Y+3
    604e: 4a 93        	st	-Y, r20
    6050: 8a 93        	st	-Y, r24
    6052: 4a 81        	ldd	r20, Y+2
    6054: 4a 93        	st	-Y, r20
    6056: b3 01 a4 01  	<unknown>
    605a: d8 dc        	rcall	.-1616
    605c: 28 01 0c 81  	<unknown>
    6060: 00 23        	tst	r16
    6062: 81 f0        	breq	.+32
    6064: b2 d0        	rcall	.+356
    6066: 82 01 45 d0  	<unknown>
    606a: 64 f4        	brge	.+24
    606c: 92 d0        	rcall	.+292
    606e: fb cf        	rjmp	.-10
    6070: 9c d0        	rcall	.+312
    6072: 0b ee        	ldi	r16, 0xeb
    6074: 1b e0        	ldi	r17, 0xb
    6076: 0c 87        	std	Y+4, r16
    6078: 1d 87        	std	Y+5, r17
    607a: 66 24        	clr	r6
    607c: 77 24        	clr	r7
    607e: 03 e0        	ldi	r16, 0x3
    6080: 40 2e        	mov	r4, r16
    6082: 55 24        	clr	r5
    6084: 42 01 86 18  	<unknown>
    6088: 97 08        	sbc	r9, r7
    608a: a8 14        	cp	r10, r8
    608c: b9 04        	cpc	r11, r9
    608e: 1c f4        	brge	.+6
    6090: 80 e0        	ldi	r24, 0x0
    6092: 90 e0        	ldi	r25, 0x0
    6094: 07 c0        	rjmp	.+14
    6096: 9f d0        	rcall	.+318
    6098: a8 18        	sub	r10, r8
    609a: b9 08        	sbc	r11, r9
    609c: 10 e0        	ldi	r17, 0x0
    609e: a0 1a        	sub	r10, r16
    60a0: b1 0a        	sbc	r11, r17
    60a2: c5 01 0a 81  	<unknown>
    60a6: 00 23        	tst	r16
    60a8: 21 f4        	brne	.+8
    60aa: 01 c0        	rjmp	.+2
    60ac: 51 d0        	rcall	.+162
    60ae: 01 97 ea f7  	<unknown>
    60b2: 09 81        	ldd	r16, Y+1
    60b4: 00 23        	tst	r16
    60b6: 31 f0        	breq	.+12
    60b8: 44 d0        	rcall	.+136
    60ba: 03 c0        	rjmp	.+6
    60bc: f3 01 01 91  	<unknown>
    60c0: 3f 01 49 d0  	<unknown>
    60c4: 0f ef        	ldi	r16, 0xff
    60c6: 80 0e        	add	r8, r16
    60c8: 90 1e        	adc	r9, r16
    60ca: 5a f0        	brmi	.+22
    60cc: 0c 85        	ldd	r16, Y+4
    60ce: 1d 85        	ldd	r17, Y+5
    60d0: 01 2b        	or	r16, r17
    60d2: 37 d0        	rcall	.+110
    60d4: 99 f3        	breq	.-26
    60d6: ec 85        	ldd	r30, Y+4
    60d8: f1 2f        	mov	r31, r17
    60da: 05 91 ec 87  	<unknown>
    60de: fd 87        	std	Y+5, r31
    60e0: f0 cf        	rjmp	.-32
    60e2: 0a 81        	ldd	r16, Y+2
    60e4: 00 23        	tst	r16
    60e6: 09 f4        	brne	.+2
    60e8: 0f ce        	rjmp	.-994
    60ea: 01 97 0a f4  	<unknown>
    60ee: 0c ce        	rjmp	.-1000
    60f0: 2f d0        	rcall	.+94
    60f2: fb cf        	rjmp	.-10
    60f4: 06 19        	sub	r16, r6
    60f6: 17 09        	sbc	r17, r7
    60f8: 08 15        	cp	r16, r8
    60fa: 19 05        	cpc	r17, r9
    60fc: 08 95        	ret
    60fe: 25 91 7f 01  	<unknown>
    6102: 4a e0        	ldi	r20, 0xa
    6104: e1 cd        	rjmp	.-1086
    6106: 1d 91        	ld	r17, X+
    6108: 2d 91        	ld	r18, X+
    610a: 3d 91        	ld	r19, X+
    610c: a0 83        	std	Z+0, r26
    610e: b1 83        	std	Z+1, r27
    6110: 08 95        	ret
    6112: 8d 91        	ld	r24, X+
    6114: 9d 91        	ld	r25, X+
    6116: a0 83        	std	Z+0, r26
    6118: b1 83        	std	Z+1, r27
    611a: a0 e0        	ldi	r26, 0x0
    611c: b0 e0        	ldi	r27, 0x0
    611e: 08 95        	ret
    6120: d6 01 ed 91  	<unknown>
    6124: fc 91        	ld	r31, X
    6126: 01 91        	ld	r16, Z+
    6128: 11 91        	ld	r17, Z+
    612a: fc 93        	st	X, r31
    612c: ee 93        	st	-X, r30
    612e: f8 01 08 95  	<unknown>
    6132: f7 01 05 91  	<unknown>
    6136: 7f 01 08 83  	<unknown>
    613a: 08 95        	ret
    613c: f7 01 04 91  	<unknown>
    6140: 08 95        	ret
    6142: 28 85        	ldd	r18, Y+0
    6144: 39 85        	ldd	r19, Y+1
    6146: 08 95        	ret
    6148: 40 0e        	add	r4, r16
    614a: 00 e0        	ldi	r16, 0x0
    614c: 50 1e        	adc	r5, r16
    614e: 08 95        	ret
    6150: 28 85        	ldd	r18, Y+0
    6152: 39 85        	ldd	r19, Y+1
    6154: 00 e2        	ldi	r16, 0x20
    6156: ea 85        	ldd	r30, Y+2
    6158: fb 85        	ldd	r31, Y+3
    615a: 09 95 0d 81  	<unknown>
    615e: 1e 81        	ldd	r17, Y+6
    6160: 0f 5f        	subi	r16, 0xff
    6162: 1f 4f        	sbci	r17, 0xff
    6164: 0d 83        	std	Y+5, r16
    6166: 1e 83        	std	Y+6, r17
    6168: 08 95        	ret
    616a: 10 e0        	ldi	r17, 0x0
    616c: 0e 87        	std	Y+6, r16
    616e: 1f 87        	std	Y+7, r17
    6170: 18 8b        	std	Y+0, r17
    6172: 19 8b        	std	Y+1, r17
    6174: 08 95        	ret
    6176: 60 0e        	add	r6, r16
    6178: 00 e0        	ldi	r16, 0x0
    617a: 70 1e        	adc	r7, r16
    617c: 08 95        	ret
    617e: 88 23        	tst	r24
    6180: f6 01 a0 81  	<unknown>
    6184: b1 81        	ldd	r27, Z+1
    6186: 08 95        	ret
    6188: f6 01 a0 81  	<unknown>
    618c: b1 81        	ldd	r27, Z+1
    618e: 0d 91        	ld	r16, X+
    6190: 08 95        	ret
    6192: 00 e3        	ldi	r16, 0x30
    6194: f3 01 02 93  	<unknown>
    6198: 3f 01 08 95  	<unknown>
    619c: 4e 85        	ldd	r20, Y+6
    619e: 5f 85        	ldd	r21, Y+7
    61a0: 68 89        	ldd	r22, Y+0
    61a2: 79 89        	ldd	r23, Y+1
    61a4: 96 dd        	rcall	.-1236
    61a6: 0c 94 3d 32  	<unknown>
    61aa: 0f ef        	ldi	r16, 0xff
    61ac: e0 0e        	add	r14, r16
    61ae: f0 1e        	adc	r15, r16
    61b0: 08 95        	ret
    61b2: 0f ef        	ldi	r16, 0xff
    61b4: 60 0e        	add	r6, r16
    61b6: e1 cf        	rjmp	.-62
    61b8: 01 e0        	ldi	r16, 0x1
    61ba: e0 0e        	add	r14, r16
    61bc: 00 e0        	ldi	r16, 0x0
    61be: f7 cf        	rjmp	.-18
    61c0: 0e 94 68 33  	<unknown>
    61c4: c8 01 d9 01  	<unknown>
    61c8: 08 95        	ret
    61ca: 05 d0        	rcall	.+10
    61cc: 10 e0        	ldi	r17, 0x0
    61ce: 45 01 80 1a  	<unknown>
    61d2: 91 0a        	sbc	r9, r17
    61d4: 08 95        	ret
    61d6: 09 81        	ldd	r16, Y+1
    61d8: 00 23        	tst	r16
    61da: 11 f0        	breq	.+4
    61dc: 01 e0        	ldi	r16, 0x1
    61de: 08 95        	ret
    61e0: 00 e0        	ldi	r16, 0x0
    61e2: 08 95        	ret
    61e4: 01 e0        	ldi	r16, 0x1
    61e6: 10 e0        	ldi	r17, 0x0
    61e8: 0c 94 d6 36  	<unknown>
    61ec: 0e 94 eb 34  	<unknown>
    61f0: d8 01 29 01  	<unknown>
    61f4: 82 e0        	ldi	r24, 0x2
    61f6: 3d 01 09 c0  	<unknown>
    61fa: 02 e0        	ldi	r16, 0x2
    61fc: 60 0e        	add	r6, r16
    61fe: 71 1e        	adc	r7, r17
    6200: 82 30        	cpi	r24, 0x2
    6202: 81 f0        	breq	.+32
    6204: 02 e0        	ldi	r16, 0x2
    6206: 60 0e        	add	r6, r16
    6208: 00 e0        	ldi	r16, 0x0
    620a: 70 1e        	adc	r7, r16
    620c: 64 14        	cp	r6, r4
    620e: 75 04        	cpc	r7, r5
    6210: 79 f0        	breq	.+30
    6212: f3 01 25 91  	<unknown>
    6216: 34 91 10 e0  	<unknown>
    621a: 20 30        	cpi	r18, 0x0
    621c: 30 40        	sbci	r19, 0x0
    621e: 69 f3        	breq	.-38
    6220: 82 30        	cpi	r24, 0x2
    6222: 81 f3        	breq	.-32
    6224: f3 01 05 91  	<unknown>
    6228: f4 91 e0 2f  	<unknown>
    622c: 09 95 ea cf  	<unknown>
    6230: 8a 95        	dec	r24
    6232: 09 f7        	brne	.-62
    6234: e8 e0        	ldi	r30, 0x8
    6236: 0c 94 fc 34  	<unknown>
    623a: ba 93        	st	-Y, r27
    623c: aa 93        	st	-Y, r26
    623e: f8 01 36 d0  	<unknown>
    6242: 23 2b        	or	r18, r19
    6244: 31 f4        	brne	.+12
    6246: 30 d0        	rcall	.+96
    6248: 20 81        	ldd	r18, Z+0
    624a: 31 81        	ldd	r19, Z+1
    624c: 02 17        	cp	r16, r18
    624e: 13 07        	cpc	r17, r19
    6250: 11 f4        	brne	.+4
    6252: 0c 94 f2 30  	<unknown>
    6256: f8 01 a0 81  	<unknown>
    625a: b1 81        	ldd	r27, Z+1
    625c: 2d 93        	st	X+, r18
    625e: 3c 93        	st	X, r19
    6260: 23 d0        	rcall	.+70
    6262: 00 83        	std	Z+0, r16
    6264: 11 83        	std	Z+1, r17
    6266: a9 91        	ld	r26, Y+
    6268: b9 91        	ld	r27, Y+
    626a: 08 95        	ret
    626c: ba 93        	st	-Y, r27
    626e: aa 93        	st	-Y, r26
    6270: 01 c0        	rjmp	.+2
    6272: 09 95 19 d0  	<unknown>
    6276: 00 81        	ldd	r16, Z+0
    6278: 11 81        	ldd	r17, Z+1
    627a: 01 2b        	or	r16, r17
    627c: a1 f0        	breq	.+40
    627e: 00 81        	ldd	r16, Z+0
    6280: e0 91 7a 07  	<unknown>
    6284: f1 2f        	mov	r31, r17
    6286: 13 d0        	rcall	.+38
    6288: 0f d0        	rcall	.+30
    628a: 20 83        	std	Z+0, r18
    628c: 31 83        	std	Z+1, r19
    628e: d8 01 14 96  	<unknown>
    6292: ed 91        	ld	r30, X+
    6294: fc 91        	ld	r31, X
    6296: d8 01 12 96  	<unknown>
    629a: 0d 91        	ld	r16, X+
    629c: 1c 91        	ld	r17, X
    629e: 20 2f        	mov	r18, r16
    62a0: 21 2b        	or	r18, r17
    62a2: 39 f7        	brne	.-50
    62a4: e6 cf        	rjmp	.-52
    62a6: df cf        	rjmp	.-66
    62a8: ea e7        	ldi	r30, 0x7a
    62aa: f7 e0        	ldi	r31, 0x7
    62ac: 08 95        	ret
    62ae: a0 81        	ldd	r26, Z+0
    62b0: b1 81        	ldd	r27, Z+1
    62b2: 2d 91        	ld	r18, X+
    62b4: 3c 91        	ld	r19, X
    62b6: 08 95        	ret
    62b8: 0f e5        	ldi	r16, 0x5f
    62ba: 0d bf        	out	0x3d, r16
    62bc: 06 e0        	ldi	r16, 0x6
    62be: 0e bf        	out	0x3e, r16
    62c0: c0 e6        	ldi	r28, 0x60
    62c2: d3 e0        	ldi	r29, 0x3
    62c4: 0e 94 1a 35  	<unknown>
    62c8: 00 23        	tst	r16
    62ca: 11 f0        	breq	.+4
    62cc: 0e 94 8d 35  	<unknown>
    62d0: 0c eb        	ldi	r16, 0xbc
    62d2: 1c e0        	ldi	r17, 0xc
    62d4: 2e eb        	ldi	r18, 0xbe
    62d6: 3c e0        	ldi	r19, 0xc
    62d8: 0e 94 f6 30  	<unknown>
    62dc: 0e 94 de 20  	<unknown>
    62e0: 0e 94 b8 31  	<unknown>
    62e4: 0c 94 fe 2c  	<unknown>
    62e8: 0c 94 76 31  	<unknown>
    62ec: 20 2f        	mov	r18, r16
    62ee: 21 2b        	or	r18, r17
    62f0: 11 f0        	breq	.+4
    62f2: 0e 94 d7 36  	<unknown>
    62f6: 08 95        	ret
    62f8: e1 99        	sbic	0x1c, 0x1
    62fa: fe cf        	rjmp	.-4
    62fc: 08 95        	ret
    62fe: 4f 5f        	subi	r20, 0xff
    6300: 5f 4f        	sbci	r21, 0xff
    6302: fa df        	rcall	.-12
    6304: 4e bb        	out	0x1e, r20
    6306: 5f bb        	out	0x1f, r21
    6308: e0 9a        	sbi	0x1c, 0x0
    630a: 08 95        	ret
    630c: fa df        	rcall	.-12
    630e: 0d b3        	in	r16, 0x1d
    6310: 08 95        	ret
    6312: f7 df        	rcall	.-18
    6314: 0d b3        	in	r16, 0x1d
    6316: f3 df        	rcall	.-26
    6318: 1d b3        	in	r17, 0x1d
    631a: 08 95        	ret
    631c: f2 df        	rcall	.-28
    631e: 0d b3        	in	r16, 0x1d
    6320: ee df        	rcall	.-36
    6322: 1d b3        	in	r17, 0x1d
    6324: ec df        	rcall	.-40
    6326: 2d b3        	in	r18, 0x1d
    6328: ea df        	rcall	.-44
    632a: 3d b3        	in	r19, 0x1d
    632c: 08 95        	ret
    632e: 4f 5f        	subi	r20, 0xff
    6330: 5f 4f        	sbci	r21, 0xff
    6332: 4e bb        	out	0x1e, r20
    6334: 5f bb        	out	0x1f, r21
    6336: f8 94        	cli
    6338: e2 9a        	sbi	0x1c, 0x2
    633a: e1 9a        	sbi	0x1c, 0x1
    633c: 0f be        	out	0x3f, r0
    633e: 08 95        	ret
    6340: 0f b6        	in	r0, 0x3f
    6342: da df        	rcall	.-76
    6344: 0d bb        	out	0x1d, r16
    6346: f5 cf        	rjmp	.-22
    6348: 0f b6        	in	r0, 0x3f
    634a: d6 df        	rcall	.-84
    634c: 0d bb        	out	0x1d, r16
    634e: f1 df        	rcall	.-30
    6350: d3 df        	rcall	.-90
    6352: 1d bb        	out	0x1d, r17
    6354: ec cf        	rjmp	.-40
    6356: 0f b6        	in	r0, 0x3f
    6358: cf df        	rcall	.-98
    635a: 0d bb        	out	0x1d, r16
    635c: ea df        	rcall	.-44
    635e: cc df        	rcall	.-104
    6360: 1d bb        	out	0x1d, r17
    6362: e5 df        	rcall	.-54
    6364: c9 df        	rcall	.-110
    6366: 2d bb        	out	0x1d, r18
    6368: e2 df        	rcall	.-60
    636a: c6 df        	rcall	.-116
    636c: 3d bb        	out	0x1d, r19
    636e: df cf        	rjmp	.-66
    6370: 0c 94 fe 2c  	<unknown>
    6374: 4a 95        	dec	r20
    6376: 12 f0        	brmi	.+4
    6378: 00 0f        	lsl	r16
    637a: e1 f7        	brne	.-8
    637c: 08 95        	ret
    637e: 00 24        	clr	r0
    6380: e8 e0        	ldi	r30, 0x8
    6382: ea 95        	dec	r30
    6384: 32 f0        	brmi	.+12
    6386: 00 1f        	rol	r16
    6388: 00 1c        	rol	r0
    638a: 04 16        	cp	r0, r20
    638c: d0 f3        	brlo	.-12
    638e: 04 1a        	sub	r0, r20
    6390: f8 cf        	rjmp	.-16
    6392: 00 1f        	rol	r16
    6394: 40 2d        	mov	r20, r0
    6396: 00 95        	com	r16
    6398: 08 95        	ret
    639a: 14 9f 10 2d  	<unknown>
    639e: 05 9f 10 0d  	<unknown>
    63a2: 04 9f 00 2d  	<unknown>
    63a6: 11 0d        	add	r17, r1
    63a8: 08 95        	ret
    63aa: 4a 95        	dec	r20
    63ac: 1a f0        	brmi	.+6
    63ae: 00 0f        	lsl	r16
    63b0: 11 1f        	rol	r17
    63b2: fb cf        	rjmp	.-10
    63b4: 08 95        	ret
    63b6: 4a 95        	dec	r20
    63b8: 1a f0        	brmi	.+6
    63ba: 15 95        	asr	r17
    63bc: 07 95        	ror	r16
    63be: fb cf        	rjmp	.-10
    63c0: 08 95        	ret
    63c2: 00 24        	clr	r0
    63c4: 11 24        	clr	r1
    63c6: ef e0        	ldi	r30, 0xf
    63c8: 00 1f        	rol	r16
    63ca: 11 1f        	rol	r17
    63cc: 00 1c        	rol	r0
    63ce: 11 1c        	rol	r1
    63d0: 04 16        	cp	r0, r20
    63d2: 15 06        	cpc	r1, r21
    63d4: 10 f0        	brlo	.+4
    63d6: 04 1a        	sub	r0, r20
    63d8: 15 0a        	sbc	r1, r21
    63da: ea 95        	dec	r30
    63dc: aa f7        	brpl	.-22
    63de: 00 1f        	rol	r16
    63e0: 11 1f        	rol	r17
    63e2: a0 01 00 95  	<unknown>
    63e6: 10 95        	com	r17
    63e8: 08 95        	ret
    63ea: 51 95        	neg	r21
    63ec: 41 95        	neg	r20
    63ee: 50 40        	sbci	r21, 0x0
    63f0: 08 95        	ret
    63f2: ff 27        	clr	r31
    63f4: 55 23        	tst	r21
    63f6: 12 f4        	brpl	.+4
    63f8: f1 60        	ori	r31, 0x1
    63fa: f7 df        	rcall	.-18
    63fc: 11 23        	tst	r17
    63fe: 12 f4        	brpl	.+4
    6400: f0 95        	com	r31
    6402: 07 d0        	rcall	.+14
    6404: 0e 94 e1 31  	<unknown>
    6408: f0 fd        	sbrc	r31, 0x0
    640a: 03 d0        	rcall	.+6
    640c: f1 fd        	sbrc	r31, 0x1
    640e: ed cf        	rjmp	.-38
    6410: 08 95        	ret
    6412: 11 95        	neg	r17
    6414: 01 95        	neg	r16
    6416: 10 40        	sbci	r17, 0x0
    6418: 08 95        	ret
    641a: 22 24        	clr	r2
    641c: 34 9f 30 2d  	<unknown>
    6420: 25 9f 30 0d  	<unknown>
    6424: 16 9f 30 0d  	<unknown>
    6428: 07 9f 30 0d  	<unknown>
    642c: 24 9f 20 2d  	<unknown>
    6430: 31 0d        	add	r19, r1
    6432: 15 9f 20 0d  	<unknown>
    6436: 31 1d        	adc	r19, r1
    6438: 06 9f 20 0d  	<unknown>
    643c: 31 1d        	adc	r19, r1
    643e: 14 9f 10 2d  	<unknown>
    6442: 21 0d        	add	r18, r1
    6444: 32 1d        	adc	r19, r2
    6446: 05 9f 10 0d  	<unknown>
    644a: 21 1d        	adc	r18, r1
    644c: 32 1d        	adc	r19, r2
    644e: 04 9f 00 2d  	<unknown>
    6452: 11 0d        	add	r17, r1
    6454: 22 1d        	adc	r18, r2
    6456: 32 1d        	adc	r19, r2
    6458: 08 95        	ret
    645a: 4a 95        	dec	r20
    645c: 2a f0        	brmi	.+10
    645e: 00 0f        	lsl	r16
    6460: 11 1f        	rol	r17
    6462: 22 1f        	rol	r18
    6464: 33 1f        	rol	r19
    6466: f9 cf        	rjmp	.-14
    6468: 08 95        	ret
    646a: 4a 95        	dec	r20
    646c: 2a f0        	brmi	.+10
    646e: 36 95        	lsr	r19
    6470: 27 95        	ror	r18
    6472: 17 95        	ror	r17
    6474: 07 95        	ror	r16
    6476: f9 cf        	rjmp	.-14
    6478: 08 95        	ret
    647a: 00 24        	clr	r0
    647c: 11 24        	clr	r1
    647e: 10 01 e0 e2  	<unknown>
    6482: ea 95        	dec	r30
    6484: 92 f0        	brmi	.+36
    6486: 00 1f        	rol	r16
    6488: 11 1f        	rol	r17
    648a: 22 1f        	rol	r18
    648c: 33 1f        	rol	r19
    648e: 00 1c        	rol	r0
    6490: 11 1c        	rol	r1
    6492: 22 1c        	rol	r2
    6494: 33 1c        	rol	r3
    6496: 04 16        	cp	r0, r20
    6498: 15 06        	cpc	r1, r21
    649a: 26 06        	cpc	r2, r22
    649c: 37 06        	cpc	r3, r23
    649e: 88 f3        	brlo	.-30
    64a0: 04 1a        	sub	r0, r20
    64a2: 15 0a        	sbc	r1, r21
    64a4: 26 0a        	sbc	r2, r22
    64a6: 37 0a        	sbc	r3, r23
    64a8: ec cf        	rjmp	.-40
    64aa: 00 1f        	rol	r16
    64ac: 11 1f        	rol	r17
    64ae: 22 1f        	rol	r18
    64b0: 33 1f        	rol	r19
    64b2: a0 01 b1 01  	<unknown>
    64b6: 00 95        	com	r16
    64b8: 10 95        	com	r17
    64ba: 20 95        	com	r18
    64bc: 30 95        	com	r19
    64be: 08 95        	ret
    64c0: 30 95        	com	r19
    64c2: 20 95        	com	r18
    64c4: 10 95        	com	r17
    64c6: 01 95        	neg	r16
    64c8: 1f 4f        	sbci	r17, 0xff
    64ca: 2f 4f        	sbci	r18, 0xff
    64cc: 3f 4f        	sbci	r19, 0xff
    64ce: 08 95        	ret
    64d0: ff 27        	clr	r31
    64d2: 11 24        	clr	r1
    64d4: 77 fb        	bst	r23, 0x7
    64d6: 66 0f        	lsl	r22
    64d8: 77 1f        	rol	r23
    64da: 08 94        	sec
    64dc: 09 f4        	brne	.+2
    64de: 77 1f        	rol	r23
    64e0: 67 95        	ror	r22
    64e2: 17 f8        	bld	r1, 0x7
    64e4: ee 27        	clr	r30
    64e6: 00 24        	clr	r0
    64e8: 37 fb        	bst	r19, 0x7
    64ea: 22 0f        	lsl	r18
    64ec: 33 1f        	rol	r19
    64ee: 08 94        	sec
    64f0: 09 f4        	brne	.+2
    64f2: 33 1f        	rol	r19
    64f4: 27 95        	ror	r18
    64f6: 07 f8        	bld	r0, 0x7
    64f8: 08 95        	ret
    64fa: 27 fd        	sbrc	r18, 0x7
    64fc: 0e c0        	rjmp	.+28
    64fe: ee 0f        	lsl	r30
    6500: 00 1f        	rol	r16
    6502: 11 1f        	rol	r17
    6504: 22 1f        	rol	r18
    6506: 3a 95        	dec	r19
    6508: 32 30        	cpi	r19, 0x2
    650a: b8 f7        	brsh	.-18
    650c: 33 23        	tst	r19
    650e: 19 f4        	brne	.+6
    6510: 27 fd        	sbrc	r18, 0x7
    6512: 31 e0        	ldi	r19, 0x1
    6514: 02 c0        	rjmp	.+4
    6516: 27 ff        	sbrs	r18, 0x7
    6518: 30 e0        	ldi	r19, 0x0
    651a: e0 38        	cpi	r30, 0x80
    651c: 21 f4        	brne	.+8
    651e: 00 ff        	sbrs	r16, 0x0
    6520: 08 94        	sec
    6522: 0e f4        	brtc	.+2
    6524: 88 94        	clc
    6526: 0f 4f        	sbci	r16, 0xff
    6528: 1f 4f        	sbci	r17, 0xff
    652a: 2f 4f        	sbci	r18, 0xff
    652c: 3f 4f        	sbci	r19, 0xff
    652e: 32 30        	cpi	r19, 0x2
    6530: 38 f4        	brsh	.+14
    6532: 33 23        	tst	r19
    6534: 19 f4        	brne	.+6
    6536: 27 fd        	sbrc	r18, 0x7
    6538: 31 e0        	ldi	r19, 0x1
    653a: 02 c0        	rjmp	.+4
    653c: 27 ff        	sbrs	r18, 0x7
    653e: 30 e0        	ldi	r19, 0x0
    6540: 3f 3f        	cpi	r19, 0xff
    6542: 29 f0        	breq	.+10
    6544: 22 0f        	lsl	r18
    6546: 00 0c        	lsl	r0
    6548: 37 95        	ror	r19
    654a: 27 95        	ror	r18
    654c: 08 95        	ret
    654e: ac c0        	rjmp	.+344
    6550: 03 2e        	mov	r0, r19
    6552: 00 20        	tst	r0
    6554: 12 f4        	brpl	.+4
    6556: 0e 94 60 32  	<unknown>
    655a: e0 2f        	mov	r30, r16
    655c: 01 2f        	mov	r16, r17
    655e: 12 2f        	mov	r17, r18
    6560: 23 2f        	mov	r18, r19
    6562: 3e e9        	ldi	r19, 0x9e
    6564: d1 cf        	rjmp	.-94
    6566: 00 24        	clr	r0
    6568: f8 cf        	rjmp	.-16
    656a: bc df        	rcall	.-136
    656c: 43 2f        	mov	r20, r19
    656e: 4f 57        	subi	r20, 0x7f
    6570: 48 f0        	brlo	.+18
    6572: 4f 31        	cpi	r20, 0x1f
    6574: 48 f0        	brlo	.+18
    6576: 07 fc        	sbrc	r0, 0x7
    6578: 91 c0        	rjmp	.+290
    657a: 3f e7        	ldi	r19, 0x7f
    657c: 2f ef        	ldi	r18, 0xff
    657e: 1f ef        	ldi	r17, 0xff
    6580: 0f ef        	ldi	r16, 0xff
    6582: 08 95        	ret
    6584: 33 27        	clr	r19
    6586: 8c c0        	rjmp	.+280
    6588: 32 2f        	mov	r19, r18
    658a: 21 2f        	mov	r18, r17
    658c: 10 2f        	mov	r17, r16
    658e: 0e 2f        	mov	r16, r30
    6590: 4f 51        	subi	r20, 0x1f
    6592: 41 95        	neg	r20
    6594: 0e 94 35 32  	<unknown>
    6598: 07 fe        	sbrs	r0, 0x7
    659a: 08 95        	ret
    659c: 0c 94 60 32  	<unknown>
    65a0: f9 01 ee 0f  	<unknown>
    65a4: ff 1f        	rol	r31
    65a6: 37 fb        	bst	r19, 0x7
    65a8: ff 3f        	cpi	r31, 0xff
    65aa: 31 f0        	breq	.+12
    65ac: ef 2b        	or	r30, r31
    65ae: e1 2b        	or	r30, r17
    65b0: e0 2b        	or	r30, r16
    65b2: 88 94        	clc
    65b4: b8 94        	clv
    65b6: 08 95        	ret
    65b8: e0 2b        	or	r30, r16
    65ba: e1 2b        	or	r30, r17
    65bc: 21 f0        	breq	.+8
    65be: 08 94        	sec
    65c0: 98 94        	clz
    65c2: b8 94        	clv
    65c4: 08 95        	ret
    65c6: 98 94        	clz
    65c8: 88 94        	clc
    65ca: 38 94        	sev
    65cc: 08 95        	ret
    65ce: fb 01 ee 0f  	<unknown>
    65d2: ff 1f        	rol	r31
    65d4: 77 fb        	bst	r23, 0x7
    65d6: ff 3f        	cpi	r31, 0xff
    65d8: 31 f0        	breq	.+12
    65da: ef 2b        	or	r30, r31
    65dc: e5 2b        	or	r30, r21
    65de: e4 2b        	or	r30, r20
    65e0: 88 94        	clc
    65e2: b8 94        	clv
    65e4: 08 95        	ret
    65e6: e4 2b        	or	r30, r20
    65e8: e5 2b        	or	r30, r21
    65ea: 69 f3        	breq	.-38
    65ec: e8 cf        	rjmp	.-48
    65ee: ef df        	rcall	.-34
    65f0: 68 f0        	brlo	.+26
    65f2: 21 f4        	brne	.+8
    65f4: 37 23        	and	r19, r23
    65f6: 26 2f        	mov	r18, r22
    65f8: 8a 01 08 95  	<unknown>
    65fc: 37 2f        	mov	r19, r23
    65fe: fb cf        	rjmp	.-10
    6600: e6 df        	rcall	.-52
    6602: 20 f0        	brlo	.+8
    6604: 0b f0        	brvs	.+2
    6606: 08 95        	ret
    6608: 73 27        	eor	r23, r19
    660a: ea f7        	brpl	.-6
    660c: 51 c0        	rjmp	.+162
    660e: c8 df        	rcall	.-112
    6610: e8 f3        	brlo	.-6
    6612: b3 f3        	brvs	.-20
    6614: 61 f3        	breq	.-40
    6616: db df        	rcall	.-74
    6618: c8 f3        	brlo	.-14
    661a: 83 f3        	brvs	.-32
    661c: a1 f3        	breq	.-24
    661e: 58 df        	rcall	.-336
    6620: 40 17        	cp	r20, r16
    6622: 51 07        	cpc	r21, r17
    6624: 62 07        	cpc	r22, r18
    6626: 73 07        	cpc	r23, r19
    6628: 31 f4        	brne	.+12
    662a: 01 14        	cp	r0, r1
    662c: 11 f1        	breq	.+68
    662e: 00 24        	clr	r0
    6630: e8 94        	clt
    6632: 88 94        	clc
    6634: 2b c0        	rjmp	.+86
    6636: 78 f0        	brlo	.+30
    6638: 33 2e        	mov	r3, r19
    663a: 37 2f        	mov	r19, r23
    663c: 73 2d        	mov	r23, r3
    663e: 32 2e        	mov	r3, r18
    6640: 26 2f        	mov	r18, r22
    6642: 63 2d        	mov	r22, r3
    6644: 31 2e        	mov	r3, r17
    6646: 15 2f        	mov	r17, r21
    6648: 53 2d        	mov	r21, r3
    664a: 30 2e        	mov	r3, r16
    664c: 04 2f        	mov	r16, r20
    664e: 43 2d        	mov	r20, r3
    6650: 30 2c        	mov	r3, r0
    6652: 01 2c        	mov	r0, r1
    6654: 13 2c        	mov	r1, r3
    6656: 37 17        	cp	r19, r23
    6658: 39 f0        	breq	.+14
    665a: 66 95        	lsr	r22
    665c: 57 95        	ror	r21
    665e: 47 95        	ror	r20
    6660: f7 95        	ror	r31
    6662: e0 40        	sbci	r30, 0x0
    6664: 73 95        	inc	r23
    6666: f7 cf        	rjmp	.-18
    6668: e7 fb        	bst	r30, 0x7
    666a: ee 0f        	lsl	r30
    666c: e0 e0        	ldi	r30, 0x0
    666e: 10 24        	eor	r1, r0
    6670: 6a f0        	brmi	.+26
    6672: ef 0f        	add	r30, r31
    6674: 04 1f        	adc	r16, r20
    6676: 15 1f        	adc	r17, r21
    6678: 26 1f        	adc	r18, r22
    667a: 60 f4        	brsh	.+24
    667c: 27 95        	ror	r18
    667e: 17 95        	ror	r17
    6680: 07 95        	ror	r16
    6682: e7 95        	ror	r30
    6684: 08 f4        	brsh	.+2
    6686: 68 94        	set
    6688: 33 95        	inc	r19
    668a: 3e cf        	rjmp	.-388
    668c: ef 0b        	sbc	r30, r31
    668e: 04 0b        	sbc	r16, r20
    6690: 15 0b        	sbc	r17, r21
    6692: 26 0b        	sbc	r18, r22
    6694: 39 cf        	rjmp	.-398
    6696: e0 e8        	ldi	r30, 0x80
    6698: 7e 27        	eor	r23, r30
    669a: b9 cf        	rjmp	.-142
    669c: 30 2d        	mov	r19, r0
    669e: 30 78        	andi	r19, 0x80
    66a0: 22 27        	clr	r18
    66a2: 11 27        	clr	r17
    66a4: 00 27        	clr	r16
    66a6: 08 95        	ret
    66a8: 3f e7        	ldi	r19, 0x7f
    66aa: 30 29        	or	r19, r0
    66ac: 20 e8        	ldi	r18, 0x80
    66ae: f9 cf        	rjmp	.-14
    66b0: 3f ef        	ldi	r19, 0xff
    66b2: 2f ef        	ldi	r18, 0xff
    66b4: f6 cf        	rjmp	.-20
    66b6: 8b df        	rcall	.-234
    66b8: d8 f3        	brlo	.-10
    66ba: d1 f3        	breq	.-12
    66bc: 70 78        	andi	r23, 0x80
    66be: 37 27        	eor	r19, r23
    66c0: 08 95        	ret
    66c2: 85 df        	rcall	.-246
    66c4: a8 f3        	brlo	.-22
    66c6: a3 f3        	brvs	.-24
    66c8: f9 cf        	rjmp	.-14
    66ca: 30 78        	andi	r19, 0x80
    66cc: 37 27        	eor	r19, r23
    66ce: 93 cf        	rjmp	.-218
    66d0: 67 df        	rcall	.-306
    66d2: 70 f3        	brlo	.-36
    66d4: 83 f3        	brvs	.-32
    66d6: a9 f3        	breq	.-22
    66d8: 7a df        	rcall	.-268
    66da: 50 f3        	brlo	.-44
    66dc: b3 f3        	brvs	.-20
    66de: a9 f3        	breq	.-22
    66e0: f7 de        	rcall	.-530
    66e2: 01 24        	eor	r0, r1
    66e4: e8 94        	clt
    66e6: 3f 57        	subi	r19, 0x7f
    66e8: e0 40        	sbci	r30, 0x0
    66ea: 37 0f        	add	r19, r23
    66ec: ef 1f        	adc	r30, r31
    66ee: 12 f0        	brmi	.+4
    66f0: d9 f6        	brne	.-74
    66f2: 03 c0        	rjmp	.+6
    66f4: 3a 3e        	cpi	r19, 0xea
    66f6: 90 f2        	brlo	.-92
    66f8: 68 94        	set
    66fa: e0 e0        	ldi	r30, 0x0
    66fc: 0a 92        	st	-Y, r0
    66fe: aa 93        	st	-Y, r26
    6700: 3a 93        	st	-Y, r19
    6702: aa 27        	clr	r26
    6704: 33 24        	clr	r3
    6706: 22 24        	clr	r2
    6708: 33 27        	clr	r19
    670a: 04 9f f0 01  	<unknown>
    670e: 05 9f f0 0d  	<unknown>
    6712: 71 2d        	mov	r23, r1
    6714: 73 1f        	adc	r23, r19
    6716: 14 9f f0 0d  	<unknown>
    671a: 71 1d        	adc	r23, r1
    671c: 22 1c        	rol	r2
    671e: 06 9f 70 0d  	<unknown>
    6722: 21 1c        	adc	r2, r1
    6724: 33 1c        	rol	r3
    6726: 15 9f 70 0d  	<unknown>
    672a: 21 1c        	adc	r2, r1
    672c: 33 1e        	adc	r3, r19
    672e: 24 9f 70 0d  	<unknown>
    6732: 21 1c        	adc	r2, r1
    6734: 33 1e        	adc	r3, r19
    6736: 16 9f 20 0c  	<unknown>
    673a: 31 1c        	adc	r3, r1
    673c: aa 1f        	rol	r26
    673e: 25 9f 20 0c  	<unknown>
    6742: 31 1c        	adc	r3, r1
    6744: a3 1f        	adc	r26, r19
    6746: 26 9f 30 0c  	<unknown>
    674a: a1 1d        	adc	r26, r1
    674c: 39 91        	ld	r19, Y+
    674e: 5e f4        	brtc	.+22
    6750: 33 95        	inc	r19
    6752: a6 95        	lsr	r26
    6754: 37 94        	ror	r3
    6756: 27 94        	ror	r2
    6758: 77 95        	ror	r23
    675a: f7 95        	ror	r31
    675c: e7 95        	ror	r30
    675e: 33 95        	inc	r19
    6760: 31 30        	cpi	r19, 0x1
    6762: bc f3        	brlt	.-18
    6764: 16 c0        	rjmp	.+44
    6766: aa 23        	tst	r26
    6768: 22 f0        	brmi	.+8
    676a: 33 23        	tst	r19
    676c: 51 f4        	brne	.+20
    676e: 33 95        	inc	r19
    6770: 10 c0        	rjmp	.+32
    6772: 33 95        	inc	r19
    6774: 71 f4        	brne	.+28
    6776: a9 91        	ld	r26, Y+
    6778: 09 90        	ld	r0, Y+
    677a: 96 cf        	rjmp	.-212
    677c: a7 fd        	sbrc	r26, 0x7
    677e: 09 c0        	rjmp	.+18
    6780: 3a 95        	dec	r19
    6782: ee 0f        	lsl	r30
    6784: ff 1f        	rol	r31
    6786: 77 1f        	rol	r23
    6788: 22 1c        	rol	r2
    678a: 33 1c        	rol	r3
    678c: aa 1f        	rol	r26
    678e: 32 30        	cpi	r19, 0x2
    6790: a8 f7        	brsh	.-22
    6792: e8 94        	clt
    6794: fe 2b        	or	r31, r30
    6796: 09 f0        	breq	.+2
    6798: 68 94        	set
    679a: 2a 2f        	mov	r18, r26
    679c: 81 01 e7 2f  	<unknown>
    67a0: a9 91        	ld	r26, Y+
    67a2: 09 90        	ld	r0, Y+
    67a4: ba ce        	rjmp	.-652
    67a6: 13 df        	rcall	.-474
    67a8: 10 f0        	brlo	.+4
    67aa: 0b f0        	brvs	.+2
    67ac: 87 cf        	rjmp	.-242
    67ae: 80 cf        	rjmp	.-256
    67b0: 0e df        	rcall	.-484
    67b2: e9 f3        	breq	.-6
    67b4: e0 f3        	brlo	.-8
    67b6: 03 2e        	mov	r0, r19
    67b8: 07 26        	eor	r0, r23
    67ba: 70 cf        	rjmp	.-288
    67bc: 03 2e        	mov	r0, r19
    67be: 07 26        	eor	r0, r23
    67c0: 73 cf        	rjmp	.-282
    67c2: ee de        	rcall	.-548
    67c4: a0 f3        	brlo	.-24
    67c6: 7b f3        	brvs	.-34
    67c8: 99 f3        	breq	.-26
    67ca: 01 df        	rcall	.-510
    67cc: 80 f3        	brlo	.-32
    67ce: 9b f3        	brvs	.-26
    67d0: a9 f3        	breq	.-22
    67d2: 7e de        	rcall	.-772
    67d4: 01 24        	eor	r0, r1
    67d6: 27 fd        	sbrc	r18, 0x7
    67d8: 06 c0        	rjmp	.+12
    67da: 00 0f        	lsl	r16
    67dc: 11 1f        	rol	r17
    67de: 22 1f        	rol	r18
    67e0: 31 50        	subi	r19, 0x1
    67e2: e0 40        	sbci	r30, 0x0
    67e4: f8 cf        	rjmp	.-16
    67e6: 67 fd        	sbrc	r22, 0x7
    67e8: 06 c0        	rjmp	.+12
    67ea: 44 0f        	lsl	r20
    67ec: 55 1f        	rol	r21
    67ee: 66 1f        	rol	r22
    67f0: 71 50        	subi	r23, 0x1
    67f2: f0 40        	sbci	r31, 0x0
    67f4: f8 cf        	rjmp	.-16
    67f6: e8 94        	clt
    67f8: 37 1b        	sub	r19, r23
    67fa: ef 0b        	sbc	r30, r31
    67fc: 31 58        	subi	r19, 0x81
    67fe: ef 4f        	sbci	r30, 0xff
    6800: 2a f0        	brmi	.+10
    6802: ee 23        	tst	r30
    6804: e9 f6        	brne	.-70
    6806: 3f 3f        	cpi	r19, 0xff
    6808: d9 f2        	breq	.-74
    680a: 03 c0        	rjmp	.+6
    680c: 3a 3e        	cpi	r19, 0xea
    680e: a8 f2        	brlo	.-86
    6810: 68 94        	set
    6812: e0 e0        	ldi	r30, 0x0
    6814: f0 e0        	ldi	r31, 0x0
    6816: 11 24        	clr	r1
    6818: 13 94        	inc	r1
    681a: 40 17        	cp	r20, r16
    681c: 51 07        	cpc	r21, r17
    681e: 62 07        	cpc	r22, r18
    6820: 38 f0        	brlo	.+14
    6822: 31 50        	subi	r19, 0x1
    6824: 08 f4        	brsh	.+2
    6826: 68 94        	set
    6828: 00 0f        	lsl	r16
    682a: 11 1f        	rol	r17
    682c: 22 1f        	rol	r18
    682e: ee 1f        	rol	r30
    6830: 04 1b        	sub	r16, r20
    6832: 15 0b        	sbc	r17, r21
    6834: 26 0b        	sbc	r18, r22
    6836: ef 0b        	sbc	r30, r31
    6838: 00 0f        	lsl	r16
    683a: 11 1f        	rol	r17
    683c: 22 1f        	rol	r18
    683e: ee 1f        	rol	r30
    6840: aa 93        	st	-Y, r26
    6842: 79 e1        	ldi	r23, 0x19
    6844: 7a 95        	dec	r23
    6846: aa f0        	brmi	.+42
    6848: 04 17        	cp	r16, r20
    684a: 15 07        	cpc	r17, r21
    684c: 26 07        	cpc	r18, r22
    684e: ef 07        	cpc	r30, r31
    6850: 30 f0        	brlo	.+12
    6852: 04 1b        	sub	r16, r20
    6854: 15 0b        	sbc	r17, r21
    6856: 26 0b        	sbc	r18, r22
    6858: ef 0b        	sbc	r30, r31
    685a: 08 94        	sec
    685c: 01 c0        	rjmp	.+2
    685e: 88 94        	clc
    6860: 11 1c        	rol	r1
    6862: 22 1c        	rol	r2
    6864: 33 1c        	rol	r3
    6866: aa 1f        	rol	r26
    6868: 00 0f        	lsl	r16
    686a: 11 1f        	rol	r17
    686c: 22 1f        	rol	r18
    686e: ee 1f        	rol	r30
    6870: e9 cf        	rjmp	.-46
    6872: f0 f9        	bld	r31, 0x0
    6874: e8 94        	clt
    6876: e2 2b        	or	r30, r18
    6878: e1 2b        	or	r30, r17
    687a: e0 2b        	or	r30, r16
    687c: 09 f0        	breq	.+2
    687e: 68 94        	set
    6880: a6 95        	lsr	r26
    6882: 37 94        	ror	r3
    6884: 27 94        	ror	r2
    6886: 17 94        	ror	r1
    6888: e7 95        	ror	r30
    688a: 08 f4        	brsh	.+2
    688c: 68 94        	set
    688e: 73 95        	inc	r23
    6890: b9 f3        	breq	.-18
    6892: a9 91        	ld	r26, Y+
    6894: 33 23        	tst	r19
    6896: 11 f0        	breq	.+4
    6898: f0 ff        	sbrs	r31, 0x0
    689a: 09 c0        	rjmp	.+18
    689c: 36 94        	lsr	r3
    689e: 27 94        	ror	r2
    68a0: 17 94        	ror	r1
    68a2: e7 95        	ror	r30
    68a4: 08 f4        	brsh	.+2
    68a6: 68 94        	set
    68a8: 33 95        	inc	r19
    68aa: 31 30        	cpi	r19, 0x1
    68ac: bc f3        	brlt	.-18
    68ae: 01 2d        	mov	r16, r1
    68b0: 12 2d        	mov	r17, r2
    68b2: 23 2d        	mov	r18, r3
    68b4: 32 ce        	rjmp	.-924
    68b6: 8b ce        	rjmp	.-746
    68b8: 98 94        	clz
    68ba: 08 95        	ret
    68bc: 18 94        	sez
    68be: 08 95        	ret
    68c0: 6f de        	rcall	.-802
    68c2: d0 f3        	brlo	.-12
    68c4: c1 f3        	breq	.-16
    68c6: 83 de        	rcall	.-762
    68c8: b8 f3        	brlo	.-18
    68ca: 04 17        	cp	r16, r20
    68cc: 15 07        	cpc	r17, r21
    68ce: 26 07        	cpc	r18, r22
    68d0: 37 07        	cpc	r19, r23
    68d2: 08 95        	ret
    68d4: 7c de        	rcall	.-776
    68d6: a0 f0        	brlo	.+40
    68d8: 63 de        	rcall	.-826
    68da: 90 f0        	brlo	.+36
    68dc: 29 f0        	breq	.+10
    68de: e3 2f        	mov	r30, r19
    68e0: e7 27        	eor	r30, r23
    68e2: 3a f4        	brpl	.+14
    68e4: 73 17        	cp	r23, r19
    68e6: 08 95        	ret
    68e8: 72 de        	rcall	.-796
    68ea: 51 f0        	breq	.+20
    68ec: 4e f0        	brts	.+18
    68ee: 08 94        	sec
    68f0: 08 95        	ret
    68f2: 04 17        	cp	r16, r20
    68f4: 15 07        	cpc	r17, r21
    68f6: 26 07        	cpc	r18, r22
    68f8: 37 07        	cpc	r19, r23
    68fa: 19 f0        	breq	.+6
    68fc: 16 f4        	brtc	.+4
    68fe: b8 f7        	brsh	.-18
    6900: 88 94        	clc
    6902: 08 95        	ret
    6904: 64 de        	rcall	.-824
    6906: e0 f3        	brlo	.-8
    6908: 4b de        	rcall	.-874
    690a: d0 f3        	brlo	.-12
    690c: e7 df        	rcall	.-50
    690e: c0 f3        	brlo	.-16
    6910: 08 94        	sec
    6912: 08 95        	ret
    6914: 75 91 65 91  	<unknown>
    6918: 55 91 45 91  	<unknown>
    691c: 15 90 11 fa  	<unknown>
    6920: 25 90 35 90  	<unknown>
    6924: 08 95        	ret
    6926: f9 df        	rcall	.-14
    6928: 04 1b        	sub	r16, r20
    692a: 10 e0        	ldi	r17, 0x0
    692c: 03 c0        	rjmp	.+6
    692e: f4 df        	rcall	.-24
    6930: 04 1b        	sub	r16, r20
    6932: 15 0b        	sbc	r17, r21
    6934: 20 e0        	ldi	r18, 0x0
    6936: 30 e0        	ldi	r19, 0x0
    6938: 05 c0        	rjmp	.+10
    693a: ec df        	rcall	.-40
    693c: 04 1b        	sub	r16, r20
    693e: 15 0b        	sbc	r17, r21
    6940: 26 0b        	sbc	r18, r22
    6942: 37 0b        	sbc	r19, r23
    6944: b8 f0        	brlo	.+46
    6946: 10 fc        	sbrc	r1, 0x0
    6948: 17 c0        	rjmp	.+46
    694a: 45 91 05 90  	<unknown>
    694e: e0 0f        	add	r30, r16
    6950: f1 1f        	adc	r31, r17
    6952: 04 17        	cp	r16, r20
    6954: 10 05        	cpc	r17, r0
    6956: 40 e0        	ldi	r20, 0x0
    6958: 24 07        	cpc	r18, r20
    695a: 34 07        	cpc	r19, r20
    695c: 58 f4        	brsh	.+22
    695e: 36 f4        	brtc	.+12
    6960: 04 91 00 24  	<unknown>
    6964: f1 01 e0 1b  	<unknown>
    6968: f0 09        	sbc	r31, r0
    696a: 09 94 e0 0f  	<unknown>
    696e: f1 1f        	adc	r31, r17
    6970: 25 90 35 90  	<unknown>
    6974: f1 01 09 94  	<unknown>
    6978: 11 f4        	brne	.+4
    697a: d6 f7        	brtc	.-12
    697c: f1 cf        	rjmp	.-30
    697e: 31 96 0e f0  	<unknown>
    6982: 31 96 50 e0  	<unknown>
    6986: 60 e0        	ldi	r22, 0x0
    6988: 70 e0        	ldi	r23, 0x0
    698a: 45 91 4b 3f  	<unknown>
    698e: 48 f0        	brlo	.+18
    6990: 89 f3        	breq	.-30
    6992: 4f 3f        	cpi	r20, 0xff
    6994: 29 f0        	breq	.+10
    6996: 4e 3f        	cpi	r20, 0xfe
    6998: 11 f0        	breq	.+4
    699a: 75 91 65 91  	<unknown>
    699e: 55 91 45 91  	<unknown>
    69a2: 04 1b        	sub	r16, r20
    69a4: 15 0b        	sbc	r17, r21
    69a6: 26 0b        	sbc	r18, r22
    69a8: 37 0b        	sbc	r19, r23
    69aa: 39 f3        	breq	.-50
    69ac: 18 f3        	brlo	.-58
    69ae: e7 cf        	rjmp	.-50
    69b0: af 93 bf 93  	<unknown>
    69b4: d8 01 05 90  	<unknown>
    69b8: 0d 92        	st	X+, r0
    69ba: 41 50        	subi	r20, 0x1
    69bc: 50 40        	sbci	r21, 0x0
    69be: d9 f7        	brne	.-10
    69c0: bf 91 af 91  	<unknown>
    69c4: 08 95        	ret
    69c6: fa 92        	st	-Y, r15
    69c8: ea 92        	st	-Y, r14
    69ca: da 92        	st	-Y, r13
    69cc: ca 92        	st	-Y, r12
    69ce: ba 92        	st	-Y, r11
    69d0: aa 92        	st	-Y, r10
    69d2: 9a 92        	st	-Y, r9
    69d4: 8a 92        	st	-Y, r8
    69d6: 7a 92        	st	-Y, r7
    69d8: 6a 92        	st	-Y, r6
    69da: 5a 92        	st	-Y, r5
    69dc: 4a 92        	st	-Y, r4
    69de: ba 93        	st	-Y, r27
    69e0: aa 93        	st	-Y, r26
    69e2: 9a 93        	st	-Y, r25
    69e4: 8a 93        	st	-Y, r24
    69e6: 08 95        	ret
    69e8: ff 84        	ldd	r15, Y+7
    69ea: ee 84        	ldd	r14, Y+6
    69ec: dd 84        	ldd	r13, Y+5
    69ee: cc 84        	ldd	r12, Y+4
    69f0: bb 84        	ldd	r11, Y+3
    69f2: aa 84        	ldd	r10, Y+2
    69f4: 99 84        	ldd	r9, Y+1
    69f6: 88 84        	ldd	r8, Y+0
    69f8: 7f 80        	ldd	r7, Y+7
    69fa: 6e 80        	ldd	r6, Y+6
    69fc: 5d 80        	ldd	r5, Y+5
    69fe: 4c 80        	ldd	r4, Y+4
    6a00: bb 81        	ldd	r27, Y+3
    6a02: aa 81        	ldd	r26, Y+2
    6a04: 99 81        	ldd	r25, Y+1
    6a06: 88 81        	ldd	r24, Y+0
    6a08: f0 e0        	ldi	r31, 0x0
    6a0a: ec 0f        	add	r30, r28
    6a0c: fd 1f        	adc	r31, r29
    6a0e: ef 01 08 95  	<unknown>
    6a12: 80 81        	ldd	r24, Z+0
    6a14: 08 17        	cp	r16, r24
    6a16: 81 81        	ldd	r24, Z+1
    6a18: 18 07        	cpc	r17, r24
    6a1a: 82 81        	ldd	r24, Z+2
    6a1c: 28 07        	cpc	r18, r24
    6a1e: 83 81        	ldd	r24, Z+3
    6a20: 38 07        	cpc	r19, r24
    6a22: 84 81        	ldd	r24, Z+4
    6a24: 48 07        	cpc	r20, r24
    6a26: 85 81        	ldd	r24, Z+5
    6a28: 58 07        	cpc	r21, r24
    6a2a: 86 81        	ldd	r24, Z+6
    6a2c: 68 07        	cpc	r22, r24
    6a2e: 87 81        	ldd	r24, Z+7
    6a30: 78 07        	cpc	r23, r24
    6a32: 08 95        	ret
    6a34: 01 e0        	ldi	r16, 0x1
    6a36: 08 95        	ret
    6a38: bd 01 f8 01  	<unknown>
    6a3c: d9 01 02 c0  	<unknown>
    6a40: 41 50        	subi	r20, 0x1
    6a42: 50 40        	sbci	r21, 0x0
    6a44: 04 2f        	mov	r16, r20
    6a46: 05 2b        	or	r16, r21
    6a48: 51 f0        	breq	.+20
    6a4a: 01 91        	ld	r16, Z+
    6a4c: 1d 91        	ld	r17, X+
    6a4e: 01 17        	cp	r16, r17
    6a50: b9 f3        	breq	.-18
    6a52: 18 f4        	brsh	.+6
    6a54: 0f ef        	ldi	r16, 0xff
    6a56: 1f ef        	ldi	r17, 0xff
    6a58: 04 c0        	rjmp	.+8
    6a5a: 01 e0        	ldi	r16, 0x1
    6a5c: 01 c0        	rjmp	.+2
    6a5e: 00 e0        	ldi	r16, 0x0
    6a60: 10 e0        	ldi	r17, 0x0
    6a62: db 01 08 95  	<unknown>
    6a66: f8 01 03 c0  	<unknown>
    6a6a: 21 93        	st	Z+, r18
    6a6c: 41 50        	subi	r20, 0x1
    6a6e: 50 40        	sbci	r21, 0x0
    6a70: 34 2f        	mov	r19, r20
    6a72: 35 2b        	or	r19, r21
    6a74: d1 f7        	brne	.-12
    6a76: 08 95        	ret
    6a78: 0c 94 3e 35  	<unknown>
    6a7c: 9a 93        	st	-Y, r25
    6a7e: 8a 93        	st	-Y, r24
    6a80: c8 01 02 c0  	<unknown>
    6a84: 0e 94 5b 35  	<unknown>
    6a88: 8c 01 0e 94  	<unknown>
    6a8c: 90 37        	cpi	r25, 0x70
    6a8e: 20 2f        	mov	r18, r16
    6a90: 01 2b        	or	r16, r17
    6a92: 69 f4        	brne	.+26
    6a94: ec e7        	ldi	r30, 0x7c
    6a96: f7 e0        	ldi	r31, 0x7
    6a98: 20 81        	ldd	r18, Z+0
    6a9a: 31 81        	ldd	r19, Z+1
    6a9c: 00 e0        	ldi	r16, 0x0
    6a9e: 20 30        	cpi	r18, 0x0
    6aa0: 30 07        	cpc	r19, r16
    6aa2: 81 f3        	breq	.-32
    6aa4: e0 91 7c 07  	<unknown>
    6aa8: f3 2f        	mov	r31, r19
    6aaa: 09 95 ed cf  	<unknown>
    6aae: 02 2f        	mov	r16, r18
    6ab0: 89 91        	ld	r24, Y+
    6ab2: 99 91        	ld	r25, Y+
    6ab4: 08 95        	ret
    6ab6: 0c 94 f2 30  	<unknown>
    6aba: 22 97 9e 01  	<unknown>
    6abe: 2e 5f        	subi	r18, 0xfe
    6ac0: 3f 4f        	sbci	r19, 0xff
    6ac2: 28 83        	std	Y+0, r18
    6ac4: 39 83        	std	Y+1, r19
    6ac6: be 01 a8 01  	<unknown>
    6aca: 21 e0        	ldi	r18, 0x1
    6acc: 30 e0        	ldi	r19, 0x0
    6ace: 04 ec        	ldi	r16, 0xc4
    6ad0: 16 e3        	ldi	r17, 0x36
    6ad2: 0e 94 0b 36  	<unknown>
    6ad6: 22 96 08 95  	<unknown>
    6ada: 10 e0        	ldi	r17, 0x0
    6adc: 0c 94 b4 20  	<unknown>
    6ae0: 22 97 9e 01  	<unknown>
    6ae4: 2e 5f        	subi	r18, 0xfe
    6ae6: 3f 4f        	sbci	r19, 0xff
    6ae8: 28 83        	std	Y+0, r18
    6aea: 39 83        	std	Y+1, r19
    6aec: be 01 40 e0  	<unknown>
    6af0: 50 e0        	ldi	r21, 0x0
    6af2: 2d e6        	ldi	r18, 0x6d
    6af4: 35 e3        	ldi	r19, 0x35
    6af6: 0e 94 71 2e  	<unknown>
    6afa: 22 96 08 95  	<unknown>
    6afe: 20 e0        	ldi	r18, 0x0
    6b00: 06 d0        	rcall	.+12
    6b02: e9 f7        	brne	.-6
    6b04: 08 95        	ret
    6b06: 25 91 02 d0  	<unknown>
    6b0a: e9 f7        	brne	.-6
    6b0c: 08 95        	ret
    6b0e: 2d 93        	st	X+, r18
    6b10: 01 50        	subi	r16, 0x1
    6b12: 10 40        	sbci	r17, 0x0
    6b14: 20 2f        	mov	r18, r16
    6b16: 21 2b        	or	r18, r17
    6b18: 08 95        	ret
    6b1a: 82 ed        	ldi	r24, 0xd2
    6b1c: 9f e6        	ldi	r25, 0x6f
    6b1e: fc 01 05 91  	<unknown>
    6b22: 14 91 fc 01  	<unknown>
    6b26: 32 96 a5 91  	<unknown>
    6b2a: b4 91 fc 01  	<unknown>
    6b2e: 34 96 25 91  	<unknown>
    6b32: 34 91 42 2f  	<unknown>
    6b36: 43 2b        	or	r20, r19
    6b38: 19 f0        	breq	.+6
    6b3a: f9 01 e4 df  	<unknown>
    6b3e: 01 c0        	rjmp	.+2
    6b40: de df        	rcall	.-68
    6b42: 06 96 1f e6  	<unknown>
    6b46: 8e 3d        	cpi	r24, 0xde
    6b48: 91 07        	cpc	r25, r17
    6b4a: 48 f3        	brlo	.-46
    6b4c: 08 95        	ret
    6b4e: 1b 2f        	mov	r17, r27
    6b50: 6a 2f        	mov	r22, r26
    6b52: f9 01 a0 81  	<unknown>
    6b56: b1 81        	ldd	r27, Z+1
    6b58: ad 01 4f 5f  	<unknown>
    6b5c: 5f 4f        	sbci	r21, 0xff
    6b5e: 40 83        	std	Z+0, r20
    6b60: 51 83        	std	Z+1, r21
    6b62: 0c 93        	st	X, r16
    6b64: a6 2f        	mov	r26, r22
    6b66: b1 2f        	mov	r27, r17
    6b68: 08 95        	ret
    6b6a: ba 93        	st	-Y, r27
    6b6c: aa 93        	st	-Y, r26
    6b6e: 24 97 0a 83  	<unknown>
    6b72: 1b 83        	std	Y+3, r17
    6b74: 89 01 9e 01  	<unknown>
    6b78: 2a 5f        	subi	r18, 0xfa
    6b7a: 3f 4f        	sbci	r19, 0xff
    6b7c: 28 83        	std	Y+0, r18
    6b7e: 39 83        	std	Y+1, r19
    6b80: be 01 ae 01  	<unknown>
    6b84: 4e 5f        	subi	r20, 0xfe
    6b86: 5f 4f        	sbci	r21, 0xff
    6b88: 27 ea        	ldi	r18, 0xa7
    6b8a: 35 e3        	ldi	r19, 0x35
    6b8c: 0e 94 71 2e  	<unknown>
    6b90: 20 e0        	ldi	r18, 0x0
    6b92: aa 81        	ldd	r26, Y+2
    6b94: bb 81        	ldd	r27, Y+3
    6b96: 2c 93        	st	X, r18
    6b98: 24 96 a9 91  	<unknown>
    6b9c: b9 91        	ld	r27, Y+
    6b9e: 08 95        	ret
    6ba0: f8 01 01 c0  	<unknown>
    6ba4: 31 96 20 81  	<unknown>
    6ba8: 22 23        	tst	r18
    6baa: e1 f7        	brne	.-8
    6bac: e0 1b        	sub	r30, r16
    6bae: f1 0b        	sbc	r31, r17
    6bb0: 8f 01 08 95  	<unknown>
    6bb4: 8f 01 25 91  	<unknown>
    6bb8: 22 23        	tst	r18
    6bba: e9 f7        	brne	.-6
    6bbc: e0 1b        	sub	r30, r16
    6bbe: f1 0b        	sbc	r31, r17
    6bc0: 31 97 8f 01  	<unknown>
    6bc4: 08 95        	ret
    6bc6: ee e7        	ldi	r30, 0x7e
    6bc8: f7 e0        	ldi	r31, 0x7
    6bca: 00 81        	ldd	r16, Z+0
    6bcc: 11 81        	ldd	r17, Z+1
    6bce: 01 2b        	or	r16, r17
    6bd0: 19 f0        	breq	.+6
    6bd2: 00 e0        	ldi	r16, 0x0
    6bd4: 10 e0        	ldi	r17, 0x0
    6bd6: 08 95        	ret
    6bd8: 00 e6        	ldi	r16, 0x60
    6bda: 13 e0        	ldi	r17, 0x3
    6bdc: 00 83        	std	Z+0, r16
    6bde: 11 83        	std	Z+1, r17
    6be0: 20 e0        	ldi	r18, 0x0
    6be2: 32 e0        	ldi	r19, 0x2
    6be4: f8 01 20 83  	<unknown>
    6be8: 31 83        	std	Z+1, r19
    6bea: 08 95        	ret
    6bec: 0e 94 ed 34  	<unknown>
    6bf0: d8 01 89 01  	<unknown>
    6bf4: ca 01 2b 01  	<unknown>
    6bf8: 08 c0        	rjmp	.+16
    6bfa: fc 01 21 91  	<unknown>
    6bfe: cf 01 fd 01  	<unknown>
    6c02: 09 95 2f ef  	<unknown>
    6c06: 42 0e        	add	r4, r18
    6c08: 52 1e        	adc	r5, r18
    6c0a: 24 2d        	mov	r18, r4
    6c0c: 25 29        	or	r18, r5
    6c0e: a9 f7        	brne	.-22
    6c10: e6 e0        	ldi	r30, 0x6
    6c12: 0c 94 fe 34  	<unknown>
    6c16: 0e 94 e4 34  	<unknown>
    6c1a: 28 97 08 83  	<unknown>
    6c1e: 19 83        	std	Y+1, r17
    6c20: c9 01 6a 01  	<unknown>
    6c24: 5b 01 04 c0  	<unknown>
    6c28: 97 d0        	rcall	.+302
    6c2a: a6 01 9d d0  	<unknown>
    6c2e: 8f d0        	rcall	.+286
    6c30: f6 01 00 81  	<unknown>
    6c34: 00 23        	tst	r16
    6c36: 31 f4        	brne	.+12
    6c38: 00 e0        	ldi	r16, 0x0
    6c3a: 10 e0        	ldi	r17, 0x0
    6c3c: 28 96 ef e0  	<unknown>
    6c40: 0c 94 f5 34  	<unknown>
    6c44: 05 32        	cpi	r16, 0x25
    6c46: 81 f7        	brne	.-32
    6c48: 82 d0        	rcall	.+260
    6c4a: f6 01 41 90  	<unknown>
    6c4e: 6f 01 04 2d  	<unknown>
    6c52: 05 52        	subi	r16, 0x25
    6c54: 09 f4        	brne	.+2
    6c56: 77 c0        	rjmp	.+238
    6c58: 03 53        	subi	r16, 0x33
    6c5a: 09 f4        	brne	.+2
    6c5c: 63 c0        	rjmp	.+198
    6c5e: 0b 50        	subi	r16, 0xb
    6c60: a1 f0        	breq	.+40
    6c62: 0a 95        	dec	r16
    6c64: f1 f0        	breq	.+60
    6c66: 05 50        	subi	r16, 0x5
    6c68: e1 f0        	breq	.+56
    6c6a: 06 50        	subi	r16, 0x6
    6c6c: 09 f4        	brne	.+2
    6c6e: 5a c0        	rjmp	.+180
    6c70: 0a 95        	dec	r16
    6c72: 09 f4        	brne	.+2
    6c74: 59 c0        	rjmp	.+178
    6c76: 03 50        	subi	r16, 0x3
    6c78: 09 f4        	brne	.+2
    6c7a: 5a c0        	rjmp	.+180
    6c7c: 02 50        	subi	r16, 0x2
    6c7e: 09 f4        	brne	.+2
    6c80: 51 c0        	rjmp	.+162
    6c82: 03 50        	subi	r16, 0x3
    6c84: 09 f4        	brne	.+2
    6c86: 4e c0        	rjmp	.+156
    6c88: d3 cf        	rjmp	.-90
    6c8a: 7a d0        	rcall	.+244
    6c8c: 0d 91        	ld	r16, X+
    6c8e: 11 96 a0 83  	<unknown>
    6c92: b1 83        	std	Z+1, r27
    6c94: 0a 83        	std	Y+2, r16
    6c96: 60 d0        	rcall	.+192
    6c98: ae 01 4e 5f  	<unknown>
    6c9c: 5f 4f        	sbci	r21, 0xff
    6c9e: 64 d0        	rcall	.+200
    6ca0: c7 cf        	rjmp	.-114
    6ca2: 68 d0        	rcall	.+208
    6ca4: 77 20        	tst	r7
    6ca6: 22 f4        	brpl	.+8
    6ca8: 57 d0        	rcall	.+174
    6caa: 4f e6        	ldi	r20, 0x6f
    6cac: 56 e0        	ldi	r21, 0x6
    6cae: 5c d0        	rcall	.+184
    6cb0: 0f e6        	ldi	r16, 0x6f
    6cb2: 40 16        	cp	r4, r16
    6cb4: 11 f4        	brne	.+4
    6cb6: 08 e0        	ldi	r16, 0x8
    6cb8: 07 c0        	rjmp	.+14
    6cba: 04 2d        	mov	r16, r4
    6cbc: 00 62        	ori	r16, 0x20
    6cbe: 08 37        	cpi	r16, 0x78
    6cc0: 11 f0        	breq	.+4
    6cc2: 0a e0        	ldi	r16, 0xa
    6cc4: 01 c0        	rjmp	.+2
    6cc6: 00 e1        	ldi	r16, 0x10
    6cc8: e0 2e        	mov	r14, r16
    6cca: 06 e0        	ldi	r16, 0x6
    6ccc: 80 2e        	mov	r8, r16
    6cce: 99 24        	clr	r9
    6cd0: d3 01 04 e6  	<unknown>
    6cd4: 40 16        	cp	r4, r16
    6cd6: 29 f4        	brne	.+10
    6cd8: 77 20        	tst	r7
    6cda: 1a f4        	brpl	.+6
    6cdc: b1 95        	neg	r27
    6cde: a1 95        	neg	r26
    6ce0: b0 40        	sbci	r27, 0x0
    6ce2: 0f ef        	ldi	r16, 0xff
    6ce4: 80 0e        	add	r8, r16
    6ce6: 90 1e        	adc	r9, r16
    6ce8: 3a d0        	rcall	.+116
    6cea: 40 5d        	subi	r20, 0xd0
    6cec: 4a 33        	cpi	r20, 0x3a
    6cee: 18 f0        	brlo	.+6
    6cf0: 04 2d        	mov	r16, r4
    6cf2: 01 55        	subi	r16, 0x51
    6cf4: 40 0f        	add	r20, r16
    6cf6: 8e 01 0e 5f  	<unknown>
    6cfa: 1f 4f        	sbci	r17, 0xff
    6cfc: 08 0d        	add	r16, r8
    6cfe: 19 1d        	adc	r17, r9
    6d00: 38 01 f8 01  	<unknown>
    6d04: 40 83        	std	Z+0, r20
    6d06: 2b d0        	rcall	.+86
    6d08: d8 01 01 2b  	<unknown>
    6d0c: 29 f0        	breq	.+10
    6d0e: 01 e0        	ldi	r16, 0x1
    6d10: 80 16        	cp	r8, r16
    6d12: 00 e0        	ldi	r16, 0x0
    6d14: 90 06        	cpc	r9, r16
    6d16: 2c f7        	brge	.-54
    6d18: 66 e0        	ldi	r22, 0x6
    6d1a: 70 e0        	ldi	r23, 0x0
    6d1c: 68 19        	sub	r22, r8
    6d1e: 79 09        	sbc	r23, r9
    6d20: a3 01 bd cf  	<unknown>
    6d24: 27 d0        	rcall	.+78
    6d26: c4 cf        	rjmp	.-120
    6d28: 25 d0        	rcall	.+74
    6d2a: 08 e7        	ldi	r16, 0x78
    6d2c: 40 2e        	mov	r4, r16
    6d2e: c0 cf        	rjmp	.-128
    6d30: 27 d0        	rcall	.+78
    6d32: 4d 90        	ld	r4, X+
    6d34: 5d 90        	ld	r5, X+
    6d36: a0 83        	std	Z+0, r26
    6d38: b1 83        	std	Z+1, r27
    6d3a: 82 01 0e 94  	<unknown>
    6d3e: d0 35        	cpi	r29, 0x50
    6d40: b8 01 a2 01  	<unknown>
    6d44: ac cf        	rjmp	.-168
    6d46: 08 d0        	rcall	.+16
    6d48: 41 e7        	ldi	r20, 0x71
    6d4a: 56 e0        	ldi	r21, 0x6
    6d4c: a8 cf        	rjmp	.-176
    6d4e: 01 e0        	ldi	r16, 0x1
    6d50: c0 0e        	add	r12, r16
    6d52: 00 e0        	ldi	r16, 0x0
    6d54: d0 1e        	adc	r13, r16
    6d56: 08 95        	ret
    6d58: 61 e0        	ldi	r22, 0x1
    6d5a: 70 e0        	ldi	r23, 0x0
    6d5c: 08 95        	ret
    6d5e: 4e 2d        	mov	r20, r14
    6d60: 50 e0        	ldi	r21, 0x0
    6d62: 8d 01 0c 94  	<unknown>
    6d66: e1 31        	cpi	r30, 0x11
    6d68: 9c 01 08 81  	<unknown>
    6d6c: 19 81        	ldd	r17, Y+1
    6d6e: 3e df        	rcall	.-388
    6d70: c8 01 08 95  	<unknown>
    6d74: 05 d0        	rcall	.+10
    6d76: 6d 90        	ld	r6, X+
    6d78: 7d 90        	ld	r7, X+
    6d7a: a0 83        	std	Z+0, r26
    6d7c: b1 83        	std	Z+1, r27
    6d7e: 08 95        	ret
    6d80: f5 01 a0 81  	<unknown>
    6d84: b1 81        	ldd	r27, Z+1
    6d86: 08 95        	ret
    6d88: 0e 94 ef 34  	<unknown>
    6d8c: d8 01 82 2f  	<unknown>
    6d90: 02 2f        	mov	r16, r18
    6d92: 10 e0        	ldi	r17, 0x0
    6d94: 0e 94 b4 20  	<unknown>
    6d98: 08 17        	cp	r16, r24
    6d9a: 10 40        	sbci	r17, 0x0
    6d9c: 11 f4        	brne	.+4
    6d9e: 8d 01 02 c0  	<unknown>
    6da2: 00 e0        	ldi	r16, 0x0
    6da4: 10 e0        	ldi	r17, 0x0
    6da6: e4 e0        	ldi	r30, 0x4
    6da8: 0c 94 00 35  	<unknown>
    6dac: ff cf        	rjmp	.-2
    6dae: 0d 01 d8 01  	<unknown>
    6db2: 01 2b        	or	r16, r17
    6db4: 09 f4        	brne	.+2
    6db6: 55 c0        	rjmp	.+170
    6db8: 12 97 ed 91  	<unknown>
    6dbc: fc 91        	ld	r31, X
    6dbe: 11 97 34 97  	<unknown>
    6dc2: 08 f4        	brsh	.+2
    6dc4: 4e c0        	rjmp	.+156
    6dc6: 00 e8        	ldi	r16, 0x80
    6dc8: 17 e0        	ldi	r17, 0x7
    6dca: f8 01 53 d0  	<unknown>
    6dce: 19 f0        	breq	.+6
    6dd0: a2 17        	cp	r26, r18
    6dd2: b3 07        	cpc	r27, r19
    6dd4: 28 f4        	brsh	.+10
    6dd6: fd 01 22 83  	<unknown>
    6dda: 33 83        	std	Z+3, r19
    6ddc: f8 01 23 c0  	<unknown>
    6de0: f9 01 48 d0  	<unknown>
    6de4: 19 f0        	breq	.+6
    6de6: 2a 17        	cp	r18, r26
    6de8: 3b 07        	cpc	r19, r27
    6dea: d0 f3        	brlo	.-12
    6dec: 40 81        	ldd	r20, Z+0
    6dee: 51 81        	ldd	r21, Z+1
    6df0: 9f 01 24 0f  	<unknown>
    6df4: 35 1f        	adc	r19, r21
    6df6: a2 17        	cp	r26, r18
    6df8: b3 07        	cpc	r27, r19
    6dfa: 98 f1        	brlo	.+102
    6dfc: 2a 17        	cp	r18, r26
    6dfe: 3b 07        	cpc	r19, r27
    6e00: 41 f4        	brne	.+16
    6e02: 2d 91        	ld	r18, X+
    6e04: 3c 91        	ld	r19, X
    6e06: 42 0f        	add	r20, r18
    6e08: 53 1f        	adc	r21, r19
    6e0a: 40 83        	std	Z+0, r20
    6e0c: 51 83        	std	Z+1, r21
    6e0e: df 01 0c c0  	<unknown>
    6e12: 30 d0        	rcall	.+96
    6e14: 21 f0        	breq	.+8
    6e16: 27 d0        	rcall	.+78
    6e18: 26 17        	cp	r18, r22
    6e1a: 37 07        	cpc	r19, r23
    6e1c: 10 f1        	brlo	.+68
    6e1e: 12 96 2d 93  	<unknown>
    6e22: 3c 93        	st	X, r19
    6e24: 13 97 a2 83  	<unknown>
    6e28: b3 83        	std	Z+3, r27
    6e2a: fd 01 23 d0  	<unknown>
    6e2e: c9 f0        	breq	.+50
    6e30: 1a d0        	rcall	.+52
    6e32: 62 17        	cp	r22, r18
    6e34: 73 07        	cpc	r23, r19
    6e36: a9 f4        	brne	.+42
    6e38: 20 e0        	ldi	r18, 0x0
    6e3a: f8 01 20 83  	<unknown>
    6e3e: 21 83        	std	Z+1, r18
    6e40: fd 01 02 81  	<unknown>
    6e44: f3 81        	ldd	r31, Z+3
    6e46: e0 2f        	mov	r30, r16
    6e48: 20 81        	ldd	r18, Z+0
    6e4a: 31 81        	ldd	r19, Z+1
    6e4c: 4d 91        	ld	r20, X+
    6e4e: 5c 91        	ld	r21, X
    6e50: 42 0f        	add	r20, r18
    6e52: 53 1f        	adc	r21, r19
    6e54: 5c 93        	st	X, r21
    6e56: 4e 93        	st	-X, r20
    6e58: 02 81        	ldd	r16, Z+2
    6e5a: 13 81        	ldd	r17, Z+3
    6e5c: fd 01 02 83  	<unknown>
    6e60: 13 83        	std	Z+3, r17
    6e62: d0 01 08 95  	<unknown>
    6e66: 4d 91        	ld	r20, X+
    6e68: 5c 91        	ld	r21, X
    6e6a: 11 97 bd 01  	<unknown>
    6e6e: 64 0f        	add	r22, r20
    6e70: 75 1f        	adc	r23, r21
    6e72: 08 95        	ret
    6e74: 22 81        	ldd	r18, Z+2
    6e76: 33 81        	ldd	r19, Z+3
    6e78: 42 2f        	mov	r20, r18
    6e7a: 43 2b        	or	r20, r19
    6e7c: 08 95        	ret
    6e7e: 9a 93        	st	-Y, r25
    6e80: 8a 93        	st	-Y, r24
    6e82: c8 01 05 c0  	<unknown>
    6e86: 2e 5f        	subi	r18, 0xfe
    6e88: 3f 4f        	sbci	r19, 0xff
    6e8a: 89 01 0e 94  	<unknown>
    6e8e: d7 36        	cpi	r29, 0x67
    6e90: e0 e8        	ldi	r30, 0x80
    6e92: f7 e0        	ldi	r31, 0x7
    6e94: 00 81        	ldd	r16, Z+0
    6e96: 11 81        	ldd	r17, Z+1
    6e98: 20 2f        	mov	r18, r16
    6e9a: 21 2b        	or	r18, r17
    6e9c: 61 f4        	brne	.+24
    6e9e: 02 e8        	ldi	r16, 0x82
    6ea0: 17 e0        	ldi	r17, 0x7
    6ea2: 01 c0        	rjmp	.+2
    6ea4: 37 d0        	rcall	.+110
    6ea6: 29 d0        	rcall	.+82
    6ea8: f1 f0        	breq	.+60
    6eaa: 2e d0        	rcall	.+92
    6eac: d8 f3        	brlo	.-10
    6eae: 22 c0        	rjmp	.+68
    6eb0: 2b d0        	rcall	.+86
    6eb2: 00 f5        	brsh	.+64
    6eb4: 2f d0        	rcall	.+94
    6eb6: 21 d0        	rcall	.+66
    6eb8: d9 f7        	brne	.-10
    6eba: e0 e8        	ldi	r30, 0x80
    6ebc: f7 e0        	ldi	r31, 0x7
    6ebe: 00 81        	ldd	r16, Z+0
    6ec0: f1 81        	ldd	r31, Z+1
    6ec2: e0 2f        	mov	r30, r16
    6ec4: 1e d0        	rcall	.+60
    6ec6: 02 e8        	ldi	r16, 0x82
    6ec8: 17 e0        	ldi	r17, 0x7
    6eca: 07 c0        	rjmp	.+14
    6ecc: fa 01 40 81  	<unknown>
    6ed0: 51 81        	ldd	r21, Z+1
    6ed2: 48 17        	cp	r20, r24
    6ed4: 59 07        	cpc	r21, r25
    6ed6: 70 f4        	brsh	.+28
    6ed8: 1d d0        	rcall	.+58
    6eda: f8 01 40 81  	<unknown>
    6ede: 51 81        	ldd	r21, Z+1
    6ee0: 42 17        	cp	r20, r18
    6ee2: 53 07        	cpc	r21, r19
    6ee4: 99 f7        	brne	.-26
    6ee6: 0e 94 e3 35  	<unknown>
    6eea: 98 01 01 2b  	<unknown>
    6eee: 59 f6        	brne	.-106
    6ef0: 00 e0        	ldi	r16, 0x0
    6ef2: 10 e0        	ldi	r17, 0x0
    6ef4: 89 91        	ld	r24, Y+
    6ef6: 99 91        	ld	r25, Y+
    6ef8: 08 95        	ret
    6efa: 02 d0        	rcall	.+4
    6efc: 23 2b        	or	r18, r19
    6efe: 08 95        	ret
    6f00: f8 01 20 81  	<unknown>
    6f04: 31 81        	ldd	r19, Z+1
    6f06: 08 95        	ret
    6f08: e0 81        	ldd	r30, Z+0
    6f0a: f3 2f        	mov	r31, r19
    6f0c: fa df        	rcall	.-12
    6f0e: 28 17        	cp	r18, r24
    6f10: 39 07        	cpc	r19, r25
    6f12: 08 95        	ret
    6f14: f8 01 00 81  	<unknown>
    6f18: 11 81        	ldd	r17, Z+1
    6f1a: 0e 5f        	subi	r16, 0xfe
    6f1c: 1f 4f        	sbci	r17, 0xff
    6f1e: 08 95        	ret
    6f20: 0e 94 ef 34  	<unknown>
    6f24: c8 01 02 96  	<unknown>
    6f28: 08 17        	cp	r16, r24
    6f2a: 19 07        	cpc	r17, r25
    6f2c: 18 f0        	brlo	.+6
    6f2e: 00 e0        	ldi	r16, 0x0
    6f30: 10 e0        	ldi	r17, 0x0
    6f32: 47 c0        	rjmp	.+142
    6f34: 84 30        	cpi	r24, 0x4
    6f36: 00 e0        	ldi	r16, 0x0
    6f38: 90 07        	cpc	r25, r16
    6f3a: 10 f4        	brsh	.+4
    6f3c: 84 e0        	ldi	r24, 0x4
    6f3e: 90 e0        	ldi	r25, 0x0
    6f40: 8c 01 9d df  	<unknown>
    6f44: 20 2f        	mov	r18, r16
    6f46: 21 2b        	or	r18, r17
    6f48: 91 f3        	breq	.-28
    6f4a: da df        	rcall	.-76
    6f4c: f9 01 a0 81  	<unknown>
    6f50: b1 81        	ldd	r27, Z+1
    6f52: 14 97 a8 17  	<unknown>
    6f56: b9 07        	cpc	r27, r25
    6f58: 30 f4        	brsh	.+12
    6f5a: 22 81        	ldd	r18, Z+2
    6f5c: 33 81        	ldd	r19, Z+3
    6f5e: d8 01 2d 93  	<unknown>
    6f62: 3c 93        	st	X, r19
    6f64: 16 c0        	rjmp	.+44
    6f66: 28 0f        	add	r18, r24
    6f68: 39 1f        	adc	r19, r25
    6f6a: d8 01 2d 93  	<unknown>
    6f6e: 3c 93        	st	X, r19
    6f70: 42 81        	ldd	r20, Z+2
    6f72: 53 81        	ldd	r21, Z+3
    6f74: 29 d0        	rcall	.+82
    6f76: 4d 93        	st	X+, r20
    6f78: 5c 93        	st	X, r21
    6f7a: 40 81        	ldd	r20, Z+0
    6f7c: 51 81        	ldd	r21, Z+1
    6f7e: 48 1b        	sub	r20, r24
    6f80: 59 0b        	sbc	r21, r25
    6f82: d8 01 2d 91  	<unknown>
    6f86: bc 91        	ld	r27, X
    6f88: a2 2f        	mov	r26, r18
    6f8a: 4d 93        	st	X+, r20
    6f8c: 5c 93        	st	X, r21
    6f8e: 80 83        	std	Z+0, r24
    6f90: 91 83        	std	Z+1, r25
    6f92: d8 01 2d 91  	<unknown>
    6f96: 3c 91        	ld	r19, X
    6f98: 23 2b        	or	r18, r19
    6f9a: 59 f0        	breq	.+22
    6f9c: 15 d0        	rcall	.+42
    6f9e: 2d 91        	ld	r18, X+
    6fa0: 3c 91        	ld	r19, X
    6fa2: 23 2b        	or	r18, r19
    6fa4: 31 f0        	breq	.+12
    6fa6: d8 01 0d 91  	<unknown>
    6faa: 1c 91        	ld	r17, X
    6fac: 0e 5f        	subi	r16, 0xfe
    6fae: 1f 4f        	sbci	r17, 0xff
    6fb0: 02 c0        	rjmp	.+4
    6fb2: 00 e0        	ldi	r16, 0x0
    6fb4: 10 e0        	ldi	r17, 0x0
    6fb6: a0 e8        	ldi	r26, 0x80
    6fb8: b7 e0        	ldi	r27, 0x7
    6fba: 0d 93        	st	X+, r16
    6fbc: 1c 93        	st	X, r17
    6fbe: 32 96 8f 01  	<unknown>
    6fc2: e4 e0        	ldi	r30, 0x4
    6fc4: 0c 94 00 35  	<unknown>
    6fc8: d8 01 2d 91  	<unknown>
    6fcc: d9 01 12 96  	<unknown>
    6fd0: 08 95        	ret
    6fd2: 11 01 73 06  	<unknown>
    6fd6: 00 00        	nop
    6fd8: 13 00 60 06  	<unknown>
    6fdc: de 6f        	ori	r29, 0xfe
    6fde: 01 78        	andi	r16, 0x81
    6fe0: 07 47        	sbci	r16, 0x77
    6fe2: 07 88        	ldd	r0, Z+7
    6fe4: 11 00 00 00  	<unknown>
    6fe8: 00 00        	nop
    6fea: 00 00        	nop
    6fec: 00 2d        	mov	r16, r0
    6fee: 00 25        	eor	r16, r0
    6ff0: 00 80        	ldd	r0, Z+0
    6ff2: 68 10        	cpse	r6, r8
    6ff4: fc 8e        	std	Y+4, r15
    6ff6: d2 16        	cp	r13, r18
    6ff8: 1c 93        	st	X, r17
    6ffa: 97 48        	sbci	r25, 0x87
