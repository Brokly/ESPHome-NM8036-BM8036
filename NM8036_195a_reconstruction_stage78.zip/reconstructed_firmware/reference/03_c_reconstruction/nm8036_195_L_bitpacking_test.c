#include <stdint.h>
#include <stdio.h>
uint8_t nm195_pack_three_flags(uint8_t, uint8_t, uint8_t);
uint8_t nm195_pack_three_flags_avr_reference(uint8_t, uint8_t, uint8_t);
int main(void) {
  for (unsigned a=0;a<256;a++) for (unsigned b=0;b<256;b++) {
    for (unsigned c=0;c<256;c+=17) {
      uint8_t x=nm195_pack_three_flags(a,b,c);
      uint8_t y=nm195_pack_three_flags_avr_reference(a,b,c);
      if(x!=y) { fprintf(stderr,"mismatch %u %u %u\n",a,b,c);return 1; }
    }
  }
  puts("OK: 1,048,576 test cases"); return 0;
}
