/* NM8036 v1.95a. Exact local AVR translation of 0x5614..0x563e.
 * Source: nm8036_195_atmega32_full.asm (llvm-objdump --mcpu=atmega32).
 * This function reconstructs ONLY the three-source bit packing, not the
 * surrounding record serialization or the memory accessor side effects.
 */
#include <stdint.h>

/* Three distinct field reads occur at 0x5614, 0x5624, and 0x5634.
 * First: ANDI 0x20; LSR three times => bit 5 moves to bit 2.
 * Second: MUL by 4; AND r1 with 0x02 => original bit 7 moves to bit 1.
 * Third: ANDI 0x20; SWAP; LSR => bit 5 moves to bit 0.
 */
uint8_t nm195_pack_three_flags(uint8_t first, uint8_t second, uint8_t third)
{
    return (uint8_t)(((first & 0x20u) >> 3) |
                     ((second & 0x80u) >> 6) |
                     ((third & 0x20u) >> 5));
}

/* Independent instruction-level reference, including AVR MUL high byte r1. */
uint8_t nm195_pack_three_flags_avr_reference(uint8_t first, uint8_t second,
                                             uint8_t third)
{
    uint8_t r17 = (uint8_t)(first & 0x20u);
    r17 >>= 3;
    uint16_t product = (uint16_t)second * 4u;
    uint8_t r1 = (uint8_t)(product >> 8);
    r1 &= 0x02u;
    r17 |= r1;
    uint8_t r16 = (uint8_t)(third & 0x20u);
    r16 = (uint8_t)((r16 << 4) | (r16 >> 4));
    r16 >>= 1;
    return (uint8_t)(r16 | r17);
}
