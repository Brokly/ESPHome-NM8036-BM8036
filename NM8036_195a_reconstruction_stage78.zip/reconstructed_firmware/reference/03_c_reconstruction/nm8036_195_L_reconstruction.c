/* NM8036 1.95a: reconstruction of command 'L' from AVR 0x5596..0x5648.
 * This is a behavioral reconstruction of the visible control structure;
 * helper routines 0x58xx and 0x4Fxx remain to be reconstructed.
 * Never assume 32*27 raw SRAM bytes are transmitted.
 */
#include <stdint.h>
#include <stddef.h>

/* Data model for reconstructing each field. The binary uses an indexed
 * storage accessor (0x58xx) with r20:r21 as field offset and r16:r17 as
 * record address. The representation is not yet established. */
typedef struct {
    void *ctx;
    uint8_t (*read_field)(void *ctx, uint8_t record, uint16_t field_offset);
    void (*tx)(void *ctx, uint8_t byte);
} NM195_L_IO;

/* AVR 0x5616..0x563e, two source bitfields assembled for a transmitted
 * byte. The final OR is directly visible at 0x563c. */
static uint8_t combine_flags(uint8_t first, uint8_t second) {
    uint8_t upper = (uint8_t)((first & 0x20u) >> 3u); /* 0x5618-0x5620 */
    uint8_t lower = (uint8_t)((second & 0x20u) >> 5u); /* SWAP then LSR, 0x5636-0x563c */
    return (uint8_t)(upper | lower);
}

/* AVR 0x55d0 swaps nibbles. */
static uint8_t swap_nibbles(uint8_t value) {
    return (uint8_t)((value << 4u) | (value >> 4u));
}

/* Verified address-level observations, NOT a finished serializer:
 * 0x5596  TX('L')
 * 0x559a  record index r24 = 0
 * 0x55a0  record-dependent pointer arithmetic
 * 0x55ac..0x55c6  field reads + transmit helper calls
 * 0x55c8..0x55d0  read, SWAP, transmit
 * 0x55e6..0x5608  16-bit / 32-bit field handling
 * 0x5616..0x563e  bit masks and bitfield packing
 * 0x5640  increment record index
 * 0x5642  compare with 0x20 (32 records)
 * 0x5648  loop to 0x559c
 * A complete 27-byte record serialization cannot yet be asserted until
 * the exact calling convention of 0x58xx helpers has been recovered.
 */
int nm195_L_structure_verified(void) { return 32; }

/* Expose the two identified primitives for tests without claiming the
 * unresolved fields are known. */
uint8_t nm195_L_swap_nibbles(uint8_t v) { return swap_nibbles(v); }
uint8_t nm195_L_combine_flags(uint8_t a, uint8_t b) { return combine_flags(a,b); }
