#include <assert.h>
#include <stdint.h>
uint8_t nm195_L_swap_nibbles(uint8_t);
uint8_t nm195_L_combine_flags(uint8_t,uint8_t);
int nm195_L_structure_verified(void);
int main(void) {
    assert(nm195_L_swap_nibbles(0xA3)==0x3A);
    assert(nm195_L_combine_flags(0x20,0)==4);
    assert(nm195_L_structure_verified()==32);
    return 0;
}
