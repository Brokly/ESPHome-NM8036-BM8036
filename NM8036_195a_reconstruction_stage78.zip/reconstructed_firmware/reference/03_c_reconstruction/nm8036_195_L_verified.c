/* NM8036 1.95a — verified reconstruction of L dispatcher control structure.
 * Source: corrected firmware at AVR byte addresses 0x5596..0x5648.
 * The calls are deliberately explicit: helper semantics are NOT invented.
 * This is NOT a complete firmware translation.
 */
#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint8_t r[32];
    uint8_t carry;
    void *context;
    /* Callback executes a helper with the same register input/output contract.
     * Helpers remain AVR-level until separately decompiled. */
    void (*call)(void *context, uint16_t address, uint8_t r[32], uint8_t *carry);
} NM195_Trace;

static void call(NM195_Trace *s, uint16_t address) {
    s->call(s->context, address, s->r, &s->carry);
}
static void ldi(NM195_Trace *s, unsigned d, uint8_t value) {s->r[d]=value;}
static void mov(NM195_Trace *s, unsigned d, unsigned r) {s->r[d]=s->r[r];}
static void movw(NM195_Trace *s, unsigned d, unsigned r) {
    s->r[d]=s->r[r]; s->r[d+1]=s->r[r+1];
}
static void add(NM195_Trace *s, unsigned d, unsigned r) {
    unsigned x=(unsigned)s->r[d]+s->r[r]; s->r[d]=(uint8_t)x; s->carry=(uint8_t)(x>255u);
}
static void adc(NM195_Trace *s, unsigned d, unsigned r) {
    unsigned x=(unsigned)s->r[d]+s->r[r]+s->carry; s->r[d]=(uint8_t)x; s->carry=(uint8_t)(x>255u);
}
static void subi(NM195_Trace *s, unsigned d, uint8_t k) {
    unsigned x=s->r[d];s->r[d]=(uint8_t)(x-k);s->carry=(uint8_t)(x<k);
}


/* 0x5596..0x55C6: exact order of visible register-level operations.
 * 0x5924 is an essential helper; r16:r17 and r20:r21 after it are unknown.
 */
void nm195_L_first_record_prefix(NM195_Trace *s) {
    ldi(s,16,'L');call(s,0x58D4); /* 0x5596: UART echo */
    ldi(s,24,0);              /* 0x559A: record index (zero for first iteration) */
    mov(s,20,24);call(s,0x5924);  /* 0x559C..0x559E */
    ldi(s,26,0x4C);ldi(s,27,0); /* 0x55A0..0x55A2 */
    add(s,26,16);adc(s,27,17);  /* 0x55A4..0x55A6 */
    movw(s,20,26);subi(s,20,0xFA); /* 0x55A8 MOVW, 0x55AA SUBI */
    call(s,0x58FE);call(s,0x58F8);
    subi(s,20,0xFF);call(s,0x58F6);
    subi(s,20,0xFB);call(s,0x58FE);
    subi(s,20,0xF9);call(s,0x58F6);
    subi(s,20,0xF8);call(s,0x58F6);
    subi(s,20,0xF7);call(s,0x58FE);
    subi(s,20,0xF6);call(s,0x58FE);
}

/* IMPORTANT: this function is a tracing primitive, not a completed L serializer.
 * It is unsafe to use it to send an 864-byte UART response until the helpers
 * and the remaining instructions at 0x55C8..0x5648 are fully translated. */
