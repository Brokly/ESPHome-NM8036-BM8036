#ifndef NM8036_195_ANNOTATED_PROTOCOL_H
#define NM8036_195_ANNOTATED_PROTOCOL_H
#include <stdint.h>
#include <stddef.h>
/* NM8036/BM8036 manual appendix 5, protocol version 1.95.
 * IMPORTANT: wire format, not necessarily identical to internal SRAM/EEPROM layout.
 * The binary's L handler (0x5596..0x5648) performs field-wise extraction and
 * bit operations; a raw 27-byte SRAM memcpy is NOT established.
 */
typedef struct __attribute__((packed)) {
    uint8_t time_on_h, time_on_m, time_on_s;
    uint8_t time_off_h, time_off_m, time_off_s;
    uint8_t time_on_day, time_off_day;
    uint8_t time_on_month, time_off_month;
    uint8_t time_on_year, time_off_year;
    uint8_t time_load, time_loadsensor;
    uint16_t time_min, time_max;
    uint8_t time_mode, time_eze;
    uint32_t time_ezedata;
    uint8_t time_bud, enable, sensortype;
} NM195_ProgramWire;
_Static_assert(sizeof(NM195_ProgramWire)==27, "manual record is 27 bytes");
#define NM195_PROGRAM_COUNT 32u
#define NM195_PROGRAM_WIRE_BYTES (NM195_PROGRAM_COUNT * sizeof(NM195_ProgramWire))
_Static_assert(NM195_PROGRAM_WIRE_BYTES==864, "manual's 832 is a typo");
#define NM195_DALLAS_BYTES (32u * 8u)
#define NM195_LCD_BYTES (64u + 16u + 16u)
#define NM195_GREETING_BYTES (17u + 17u)
#define NM195_ADC_BYTES (4u * 2u)
#define NM195_PULSE_BYTES (12u * 2u * 2u)
/* Clock fields in the manual are bitfields. Represent as raw bytes to avoid
 * compiler-specific bitfield allocation and to preserve the exact wire image. */
typedef struct { uint8_t raw[8]; } NM195_ClockWire;
#endif
