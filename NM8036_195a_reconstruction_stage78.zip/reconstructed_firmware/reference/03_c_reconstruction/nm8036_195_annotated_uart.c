/* NM8036 v1.95a: commented, source-grounded UART subset.
 * Machine code: nm8036_195_corrected.bin; instruction listing: corrected.asm.
 * Protocol semantics: NMBM8036.pdf, Appendix 5 (pp. 16-18).
 * This is NOT the complete original C firmware.
 * Distinguish VERIFIED binary actions from MANUAL-ONLY semantics below.
 */
#include "nm8036_195_annotated_protocol.h"
#include <stdint.h>
#include <stddef.h>

typedef struct {
    void *context;
    void (*tx)(void *, uint8_t);
    void (*tx_bytes)(void *, const uint8_t *, size_t);
    void (*rx_bytes)(void *, uint8_t *, size_t);
    uint8_t *sram;  /* address-indexed view; >= 0x073a bytes */
    const uint8_t *lcd_snapshot; /* resolved elsewhere by AVR helper 0x1F26 */
    void (*enter_bootloader)(void *); /* implementation not yet reconstructed */
} NM195_UartContext;

static void tx1(NM195_UartContext *u, uint8_t b) { u->tx(u->context,b); }
static void txram(NM195_UartContext *u, uint16_t address, size_t n) {
    u->tx_bytes(u->context, u->sram+address, n);
}
/* AVR 0x579A: LDI 0x44; transmit; R18:R19=0x0100;
 * R16:R17=0x02F0; call send_buffer.
 * Manual: 32 Dallas 8-byte identifiers. */
static void handle_D(NM195_UartContext *u) {
    tx1(u,'D'); txram(u,0x02F0,NM195_DALLAS_BYTES);
}
/* AVR 0x57AA: transmit 'd'; LDS 0x068E; transmit; STS 0x068E,0.
 * Manual: LCD change flag, read-and-clear. */
static void handle_d(NM195_UartContext *u) {
    tx1(u,'d'); tx1(u,u->sram[0x068E]); u->sram[0x068E]=0;
}
/* AVR 0x5838: transmit 's'; pointer 0x0673; 8 bytes.
 * Manual: four 16-bit ADC samples. */
static void handle_s(NM195_UartContext *u) {
    tx1(u,'s'); txram(u,0x0673,NM195_ADC_BYTES);
}
/* AVR 0x581E: transmit 'S'; call 0x1F26; send 0x60 bytes.
 * Manual: 64 graphic + 16 top + 16 bottom characters. */
static void handle_S(NM195_UartContext *u) {
    tx1(u,'S'); u->tx_bytes(u->context,u->lcd_snapshot,NM195_LCD_BYTES);
}
/* AVR 0x580E: transmit 'K'; receive 1 byte at SRAM 0x0739.
 * Manual: emulate a keypress. */
static void handle_K(NM195_UartContext *u) {
    tx1(u,'K'); u->rx_bytes(u->context,u->sram+0x0739,1);
}
/* AVR 0x5532: transmit 'E'; transition into firmware update mode.
 * Manual: bootloader session exits with 'X'. Transition remains unresolved. */
static void handle_E(NM195_UartContext *u) {
    tx1(u,'E'); if (u->enter_bootloader) u->enter_bootloader(u->context);
}
/* NOT IMPLEMENTED: 'L' at 0x5596 serializes 32 entries by field and bit,
 * including SWAP/AND/OR operations. Its documented wire length is 864 bytes.
 * Sending 864 raw SRAM bytes here would misrepresent the actual firmware.
 * 'W' at 0x564A performs the inverse packed-field handling.
 * 'H'/'h' at 0x57BC/0x57C8 handle 34-byte greeting data through helpers.
 * 'i'/'I' at 0x57D4/0x57E8 and 'A'/'a' at 0x57FA/0x5804
 * call further helpers; their exact state effects need decompilation.
 */
int nm195_dispatch_verified(NM195_UartContext *u, uint8_t cmd) {
    switch(cmd) {
        case 'D': handle_D(u); return 1;
        case 'd': handle_d(u); return 1;
        case 's': handle_s(u); return 1;
        case 'S': handle_S(u); return 1;
        case 'K': handle_K(u); return 1;
        case 'E': handle_E(u); return 1;
        default: return 0;
    }
}
