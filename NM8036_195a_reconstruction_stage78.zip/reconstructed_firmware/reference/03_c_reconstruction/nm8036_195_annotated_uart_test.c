#include "nm8036_195_annotated_uart.c"
#include <assert.h>
#include <string.h>
typedef struct {uint8_t out[512]; size_t n; uint8_t in; int boot;} Test;
static void tx(void *ctx,uint8_t b){Test *t=ctx; assert(t->n<sizeof t->out);t->out[t->n++]=b;}
static void txb(void *ctx,const uint8_t *p,size_t n){for(size_t i=0;i<n;i++)tx(ctx,p[i]);}
static void rxb(void *ctx,uint8_t *p,size_t n){Test *t=ctx;assert(n==1);*p=t->in;}
static void boot(void *ctx){((Test*)ctx)->boot++;}
int main(void){
    Test t={0};uint8_t ram[0x740]={0},lcd[96]={0};
    NM195_UartContext u={&t,tx,txb,rxb,ram,lcd,boot};
    ram[0x068E]=1;assert(nm195_dispatch_verified(&u,'d'));
    assert(t.n==2&&t.out[0]=='d'&&t.out[1]==1&&ram[0x068E]==0);
    t.n=0;for(unsigned i=0;i<256;i++)ram[0x02F0+i]=(uint8_t)i;
    assert(nm195_dispatch_verified(&u,'D'));
    assert(t.n==257&&t.out[0]=='D'&&t.out[256]==255);
    t.n=0;assert(nm195_dispatch_verified(&u,'S')&&t.n==97);
    t.n=0;assert(nm195_dispatch_verified(&u,'s')&&t.n==9);
    t.n=0;t.in=0x80;assert(nm195_dispatch_verified(&u,'K')&&ram[0x0739]==0x80&&t.n==1);
    t.n=0;assert(nm195_dispatch_verified(&u,'E')&&t.boot==1&&t.n==1);
    assert(!nm195_dispatch_verified(&u,'L'));
    return 0;
}
