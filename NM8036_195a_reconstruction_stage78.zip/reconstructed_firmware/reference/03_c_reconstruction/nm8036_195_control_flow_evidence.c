/* NM8036 1.95a: extracted control-flow and instruction evidence. */
/* NOT source-equivalent decompilation. Addresses are byte offsets. */
#include <stdint.h>
typedef struct { uint16_t address, target; } nm_call_edge;
static const nm_call_edge nm195_direct_calls[] = {
    {0x0CC6, 0x0CE6},
    {0x0CD6, 0x0CE6},
    {0x0D0A, 0x0D22},
    {0x0D0C, 0x0D22},
    {0x0D14, 0x0D8A},
    {0x0D38, 0x0CEA},
    {0x0D46, 0x69DC},
    {0x0D54, 0x0D02},
    {0x0D6E, 0x69DE},
    {0x0D7A, 0x0D2C},
    {0x0DE4, 0x6356},
    {0x0DF4, 0x0E12},
    {0x0DFC, 0x0E12},
    {0x0E04, 0x0E12},
    {0x0E0A, 0x0E12},
    {0x11D2, 0x120E},
    {0x11D4, 0x1220},
    {0x11D6, 0x120C},
    {0x11D8, 0x120A},
    {0x11DA, 0x12A6},
    {0x11DE, 0x120C},
    {0x11E4, 0x1264},
    {0x11E8, 0x1218},
    {0x11EC, 0x120A},
    {0x11F4, 0x120E},
    {0x11FA, 0x1220},
    {0x1200, 0x120C},
    {0x1202, 0x1218},
    {0x1206, 0x120A},
    {0x120E, 0x69DE},
    {0x1220, 0x12A6},
    {0x1224, 0x122A},
    {0x1236, 0x129A},
    {0x123A, 0x129C},
    {0x124C, 0x1298},
    {0x124E, 0x1296},
    {0x125A, 0x129E},
    {0x1264, 0x69E0},
    {0x126C, 0x1298},
    {0x1272, 0x1296},
    {0x127A, 0x129E},
    {0x127C, 0x1218},
    {0x128A, 0x129A},
    {0x128C, 0x129C},
    {0x1296, 0x12A2},
    {0x129C, 0x12A2},
    {0x12A8, 0x129A},
    {0x12AC, 0x12A2},
    {0x12C4, 0x12EC},
    {0x12C8, 0x1356},
    {0x1312, 0x133A},
    {0x131A, 0x1332},
    {0x133E, 0x1352},
    {0x1342, 0x1356},
    {0x1344, 0x13CE},
    {0x135A, 0x133A},
    {0x135C, 0x1524},
    {0x137A, 0x13CE},
    {0x137E, 0x13D8},
    {0x1384, 0x0D46},
    {0x1388, 0x13D4},
    {0x138C, 0x13D4},
    {0x13A6, 0x14EC},
    {0x13AA, 0x14F6},
    {0x13BA, 0x14F2},
    {0x13C2, 0x1504},
    {0x13CE, 0x1542},
    {0x13D8, 0x1352},
    {0x13DC, 0x1356},
    {0x14F8, 0x63F2},
    {0x1504, 0x14F0},
    {0x150C, 0x1524},
    {0x1524, 0x1352},
    {0x1528, 0x1356},
    {0x152A, 0x1542},
    {0x153A, 0x1352},
    {0x153E, 0x1356},
    {0x1DAE, 0x1DEC},
    {0x1DBE, 0x1DE0},
    {0x1DC0, 0x1DE0},
    {0x1DCA, 0x1DE0},
    {0x1DD0, 0x1E66},
    {0x1DD6, 0x1E66},
    {0x1DDC, 0x1E66},
    {0x1DE0, 0x1DEC},
    {0x1E70, 0x1E52},
    {0x1E78, 0x1E66},
    {0x1E8A, 0x1E66},
    {0x1E9E, 0x1F6A},
    {0x1EA4, 0x1EB0},
    {0x1EA6, 0x1E9C},
    {0x1EB0, 0x69DE},
    {0x1EBA, 0x1EE0},
    {0x1EC0, 0x1F4A},
    {0x1ED2, 0x1E66},
    {0x1ED6, 0x1E9C},
    {0x1EE0, 0x1F06},
    {0x1F10, 0x1DFA},
    {0x1F14, 0x1F1C},
    {0x1F20, 0x1F1C},
    {0x1F26, 0x1F4A},
    {0x1F2C, 0x6A78},
    {0x1F30, 0x1EB4},
    {0x1F34, 0x1F74},
    {0x1F36, 0x1F1E},
    {0x1F38, 0x1F6A},
    {0x1F4E, 0x1EB0},
    {0x1F52, 0x1F74},
    {0x1F56, 0x1F6A},
    {0x1F5A, 0x1F10},
    {0x1F84, 0x1E52},
    {0x1FA0, 0x2158},
    {0x1FC8, 0x630C},
    {0x1FF0, 0x1F4A},
    {0x2006, 0x639A},
    {0x2042, 0x20D4},
    {0x20DA, 0x69CE},
    {0x20DE, 0x203E},
    {0x20E2, 0x2158},
    {0x20F8, 0x2140},
    {0x2102, 0x214A},
    {0x2118, 0x2166},
    {0x212C, 0x2166},
    {0x2130, 0x2140},
    {0x2132, 0x214A},
    {0x2180, 0x6A7C},
    {0x219E, 0x22FE},
    {0x21B8, 0x1E86},
    {0x21C2, 0x21E6},
    {0x21CA, 0x21E6},
    {0x21D2, 0x21E6},
    {0x21D4, 0x2274},
    {0x2208, 0x2258},
    {0x222C, 0x2258},
    {0x2254, 0x2226},
    {0x2282, 0x69DE},
    {0x2292, 0x1E52},
    {0x22A8, 0x1EE0},
    {0x22BE, 0x639A},
    {0x22C6, 0x6AE0},
    {0x2336, 0x1FF0},
    {0x23FA, 0x69E0},
    {0x24DA, 0x69DE},
    {0x2728, 0x2730},
    {0x2734, 0x6A7C},
    {0x2872, 0x287C},
    {0x2888, 0x1E68},
    {0x2932, 0x27CA},
    {0x2948, 0x1EA4},
    {0x294C, 0x296E},
    {0x2952, 0x2962},
    {0x2958, 0x2972},
    {0x295E, 0x2962},
    {0x2A8E, 0x2AB8},
    {0x2A96, 0x2AB8},
    {0x2A9C, 0x2AB8},
    {0x2AA4, 0x2AB8},
    {0x2AAC, 0x2AB8},
    {0x2AB2, 0x2AB8},
    {0x2C08, 0x69D8},
    {0x2C36, 0x69DA},
    {0x39B6, 0x3F30},
    {0x39BE, 0x3F30},
    {0x39C4, 0x39BE},
    {0x39E2, 0x3F34},
    {0x3A20, 0x3A3C},
    {0x3AF4, 0x69D4},
    {0x3B02, 0x3BB8},
    {0x3B0C, 0x3B9A},
    {0x3B0E, 0x3BB2},
    {0x3B12, 0x3BB8},
    {0x3B18, 0x3B9E},
    {0x3B38, 0x3B9E},
    {0x3B4A, 0x3B9E},
    {0x3B66, 0x3BB8},
    {0x3B6E, 0x3B9A},
    {0x3B82, 0x3B9A},
    {0x3B9E, 0x641A},
    {0x3BB0, 0x3F9A},
    {0x3BC0, 0x69C6},
    {0x3BD4, 0x3F9C},
    {0x3BD6, 0x3F3A},
    {0x3C4C, 0x3F48},
    {0x3C50, 0x3ECA},
    {0x3C7C, 0x3BAC},
    {0x3C82, 0x3F14},
    {0x3C84, 0x3ED0},
    {0x3C88, 0x3EF2},
    {0x3C8A, 0x3F4E},
    {0x3C92, 0x3F54},
    {0x3C94, 0x3EFA},
    {0x3C9E, 0x3F14},
    {0x3CA2, 0x3ED0},
    {0x3CA6, 0x3EF2},
    {0x3CA8, 0x3F3E},
    {0x3CB0, 0x3F60},
    {0x3CB2, 0x3EFA},
    {0x3CCC, 0x3F34},
    {0x3CD2, 0x3F90},
    {0x3CE8, 0x3F80},
    {0x3CF0, 0x3FB8},
    {0x3CFC, 0x3BAC},
    {0x3D00, 0x3F4E},
    {0x3D02, 0x3F54},
    {0x3D04, 0x3F94},
    {0x3D0C, 0x3F3E},
    {0x3D0E, 0x3F60},
    {0x3D10, 0x3F94},
    {0x3D36, 0x3F80},
    {0x3D3C, 0x3FB8},
    {0x3D40, 0x3F10},
    {0x3D46, 0x39F6},
    {0x3D58, 0x39F6},
    {0x3D64, 0x3A3C},
    {0x3D66, 0x3EC0},
    {0x3D6A, 0x3F1E},
    {0x3D88, 0x3F80},
    {0x3D8E, 0x3FB8},
    {0x3DA4, 0x3F22},
    {0x3DAA, 0x3EEE},
    {0x3DB2, 0x3EEA},
    {0x3DD4, 0x3A96},
    {0x3DE4, 0x3ECA},
    {0x3DF6, 0x3FD4},
    {0x3E12, 0x3F6E},
    {0x3E1E, 0x3FD4},
    {0x3E3A, 0x3F6E},
    {0x3E40, 0x39F6},
    {0x3E4C, 0x3F2C},
    {0x3E5E, 0x203E},
    {0x3E6C, 0x3FA8},
    {0x3E70, 0x3EDC},
    {0x3EA2, 0x2312},
    {0x3EEA, 0x3F1E},
    {0x3EF2, 0x3F00},
    {0x3EFA, 0x3F00},
    {0x3F00, 0x3F1E},
    {0x3F10, 0x39DE},
    {0x3F14, 0x3F1E},
    {0x3F42, 0x3FB2},
    {0x3F4E, 0x3F48},
    {0x3F54, 0x39DE},
    {0x3F64, 0x3FB2},
    {0x3F7A, 0x2362},
    {0x3F86, 0x631C},
    {0x3F90, 0x39F6},
    {0x3F94, 0x3F00},
    {0x3F9C, 0x3A3C},
    {0x3FA8, 0x3A20},
    {0x3FAC, 0x3FB2},
    {0x3FB2, 0x3F1E},
    {0x3FC0, 0x645A},
    {0x3FD4, 0x39F6},
    {0x3FDC, 0x3F34},
    {0x3FF2, 0x410E},
    {0x3FF6, 0x40E2},
    {0x3FFC, 0x40DE},
    {0x4000, 0x40AC},
    {0x4002, 0x40F2},
    {0x4006, 0x40EE},
    {0x400A, 0x40C8},
    {0x400E, 0x40F2},
    {0x4012, 0x40CE},
    {0x4014, 0x40F2},
    {0x4018, 0x4100},
    {0x401A, 0x4108},
    {0x401C, 0x40FC},
    {0x401E, 0x40C4},
    {0x4024, 0x40E8},
    {0x402E, 0x4100},
    {0x4032, 0x40E2},
    {0x403A, 0x3F30},
    {0x4042, 0x39B6},
    {0x4048, 0x3F30},
    {0x4050, 0x40BC},
    {0x4054, 0x40BC},
    {0x4058, 0x40DE},
    {0x405C, 0x40AC},
    {0x405E, 0x40DA},
    {0x4060, 0x39B4},
    {0x4070, 0x40FC},
    {0x4074, 0x40D4},
    {0x4076, 0x40CA},
    {0x407A, 0x3F1E},
    {0x4082, 0x40EE},
    {0x4088, 0x40C8},
    {0x408C, 0x40D4},
    {0x4090, 0x40CE},
    {0x4092, 0x40DA},
    {0x4096, 0x40E8},
    {0x409E, 0x3F0A},
    {0x40AC, 0x3F0A},
    {0x40BE, 0x6348},
    {0x40CE, 0x4100},
    {0x40D4, 0x3F1E},
    {0x40DA, 0x3FB2},
    {0x40DE, 0x4100},
    {0x40E2, 0x3F1E},
    {0x40E8, 0x4100},
    {0x40EE, 0x4100},
    {0x40F2, 0x40F8},
    {0x40F8, 0x3F1E},
    {0x4100, 0x3F30},
    {0x410A, 0x3F1E},
    {0x410E, 0x3A3C},
    {0x4170, 0x48F0},
    {0x41BC, 0x69CA},
    {0x41C4, 0x1D8C},
    {0x41C8, 0x2BF6},
    {0x41CC, 0x0D94},
    {0x41D0, 0x2022},
    {0x41DC, 0x4910},
    {0x41DE, 0x5040},
    {0x41E0, 0x23FA},
    {0x41E4, 0x203E},
    {0x41F2, 0x53E4},
    {0x41F6, 0x53E0},
    {0x4200, 0x53E4},
    {0x4208, 0x53E4},
    {0x4218, 0x52EC},
    {0x4220, 0x52E2},
    {0x4224, 0x532C},
    {0x422C, 0x4F16},
    {0x422E, 0x48D0},
    {0x4230, 0x3FEA},
    {0x4234, 0x0DCE},
    {0x4238, 0x2A88},
    {0x423C, 0x5040},
    {0x423E, 0x24DA},
    {0x424E, 0x5306},
    {0x4258, 0x53E4},
    {0x4298, 0x48D0},
    {0x42A8, 0x52E8},
    {0x42BC, 0x4DD4},
    {0x42BE, 0x4F12},
    {0x42D2, 0x503C},
    {0x42E0, 0x5498},
    {0x42E6, 0x59F4},
    {0x431E, 0x53E8},
    {0x4322, 0x2728},
    {0x432C, 0x2872},
    {0x4332, 0x53D4},
    {0x4336, 0x4916},
    {0x433E, 0x4916},
    {0x4340, 0x486C},
    {0x4348, 0x5304},
    {0x4350, 0x52C8},
    {0x4352, 0x4958},
    {0x435A, 0x4878},
    {0x435E, 0x52BC},
    {0x4366, 0x4862},
    {0x4378, 0x486C},
    {0x4396, 0x1FF0},
    {0x43AC, 0x59EC},
    {0x43BC, 0x4F16},
    {0x43C6, 0x52C8},
    {0x43C8, 0x5038},
    {0x43CA, 0x4854},
    {0x43F2, 0x59EC},
    {0x43FA, 0x4894},
    {0x4408, 0x49A4},
    {0x4410, 0x501E},
    {0x4418, 0x59EE},
    {0x441C, 0x4DAA},
    {0x4428, 0x0DA2},
    {0x442C, 0x52B2},
    {0x442E, 0x54BC},
    {0x4434, 0x501E},
    {0x443A, 0x59F4},
    {0x4440, 0x1F26},
    {0x444C, 0x4F16},
    {0x4456, 0x53E0},
    {0x445C, 0x4D82},
    {0x4460, 0x4910},
    {0x4466, 0x4960},
    {0x446C, 0x4E96},
    {0x446E, 0x4DAA},
    {0x4470, 0x3BC0},
    {0x4474, 0x52B2},
    {0x447E, 0x53E0},
    {0x4480, 0x53E8},
    {0x4492, 0x52D2},
    {0x44BE, 0x52AE},
    {0x44C0, 0x4878},
    {0x44C8, 0x48A8},
    {0x44CA, 0x493A},
    {0x44CE, 0x4878},
    {0x44D2, 0x48C0},
    {0x44D6, 0x48C0},
    {0x44DA, 0x48A8},
    {0x44DC, 0x493A},
    {0x44E0, 0x4878},
    {0x44E4, 0x48C0},
    {0x44E8, 0x52AE},
    {0x44EA, 0x4878},
    {0x44F2, 0x4D82},
    {0x44F6, 0x4910},
    {0x44F8, 0x3BC0},
    {0x451C, 0x52C8},
    {0x4524, 0x52CC},
    {0x452E, 0x52C8},
    {0x4544, 0x501E},
    {0x4550, 0x4894},
    {0x45C4, 0x4848},
    {0x45C6, 0x52CC},
    {0x45CE, 0x4F16},
    {0x45D4, 0x52DC},
    {0x45DA, 0x48FE},
    {0x45F8, 0x48F8},
    {0x45FA, 0x48F0},
    {0x4616, 0x58D8},
    {0x4624, 0x502A},
    {0x4636, 0x4848},
    {0x4638, 0x52CC},
    {0x4640, 0x4F16},
    {0x4646, 0x52DC},
    {0x464C, 0x48FE},
    {0x467C, 0x48F4},
    {0x4680, 0x48F0},
    {0x468E, 0x48E6},
    {0x4698, 0x502A},
    {0x46A6, 0x4960},
    {0x46AC, 0x4E96},
    {0x46AE, 0x4D44},
    {0x46B0, 0x52F8},
    {0x46B6, 0x5330},
    {0x46B8, 0x4DB2},
    {0x46BE, 0x4F16},
    {0x46C0, 0x4E00},
    {0x46C2, 0x4F12},
    {0x46C4, 0x4D88},
    {0x46C6, 0x4DBC},
    {0x46CC, 0x4F16},
    {0x46DA, 0x52CC},
    {0x46DC, 0x52E8},
    {0x46DE, 0x48E6},
    {0x46E0, 0x4928},
    {0x46E2, 0x4872},
    {0x46E8, 0x5032},
    {0x46EE, 0x52DC},
    {0x46FC, 0x52CC},
    {0x46FE, 0x52E8},
    {0x4704, 0x4EB2},
    {0x4706, 0x4844},
    {0x4708, 0x4E24},
    {0x470E, 0x4844},
    {0x4714, 0x4872},
    {0x471A, 0x4E96},
    {0x4720, 0x52DC},
    {0x473E, 0x48A0},
    {0x474E, 0x58D8},
    {0x4752, 0x58D8},
    {0x4756, 0x48A0},
    {0x475C, 0x6696},
    {0x476C, 0x4844},
    {0x477A, 0x4844},
    {0x4780, 0x660E},
    {0x4790, 0x52C8},
    {0x47D6, 0x52EA},
    {0x47E8, 0x4840},
    {0x47F4, 0x483C},
    {0x47F8, 0x4916},
    {0x47FA, 0x4840},
    {0x4806, 0x483C},
    {0x4812, 0x4840},
    {0x4818, 0x4916},
    {0x481A, 0x483C},
    {0x4820, 0x4854},
    {0x4826, 0x4E96},
    {0x482C, 0x49A4},
    {0x4848, 0x1EA4},
    {0x4872, 0x53DA},
    {0x48F4, 0x1EE0},
    {0x4910, 0x4DDE},
    {0x4916, 0x4E24},
    {0x4940, 0x5304},
    {0x4946, 0x52C8},
    {0x4948, 0x4958},
    {0x4960, 0x52EC},
    {0x4970, 0x4992},
    {0x4978, 0x4998},
    {0x497C, 0x4992},
    {0x4984, 0x4998},
    {0x4988, 0x4992},
    {0x499A, 0x4DD4},
    {0x499C, 0x5276},
    {0x49A4, 0x53B0},
    {0x49A8, 0x217C},
    {0x49B8, 0x21EA},
    {0x49BE, 0x4AB0},
    {0x49C0, 0x22DE},
    {0x49C6, 0x4AB0},
    {0x49CA, 0x2262},
    {0x4A48, 0x21F4},
    {0x4A52, 0x2262},
    {0x4AA8, 0x2192},
    {0x4AB8, 0x69DC},
    {0x4AC2, 0x501A},
    {0x4AFC, 0x4D82},
    {0x4B36, 0x4D50},
    {0x4B50, 0x4D72},
    {0x4B5C, 0x4D3A},
    {0x4B5E, 0x4D58},
    {0x4B70, 0x4D94},
    {0x4B72, 0x4DEC},
    {0x4B7E, 0x4D3A},
    {0x4B80, 0x4D58},
    {0x4B92, 0x4D94},
    {0x4B94, 0x4DEC},
    {0x4BCC, 0x4D50},
    {0x4BE4, 0x4D72},
    {0x4BFC, 0x4D7C},
    {0x4C18, 0x4D64},
    {0x4C1E, 0x4D6C},
    {0x4C36, 0x4D7C},
    {0x4C50, 0x4D64},
    {0x4C58, 0x4D6C},
    {0x4C6A, 0x4DDA},
    {0x4C6C, 0x4962},
    {0x4C76, 0x4D34},
    {0x4C7C, 0x52FC},
    {0x4C82, 0x4D34},
    {0x4C84, 0x4DB2},
    {0x4C8E, 0x4D34},
    {0x4C90, 0x4E00},
    {0x4C9A, 0x4D34},
    {0x4C9C, 0x4D88},
    {0x4C9E, 0x4DBC},
    {0x4CA8, 0x4D34},
    {0x4D0C, 0x4F1E},
    {0x4D14, 0x6ABA},
    {0x4D18, 0x5332},
    {0x4D20, 0x4DAA},
    {0x4D22, 0x4F0C},
    {0x4D6C, 0x4D64},
    {0x4D74, 0x4DF4},
    {0x4D8C, 0x4DCA},
    {0x4DB6, 0x4DCA},
    {0x4DBE, 0x4DD2},
    {0x4DDA, 0x4DDE},
    {0x4DEE, 0x4DF4},
    {0x4DF6, 0x4D64},
    {0x4DFC, 0x4D64},
    {0x4E14, 0x4E24},
    {0x4E18, 0x4DD2},
    {0x4E1A, 0x5276},
    {0x4E96, 0x4F16},
    {0x4E9C, 0x4932},
    {0x4E9E, 0x4EB2},
    {0x4EA0, 0x66D0},
    {0x4EAC, 0x67C2},
    {0x4EB2, 0x4E24},
    {0x4F0C, 0x501E},
    {0x502A, 0x527C},
    {0x502C, 0x59E6},
    {0x5032, 0x4F16},
    {0x5284, 0x6550},
    {0x5288, 0x4E24},
    {0x52B2, 0x20DA},
    {0x52BC, 0x133E},
    {0x52E2, 0x4F16},
    {0x52FC, 0x5310},
    {0x5304, 0x5310},
    {0x5330, 0x4F16},
    {0x53EC, 0x52C8},
    {0x549C, 0x52C8},
    {0x54BC, 0x52A0},
    {0x54C2, 0x2BE4},
    {0x5598, 0x58D4},
    {0x559E, 0x5924},
    {0x55AC, 0x58FE},
    {0x55AE, 0x58F8},
    {0x55B2, 0x58F6},
    {0x55B6, 0x58FE},
    {0x55BA, 0x58F6},
    {0x55BE, 0x58F6},
    {0x55C2, 0x58FE},
    {0x55C6, 0x58FE},
    {0x55C8, 0x52C4},
    {0x55CA, 0x58B2},
    {0x55CC, 0x52C4},
    {0x55D0, 0x58B2},
    {0x55D4, 0x5908},
    {0x55D8, 0x5908},
    {0x55DC, 0x5908},
    {0x55E0, 0x52C6},
    {0x55E2, 0x58D4},
    {0x55E4, 0x58C4},
    {0x55EC, 0x5864},
    {0x55EE, 0x58C4},
    {0x55F4, 0x58A8},
    {0x55F6, 0x58EC},
    {0x55FE, 0x58EC},
    {0x5608, 0x58A8},
    {0x560C, 0x591A},
    {0x5610, 0x591A},
    {0x5614, 0x52C6},
    {0x5624, 0x52C6},
    {0x5634, 0x52C8},
    {0x563E, 0x58D4},
    {0x579C, 0x58D4},
    {0x57A6, 0x5864},
    {0x57AC, 0x58D4},
    {0x57B2, 0x58D4},
    {0x5820, 0x58D4},
    {0x5822, 0x1F26},
    {0x582C, 0x2C36},
    {0x583A, 0x58D4},
    {0x5844, 0x2C36},
    {0x58AA, 0x2C08},
    {0x58EC, 0x52C8},
    {0x58F8, 0x52C8},
    {0x58FE, 0x52C6},
    {0x5902, 0x2BDC},
    {0x5908, 0x52C6},
    {0x591A, 0x52C6},
    {0x597E, 0x59E6},
    {0x59B4, 0x1FF0},
    {0x59BC, 0x59F4},
    {0x59F8, 0x52C8},
    {0x5A00, 0x626C},
    {0x5CE2, 0x69C6},
    {0x5D00, 0x61B8},
    {0x5D02, 0x6142},
    {0x5D06, 0x6156},
    {0x5D10, 0x6142},
    {0x5D12, 0x6156},
    {0x5D14, 0x6132},
    {0x5D40, 0x6176},
    {0x5D56, 0x61B8},
    {0x5D58, 0x613C},
    {0x5D8E, 0x6180},
    {0x5D94, 0x610C},
    {0x5DA8, 0x61B8},
    {0x5DB2, 0x60FE},
    {0x5DCA, 0x613C},
    {0x5DDE, 0x613C},
    {0x5DE4, 0x61B8},
    {0x5DE6, 0x613C},
    {0x5DEC, 0x6180},
    {0x5DF2, 0x610C},
    {0x5DF4, 0x61B8},
    {0x5DFC, 0x613C},
    {0x5E06, 0x60FE},
    {0x5E28, 0x613C},
    {0x5E46, 0x6132},
    {0x61EC, 0x69D6},
    {0x62C4, 0x6A34},
    {0x62CC, 0x6B1A},
    {0x62D8, 0x61EC},
    {0x62DC, 0x41BC},
    {0x62E0, 0x6370},
    {0x6302, 0x62F8},
    {0x630C, 0x6302},
    {0x6312, 0x6302},
    {0x6316, 0x62FE},
    {0x631C, 0x6302},
    {0x6320, 0x62FE},
    {0x6324, 0x62FE},
    {0x6328, 0x62FE},
    {0x6342, 0x62F8},
    {0x634A, 0x62F8},
    {0x634E, 0x6332},
    {0x6350, 0x62F8},
    {0x6358, 0x62F8},
    {0x635C, 0x6332},
    {0x635E, 0x62F8},
    {0x6362, 0x632E},
    {0x6364, 0x62F8},
    {0x6368, 0x632E},
    {0x636A, 0x62F8},
    {0x63FA, 0x63EA},
    {0x6402, 0x6412},
    {0x6404, 0x63C2},
    {0x640A, 0x6412},
    {0x6556, 0x64C0},
    {0x65EE, 0x65CE},
    {0x6600, 0x65CE},
    {0x660E, 0x65A0},
    {0x6616, 0x65CE},
    {0x661E, 0x64D0},
    {0x66B6, 0x65CE},
    {0x66C2, 0x65CE},
    {0x66D0, 0x65A0},
    {0x66D8, 0x65CE},
    {0x66E0, 0x64D0},
    {0x67A6, 0x65CE},
    {0x67B0, 0x65CE},
    {0x67C2, 0x65A0},
    {0x67CA, 0x65CE},
    {0x67D2, 0x64D0},
    {0x68D4, 0x65CE},
    {0x68D8, 0x65A0},
    {0x68E8, 0x65CE},
    {0x6904, 0x65CE},
    {0x6908, 0x65A0},
    {0x690C, 0x68DC},
    {0x6926, 0x691A},
    {0x6A84, 0x6AB6},
    {0x6AD2, 0x6C16},
    {0x6AF6, 0x5CE2},
    {0x6B00, 0x6B0E},
    {0x6B40, 0x6AFE},
    {0x6B8C, 0x5CE2},
    {0x6BEC, 0x69DA},
    {0x6C16, 0x69C8},
    {0x6C28, 0x6D58},
    {0x6C2E, 0x6D4E},
    {0x6C48, 0x6D4E},
    {0x6C8A, 0x6D80},
    {0x6C96, 0x6D58},
    {0x6C9E, 0x6D68},
    {0x6CA2, 0x6D74},
    {0x6CA8, 0x6D58},
    {0x6CAE, 0x6D68},
    {0x6CE8, 0x6D5E},
    {0x6D06, 0x6D5E},
    {0x6D24, 0x6D74},
    {0x6D28, 0x6D74},
    {0x6D30, 0x6D80},
    {0x6D46, 0x6D58},
    {0x6D6E, 0x6BEC},
    {0x6D74, 0x6D80},
};
const unsigned nm195_direct_calls_count = sizeof nm195_direct_calls / sizeof nm195_direct_calls[0];
/* Reachable instruction listing, including indirect-branch limitations: */
/* 0x0CBE: 8a 93        st	-Y, r24 */
/* 0x0CC0: 97 98        cbi	0x12, 0x7 */
/* 0x0CC2: 8f ef        ldi	r24, 0xff */
/* 0x0CC4: 8f 9a        sbi	0x11, 0x7 */
/* 0x0CC6: 0f d0        rcall	.+30 */
/* 0x0CC8: f8 94        cli */
/* 0x0CCA: 8f 98        cbi	0x11, 0x7 */
/* 0x0CCC: 8a 95        dec	r24 */
/* 0x0CCE: 11 f0        breq	.+4 */
/* 0x0CD0: 87 99        sbic	0x10, 0x7 */
/* 0x0CD2: fc cf        rjmp	.-8 */
/* 0x0CD4: 78 94        sei */
/* 0x0CD6: 07 d0        rcall	.+14 */
/* 0x0CD8: 88 23        tst	r24 */
/* 0x0CDA: 11 f4        brne	.+4 */
/* 0x0CDC: 01 e0        ldi	r16, 0x1 */
/* 0x0CDE: 01 c0        rjmp	.+2 */
/* 0x0CE0: 00 e0        ldi	r16, 0x0 */
/* 0x0CE2: 89 91        ld	r24, Y+ */
/* 0x0CE4: 08 95        ret */
/* 0x0CE6: 04 e6        ldi	r16, 0x64 */
/* 0x0CE8: 50 c0        rjmp	.+160 */
/* 0x0CEA: f8 94        cli */
/* 0x0CEC: 8f 9a        sbi	0x11, 0x7 */
/* 0x0CEE: 00 23        tst	r16 */
/* 0x0CF0: 09 f0        breq	.+2 */
/* 0x0CF2: 8f 98        cbi	0x11, 0x7 */
/* 0x0CF4: 01 e2        ldi	r16, 0x21 */
/* 0x0CF6: 0a 95        dec	r16 */
/* 0x0CF8: f1 f7        brne	.-4 */
/* 0x0CFA: 00 00        nop */
/* 0x0CFC: 8f 98        cbi	0x11, 0x7 */
/* 0x0CFE: 78 94        sei */
/* 0x0D00: 08 95        ret */
/* 0x0D02: 8a 93        st	-Y, r24 */
/* 0x0D04: f8 94        cli */
/* 0x0D06: 8f 9a        sbi	0x11, 0x7 */
/* 0x0D08: 8f 98        cbi	0x11, 0x7 */
/* 0x0D0A: 0b d0        rcall	.+22 */
/* 0x0D0C: 0a d0        rcall	.+20 */
/* 0x0D0E: 80 b3        in	r24, 0x10 */
/* 0x0D10: 78 94        sei */
/* 0x0D12: 0f e0        ldi	r16, 0xf */
/* 0x0D14: 3a d0        rcall	.+116 */
/* 0x0D16: 87 fb        bst	r24, 0x7 */
/* 0x0D18: 16 f4        brtc	.+4 */
/* 0x0D1A: 01 e0        ldi	r16, 0x1 */
/* 0x0D1C: 01 c0        rjmp	.+2 */
/* 0x0D1E: 00 e0        ldi	r16, 0x0 */
/* 0x0D20: e0 cf        rjmp	.-64 */
/* 0x0D2C: 9a 93        st	-Y, r25 */
/* 0x0D2E: 8a 93        st	-Y, r24 */
/* 0x0D30: 90 2f        mov	r25, r16 */
/* 0x0D32: 81 e0        ldi	r24, 0x1 */
/* 0x0D34: 09 2f        mov	r16, r25 */
/* 0x0D36: 08 23        and	r16, r24 */
/* 0x0D38: d8 df        rcall	.-80 */
/* 0x0D3A: 88 0f        lsl	r24 */
/* 0x0D3C: d9 f7        brne	.-10 */
/* 0x0D3E: 89 91        ld	r24, Y+ */
/* 0x0D40: 99 91        ld	r25, Y+ */
/* 0x0D42: 08 95        ret */
/* 0x0D44: 08 e0        ldi	r16, 0x8 */
/* 0x0D46: 0e 94 ee 34  <unknown> */
/* 0x0D4A: 40 2e        mov	r4, r16 */
/* 0x0D4C: a1 e0        ldi	r26, 0x1 */
/* 0x0D4E: b0 e0        ldi	r27, 0x0 */
/* 0x0D50: 80 e0        ldi	r24, 0x0 */
/* 0x0D52: 90 e0        ldi	r25, 0x0 */
/* 0x0D54: d6 df        rcall	.-84 */
/* 0x0D56: 00 23        tst	r16 */
/* 0x0D58: 11 f0        breq	.+4 */
/* 0x0D5A: 8a 2b        or	r24, r26 */
/* 0x0D5C: 9b 2b        or	r25, r27 */
/* 0x0D5E: aa 0f        lsl	r26 */
/* 0x0D60: bb 1f        rol	r27 */
/* 0x0D62: 4a 94        dec	r4 */
/* 0x0D64: b9 f7        brne	.-18 */
/* 0x0D66: 8c 01 e5 e0  <unknown> */
/* 0x0D6A: 0c 94 ff 34  <unknown> */
/* 0x0D6E: 0e 94 ef 34  <unknown> */
/* 0x0D72: d8 01 82 2f  <unknown> */
/* 0x0D76: 02 c0        rjmp	.+4 */
/* 0x0D78: 0d 91        ld	r16, X+ */
/* 0x0D7A: d8 df        rcall	.-80 */
/* 0x0D7C: 08 2f        mov	r16, r24 */
/* 0x0D7E: 8a 95        dec	r24 */
/* 0x0D80: 00 23        tst	r16 */
/* 0x0D82: d1 f7        brne	.-12 */
/* 0x0D84: e4 e0        ldi	r30, 0x4 */
/* 0x0D86: 0c 94 00 35  <unknown> */
/* 0x0D8A: 10 2f        mov	r17, r16 */
/* 0x0D8C: 0a 95        dec	r16 */
/* 0x0D8E: 11 23        tst	r17 */
/* 0x0D90: e1 f7        brne	.-8 */
/* 0x0D92: 08 95        ret */
/* 0x0D94: d1 98        cbi	0x1a, 0x1 */
/* 0x0D96: 0f e8        ldi	r16, 0x8f */
/* 0x0D98: 06 b9        out	0x6, r16 */
/* 0x0D9A: 05 b7        in	r16, 0x35 */
/* 0x0D9C: 00 61        ori	r16, 0x10 */
/* 0x0D9E: 05 bf        out	0x35, r16 */
/* 0x0DA0: 01 e0        ldi	r16, 0x1 */
/* 0x0DA2: 2f b7        in	r18, 0x3f */
/* 0x0DA4: f8 94        cli */
/* 0x0DA6: 10 2f        mov	r17, r16 */
/* 0x0DA8: 10 5c        subi	r17, 0xc0 */
/* 0x0DAA: 17 b9        out	0x7, r17 */
/* 0x0DAC: 36 9a        sbi	0x6, 0x6 */
/* 0x0DAE: 34 9b        sbis	0x6, 0x4 */
/* 0x0DB0: fe cf        rjmp	.-4 */
/* 0x0DCC: 18 95        reti */
/* 0x0DCE: 60 e0        ldi	r22, 0x0 */
/* 0x0DD0: 00 e0        ldi	r16, 0x0 */
/* 0x0DD2: 10 e0        ldi	r17, 0x0 */
/* 0x0DD4: 20 e8        ldi	r18, 0x80 */
/* 0x0DD6: 3f e3        ldi	r19, 0x3f */
/* 0x0DD8: 44 e0        ldi	r20, 0x4 */
/* 0x0DDA: 64 9f 40 e0  <unknown> */
/* 0x0DDE: 50 e0        ldi	r21, 0x0 */
/* 0x0DE0: 40 0d        add	r20, r0 */
/* 0x0DE2: 51 1d        adc	r21, r1 */
/* 0x0DE4: 0e 94 ab 31  <unknown> */
/* 0x0DE8: 63 95        inc	r22 */
/* 0x0DEA: 64 30        cpi	r22, 0x4 */
/* 0x0DEC: 88 f3        brlo	.-30 */
/* 0x0DEE: 05 e2        ldi	r16, 0x25 */
/* 0x0DF0: 40 e1        ldi	r20, 0x10 */
/* 0x0DF2: 50 e0        ldi	r21, 0x0 */
/* 0x0DF4: 0e d0        rcall	.+28 */
/* 0x0DF6: 00 e5        ldi	r16, 0x50 */
/* 0x0DF8: 41 e1        ldi	r20, 0x11 */
/* 0x0DFA: 50 e0        ldi	r21, 0x0 */
/* 0x0DFC: 0a d0        rcall	.+20 */
/* 0x0DFE: 01 e0        ldi	r16, 0x1 */
/* 0x0E00: 42 e1        ldi	r20, 0x12 */
/* 0x0E02: 50 e0        ldi	r21, 0x0 */
/* 0x0E04: 06 d0        rcall	.+12 */
/* 0x0E06: 43 e1        ldi	r20, 0x13 */
/* 0x0E08: 50 e0        ldi	r21, 0x0 */
/* 0x0E0A: 03 d0        rcall	.+6 */
/* 0x0E0C: 00 e0        ldi	r16, 0x0 */
/* 0x0E0E: 44 e1        ldi	r20, 0x14 */
/* 0x0E10: 50 e0        ldi	r21, 0x0 */
/* 0x0E12: 0c 94 a0 31  <unknown> */
/* 0x11AC: a9 98        cbi	0x15, 0x1 */
/* 0x11AE: 00 23        tst	r16 */
/* 0x11B0: 11 f0        breq	.+4 */
/* 0x11B2: a1 98        cbi	0x14, 0x1 */
/* 0x11B4: 01 c0        rjmp	.+2 */
/* 0x11B6: a1 9a        sbi	0x14, 0x1 */
/* 0x11B8: 99 9b        sbis	0x13, 0x1 */
/* 0x11BA: 02 c0        rjmp	.+4 */
/* 0x11C0: 00 e0        ldi	r16, 0x0 */
/* 0x11C2: 08 95        ret */
/* 0x11C4: a0 9a        sbi	0x14, 0x0 */
/* 0x11C6: 00 23        tst	r16 */
/* 0x11C8: 11 f0        breq	.+4 */
/* 0x11CA: a8 9a        sbi	0x15, 0x0 */
/* 0x11CC: 08 95        ret */
/* 0x11CE: a8 98        cbi	0x15, 0x0 */
/* 0x11D0: 08 95        ret */
/* 0x11D2: 1d d0        rcall	.+58 */
/* 0x11D4: 25 d0        rcall	.+74 */
/* 0x11D6: 1a d0        rcall	.+52 */
/* 0x11D8: 18 d0        rcall	.+48 */
/* 0x11DA: 65 d0        rcall	.+202 */
/* 0x11DC: 01 ed        ldi	r16, 0xd1 */
/* 0x11DE: 16 d0        rcall	.+44 */
/* 0x11E0: 03 c0        rjmp	.+6 */
/* 0x11E2: 09 2f        mov	r16, r25 */
/* 0x11E4: 3f d0        rcall	.+126 */
/* 0x11E6: 0d 93        st	X+, r16 */
/* 0x11E8: 17 d0        rcall	.+46 */
/* 0x11EA: d9 f7        brne	.-10 */
/* 0x11EC: 0e d0        rcall	.+28 */
/* 0x11EE: e4 e0        ldi	r30, 0x4 */
/* 0x11F0: 0c 94 00 35  <unknown> */
/* 0x11F4: 0c d0        rcall	.+24 */
/* 0x11F6: 33 23        tst	r19 */
/* 0x11F8: 39 f0        breq	.+14 */
/* 0x11FA: 12 d0        rcall	.+36 */
/* 0x11FC: 01 c0        rjmp	.+2 */
/* 0x11FE: 0d 91        ld	r16, X+ */
/* 0x1200: 05 d0        rcall	.+10 */
/* 0x1202: 0a d0        rcall	.+20 */
/* 0x1204: e1 f7        brne	.-8 */
/* 0x1206: 01 d0        rcall	.+2 */
/* 0x1208: f2 cf        rjmp	.-28 */
/* 0x120A: 50 c0        rjmp	.+160 */
/* 0x120C: 0e c0        rjmp	.+28 */
/* 0x120E: 0e 94 ef 34  <unknown> */
/* 0x1212: c9 01 d8 01  <unknown> */
/* 0x1216: 08 95        ret */
/* 0x1218: 09 2f        mov	r16, r25 */
/* 0x121A: 9a 95        dec	r25 */
/* 0x121C: 00 23        tst	r16 */
/* 0x121E: 08 95        ret */
/* 0x1220: 42 d0        rcall	.+132 */
/* 0x1222: 00 ed        ldi	r16, 0xd0 */
/* 0x1224: 02 d0        rcall	.+4 */
/* 0x1226: 08 2f        mov	r16, r24 */
/* 0x1228: 08 95        ret */
/* 0x122A: 9a 93        st	-Y, r25 */
/* 0x122C: 8a 93        st	-Y, r24 */
/* 0x122E: 90 2f        mov	r25, r16 */
/* 0x1230: 88 e0        ldi	r24, 0x8 */
/* 0x1232: 04 c0        rjmp	.+8 */
/* 0x1234: 00 e0        ldi	r16, 0x0 */
/* 0x1236: 31 d0        rcall	.+98 */
/* 0x1238: 99 0f        lsl	r25 */
/* 0x123A: 30 d0        rcall	.+96 */
/* 0x123C: 08 2f        mov	r16, r24 */
/* 0x123E: 8a 95        dec	r24 */
/* 0x1240: 00 23        tst	r16 */
/* 0x1242: 21 f0        breq	.+8 */
/* 0x1244: 97 fb        bst	r25, 0x7 */
/* 0x1246: b6 f7        brtc	.-20 */
/* 0x1248: 01 e0        ldi	r16, 0x1 */
/* 0x124A: f5 cf        rjmp	.-22 */
/* 0x124C: 25 d0        rcall	.+74 */
/* 0x124E: 23 d0        rcall	.+70 */
/* 0x1250: 00 23        tst	r16 */
/* 0x1252: 11 f0        breq	.+4 */
/* 0x1254: 81 e0        ldi	r24, 0x1 */
/* 0x1256: 01 c0        rjmp	.+2 */
/* 0x1258: 80 e0        ldi	r24, 0x0 */
/* 0x125A: 21 d0        rcall	.+66 */
/* 0x125C: 08 2f        mov	r16, r24 */
/* 0x125E: 89 91        ld	r24, Y+ */
/* 0x1260: 99 91        ld	r25, Y+ */
/* 0x1262: 08 95        ret */
/* 0x1264: 0e 94 f0 34  <unknown> */
/* 0x1268: a0 2f        mov	r26, r16 */
/* 0x126A: 98 e0        ldi	r25, 0x8 */
/* 0x126C: 15 d0        rcall	.+42 */
/* 0x126E: 06 c0        rjmp	.+12 */
/* 0x1270: 88 0f        lsl	r24 */
/* 0x1272: 11 d0        rcall	.+34 */
/* 0x1274: 00 23        tst	r16 */
/* 0x1276: 09 f0        breq	.+2 */
/* 0x1278: 81 60        ori	r24, 0x1 */
/* 0x127A: 11 d0        rcall	.+34 */
/* 0x127C: cd df        rcall	.-102 */
/* 0x127E: c1 f7        brne	.-16 */
/* 0x1280: aa 23        tst	r26 */
/* 0x1282: 11 f0        breq	.+4 */
/* 0x1284: 00 e0        ldi	r16, 0x0 */
/* 0x1286: 01 c0        rjmp	.+2 */
/* 0x1288: 01 e0        ldi	r16, 0x1 */
/* 0x128A: 07 d0        rcall	.+14 */
/* 0x128C: 07 d0        rcall	.+14 */
/* 0x128E: 08 2f        mov	r16, r24 */
/* 0x1290: e3 e0        ldi	r30, 0x3 */
/* 0x1292: 0c 94 01 35  <unknown> */
/* 0x1296: 05 d0        rcall	.+10 */
/* 0x1298: 01 e0        ldi	r16, 0x1 */
/* 0x129A: 88 cf        rjmp	.-240 */
/* 0x129C: 02 d0        rcall	.+4 */
/* 0x129E: 00 e0        ldi	r16, 0x0 */
/* 0x12A0: 91 cf        rjmp	.-222 */
/* 0x12A2: 01 e0        ldi	r16, 0x1 */
/* 0x12A4: fd cf        rjmp	.-6 */
/* 0x12A6: 00 e0        ldi	r16, 0x0 */
/* 0x12A8: f8 df        rcall	.-16 */
/* 0x12AA: f9 cf        rjmp	.-14 */
/* 0x12AC: fa df        rcall	.-12 */
/* 0x12AE: 01 e0        ldi	r16, 0x1 */
/* 0x12B0: f4 cf        rjmp	.-24 */
/* 0x12C4: 13 d0        rcall	.+38 */
/* 0x12C6: 05 e5        ldi	r16, 0x55 */
/* 0x12C8: 46 d0        rcall	.+140 */
/* 0x12CA: 28 e0        ldi	r18, 0x8 */
/* 0x12CC: 01 e8        ldi	r16, 0x81 */
/* 0x12CE: 16 e0        ldi	r17, 0x6 */
/* 0x12D0: 0c 94 b7 06  <unknown> */
/* 0x12EC: 0c 94 5f 06  <unknown> */
/* 0x1312: 13 d0        rcall	.+38 */
/* 0x1314: 23 97 a0 2f  <unknown> */
/* 0x1318: 81 2f        mov	r24, r17 */
/* 0x131A: 0b d0        rcall	.+22 */
/* 0x131C: b0 e0        ldi	r27, 0x0 */
/* 0x131E: ea 0f        add	r30, r26 */
/* 0x1320: fb 1f        adc	r31, r27 */
/* 0x1322: 00 81        ldd	r16, Z+0 */
/* 0x1324: 08 17        cp	r16, r24 */
/* 0x1326: 19 f0        breq	.+6 */
/* 0x1328: 80 83        std	Z+0, r24 */
/* 0x132A: 8e 01 e1 df  <unknown> */
/* 0x132E: 23 96 da cf  <unknown> */
/* 0x1332: 8e 01 cf df  <unknown> */
/* 0x1336: fe 01 08 95  <unknown> */
/* 0x133A: 0c 94 ef 34  <unknown> */
/* 0x133E: 09 d0        rcall	.+18 */
/* 0x1340: 04 eb        ldi	r16, 0xb4 */
/* 0x1342: 09 d0        rcall	.+18 */
/* 0x1344: 44 d0        rcall	.+136 */
/* 0x1346: 11 f0        breq	.+4 */
/* 0x1348: 1f e7        ldi	r17, 0x7f */
/* 0x134A: 01 c0        rjmp	.+2 */
/* 0x134C: 1f e3        ldi	r17, 0x3f */
/* 0x134E: 02 e0        ldi	r16, 0x2 */
/* 0x1350: e0 cf        rjmp	.-64 */
/* 0x1352: b8 cf        rjmp	.-144 */
/* 0x1356: 0c 94 96 06  <unknown> */
/* 0x135A: ef df        rcall	.-34 */
/* 0x135C: e3 d0        rcall	.+454 */
/* 0x135E: 69 f0        breq	.+26 */
/* 0x1360: 8f 9a        sbi	0x11, 0x7 */
/* 0x1362: 97 9a        sbi	0x12, 0x7 */
/* 0x1364: 0f ef        ldi	r16, 0xff */
/* 0x1366: 10 e7        ldi	r17, 0x70 */
/* 0x1368: 22 e0        ldi	r18, 0x2 */
/* 0x136A: 01 50        subi	r16, 0x1 */
/* 0x136C: 10 40        sbci	r17, 0x0 */
/* 0x136E: 20 40        sbci	r18, 0x0 */
/* 0x1370: e1 f7        brne	.-8 */
/* 0x1372: 00 c0        rjmp	.+0 */
/* 0x1374: 00 00        nop */
/* 0x1376: 8f 98        cbi	0x11, 0x7 */
/* 0x1378: 97 98        cbi	0x12, 0x7 */
/* 0x137A: 29 d0        rcall	.+82 */
/* 0x137C: f1 f3        breq	.-4 */
/* 0x137E: 2c d0        rcall	.+88 */
/* 0x1380: c8 01 00 e2  <unknown> */
/* 0x1384: 0e 94 a3 06  <unknown> */
/* 0x1388: 25 d0        rcall	.+74 */
/* 0x138A: a0 2f        mov	r26, r16 */
/* 0x138C: 23 d0        rcall	.+70 */
/* 0x138E: 20 2f        mov	r18, r16 */
/* 0x1390: 00 91 81 06  <unknown> */
/* 0x1394: 00 31        cpi	r16, 0x10 */
/* 0x1396: 59 f4        brne	.+22 */
/* 0x1398: 8e 7f        andi	r24, 0xfe */
/* 0x139A: 42 e3        ldi	r20, 0x32 */
/* 0x139C: 50 e0        ldi	r21, 0x0 */
/* 0x139E: 8c 01 a2 d0  <unknown> */
/* 0x13A2: 42 2f        mov	r20, r18 */
/* 0x13A4: 4a 1b        sub	r20, r26 */
/* 0x13A6: a2 d0        rcall	.+324 */
/* 0x13A8: 42 2f        mov	r20, r18 */
/* 0x13AA: a5 d0        rcall	.+330 */
/* 0x13AC: 0e c0        rjmp	.+28 */
/* 0x13AE: 44 e0        ldi	r20, 0x4 */
/* 0x13B0: 8c 01 0e 94  <unknown> */
/* 0x13B4: db 31        cpi	r29, 0x1b */
/* 0x13B6: 44 e6        ldi	r20, 0x64 */
/* 0x13B8: 50 e0        ldi	r21, 0x0 */
/* 0x13BA: 9b d0        rcall	.+310 */
/* 0x13BC: d8 01 8f 70  <unknown> */
/* 0x13C0: 08 2f        mov	r16, r24 */
/* 0x13C2: a0 d0        rcall	.+320 */
/* 0x13C4: cd 01 80 0f  <unknown> */
/* 0x13C8: 91 1f        adc	r25, r17 */
/* 0x13CA: 8c 01 8c cf  <unknown> */
/* 0x13CE: b9 d0        rcall	.+370 */
/* 0x13D0: 00 23        tst	r16 */
/* 0x13D2: 08 95        ret */
/* 0x13D4: 0c 94 a2 06  <unknown> */
/* 0x13D8: bc df        rcall	.-136 */
/* 0x13DA: 0e eb        ldi	r16, 0xbe */
/* 0x13DC: bc df        rcall	.-136 */
/* 0x13DE: 00 e1        ldi	r16, 0x10 */
/* 0x13E0: 0c 94 a3 06  <unknown> */
/* 0x14EC: 50 40        sbci	r21, 0x0 */
/* 0x14EE: 04 e6        ldi	r16, 0x64 */
/* 0x14F0: 10 e0        ldi	r17, 0x0 */
/* 0x14F2: 0c 94 cd 31  <unknown> */
/* 0x14F6: 50 e0        ldi	r21, 0x0 */
/* 0x14F8: 0e 94 f9 31  <unknown> */
/* 0x14FC: 80 0f        add	r24, r16 */
/* 0x14FE: 91 1f        adc	r25, r17 */
/* 0x1500: 49 97 08 95  <unknown> */
/* 0x1504: f5 df        rcall	.-22 */
/* 0x1506: 40 e1        ldi	r20, 0x10 */
/* 0x1508: 0c 94 f9 31  <unknown> */
/* 0x150C: 0b d0        rcall	.+22 */
/* 0x150E: 49 f0        breq	.+18 */
/* 0x1510: 97 9a        sbi	0x12, 0x7 */
/* 0x1512: 8f 9a        sbi	0x11, 0x7 */
/* 0x1514: 82 9b        sbis	0x10, 0x2 */
/* 0x1516: 02 c0        rjmp	.+4 */
/* 0x151C: 00 e0        ldi	r16, 0x0 */
/* 0x151E: 00 93 89 06  <unknown> */
/* 0x1522: 08 95        ret */
/* 0x1524: 16 df        rcall	.-468 */
/* 0x1526: 04 eb        ldi	r16, 0xb4 */
/* 0x1528: 16 df        rcall	.-468 */
/* 0x152A: 0b d0        rcall	.+22 */
/* 0x152C: 00 23        tst	r16 */
/* 0x152E: 11 f4        brne	.+4 */
/* 0x1530: 01 e0        ldi	r16, 0x1 */
/* 0x1532: 01 c0        rjmp	.+2 */
/* 0x1534: 00 e0        ldi	r16, 0x0 */
/* 0x1536: 00 93 7f 06  <unknown> */
/* 0x153A: 0b df        rcall	.-490 */
/* 0x153C: 04 e4        ldi	r16, 0x44 */
/* 0x153E: 0b df        rcall	.-490 */
/* 0x1540: 02 c0        rjmp	.+4 */
/* 0x1542: 0c 94 81 06  <unknown> */
/* 0x1546: 00 91 7f 06  <unknown> */
/* 0x154A: 42 cf        rjmp	.-380 */
/* 0x1D8C: c1 98        cbi	0x18, 0x1 */
/* 0x1D8E: c2 98        cbi	0x18, 0x2 */
/* 0x1D90: 0f ef        ldi	r16, 0xff */
/* 0x1D92: 07 bb        out	0x17, r16 */
/* 0x1D94: 08 b3        in	r16, 0x18 */
/* 0x1D96: 0f 70        andi	r16, 0xf */
/* 0x1D98: 08 bb        out	0x18, r16 */
/* 0x1D9A: 05 ea        ldi	r16, 0xa5 */
/* 0x1D9C: 1e e0        ldi	r17, 0xe */
/* 0x1D9E: 01 50        subi	r16, 0x1 */
/* 0x1DA0: 10 40        sbci	r17, 0x0 */
/* 0x1DA2: e9 f7        brne	.-6 */
/* 0x1DA4: 00 c0        rjmp	.+0 */
/* 0x1DA6: 00 00        nop */
/* 0x1DA8: 08 b3        in	r16, 0x18 */
/* 0x1DAA: 00 63        ori	r16, 0x30 */
/* 0x1DAC: 08 bb        out	0x18, r16 */
/* 0x1DAE: 1e d0        rcall	.+60 */
/* 0x1DB0: 01 ee        ldi	r16, 0xe1 */
/* 0x1DB2: 14 e0        ldi	r17, 0x4 */
/* 0x1DB4: 01 50        subi	r16, 0x1 */
/* 0x1DB6: 10 40        sbci	r17, 0x0 */
/* 0x1DB8: e9 f7        brne	.-6 */
/* 0x1DBA: 00 c0        rjmp	.+0 */
/* 0x1DBC: 00 00        nop */
/* 0x1DBE: 10 d0        rcall	.+32 */
/* 0x1DC0: 0f d0        rcall	.+30 */
/* 0x1DC2: 08 b3        in	r16, 0x18 */
/* 0x1DC4: 0f 70        andi	r16, 0xf */
/* 0x1DC6: 08 bb        out	0x18, r16 */
/* 0x1DC8: c5 9a        sbi	0x18, 0x5 */
/* 0x1DCA: 0a d0        rcall	.+20 */
/* 0x1DCC: 10 e0        ldi	r17, 0x0 */
/* 0x1DCE: 0a e2        ldi	r16, 0x2a */
/* 0x1DD0: 4a d0        rcall	.+148 */
/* 0x1DD2: 10 e0        ldi	r17, 0x0 */
/* 0x1DD4: 0c e0        ldi	r16, 0xc */
/* 0x1DD6: 47 d0        rcall	.+142 */
/* 0x1DD8: 10 e0        ldi	r17, 0x0 */
/* 0x1DDA: 06 e0        ldi	r16, 0x6 */
/* 0x1DDC: 44 d0        rcall	.+136 */
/* 0x1DDE: 53 c0        rjmp	.+166 */
/* 0x1DE0: 05 d0        rcall	.+10 */
/* 0x1DE2: 02 e4        ldi	r16, 0x42 */
/* 0x1DE4: 0a 95        dec	r16 */
/* 0x1DE6: f1 f7        brne	.-4 */
/* 0x1DE8: 00 c0        rjmp	.+0 */
/* 0x1DEA: 08 95        ret */
/* 0x1DEC: c0 9a        sbi	0x18, 0x0 */
/* 0x1DEE: 03 e0        ldi	r16, 0x3 */
/* 0x1DF0: 0a 95        dec	r16 */
/* 0x1DF2: f1 f7        brne	.-4 */
/* 0x1DF4: 00 00        nop */
/* 0x1DF6: c0 98        cbi	0x18, 0x0 */
/* 0x1DF8: 08 95        ret */
/* 0x1DFA: 17 b3        in	r17, 0x17 */
/* 0x1DFC: 1f ef        ldi	r17, 0xff */
/* 0x1DFE: 17 bb        out	0x17, r17 */
/* 0x1E00: c1 98        cbi	0x18, 0x1 */
/* 0x1E02: 18 b3        in	r17, 0x18 */
/* 0x1E04: 1f 70        andi	r17, 0xf */
/* 0x1E06: 18 bb        out	0x18, r17 */
/* 0x1E08: 10 2f        mov	r17, r16 */
/* 0x1E0A: 10 7f        andi	r17, 0xf0 */
/* 0x1E0C: 28 b3        in	r18, 0x18 */
/* 0x1E0E: 21 2b        or	r18, r17 */
/* 0x1E10: 28 bb        out	0x18, r18 */
/* 0x1E12: c0 9a        sbi	0x18, 0x0 */
/* 0x1E14: c0 98        cbi	0x18, 0x0 */
/* 0x1E16: 18 b3        in	r17, 0x18 */
/* 0x1E18: 1f 70        andi	r17, 0xf */
/* 0x1E1A: 18 bb        out	0x18, r17 */
/* 0x1E1C: 02 95        swap	r16 */
/* 0x1E1E: 00 7f        andi	r16, 0xf0 */
/* 0x1E20: 18 b3        in	r17, 0x18 */
/* 0x1E22: 10 2b        or	r17, r16 */
/* 0x1E24: 18 bb        out	0x18, r17 */
/* 0x1E26: c0 9a        sbi	0x18, 0x0 */
/* 0x1E28: e6 cf        rjmp	.-52 */
/* 0x1E2A: 07 b3        in	r16, 0x17 */
/* 0x1E2C: 0f 70        andi	r16, 0xf */
/* 0x1E2E: 07 bb        out	0x17, r16 */
/* 0x1E30: 08 b3        in	r16, 0x18 */
/* 0x1E32: 00 6f        ori	r16, 0xf0 */
/* 0x1E34: 08 bb        out	0x18, r16 */
/* 0x1E36: c1 9a        sbi	0x18, 0x1 */
/* 0x1E38: c0 9a        sbi	0x18, 0x0 */
/* 0x1E3A: 00 00        nop */
/* 0x1E3C: 06 b3        in	r16, 0x16 */
/* 0x1E3E: c0 98        cbi	0x18, 0x0 */
/* 0x1E40: c0 9a        sbi	0x18, 0x0 */
/* 0x1E42: 00 00        nop */
/* 0x1E44: 16 b3        in	r17, 0x16 */
/* 0x1E46: 10 7f        andi	r17, 0xf0 */
/* 0x1E48: 12 95        swap	r17 */
/* 0x1E4A: c0 98        cbi	0x18, 0x0 */
/* 0x1E4C: 00 7f        andi	r16, 0xf0 */
/* 0x1E4E: 01 2b        or	r16, r17 */
/* 0x1E50: 08 95        ret */
/* 0x1E52: 11 23        tst	r17 */
/* 0x1E54: 19 f0        breq	.+6 */
/* 0x1E56: 1a 95        dec	r17 */
/* 0x1E58: 21 f0        breq	.+8 */
/* 0x1E5A: 08 95        ret */
/* 0x1E5C: 10 e0        ldi	r17, 0x0 */
/* 0x1E5E: 00 58        subi	r16, 0x80 */
/* 0x1E60: 02 c0        rjmp	.+4 */
/* 0x1E62: 10 e0        ldi	r17, 0x0 */
/* 0x1E64: 00 54        subi	r16, 0x40 */
/* 0x1E66: 3c c0        rjmp	.+120 */
/* 0x1E68: 9a 93        st	-Y, r25 */
/* 0x1E6A: 8a 93        st	-Y, r24 */
/* 0x1E6C: c8 01 12 2f  <unknown> */
/* 0x1E70: f0 df        rcall	.-32 */
/* 0x1E72: 04 c0        rjmp	.+8 */
/* 0x1E74: 11 e0        ldi	r17, 0x1 */
/* 0x1E76: 00 e2        ldi	r16, 0x20 */
/* 0x1E78: f6 df        rcall	.-20 */
/* 0x1E7A: 83 95        inc	r24 */
/* 0x1E7C: 98 17        cp	r25, r24 */
/* 0x1E7E: d0 f7        brsh	.-12 */
/* 0x1E80: 89 91        ld	r24, Y+ */
/* 0x1E82: 99 91        ld	r25, Y+ */
/* 0x1E84: 08 95        ret */
/* 0x1E86: 10 e0        ldi	r17, 0x0 */
/* 0x1E88: 01 e0        ldi	r16, 0x1 */
/* 0x1E8A: ed df        rcall	.-38 */
/* 0x1E8C: 0d ee        ldi	r16, 0xed */
/* 0x1E8E: 12 e0        ldi	r17, 0x2 */
/* 0x1E90: 01 50        subi	r16, 0x1 */
/* 0x1E92: 10 40        sbci	r17, 0x0 */
/* 0x1E94: e9 f7        brne	.-6 */
/* 0x1E96: 00 c0        rjmp	.+0 */
/* 0x1E98: 00 00        nop */
/* 0x1E9A: 08 95        ret */
/* 0x1E9C: 11 e0        ldi	r17, 0x1 */
/* 0x1E9E: 65 d0        rcall	.+202 */
/* 0x1EA0: 04 91 e1 cf  <unknown> */
/* 0x1EA4: 05 d0        rcall	.+10 */
/* 0x1EA6: fa df        rcall	.-12 */
/* 0x1EA8: a3 95        inc	r26 */
/* 0x1EAA: a0 34        cpi	r26, 0x40 */
/* 0x1EAC: e0 f3        brlo	.-8 */
/* 0x1EAE: 4a c0        rjmp	.+148 */
/* 0x1EB0: 0e 94 ef 34  <unknown> */
/* 0x1EB4: c8 01 10 e0  <unknown> */
/* 0x1EB8: 00 e4        ldi	r16, 0x40 */
/* 0x1EBA: 12 d0        rcall	.+36 */
/* 0x1EBC: a0 e0        ldi	r26, 0x0 */
/* 0x1EBE: 08 95        ret */
/* 0x1EC0: 44 d0        rcall	.+136 */
/* 0x1EC2: c8 01 10 e0  <unknown> */
/* 0x1EC6: 22 0f        lsl	r18 */
/* 0x1EC8: 22 0f        lsl	r18 */
/* 0x1ECA: 22 0f        lsl	r18 */
/* 0x1ECC: 2f 77        andi	r18, 0x7f */
/* 0x1ECE: 20 64        ori	r18, 0x40 */
/* 0x1ED0: 02 2f        mov	r16, r18 */
/* 0x1ED2: c9 df        rcall	.-110 */
/* 0x1ED4: a0 e0        ldi	r26, 0x0 */
/* 0x1ED6: e2 df        rcall	.-60 */
/* 0x1ED8: a3 95        inc	r26 */
/* 0x1EDA: a8 30        cpi	r26, 0x8 */
/* 0x1EDC: e0 f3        brlo	.-8 */
/* 0x1EDE: 32 c0        rjmp	.+100 */
/* 0x1EE0: 12 d0        rcall	.+36 */
/* 0x1EE2: 49 f0        breq	.+18 */
/* 0x1EE4: 08 3a        cpi	r16, 0xa8 */
/* 0x1EE6: 28 f0        brlo	.+10 */
/* 0x1EE8: f0 e0        ldi	r31, 0x0 */
/* 0x1EEA: e0 2f        mov	r30, r16 */
/* 0x1EEC: e9 5e        subi	r30, 0xe9 */
/* 0x1EEE: fe 4f        sbci	r31, 0xfe */
/* 0x1EF0: 04 91 c2 9a  <unknown> */
/* 0x1EF4: 01 c0        rjmp	.+2 */
/* 0x1EF6: c2 98        cbi	0x18, 0x2 */
/* 0x1EF8: 0b c0        rjmp	.+22 */
/* 0x1F06: 21 e0        ldi	r18, 0x1 */
/* 0x1F08: 20 93 8e 06  <unknown> */
/* 0x1F0C: 11 23        tst	r17 */
/* 0x1F0E: 08 95        ret */
/* 0x1F10: 74 df        rcall	.-280 */
/* 0x1F12: c2 98        cbi	0x18, 0x2 */
/* 0x1F14: 03 d0        rcall	.+6 */
/* 0x1F16: 07 fb        bst	r16, 0x7 */
/* 0x1F18: ee f3        brts	.-6 */
/* 0x1F1A: 08 95        ret */
/* 0x1F1C: 86 cf        rjmp	.-244 */
/* 0x1F1E: c2 9a        sbi	0x18, 0x2 */
/* 0x1F20: fd df        rcall	.-6 */
/* 0x1F22: c2 98        cbi	0x18, 0x2 */
/* 0x1F24: 08 95        ret */
/* 0x1F26: 11 d0        rcall	.+34 */
/* 0x1F28: 00 e6        ldi	r16, 0x60 */
/* 0x1F2A: 10 e0        ldi	r17, 0x0 */
/* 0x1F2C: 0e 94 3c 35  <unknown> */
/* 0x1F30: c1 df        rcall	.-126 */
/* 0x1F32: 01 c0        rjmp	.+2 */
/* 0x1F34: 1f d0        rcall	.+62 */
/* 0x1F36: f3 df        rcall	.-26 */
/* 0x1F38: 18 d0        rcall	.+48 */
/* 0x1F3A: 00 83        std	Z+0, r16 */
/* 0x1F3C: a3 95        inc	r26 */
/* 0x1F3E: a0 36        cpi	r26, 0x60 */
/* 0x1F40: c8 f3        brlo	.-14 */
/* 0x1F42: 8c 01 e4 e0  <unknown> */
/* 0x1F46: 0c 94 00 35  <unknown> */
/* 0x1F4A: 0c 94 ef 34  <unknown> */
/* 0x1F4E: b0 df        rcall	.-160 */
/* 0x1F50: 01 c0        rjmp	.+2 */
/* 0x1F52: 10 d0        rcall	.+32 */
/* 0x1F54: c2 9a        sbi	0x18, 0x2 */
/* 0x1F56: 09 d0        rcall	.+18 */
/* 0x1F58: 00 81        ldd	r16, Z+0 */
/* 0x1F5A: da df        rcall	.-76 */
/* 0x1F5C: a3 95        inc	r26 */
/* 0x1F5E: a0 36        cpi	r26, 0x60 */
/* 0x1F60: c0 f3        brlo	.-16 */
/* 0x1F62: 8c 01 0e 94  <unknown> */
/* 0x1F66: 74 31        cpi	r23, 0x14 */
/* 0x1F68: ed cf        rjmp	.-38 */
/* 0x1F6A: b0 e0        ldi	r27, 0x0 */
/* 0x1F6C: fc 01 ea 0f  <unknown> */
/* 0x1F70: fb 1f        adc	r31, r27 */
/* 0x1F72: 08 95        ret */
/* 0x1F74: a0 34        cpi	r26, 0x40 */
/* 0x1F76: 11 f4        brne	.+4 */
/* 0x1F78: 10 e0        ldi	r17, 0x0 */
/* 0x1F7A: 03 c0        rjmp	.+6 */
/* 0x1F7C: a0 35        cpi	r26, 0x50 */
/* 0x1F7E: 19 f4        brne	.+6 */
/* 0x1F80: 11 e0        ldi	r17, 0x1 */
/* 0x1F82: 00 e0        ldi	r16, 0x0 */
/* 0x1F84: 66 df        rcall	.-308 */
/* 0x1F86: 08 95        ret */
/* 0x1F88: fa 93        st	-Y, r31 */
/* 0x1F8A: ea 93        st	-Y, r30 */
/* 0x1F8C: 0a 92        st	-Y, r0 */
/* 0x1F8E: 7a 93        st	-Y, r23 */
/* 0x1F90: 6a 93        st	-Y, r22 */
/* 0x1F92: 5a 93        st	-Y, r21 */
/* 0x1F94: 4a 93        st	-Y, r20 */
/* 0x1F96: 3a 93        st	-Y, r19 */
/* 0x1F98: 2a 93        st	-Y, r18 */
/* 0x1F9A: 1a 93        st	-Y, r17 */
/* 0x1F9C: 0a 93        st	-Y, r16 */
/* 0x1F9E: 0f b6        in	r0, 0x3f */
/* 0x1FA0: db d0        rcall	.+438 */
/* 0x1FA2: 0f 5f        subi	r16, 0xff */
/* 0x1FA4: 1f 4f        sbci	r17, 0xff */
/* 0x1FA6: 2f 4f        sbci	r18, 0xff */
/* 0x1FA8: 3f 4f        sbci	r19, 0xff */
/* 0x1FAA: 00 87        std	Z+0, r16 */
/* 0x1FAC: 11 87        std	Z+1, r17 */
/* 0x1FAE: 22 87        std	Z+2, r18 */
/* 0x1FB0: 33 87        std	Z+3, r19 */
/* 0x1FB2: 44 85        ldd	r20, Z+4 */
/* 0x1FB4: 55 85        ldd	r21, Z+5 */
/* 0x1FB6: 66 85        ldd	r22, Z+6 */
/* 0x1FB8: 77 85        ldd	r23, Z+7 */
/* 0x1FBA: 04 17        cp	r16, r20 */
/* 0x1FBC: 15 07        cpc	r17, r21 */
/* 0x1FBE: 26 07        cpc	r18, r22 */
/* 0x1FC0: 37 07        cpc	r19, r23 */
/* 0x1FC2: 40 f4        brsh	.+16 */
/* 0x1FC4: 4c ee        ldi	r20, 0xec */
/* 0x1FC6: 52 e0        ldi	r21, 0x2 */
/* 0x1FC8: 0e 94 86 31  <unknown> */
/* 0x1FCC: 00 23        tst	r16 */
/* 0x1FCE: 11 f0        breq	.+4 */
/* 0x1FD0: 8d 9a        sbi	0x11, 0x5 */
/* 0x1FD2: 01 c0        rjmp	.+2 */
/* 0x1FD4: 8d 98        cbi	0x11, 0x5 */
/* 0x1FD6: 0f be        out	0x3f, r0 */
/* 0x1FD8: 09 91        ld	r16, Y+ */
/* 0x1FDA: 19 91        ld	r17, Y+ */
/* 0x1FDC: 29 91        ld	r18, Y+ */
/* 0x1FDE: 39 91        ld	r19, Y+ */
/* 0x1FE0: 49 91        ld	r20, Y+ */
/* 0x1FE2: 59 91        ld	r21, Y+ */
/* 0x1FE4: 69 91        ld	r22, Y+ */
/* 0x1FE6: 79 91        ld	r23, Y+ */
/* 0x1FE8: 09 90        ld	r0, Y+ */
/* 0x1FEA: e9 91        ld	r30, Y+ */
/* 0x1FEC: f9 91        ld	r31, Y+ */
/* 0x1FEE: 18 95        reti */
/* 0x1FF0: ac df        rcall	.-168 */
/* 0x1FF2: ef e8        ldi	r30, 0x8f */
/* 0x1FF4: f6 e0        ldi	r31, 0x6 */
/* 0x1FF6: 80 85        ldd	r24, Z+0 */
/* 0x1FF8: 91 85        ldd	r25, Z+1 */
/* 0x1FFA: a2 85        ldd	r26, Z+2 */
/* 0x1FFC: b3 85        ldd	r27, Z+3 */
/* 0x1FFE: 40 2f        mov	r20, r16 */
/* 0x2000: 50 e0        ldi	r21, 0x0 */
/* 0x2002: 06 e0        ldi	r16, 0x6 */
/* 0x2004: 10 e0        ldi	r17, 0x0 */
/* 0x2006: 0e 94 cd 31  <unknown> */
/* 0x200A: 21 2f        mov	r18, r17 */
/* 0x200C: 22 0f        lsl	r18 */
/* 0x200E: 22 0b        sbc	r18, r18 */
/* 0x2010: 80 0f        add	r24, r16 */
/* 0x2012: 91 1f        adc	r25, r17 */
/* 0x2014: a2 1f        adc	r26, r18 */
/* 0x2016: b2 1f        adc	r27, r18 */
/* 0x2018: 84 87        std	Z+4, r24 */
/* 0x201A: 95 87        std	Z+5, r25 */
/* 0x201C: a6 87        std	Z+6, r26 */
/* 0x201E: b7 87        std	Z+7, r27 */
/* 0x2020: 91 cf        rjmp	.-222 */
/* 0x2022: ef e8        ldi	r30, 0x8f */
/* 0x2024: f6 e0        ldi	r31, 0x6 */
/* 0x2026: 0d e3        ldi	r16, 0x3d */
/* 0x2028: 10 e0        ldi	r17, 0x0 */
/* 0x202A: 00 83        std	Z+0, r16 */
/* 0x202C: 11 83        std	Z+1, r17 */
/* 0x202E: 12 83        std	Z+2, r17 */
/* 0x2030: 13 83        std	Z+3, r17 */
/* 0x2032: 06 e0        ldi	r16, 0x6 */
/* 0x2034: 04 83        std	Z+4, r16 */
/* 0x2036: 15 83        std	Z+5, r17 */
/* 0x2038: 16 83        std	Z+6, r17 */
/* 0x203A: 17 83        std	Z+7, r17 */
/* 0x203C: 08 95        ret */
/* 0x203E: 9a 93        st	-Y, r25 */
/* 0x2040: 8a 93        st	-Y, r24 */
/* 0x2042: 48 d0        rcall	.+144 */
/* 0x2044: c8 01 46 d0  <unknown> */
/* 0x2048: 80 1b        sub	r24, r16 */
/* 0x204A: 91 0b        sbc	r25, r17 */
/* 0x204C: 83 30        cpi	r24, 0x3 */
/* 0x204E: 20 e0        ldi	r18, 0x0 */
/* 0x2050: 92 07        cpc	r25, r18 */
/* 0x2052: f4 f5        brge	.+124 */
/* 0x2054: 8e 3f        cpi	r24, 0xfe */
/* 0x2056: 9f 4f        sbci	r25, 0xff */
/* 0x2058: dc f1        brlt	.+118 */
/* 0x205A: 02 36        cpi	r16, 0x62 */
/* 0x205C: 23 e0        ldi	r18, 0x3 */
/* 0x205E: 12 07        cpc	r17, r18 */
/* 0x2060: 28 f0        brlo	.+10 */
/* 0x2062: 04 38        cpi	r16, 0x84 */
/* 0x2064: 12 07        cpc	r17, r18 */
/* 0x2066: 10 f4        brsh	.+4 */
/* 0x2068: 00 e0        ldi	r16, 0x0 */
/* 0x206A: 33 c0        rjmp	.+102 */
/* 0x206C: 09 34        cpi	r16, 0x49 */
/* 0x206E: 12 07        cpc	r17, r18 */
/* 0x2070: 28 f0        brlo	.+10 */
/* 0x2072: 01 36        cpi	r16, 0x61 */
/* 0x2074: 12 07        cpc	r17, r18 */
/* 0x2076: 10 f4        brsh	.+4 */
/* 0x2078: 01 e0        ldi	r16, 0x1 */
/* 0x207A: 2b c0        rjmp	.+86 */
/* 0x207C: 01 32        cpi	r16, 0x21 */
/* 0x207E: 12 07        cpc	r17, r18 */
/* 0x2080: 28 f0        brlo	.+10 */
/* 0x2082: 08 34        cpi	r16, 0x48 */
/* 0x2084: 12 07        cpc	r17, r18 */
/* 0x2086: 10 f4        brsh	.+4 */
/* 0x2088: 02 e0        ldi	r16, 0x2 */
/* 0x208A: 23 c0        rjmp	.+70 */
/* 0x208C: 09 3f        cpi	r16, 0xf9 */
/* 0x208E: 22 e0        ldi	r18, 0x2 */
/* 0x2090: 12 07        cpc	r17, r18 */
/* 0x2092: 30 f0        brlo	.+12 */
/* 0x2094: 0c 30        cpi	r16, 0xc */
/* 0x2096: 23 e0        ldi	r18, 0x3 */
/* 0x2098: 12 07        cpc	r17, r18 */
/* 0x209A: 10 f4        brsh	.+4 */
/* 0x209C: 03 e0        ldi	r16, 0x3 */
/* 0x209E: 19 c0        rjmp	.+50 */
/* 0x20A0: 0f 39        cpi	r16, 0x9f */
/* 0x20A2: 22 e0        ldi	r18, 0x2 */
/* 0x20A4: 12 07        cpc	r17, r18 */
/* 0x20A6: 28 f0        brlo	.+10 */
/* 0x20A8: 02 3b        cpi	r16, 0xb2 */
/* 0x20AA: 12 07        cpc	r17, r18 */
/* 0x20AC: 10 f4        brsh	.+4 */
/* 0x20AE: 04 e0        ldi	r16, 0x4 */
/* 0x20B0: 10 c0        rjmp	.+32 */
/* 0x20B2: 05 3f        cpi	r16, 0xf5 */
/* 0x20B4: 21 e0        ldi	r18, 0x1 */
/* 0x20B6: 12 07        cpc	r17, r18 */
/* 0x20B8: 30 f0        brlo	.+12 */
/* 0x20BA: 08 30        cpi	r16, 0x8 */
/* 0x20BC: 22 e0        ldi	r18, 0x2 */
/* 0x20BE: 12 07        cpc	r17, r18 */
/* 0x20C0: 10 f4        brsh	.+4 */
/* 0x20C2: 05 e0        ldi	r16, 0x5 */
/* 0x20C4: 06 c0        rjmp	.+12 */
/* 0x20C6: 0e 31        cpi	r16, 0x1e */
/* 0x20C8: 10 40        sbci	r17, 0x0 */
/* 0x20CA: 10 f4        brsh	.+4 */
/* 0x20CC: 06 e0        ldi	r16, 0x6 */
/* 0x20CE: 01 c0        rjmp	.+2 */
/* 0x20D0: 0f ef        ldi	r16, 0xff */
/* 0x20D2: d6 ce        rjmp	.-596 */
/* 0x20D4: 01 e0        ldi	r16, 0x1 */
/* 0x20D6: 0c 94 d1 06  <unknown> */
/* 0x20DA: 0e 94 e7 34  <unknown> */
/* 0x20DE: af df        rcall	.-162 */
/* 0x20E0: 80 2f        mov	r24, r16 */
/* 0x20E2: 3a d0        rcall	.+116 */
/* 0x20E4: a8 01 b9 01  <unknown> */
/* 0x20E8: 4e 5f        subi	r20, 0xfe */
/* 0x20EA: 5f 4f        sbci	r21, 0xff */
/* 0x20EC: 6f 4f        sbci	r22, 0xff */
/* 0x20EE: 7f 4f        sbci	r23, 0xff */
/* 0x20F0: 00 8c        ldd	r0, Z+0 */
/* 0x20F2: 80 15        cp	r24, r0 */
/* 0x20F4: 49 f0        breq	.+18 */
/* 0x20F6: 80 8f        std	Z+0, r24 */
/* 0x20F8: 23 d0        rcall	.+70 */
/* 0x20FA: 04 8b        std	Z+4, r16 */
/* 0x20FC: 15 8b        std	Z+5, r17 */
/* 0x20FE: 26 8b        std	Z+6, r18 */
/* 0x2100: 37 8b        std	Z+7, r19 */
/* 0x2102: 23 d0        rcall	.+70 */
/* 0x2104: 08 2f        mov	r16, r24 */
/* 0x2106: 19 c0        rjmp	.+50 */
/* 0x2108: 00 80        ldd	r0, Z+0 */
/* 0x210A: 11 80        ldd	r1, Z+1 */
/* 0x210C: 22 80        ldd	r2, Z+2 */
/* 0x210E: 33 80        ldd	r3, Z+3 */
/* 0x2110: 44 88        ldd	r4, Z+4 */
/* 0x2112: 55 88        ldd	r5, Z+5 */
/* 0x2114: 66 88        ldd	r6, Z+6 */
/* 0x2116: 77 88        ldd	r7, Z+7 */
/* 0x2118: 26 d0        rcall	.+76 */
/* 0x211A: 70 f4        brsh	.+28 */
/* 0x211C: 04 80        ldd	r0, Z+4 */
/* 0x211E: 15 80        ldd	r1, Z+5 */
/* 0x2120: 26 80        ldd	r2, Z+6 */
/* 0x2122: 37 80        ldd	r3, Z+7 */
/* 0x2124: 40 88        ldd	r4, Z+0 */
/* 0x2126: 51 88        ldd	r5, Z+1 */
/* 0x2128: 62 88        ldd	r6, Z+2 */
/* 0x212A: 73 88        ldd	r7, Z+3 */
/* 0x212C: 1c d0        rcall	.+56 */
/* 0x212E: 20 f4        brsh	.+8 */
/* 0x2130: 07 d0        rcall	.+14 */
/* 0x2132: 0b d0        rcall	.+22 */
/* 0x2134: 80 68        ori	r24, 0x80 */
/* 0x2136: e6 cf        rjmp	.-52 */
/* 0x2138: 0f ef        ldi	r16, 0xff */
/* 0x213A: ec e0        ldi	r30, 0xc */
/* 0x213C: 0c 94 f8 34  <unknown> */
/* 0x2140: 00 8b        std	Z+0, r16 */
/* 0x2142: 11 8b        std	Z+1, r17 */
/* 0x2144: 22 8b        std	Z+2, r18 */
/* 0x2146: 33 8b        std	Z+3, r19 */
/* 0x2148: 08 95        ret */
/* 0x214A: 8f 3f        cpi	r24, 0xff */
/* 0x214C: 21 f0        breq	.+8 */
/* 0x214E: 44 87        std	Z+4, r20 */
/* 0x2150: 55 87        std	Z+5, r21 */
/* 0x2152: 66 87        std	Z+6, r22 */
/* 0x2154: 77 87        std	Z+7, r23 */
/* 0x2156: 08 95        ret */
/* 0x2158: ef e8        ldi	r30, 0x8f */
/* 0x215A: f6 e0        ldi	r31, 0x6 */
/* 0x215C: 00 85        ldd	r16, Z+0 */
/* 0x215E: 11 85        ldd	r17, Z+1 */
/* 0x2160: 22 85        ldd	r18, Z+2 */
/* 0x2162: 33 85        ldd	r19, Z+3 */
/* 0x2164: 08 95        ret */
/* 0x2166: 48 01 59 01  <unknown> */
/* 0x216A: 84 18        sub	r8, r4 */
/* 0x216C: 95 08        sbc	r9, r5 */
/* 0x216E: a6 08        sbc	r10, r6 */
/* 0x2170: b7 08        sbc	r11, r7 */
/* 0x2172: 08 14        cp	r0, r8 */
/* 0x2174: 19 04        cpc	r1, r9 */
/* 0x2176: 2a 04        cpc	r2, r10 */
/* 0x2178: 3b 04        cpc	r3, r11 */
/* 0x217A: 08 95        ret */
/* 0x217C: 08 e0        ldi	r16, 0x8 */
/* 0x217E: 10 e0        ldi	r17, 0x0 */
/* 0x2180: 0e 94 3e 35  <unknown> */
/* 0x2184: 20 2f        mov	r18, r16 */
/* 0x2186: 21 2b        or	r18, r17 */
/* 0x2188: 09 f0        breq	.+2 */
/* 0x218A: 11 c0        rjmp	.+34 */
/* 0x218C: 00 e0        ldi	r16, 0x0 */
/* 0x218E: 10 e0        ldi	r17, 0x0 */
/* 0x2190: 08 95        ret */
/* 0x2192: 9a 93        st	-Y, r25 */
/* 0x2194: 8a 93        st	-Y, r24 */
/* 0x2196: c8 01 01 2b  <unknown> */
/* 0x219A: 31 f0        breq	.+12 */
/* 0x219C: 08 2f        mov	r16, r24 */
/* 0x219E: 0e 94 7f 11  <unknown> */
/* 0x21A2: 8c 01 0e 94  <unknown> */
/* 0x21A6: 76 31        cpi	r23, 0x16 */
/* 0x21A8: 89 91        ld	r24, Y+ */
/* 0x21AA: 99 91        ld	r25, Y+ */
/* 0x21AC: 08 95        ret */
/* 0x21AE: ba 93        st	-Y, r27 */
/* 0x21B0: aa 93        st	-Y, r26 */
/* 0x21B2: d8 01 0e 94  <unknown> */
/* 0x21B6: 75 11        cpse	r23, r5 */
/* 0x21B8: 0e 94 43 0f  <unknown> */
/* 0x21BC: 20 e0        ldi	r18, 0x0 */
/* 0x21BE: 07 e1        ldi	r16, 0x17 */
/* 0x21C0: 12 e0        ldi	r17, 0x2 */
/* 0x21C2: 11 d0        rcall	.+34 */
/* 0x21C4: 21 e0        ldi	r18, 0x1 */
/* 0x21C6: 0f e1        ldi	r16, 0x1f */
/* 0x21C8: 12 e0        ldi	r17, 0x2 */
/* 0x21CA: 0d d0        rcall	.+26 */
/* 0x21CC: 22 e0        ldi	r18, 0x2 */
/* 0x21CE: 07 e2        ldi	r16, 0x27 */
/* 0x21D0: 12 e0        ldi	r17, 0x2 */
/* 0x21D2: 09 d0        rcall	.+18 */
/* 0x21D4: 4f d0        rcall	.+158 */
/* 0x21D6: 14 97 01 e0  <unknown> */
/* 0x21DA: 0c 93        st	X, r16 */
/* 0x21DC: 12 97 8d 01  <unknown> */
/* 0x21E0: a9 91        ld	r26, Y+ */
/* 0x21E2: b9 91        ld	r27, Y+ */
/* 0x21E4: 08 95        ret */
/* 0x21E6: 0c 94 60 0f  <unknown> */
/* 0x21EA: f8 01 23 83  <unknown> */
/* 0x21EE: 34 83        std	Z+4, r19 */
/* 0x21F0: 45 83        std	Z+5, r20 */
/* 0x21F2: 19 c0        rjmp	.+50 */
/* 0x21F4: 23 95        inc	r18 */
/* 0x21F6: 29 f0        breq	.+10 */
/* 0x21F8: 2a 95        dec	r18 */
/* 0x21FA: 21 f0        breq	.+8 */
/* 0x21FC: 2a 95        dec	r18 */
/* 0x21FE: 19 f0        breq	.+6 */
/* 0x2200: 08 95        ret */
/* 0x2202: 02 c0        rjmp	.+4 */
/* 0x2204: 10 c0        rjmp	.+32 */
/* 0x2206: 10 c0        rjmp	.+32 */
/* 0x2208: 27 d0        rcall	.+78 */
/* 0x220A: 41 f0        breq	.+16 */
/* 0x220C: 34 2f        mov	r19, r20 */
/* 0x220E: 24 2f        mov	r18, r20 */
/* 0x2210: 2c 7f        andi	r18, 0xfc */
/* 0x2212: 3a 95        dec	r19 */
/* 0x2214: 33 70        andi	r19, 0x3 */
/* 0x2216: 23 2b        or	r18, r19 */
/* 0x2218: 27 83        std	Z+7, r18 */
/* 0x221A: 05 c0        rjmp	.+10 */
/* 0x221C: 26 81        ldd	r18, Z+6 */
/* 0x221E: 22 23        tst	r18 */
/* 0x2220: 11 f0        breq	.+4 */
/* 0x2222: 2a 95        dec	r18 */
/* 0x2224: 26 83        std	Z+6, r18 */
/* 0x2226: 2d c0        rjmp	.+90 */
/* 0x2228: 9a 93        st	-Y, r25 */
/* 0x222A: 8a 93        st	-Y, r24 */
/* 0x222C: 15 d0        rcall	.+42 */
/* 0x222E: 41 f4        brne	.+16 */
/* 0x2230: 34 2f        mov	r19, r20 */
/* 0x2232: 24 2f        mov	r18, r20 */
/* 0x2234: 2c 7f        andi	r18, 0xfc */
/* 0x2236: 33 95        inc	r19 */
/* 0x2238: 33 70        andi	r19, 0x3 */
/* 0x223A: 23 2b        or	r18, r19 */
/* 0x223C: 27 83        std	Z+7, r18 */
/* 0x223E: 0a c0        rjmp	.+20 */
/* 0x2240: 26 81        ldd	r18, Z+6 */
/* 0x2242: 30 e0        ldi	r19, 0x0 */
/* 0x2244: 85 81        ldd	r24, Z+5 */
/* 0x2246: 90 e0        ldi	r25, 0x0 */
/* 0x2248: 02 97 28 17  <unknown> */
/* 0x224C: 39 07        cpc	r19, r25 */
/* 0x224E: 14 f4        brge	.+4 */
/* 0x2250: 23 95        inc	r18 */
/* 0x2252: 26 83        std	Z+6, r18 */
/* 0x2254: e8 df        rcall	.-48 */
/* 0x2256: a8 cf        rjmp	.-176 */
/* 0x2258: f8 01 47 81  <unknown> */
/* 0x225C: 24 2f        mov	r18, r20 */
/* 0x225E: 23 70        andi	r18, 0x3 */
/* 0x2260: 08 95        ret */
/* 0x2262: f8 01 26 81  <unknown> */
/* 0x2266: 07 81        ldd	r16, Z+7 */
/* 0x2268: 03 70        andi	r16, 0x3 */
/* 0x226A: 02 0f        add	r16, r18 */
/* 0x226C: 08 95        ret */
/* 0x226E: e4 e0        ldi	r30, 0x4 */
/* 0x2270: 0c 94 00 35  <unknown> */
/* 0x2274: 17 96 0c 91  <unknown> */
/* 0x2278: 0c 7f        andi	r16, 0xfc */
/* 0x227A: 0c 93        st	X, r16 */
/* 0x227C: 00 e0        ldi	r16, 0x0 */
/* 0x227E: 0e 93        st	-X, r16 */
/* 0x2280: 08 95        ret */
/* 0x2282: 0e 94 ef 34  <unknown> */
/* 0x2286: d8 01 0e 94  <unknown> */
/* 0x228A: 43 0f        add	r20, r19 */
/* 0x228C: 80 e0        ldi	r24, 0x0 */
/* 0x228E: 18 2f        mov	r17, r24 */
/* 0x2290: 00 e0        ldi	r16, 0x0 */
/* 0x2292: 0e 94 29 0f  <unknown> */
/* 0x2296: fd 01 07 81  <unknown> */
/* 0x229A: 03 70        andi	r16, 0x3 */
/* 0x229C: 08 17        cp	r16, r24 */
/* 0x229E: 11 e0        ldi	r17, 0x1 */
/* 0x22A0: 11 f4        brne	.+4 */
/* 0x22A2: 00 e0        ldi	r16, 0x0 */
/* 0x22A4: 01 c0        rjmp	.+2 */
/* 0x22A6: 00 e2        ldi	r16, 0x20 */
/* 0x22A8: 0e 94 70 0f  <unknown> */
/* 0x22AC: fd 01 23 81  <unknown> */
/* 0x22B0: 34 81        ldd	r19, Z+4 */
/* 0x22B2: 46 81        ldd	r20, Z+6 */
/* 0x22B4: 50 e0        ldi	r21, 0x0 */
/* 0x22B6: 48 0f        add	r20, r24 */
/* 0x22B8: 55 1f        rol	r21 */
/* 0x22BA: 01 e1        ldi	r16, 0x11 */
/* 0x22BC: 10 e0        ldi	r17, 0x0 */
/* 0x22BE: 0e 94 cd 31  <unknown> */
/* 0x22C2: 02 0f        add	r16, r18 */
/* 0x22C4: 13 1f        adc	r17, r19 */
/* 0x22C6: 0e 94 70 35  <unknown> */
/* 0x22CA: 83 95        inc	r24 */
/* 0x22CC: 82 30        cpi	r24, 0x2 */
/* 0x22CE: f8 f2        brlo	.-66 */
/* 0x22D0: ce cf        rjmp	.-100 */
/* 0x22DE: f8 01 02 81  <unknown> */
/* 0x22E2: 08 95        ret */
/* 0x22FE: f8 01 00 81  <unknown> */
/* 0x2302: 11 81        ldd	r17, Z+1 */
/* 0x2304: 0c 94 a7 0f  <unknown> */
/* 0x2312: 50 e0        ldi	r21, 0x0 */
/* 0x2314: 02 0f        add	r16, r18 */
/* 0x2316: 15 1f        adc	r17, r21 */
/* 0x2318: 33 23        tst	r19 */
/* 0x231A: f8 01 25 a1  <unknown> */
/* 0x231E: 39 f0        breq	.+14 */
/* 0x2320: 22 23        tst	r18 */
/* 0x2322: 59 f4        brne	.+22 */
/* 0x2324: 21 e0        ldi	r18, 0x1 */
/* 0x2326: 25 a3 0a e0  <unknown> */
/* 0x232A: 0c 94 f8 0f  <unknown> */
/* 0x232E: 22 23        tst	r18 */
/* 0x2330: 21 f0        breq	.+8 */
/* 0x2332: 55 a3 03 e0  <unknown> */
/* 0x2336: 0e 94 f8 0f  <unknown> */
/* 0x233A: 08 95        ret */
/* 0x2362: 30 e0        ldi	r19, 0x0 */
/* 0x2364: 02 0f        add	r16, r18 */
/* 0x2366: 13 1f        adc	r17, r19 */
/* 0x2368: f8 01 05 a1  <unknown> */
/* 0x236C: 08 95        ret */
/* 0x23FA: 0e 94 f0 34  <unknown> */
/* 0x23FE: c8 01 a0 e0  <unknown> */
/* 0x2402: 2a 2f        mov	r18, r26 */
/* 0x2404: 8c 01 dc df  <unknown> */
/* 0x2408: a3 95        inc	r26 */
/* 0x240A: ac 30        cpi	r26, 0xc */
/* 0x240C: d0 f3        brlo	.-12 */
/* 0x240E: e3 e0        ldi	r30, 0x3 */
/* 0x2410: 0c 94 01 35  <unknown> */
/* 0x24DA: 0e 94 ef 34  <unknown> */
/* 0x24DE: bf b7        in	r27, 0x3f */
/* 0x24E0: f8 94        cli */
/* 0x24E2: c8 01 a0 e0  <unknown> */
/* 0x24E6: 4a e0        ldi	r20, 0xa */
/* 0x24E8: 50 e0        ldi	r21, 0x0 */
/* 0x24EA: 2a 2f        mov	r18, r26 */
/* 0x24EC: 8c 01 50 df  <unknown> */
/* 0x24F0: 40 e0        ldi	r20, 0x0 */
/* 0x24F2: 50 e0        ldi	r21, 0x0 */
/* 0x24F4: 2a 2f        mov	r18, r26 */
/* 0x24F6: 8c 01 5b df  <unknown> */
/* 0x24FA: a3 95        inc	r26 */
/* 0x24FC: ac 30        cpi	r26, 0xc */
/* 0x24FE: 98 f3        brlo	.-26 */
/* 0x2500: bf bf        out	0x3f, r27 */
/* 0x2502: e4 e0        ldi	r30, 0x4 */
/* 0x2504: 0c 94 00 35  <unknown> */
/* 0x2706: 00 e0        ldi	r16, 0x0 */
/* 0x2708: 10 e0        ldi	r17, 0x0 */
/* 0x270A: 08 95        ret */
/* 0x2722: 89 91        ld	r24, Y+ */
/* 0x2724: 99 91        ld	r25, Y+ */
/* 0x2726: 08 95        ret */
/* 0x2728: 03 d0        rcall	.+6 */
/* 0x272A: 09 f0        breq	.+2 */
/* 0x272C: 02 c1        rjmp	.+516 */
/* 0x272E: eb cf        rjmp	.-42 */
/* 0x2730: 00 e1        ldi	r16, 0x10 */
/* 0x2732: 10 e0        ldi	r17, 0x0 */
/* 0x2734: 0e 94 3e 35  <unknown> */
/* 0x2738: 20 2f        mov	r18, r16 */
/* 0x273A: 21 2b        or	r18, r17 */
/* 0x273C: 08 95        ret */
/* 0x27CA: ba 93        st	-Y, r27 */
/* 0x27CC: aa 93        st	-Y, r26 */
/* 0x27CE: 08 95        ret */
/* 0x2872: 04 d0        rcall	.+8 */
/* 0x2874: 8c 01 0e 94  <unknown> */
/* 0x2878: 70 35        cpi	r23, 0x50 */
/* 0x287A: 53 cf        rjmp	.-346 */
/* 0x287C: 9a 93        st	-Y, r25 */
/* 0x287E: 8a 93        st	-Y, r24 */
/* 0x2880: c9 01 20 e0  <unknown> */
/* 0x2884: 1f e0        ldi	r17, 0xf */
/* 0x2886: 00 e0        ldi	r16, 0x0 */
/* 0x2888: 0e 94 34 0f  <unknown> */
/* 0x288C: 10 e0        ldi	r17, 0x0 */
/* 0x288E: 70 c0        rjmp	.+224 */
/* 0x2932: 4b df        rcall	.-362 */
/* 0x2934: d8 01 03 df  <unknown> */
/* 0x2938: 0c ed        ldi	r16, 0xdc */
/* 0x293A: 13 e0        ldi	r17, 0x3 */
/* 0x293C: 1e 96 0d 93  <unknown> */
/* 0x2940: 1c 93        st	X, r17 */
/* 0x2942: 1f 97 00 ee  <unknown> */
/* 0x2946: 13 e0        ldi	r17, 0x3 */
/* 0x2948: 0e 94 52 0f  <unknown> */
/* 0x294C: 10 d0        rcall	.+32 */
/* 0x294E: 11 e0        ldi	r17, 0x1 */
/* 0x2950: 00 e0        ldi	r16, 0x0 */
/* 0x2952: 07 d0        rcall	.+14 */
/* 0x2954: 11 e0        ldi	r17, 0x1 */
/* 0x2956: 0f e0        ldi	r16, 0xf */
/* 0x2958: 0c d0        rcall	.+24 */
/* 0x295A: 11 e0        ldi	r17, 0x1 */
/* 0x295C: 05 e0        ldi	r16, 0x5 */
/* 0x295E: 01 d0        rcall	.+2 */
/* 0x2960: 02 c0        rjmp	.+4 */
/* 0x2962: 0c 94 70 0f  <unknown> */
/* 0x2966: 8d 01 a9 91  <unknown> */
/* 0x296A: b9 91        ld	r27, Y+ */
/* 0x296C: 08 95        ret */
/* 0x296E: 11 e0        ldi	r17, 0x1 */
/* 0x2970: 00 e0        ldi	r16, 0x0 */
/* 0x2972: 0c 94 29 0f  <unknown> */
/* 0x2A88: 05 e0        ldi	r16, 0x5 */
/* 0x2A8A: 45 e4        ldi	r20, 0x45 */
/* 0x2A8C: 50 e0        ldi	r21, 0x0 */
/* 0x2A8E: 14 d0        rcall	.+40 */
/* 0x2A90: 00 e0        ldi	r16, 0x0 */
/* 0x2A92: 46 e4        ldi	r20, 0x46 */
/* 0x2A94: 50 e0        ldi	r21, 0x0 */
/* 0x2A96: 10 d0        rcall	.+32 */
/* 0x2A98: 47 e4        ldi	r20, 0x47 */
/* 0x2A9A: 50 e0        ldi	r21, 0x0 */
/* 0x2A9C: 0d d0        rcall	.+26 */
/* 0x2A9E: 05 e0        ldi	r16, 0x5 */
/* 0x2AA0: 48 e4        ldi	r20, 0x48 */
/* 0x2AA2: 50 e0        ldi	r21, 0x0 */
/* 0x2AA4: 09 d0        rcall	.+18 */
/* 0x2AA6: 00 e0        ldi	r16, 0x0 */
/* 0x2AA8: 49 e4        ldi	r20, 0x49 */
/* 0x2AAA: 50 e0        ldi	r21, 0x0 */
/* 0x2AAC: 05 d0        rcall	.+10 */
/* 0x2AAE: 4a e4        ldi	r20, 0x4a */
/* 0x2AB0: 50 e0        ldi	r21, 0x0 */
/* 0x2AB2: 02 d0        rcall	.+4 */
/* 0x2AB4: 4b e4        ldi	r20, 0x4b */
/* 0x2AB6: 50 e0        ldi	r21, 0x0 */
/* 0x2AB8: 0c 94 a0 31  <unknown> */
/* 0x2BDC: 5d 9b        sbis	0xb, 0x5 */
/* 0x2BDE: fe cf        rjmp	.-4 */
/* 0x2BE4: 5f 99        sbic	0xb, 0x7 */
/* 0x2BE6: 02 c0        rjmp	.+4 */
/* 0x2BEC: 2c b1        in	r18, 0xc */
/* 0x2BEE: f8 01 20 83  <unknown> */
/* 0x2BF2: 01 e0        ldi	r16, 0x1 */
/* 0x2BF4: 08 95        ret */
/* 0x2BF6: 0c e0        ldi	r16, 0xc */
/* 0x2BF8: 09 b9        out	0x9, r16 */
/* 0x2BFA: 02 e0        ldi	r16, 0x2 */
/* 0x2BFC: 0b b9        out	0xb, r16 */
/* 0x2BFE: 08 e1        ldi	r16, 0x18 */
/* 0x2C00: 0a b9        out	0xa, r16 */
/* 0x2C02: 0e e8        ldi	r16, 0x8e */
/* 0x2C04: 00 bd        out	0x20, r16 */
/* 0x2C06: 08 95        ret */
/* 0x2C08: 0e 94 ec 34  <unknown> */
/* 0x2C0C: 6f b6        in	r6, 0x3f */
/* 0x2C0E: f8 94        cli */
/* 0x2C10: c8 01 29 01  <unknown> */
/* 0x2C14: a0 e0        ldi	r26, 0x0 */
/* 0x2C16: b0 e0        ldi	r27, 0x0 */
/* 0x2C18: 07 c0        rjmp	.+14 */
/* 0x2C36: 0e 94 ed 34  <unknown> */
/* 0x2C3A: d8 01 29 01  <unknown> */
/* 0x2C3E: 80 e0        ldi	r24, 0x0 */
/* 0x2C40: 90 e0        ldi	r25, 0x0 */
/* 0x2C42: 06 c0        rjmp	.+12 */
/* 0x2C90: 59 2f        mov	r21, r25 */
/* 0x2C92: 68 2f        mov	r22, r24 */
/* 0x2C94: 80 e0        ldi	r24, 0x0 */
/* 0x2C96: 90 e0        ldi	r25, 0x0 */
/* 0x2C98: 08 c0        rjmp	.+16 */
/* 0x3912: 00 23        tst	r16 */
/* 0x3914: 08 95        ret */
/* 0x398C: 00 e0        ldi	r16, 0x0 */
/* 0x398E: 08 95        ret */
/* 0x39B4: 4f 5f        subi	r20, 0xff */
/* 0x39B6: bc d2        rcall	.+1400 */
/* 0x39B8: e9 cf        rjmp	.-46 */
/* 0x39BE: b8 d2        rcall	.+1392 */
/* 0x39C0: a9 01 08 95  <unknown> */
/* 0x39C4: fc df        rcall	.-8 */
/* 0x39C6: 67 c0        rjmp	.+206 */
/* 0x39DE: ac 01 5a c0  <unknown> */
/* 0x39E2: a8 d2        rcall	.+1360 */
/* 0x39E4: 01 70        andi	r16, 0x1 */
/* 0x39E6: 08 95        ret */
/* 0x39F6: ac 01 4b 5f  <unknown> */
/* 0x39FA: 91 c2        rjmp	.+1314 */
/* 0x3A18: 0c 94 cd 31  <unknown> */
/* 0x3A20: 0d d0        rcall	.+26 */
/* 0x3A22: 2c e4        ldi	r18, 0x4c */
/* 0x3A24: 30 e0        ldi	r19, 0x0 */
/* 0x3A26: 20 0f        add	r18, r16 */
/* 0x3A28: 31 1f        adc	r19, r17 */
/* 0x3A2A: ca cf        rjmp	.-108 */
/* 0x3A2E: 00 72        andi	r16, 0x20 */
/* 0x3A30: 08 95        ret */
/* 0x3A3C: 50 e0        ldi	r21, 0x0 */
/* 0x3A3E: 05 e1        ldi	r16, 0x15 */
/* 0x3A40: 10 e0        ldi	r17, 0x0 */
/* 0x3A42: ea cf        rjmp	.-44 */
/* 0x3A46: 00 7c        andi	r16, 0xc0 */
/* 0x3A48: 08 95        ret */
/* 0x3A78: 00 78        andi	r16, 0x80 */
/* 0x3A7A: 08 95        ret */
/* 0x3A96: 0c 94 86 31  <unknown> */
/* 0x3AF4: 0e 94 ea 34  <unknown> */
/* 0x3AF8: 81 2e        mov	r8, r17 */
/* 0x3AFA: a2 2f        mov	r26, r18 */
/* 0x3AFC: e3 2f        mov	r30, r19 */
/* 0x3AFE: 94 2f        mov	r25, r20 */
/* 0x3B00: 85 2f        mov	r24, r21 */
/* 0x3B02: 5a d0        rcall	.+180 */
/* 0x3B04: 40 e1        ldi	r20, 0x10 */
/* 0x3B06: 5e e0        ldi	r21, 0xe */
/* 0x3B08: 60 e0        ldi	r22, 0x0 */
/* 0x3B0A: 70 e0        ldi	r23, 0x0 */
/* 0x3B0C: 46 d0        rcall	.+140 */
/* 0x3B0E: 51 d0        rcall	.+162 */
/* 0x3B10: 08 2d        mov	r16, r8 */
/* 0x3B12: 52 d0        rcall	.+164 */
/* 0x3B14: 4c e3        ldi	r20, 0x3c */
/* 0x3B16: 50 e0        ldi	r21, 0x0 */
/* 0x3B18: 42 d0        rcall	.+132 */
/* 0x3B1A: 10 e0        ldi	r17, 0x0 */
/* 0x3B1C: 4a 0e        add	r4, r26 */
/* 0x3B1E: 57 1e        adc	r5, r23 */
/* 0x3B20: 67 1e        adc	r6, r23 */
/* 0x3B22: 77 1e        adc	r7, r23 */
/* 0x3B24: 0e 2f        mov	r16, r30 */
/* 0x3B26: 01 50        subi	r16, 0x1 */
/* 0x3B28: 10 40        sbci	r17, 0x0 */
/* 0x3B2A: 21 2f        mov	r18, r17 */
/* 0x3B2C: 22 0f        lsl	r18 */
/* 0x3B2E: 22 0b        sbc	r18, r18 */
/* 0x3B30: 32 2f        mov	r19, r18 */
/* 0x3B32: 40 e8        ldi	r20, 0x80 */
/* 0x3B34: 51 e5        ldi	r21, 0x51 */
/* 0x3B36: 61 e0        ldi	r22, 0x1 */
/* 0x3B38: 32 d0        rcall	.+100 */
/* 0x3B3A: a1 e0        ldi	r26, 0x1 */
/* 0x3B3C: 08 c0        rjmp	.+16 */
/* 0x3B3E: f0 e0        ldi	r31, 0x0 */
/* 0x3B40: ea 2f        mov	r30, r26 */
/* 0x3B42: e0 57        subi	r30, 0x70 */
/* 0x3B44: f8 4f        sbci	r31, 0xf8 */
/* 0x3B46: 04 91 37 d0  <unknown> */
/* 0x3B4A: 29 d0        rcall	.+82 */
/* 0x3B4C: a3 95        inc	r26 */
/* 0x3B4E: a9 17        cp	r26, r25 */
/* 0x3B50: b0 f3        brlo	.-20 */
/* 0x3B52: 93 30        cpi	r25, 0x3 */
/* 0x3B54: 39 f4        brne	.+14 */
/* 0x3B56: 08 2f        mov	r16, r24 */
/* 0x3B58: 03 70        andi	r16, 0x3 */
/* 0x3B5A: 21 f4        brne	.+8 */
/* 0x3B5C: 44 0e        add	r4, r20 */
/* 0x3B5E: 55 1e        adc	r5, r21 */
/* 0x3B60: 66 1e        adc	r6, r22 */
/* 0x3B62: 77 1e        adc	r7, r23 */
/* 0x3B64: 08 2f        mov	r16, r24 */
/* 0x3B66: 28 d0        rcall	.+80 */
/* 0x3B68: 4d e6        ldi	r20, 0x6d */
/* 0x3B6A: 51 e0        ldi	r21, 0x1 */
/* 0x3B6C: 60 e0        ldi	r22, 0x0 */
/* 0x3B6E: 15 d0        rcall	.+42 */
/* 0x3B70: 86 95        lsr	r24 */
/* 0x3B72: 86 95        lsr	r24 */
/* 0x3B74: 08 0f        add	r16, r24 */
/* 0x3B76: 17 1f        adc	r17, r23 */
/* 0x3B78: 27 1f        adc	r18, r23 */
/* 0x3B7A: 37 1f        adc	r19, r23 */
/* 0x3B7C: 40 e8        ldi	r20, 0x80 */
/* 0x3B7E: 51 e5        ldi	r21, 0x51 */
/* 0x3B80: 61 e0        ldi	r22, 0x1 */
/* 0x3B82: 0b d0        rcall	.+22 */
/* 0x3B84: a8 01 b9 01  <unknown> */
/* 0x3B88: 82 01 93 01  <unknown> */
/* 0x3B8C: 04 0f        add	r16, r20 */
/* 0x3B8E: 15 1f        adc	r17, r21 */
/* 0x3B90: 26 1f        adc	r18, r22 */
/* 0x3B92: 37 1f        adc	r19, r23 */
/* 0x3B94: e9 e0        ldi	r30, 0x9 */
/* 0x3B96: 0c 94 fb 34  <unknown> */
/* 0x3B9A: 0c 94 0d 32  <unknown> */
/* 0x3B9E: 0e 94 0d 32  <unknown> */
/* 0x3BA2: 40 0e        add	r4, r16 */
/* 0x3BA4: 51 1e        adc	r5, r17 */
/* 0x3BA6: 62 1e        adc	r6, r18 */
/* 0x3BA8: 73 1e        adc	r7, r19 */
/* 0x3BAA: 08 95        ret */
/* 0x3BAC: 1a 2f        mov	r17, r26 */
/* 0x3BAE: 0b 2f        mov	r16, r27 */
/* 0x3BB0: f4 d1        rcall	.+1000 */
/* 0x3BB2: 28 01 39 01  <unknown> */
/* 0x3BB6: 08 95        ret */
/* 0x3BB8: 10 e0        ldi	r17, 0x0 */
/* 0x3BBA: 20 e0        ldi	r18, 0x0 */
/* 0x3BBC: 30 e0        ldi	r19, 0x0 */
/* 0x3BBE: 08 95        ret */
/* 0x3BC0: 0e 94 e3 34  <unknown> */
/* 0x3BC4: 0f b7        in	r16, 0x3f */
/* 0x3BC6: 0a 93        st	-Y, r16 */
/* 0x3BC8: f8 94        cli */
/* 0x3BCA: 22 97 00 e0  <unknown> */
/* 0x3BCE: 08 83        std	Y+0, r16 */
/* 0x3BD0: 40 91 b9 06  <unknown> */
/* 0x3BD4: e3 d1        rcall	.+966 */
/* 0x3BD6: b1 d1        rcall	.+866 */
/* 0x3BD8: 09 f4        brne	.+2 */
/* 0x3BDA: 51 c1        rjmp	.+674 */
/* 0x3BDC: e7 e2        ldi	r30, 0x27 */
/* 0x3BDE: f7 e0        ldi	r31, 0x7 */
/* 0x3BE0: 02 81        ldd	r16, Z+2 */
/* 0x3BE2: b0 2f        mov	r27, r16 */
/* 0x3BE4: bf 70        andi	r27, 0xf */
/* 0x3BE6: 00 73        andi	r16, 0x30 */
/* 0x3BE8: 02 95        swap	r16 */
/* 0x3BEA: 1a e0        ldi	r17, 0xa */
/* 0x3BEC: 01 9f b0 0d  <unknown> */
/* 0x3BF0: 01 81        ldd	r16, Z+1 */
/* 0x3BF2: a0 2f        mov	r26, r16 */
/* 0x3BF4: af 70        andi	r26, 0xf */
/* 0x3BF6: 00 77        andi	r16, 0x70 */
/* 0x3BF8: 02 95        swap	r16 */
/* 0x3BFA: 01 9f a0 0d  <unknown> */
/* 0x3BFE: 20 81        ldd	r18, Z+0 */
/* 0x3C00: 2f 70        andi	r18, 0xf */
/* 0x3C02: 00 81        ldd	r16, Z+0 */
/* 0x3C04: 00 77        andi	r16, 0x70 */
/* 0x3C06: 02 95        swap	r16 */
/* 0x3C08: 01 9f 20 0d  <unknown> */
/* 0x3C0C: 29 83        std	Y+1, r18 */
/* 0x3C0E: 04 81        ldd	r16, Z+4 */
/* 0x3C10: 60 2f        mov	r22, r16 */
/* 0x3C12: 6f 70        andi	r22, 0xf */
/* 0x3C14: 00 73        andi	r16, 0x30 */
/* 0x3C16: 02 95        swap	r16 */
/* 0x3C18: 01 9f 60 0d  <unknown> */
/* 0x3C1C: 75 81        ldd	r23, Z+5 */
/* 0x3C1E: 7f 70        andi	r23, 0xf */
/* 0x3C20: 15 81        ldd	r17, Z+5 */
/* 0x3C22: 14 fb        bst	r17, 0x4 */
/* 0x3C24: 10 e0        ldi	r17, 0x0 */
/* 0x3C26: 10 f9        bld	r17, 0x0 */
/* 0x3C28: 0a e0        ldi	r16, 0xa */
/* 0x3C2A: 10 9f 70 0d  <unknown> */
/* 0x3C2E: 55 24        clr	r5 */
/* 0x3C30: 66 24        clr	r6 */
/* 0x3C32: 77 24        clr	r7 */
/* 0x3C34: 44 24        clr	r4 */
/* 0x3C36: 43 94        inc	r4 */
/* 0x3C38: 02 e0        ldi	r16, 0x2 */
/* 0x3C3A: c0 2e        mov	r12, r16 */
/* 0x3C3C: dd 24        clr	r13 */
/* 0x3C3E: ee 24        clr	r14 */
/* 0x3C40: ff 24        clr	r15 */
/* 0x3C42: 03 e0        ldi	r16, 0x3 */
/* 0x3C44: 80 2e        mov	r8, r16 */
/* 0x3C46: 99 24        clr	r9 */
/* 0x3C48: aa 24        clr	r10 */
/* 0x3C4A: bb 24        clr	r11 */
/* 0x3C4C: 7d d1        rcall	.+762 */
/* 0x3C4E: 10 2f        mov	r17, r16 */
/* 0x3C50: 3c d1        rcall	.+632 */
/* 0x3C52: 51 f0        breq	.+20 */
/* 0x3C54: 0a 95        dec	r16 */
/* 0x3C56: 09 f4        brne	.+2 */
/* 0x3C58: 47 c0        rjmp	.+142 */
/* 0x3C5A: 0a 95        dec	r16 */
/* 0x3C5C: 09 f4        brne	.+2 */
/* 0x3C5E: 6b c0        rjmp	.+214 */
/* 0x3C60: 0a 95        dec	r16 */
/* 0x3C62: 09 f4        brne	.+2 */
/* 0x3C64: 91 c0        rjmp	.+290 */
/* 0x3C66: 28 c0        rjmp	.+80 */
/* 0x3C68: 06 81        ldd	r16, Z+6 */
/* 0x3C6A: 50 2f        mov	r21, r16 */
/* 0x3C6C: 5f 70        andi	r21, 0xf */
/* 0x3C6E: 02 95        swap	r16 */
/* 0x3C70: 0f 70        andi	r16, 0xf */
/* 0x3C72: 1a e0        ldi	r17, 0xa */
/* 0x3C74: 01 9f 50 0d  <unknown> */
/* 0x3C78: 47 2f        mov	r20, r23 */
/* 0x3C7A: 36 2f        mov	r19, r22 */
/* 0x3C7C: 97 df        rcall	.-210 */
/* 0x3C7E: ac 01 4d 5f  <unknown> */
/* 0x3C82: 48 d1        rcall	.+656 */
/* 0x3C84: 25 d1        rcall	.+586 */
/* 0x3C86: 47 5f        subi	r20, 0xf7 */
/* 0x3C88: 34 d1        rcall	.+616 */
/* 0x3C8A: 61 d1        rcall	.+706 */
/* 0x3C8C: 56 2f        mov	r21, r22 */
/* 0x3C8E: 61 2f        mov	r22, r17 */
/* 0x3C90: 75 2f        mov	r23, r21 */
/* 0x3C92: 60 d1        rcall	.+704 */
/* 0x3C94: 32 d1        rcall	.+612 */
/* 0x3C96: 68 01 79 01  <unknown> */
/* 0x3C9A: ac 01 4e 5f  <unknown> */
/* 0x3C9E: 3a d1        rcall	.+628 */
/* 0x3CA0: 02 95        swap	r16 */
/* 0x3CA2: 16 d1        rcall	.+556 */
/* 0x3CA4: 46 5f        subi	r20, 0xf6 */
/* 0x3CA6: 25 d1        rcall	.+586 */
/* 0x3CA8: 4a d1        rcall	.+660 */
/* 0x3CAA: 56 2f        mov	r21, r22 */
/* 0x3CAC: 61 2f        mov	r22, r17 */
/* 0x3CAE: 75 2f        mov	r23, r21 */
/* 0x3CB0: 57 d1        rcall	.+686 */
/* 0x3CB2: 23 d1        rcall	.+582 */
/* 0x3CB4: 48 01 59 01  <unknown> */
/* 0x3CB8: 4c 14        cp	r4, r12 */
/* 0x3CBA: 5d 04        cpc	r5, r13 */
/* 0x3CBC: 6e 04        cpc	r6, r14 */
/* 0x3CBE: 7f 04        cpc	r7, r15 */
/* 0x3CC0: f8 f1        brlo	.+126 */
/* 0x3CC2: 48 14        cp	r4, r8 */
/* 0x3CC4: 59 04        cpc	r5, r9 */
/* 0x3CC6: 6a 04        cpc	r6, r10 */
/* 0x3CC8: 7b 04        cpc	r7, r11 */
/* 0x3CCA: d0 f5        brsh	.+116 */
/* 0x3CCC: 33 d1        rcall	.+614 */
/* 0x3CCE: 20 2f        mov	r18, r16 */
/* 0x3CD0: 30 e0        ldi	r19, 0x0 */
/* 0x3CD2: 5e d1        rcall	.+700 */
/* 0x3CD4: 09 f4        brne	.+2 */
/* 0x3CD6: 5f c0        rjmp	.+190 */
/* 0x3CD8: 21 70        andi	r18, 0x1 */
/* 0x3CDA: 22 0f        lsl	r18 */
/* 0x3CDC: f9 01 ed 58  <unknown> */
/* 0x3CE0: f9 4f        sbci	r31, 0xf9 */
/* 0x3CE2: 24 81        ldd	r18, Z+4 */
/* 0x3CE4: 35 81        ldd	r19, Z+5 */
/* 0x3CE6: 5e c0        rjmp	.+188 */
/* 0x3CE8: 4b d1        rcall	.+662 */
/* 0x3CEA: 43 81        ldd	r20, Z+3 */
/* 0x3CEC: 47 70        andi	r20, 0x7 */
/* 0x3CEE: 4a 95        dec	r20 */
/* 0x3CF0: 63 d1        rcall	.+710 */
/* 0x3CF2: 31 f1        breq	.+76 */
/* 0x3CF4: 50 e0        ldi	r21, 0x0 */
/* 0x3CF6: 40 e0        ldi	r20, 0x0 */
/* 0x3CF8: 30 e0        ldi	r19, 0x0 */
/* 0x3CFA: 29 81        ldd	r18, Y+1 */
/* 0x3CFC: 57 df        rcall	.-338 */
/* 0x3CFE: 30 e0        ldi	r19, 0x0 */
/* 0x3D00: 26 d1        rcall	.+588 */
/* 0x3D02: 28 d1        rcall	.+592 */
/* 0x3D04: 47 d1        rcall	.+654 */
/* 0x3D06: 68 01 79 01  <unknown> */
/* 0x3D0A: 30 e0        ldi	r19, 0x0 */
/* 0x3D0C: 18 d1        rcall	.+560 */
/* 0x3D0E: 28 d1        rcall	.+592 */
/* 0x3D10: 41 d1        rcall	.+642 */
/* 0x3D12: 48 01 59 01  <unknown> */
/* 0x3D16: 8c 14        cp	r8, r12 */
/* 0x3D18: 9d 04        cpc	r9, r13 */
/* 0x3D1A: ae 04        cpc	r10, r14 */
/* 0x3D1C: bf 04        cpc	r11, r15 */
/* 0x3D1E: 60 f6        brsh	.-104 */
/* 0x3D20: 40 16        cp	r4, r16 */
/* 0x3D22: 51 06        cpc	r5, r17 */
/* 0x3D24: 62 06        cpc	r6, r18 */
/* 0x3D26: 73 06        cpc	r7, r19 */
/* 0x3D28: 88 f2        brlo	.-94 */
/* 0x3D2A: c4 14        cp	r12, r4 */
/* 0x3D2C: d5 04        cpc	r13, r5 */
/* 0x3D2E: e6 04        cpc	r14, r6 */
/* 0x3D30: f7 04        cpc	r15, r7 */
/* 0x3D32: 10 f6        brsh	.-124 */
/* 0x3D34: cb cf        rjmp	.-106 */
/* 0x3D36: 24 d1        rcall	.+584 */
/* 0x3D38: 6a 95        dec	r22 */
/* 0x3D3A: 46 2f        mov	r20, r22 */
/* 0x3D3C: 3d d1        rcall	.+634 */
/* 0x3D3E: d1 f6        brne	.-76 */
/* 0x3D40: e7 d0        rcall	.+462 */
/* 0x3D42: 00 38        cpi	r16, 0x80 */
/* 0x3D44: 69 f4        brne	.+26 */
/* 0x3D46: 57 de        rcall	.-850 */
/* 0x3D48: 00 7c        andi	r16, 0xc0 */
/* 0x3D4A: 00 34        cpi	r16, 0x40 */
/* 0x3D4C: 19 f4        brne	.+6 */
/* 0x3D4E: 10 e0        ldi	r17, 0x0 */
/* 0x3D50: 10 93 37 07  <unknown> */
/* 0x3D54: 00 23        tst	r16 */
/* 0x3D56: 21 f0        breq	.+8 */
/* 0x3D58: 4e de        rcall	.-868 */
/* 0x3D5A: 0f 73        andi	r16, 0x3f */
/* 0x3D5C: 05 96 d3 d0  <unknown> */
/* 0x3D60: 40 91 b9 06  <unknown> */
/* 0x3D64: 6b de        rcall	.-810 */
/* 0x3D66: ac d0        rcall	.+344 */
/* 0x3D68: 44 5f        subi	r20, 0xf4 */
/* 0x3D6A: d9 d0        rcall	.+434 */
/* 0x3D6C: 20 2f        mov	r18, r16 */
/* 0x3D6E: 2f 77        andi	r18, 0x7f */
/* 0x3D70: 30 e0        ldi	r19, 0x0 */
/* 0x3D72: e9 eb        ldi	r30, 0xb9 */
/* 0x3D74: f6 e0        ldi	r31, 0x6 */
/* 0x3D76: e2 0f        add	r30, r18 */
/* 0x3D78: f3 1f        adc	r31, r19 */
/* 0x3D7A: 00 78        andi	r16, 0x80 */
/* 0x3D7C: 08 81        ldd	r16, Y+0 */
/* 0x3D7E: 11 81        ldd	r17, Z+1 */
/* 0x3D80: 09 f0        breq	.+2 */
/* 0x3D82: 7b c0        rjmp	.+246 */
/* 0x3D84: 10 2b        or	r17, r16 */
/* 0x3D86: 7a c0        rjmp	.+244 */
/* 0x3D88: fb d0        rcall	.+502 */
/* 0x3D8A: 7a 95        dec	r23 */
/* 0x3D8C: 47 2f        mov	r20, r23 */
/* 0x3D8E: 14 d1        rcall	.+552 */
/* 0x3D90: 09 f0        breq	.+2 */
/* 0x3D92: b0 cf        rjmp	.-160 */
/* 0x3D94: d5 cf        rjmp	.-86 */
/* 0x3D96: 22 0f        lsl	r18 */
/* 0x3D98: 33 1f        rol	r19 */
/* 0x3D9A: f9 01 e9 53  <unknown> */
/* 0x3D9E: f9 4f        sbci	r31, 0xf9 */
/* 0x3DA0: 20 81        ldd	r18, Z+0 */
/* 0x3DA2: 31 81        ldd	r19, Z+1 */
/* 0x3DA4: be d0        rcall	.+380 */
/* 0x3DA6: b8 01 ac 01  <unknown> */
/* 0x3DAA: a1 d0        rcall	.+322 */
/* 0x3DAC: d8 01 ac 01  <unknown> */
/* 0x3DB0: 4a 5f        subi	r20, 0xfa */
/* 0x3DB2: 9b d0        rcall	.+310 */
/* 0x3DB4: 59 f0        breq	.+22 */
/* 0x3DB6: 02 e0        ldi	r16, 0x2 */
/* 0x3DB8: 60 9f f0 01  <unknown> */
/* 0x3DBC: e9 53        subi	r30, 0x39 */
/* 0x3DBE: f9 4f        sbci	r31, 0xf9 */
/* 0x3DC0: a0 81        ldd	r26, Z+0 */
/* 0x3DC2: b1 81        ldd	r27, Z+1 */
/* 0x3DC4: bd 01 62 53  <unknown> */
/* 0x3DC8: 70 40        sbci	r23, 0x0 */
/* 0x3DCA: d2 96 08 de  <unknown> */
/* 0x3DCE: 10 2f        mov	r17, r16 */
/* 0x3DD0: 4d ee        ldi	r20, 0xed */
/* 0x3DD2: 52 e0        ldi	r21, 0x2 */
/* 0x3DD4: 60 de        rcall	.-832 */
/* 0x3DD6: 00 23        tst	r16 */
/* 0x3DD8: 29 f4        brne	.+10 */
/* 0x3DDA: 01 2f        mov	r16, r17 */
/* 0x3DDC: 00 7c        andi	r16, 0xc0 */
/* 0x3DDE: 00 38        cpi	r16, 0x80 */
/* 0x3DE0: 09 f0        breq	.+2 */
/* 0x3DE2: be cf        rjmp	.-132 */
/* 0x3DE4: 72 d0        rcall	.+228 */
/* 0x3DE6: 39 f0        breq	.+14 */
/* 0x3DE8: 0a 95        dec	r16 */
/* 0x3DEA: c9 f0        breq	.+50 */
/* 0x3DEC: 0a 95        dec	r16 */
/* 0x3DEE: 41 f1        breq	.+80 */
/* 0x3DF0: 0a 95        dec	r16 */
/* 0x3DF2: 91 f0        breq	.+36 */
/* 0x3DF4: b5 cf        rjmp	.-150 */
/* 0x3DF6: ee d0        rcall	.+476 */
/* 0x3DF8: 11 f0        breq	.+4 */
/* 0x3DFA: 00 20        tst	r0 */
/* 0x3DFC: 19 f0        breq	.+6 */
/* 0x3DFE: 00 20        tst	r0 */
/* 0x3E00: 09 f4        brne	.+2 */
/* 0x3E02: ae cf        rjmp	.-164 */
/* 0x3E04: 62 17        cp	r22, r18 */
/* 0x3E06: 73 07        cpc	r23, r19 */
/* 0x3E08: 3c f4        brge	.+14 */
/* 0x3E0A: 2a 17        cp	r18, r26 */
/* 0x3E0C: 3b 07        cpc	r19, r27 */
/* 0x3E0E: 0c f0        brlt	.+2 */
/* 0x3E10: a7 cf        rjmp	.-178 */
/* 0x3E12: ad d0        rcall	.+346 */
/* 0x3E14: 09 f4        brne	.+2 */
/* 0x3E16: a4 cf        rjmp	.-184 */
/* 0x3E18: 01 e0        ldi	r16, 0x1 */
/* 0x3E1A: 08 83        std	Y+0, r16 */
/* 0x3E1C: a1 cf        rjmp	.-190 */
/* 0x3E1E: da d0        rcall	.+436 */
/* 0x3E20: 11 f0        breq	.+4 */
/* 0x3E22: 00 20        tst	r0 */
/* 0x3E24: 19 f0        breq	.+6 */
/* 0x3E26: 00 20        tst	r0 */
/* 0x3E28: 09 f4        brne	.+2 */
/* 0x3E2A: 9a cf        rjmp	.-204 */
/* 0x3E2C: 2a 17        cp	r18, r26 */
/* 0x3E2E: 3b 07        cpc	r19, r27 */
/* 0x3E30: 9c f7        brge	.-26 */
/* 0x3E32: 62 17        cp	r22, r18 */
/* 0x3E34: 73 07        cpc	r23, r19 */
/* 0x3E36: 0c f0        brlt	.+2 */
/* 0x3E38: 93 cf        rjmp	.-218 */
/* 0x3E3A: 99 d0        rcall	.+306 */
/* 0x3E3C: 69 f7        brne	.-38 */
/* 0x3E3E: 90 cf        rjmp	.-224 */
/* 0x3E40: da dd        rcall	.-1100 */
/* 0x3E42: 10 2f        mov	r17, r16 */
/* 0x3E44: 10 7c        andi	r17, 0xc0 */
/* 0x3E46: 31 f4        brne	.+12 */
/* 0x3E48: 0f 73        andi	r16, 0x3f */
/* 0x3E4A: 00 64        ori	r16, 0x40 */
/* 0x3E4C: 6f d0        rcall	.+222 */
/* 0x3E4E: 01 e0        ldi	r16, 0x1 */
/* 0x3E50: 00 93 37 07  <unknown> */
/* 0x3E54: 05 96 5c d0  <unknown> */
/* 0x3E58: 00 34        cpi	r16, 0x40 */
/* 0x3E5A: 09 f0        breq	.+2 */
/* 0x3E5C: 81 cf        rjmp	.-254 */
/* 0x3E5E: 0e 94 1f 10  <unknown> */
/* 0x3E62: 00 23        tst	r16 */
/* 0x3E64: 09 f0        breq	.+2 */
/* 0x3E66: 7c cf        rjmp	.-264 */
/* 0x3E68: 40 91 b9 06  <unknown> */
/* 0x3E6C: 9d d0        rcall	.+314 */
/* 0x3E6E: 2b 5f        subi	r18, 0xfb */
/* 0x3E70: 35 d0        rcall	.+106 */
/* 0x3E72: 00 e0        ldi	r16, 0x0 */
/* 0x3E74: 00 93 37 07  <unknown> */
/* 0x3E78: 73 cf        rjmp	.-282 */
/* 0x3E7A: 10 23        and	r17, r16 */
/* 0x3E7C: 11 83        std	Z+1, r17 */
/* 0x3E7E: e9 eb        ldi	r30, 0xb9 */
/* 0x3E80: f6 e0        ldi	r31, 0x6 */
/* 0x3E82: 00 81        ldd	r16, Z+0 */
/* 0x3E84: 03 95        inc	r16 */
/* 0x3E86: 00 83        std	Z+0, r16 */
/* 0x3E88: 00 32        cpi	r16, 0x20 */
/* 0x3E8A: a0 f0        brlo	.+40 */
/* 0x3E8C: 80 e0        ldi	r24, 0x0 */
/* 0x3E8E: 90 e0        ldi	r25, 0x0 */
/* 0x3E90: a9 eb        ldi	r26, 0xb9 */
/* 0x3E92: b6 e0        ldi	r27, 0x6 */
/* 0x3E94: a8 0f        add	r26, r24 */
/* 0x3E96: b9 1f        adc	r27, r25 */
/* 0x3E98: fd 01 31 81  <unknown> */
/* 0x3E9C: 28 2f        mov	r18, r24 */
/* 0x3E9E: 07 e4        ldi	r16, 0x47 */
/* 0x3EA0: 17 e0        ldi	r17, 0x7 */
/* 0x3EA2: 0e 94 89 11  <unknown> */
/* 0x3EA6: fd 01 91 83  <unknown> */
/* 0x3EAA: 83 95        inc	r24 */
/* 0x3EAC: 8c 30        cpi	r24, 0xc */
/* 0x3EAE: 78 f3        brlo	.-34 */
/* 0x3EB0: 90 93 b9 06  <unknown> */
/* 0x3EB4: 22 96 09 91  <unknown> */
/* 0x3EB8: 0f bf        out	0x3f, r16 */
/* 0x3EBA: e0 e1        ldi	r30, 0x10 */
/* 0x3EBC: 0c 94 f4 34  <unknown> */
/* 0x3EC0: 4c e4        ldi	r20, 0x4c */
/* 0x3EC2: 50 e0        ldi	r21, 0x0 */
/* 0x3EC4: 40 0f        add	r20, r16 */
/* 0x3EC6: 51 1f        adc	r21, r17 */
/* 0x3EC8: 08 95        ret */
/* 0x3ECA: 04 e0        ldi	r16, 0x4 */
/* 0x3ECC: 10 9f c2 cd  <unknown> */
/* 0x3ED0: 0f 70        andi	r16, 0xf */
/* 0x3ED2: 51 2f        mov	r21, r17 */
/* 0x3ED4: 10 2f        mov	r17, r16 */
/* 0x3ED6: 25 2f        mov	r18, r21 */
/* 0x3ED8: ac 01 08 95  <unknown> */
/* 0x3EDC: 3f 4f        sbci	r19, 0xff */
/* 0x3EDE: a9 01 15 c0  <unknown> */
/* 0x3EE2: 2b 5f        subi	r18, 0xfb */
/* 0x3EE4: 3f 4f        sbci	r19, 0xff */
/* 0x3EE6: a9 01 d6 cd  <unknown> */
/* 0x3EEA: 19 d0        rcall	.+50 */
/* 0x3EEC: a0 cd        rjmp	.-1216 */
/* 0x3EEE: 41 5f        subi	r20, 0xf1 */
/* 0x3EF0: 1a c0        rjmp	.+52 */
/* 0x3EF2: 06 d0        rcall	.+12 */
/* 0x3EF4: 30 2f        mov	r19, r16 */
/* 0x3EF6: 62 2f        mov	r22, r18 */
/* 0x3EF8: 08 95        ret */
/* 0x3EFA: 02 d0        rcall	.+4 */
/* 0x3EFC: ab 01 4d c0  <unknown> */
/* 0x3F00: 0e d0        rcall	.+28 */
/* 0x3F02: 0f 71        andi	r16, 0x1f */
/* 0x3F04: 08 95        ret */
/* 0x3F0A: ab 01 0c 94  <unknown> */
/* 0x3F0E: a0 31        cpi	r26, 0x10 */
/* 0x3F10: 66 dd        rcall	.-1332 */
/* 0x3F12: 99 cd        rjmp	.-1230 */
/* 0x3F14: 04 d0        rcall	.+8 */
/* 0x3F16: 0f 77        andi	r16, 0x7f */
/* 0x3F18: 10 2f        mov	r17, r16 */
/* 0x3F1A: ac 01 4c 5f  <unknown> */
/* 0x3F1E: 5f 4f        sbci	r21, 0xff */
/* 0x3F20: ba cd        rjmp	.-1164 */
/* 0x3F22: ac 01 43 5f  <unknown> */
/* 0x3F26: 5f 4f        sbci	r21, 0xff */
/* 0x3F28: 0c 94 89 31  <unknown> */
/* 0x3F2C: ac 01 4b 5f  <unknown> */
/* 0x3F30: 5f 4f        sbci	r21, 0xff */
/* 0x3F32: ec cf        rjmp	.-40 */
/* 0x3F34: ac 01 45 5f  <unknown> */
/* 0x3F38: f2 cf        rjmp	.-28 */
/* 0x3F3A: ac 01 e5 c0  <unknown> */
/* 0x3F3E: ac 01 48 5f  <unknown> */
/* 0x3F42: 37 d0        rcall	.+110 */
/* 0x3F44: 20 2f        mov	r18, r16 */
/* 0x3F46: 08 95        ret */
/* 0x3F48: ac 01 4f 5f  <unknown> */
/* 0x3F4C: e8 cf        rjmp	.-48 */
/* 0x3F4E: fc df        rcall	.-8 */
/* 0x3F50: 0f 73        andi	r16, 0x3f */
/* 0x3F52: f8 cf        rjmp	.-16 */
/* 0x3F54: 44 dd        rcall	.-1400 */
/* 0x3F56: 0f 73        andi	r16, 0x3f */
/* 0x3F58: 10 2f        mov	r17, r16 */
/* 0x3F5A: ac 01 4a 5f  <unknown> */
/* 0x3F5E: 08 95        ret */
/* 0x3F60: ac 01 49 5f  <unknown> */
/* 0x3F64: 26 d0        rcall	.+76 */
/* 0x3F66: 10 2f        mov	r17, r16 */
/* 0x3F68: ac 01 4b 5f  <unknown> */
/* 0x3F6C: 08 95        ret */
/* 0x3F6E: 0c 96 36 dd  <unknown> */
/* 0x3F72: 0f 77        andi	r16, 0x7f */
/* 0x3F74: 20 2f        mov	r18, r16 */
/* 0x3F76: 07 e4        ldi	r16, 0x47 */
/* 0x3F78: 17 e0        ldi	r17, 0x7 */
/* 0x3F7A: 0e 94 b1 11  <unknown> */
/* 0x3F7E: c9 cc        rjmp	.-1646 */
/* 0x3F80: ac 01 4f 5e  <unknown> */
/* 0x3F84: 5f 4f        sbci	r21, 0xff */
/* 0x3F86: 0e 94 8e 31  <unknown> */
/* 0x3F8A: 08 01 19 01  <unknown> */
/* 0x3F8E: 08 95        ret */
/* 0x3F90: 32 dd        rcall	.-1436 */
/* 0x3F92: 4d cd        rjmp	.-1382 */
/* 0x3F94: b5 df        rcall	.-150 */
/* 0x3F96: 50 e0        ldi	r21, 0x0 */
/* 0x3F98: 40 e0        ldi	r20, 0x0 */
/* 0x3F9A: ac cd        rjmp	.-1192 */
/* 0x3F9C: 4f dd        rcall	.-1378 */
/* 0x3F9E: 8c e4        ldi	r24, 0x4c */
/* 0x3FA0: 90 e0        ldi	r25, 0x0 */
/* 0x3FA2: 80 0f        add	r24, r16 */
/* 0x3FA4: 91 1f        adc	r25, r17 */
/* 0x3FA6: 08 95        ret */
/* 0x3FA8: 3b dd        rcall	.-1418 */
/* 0x3FAA: 4b 5f        subi	r20, 0xfb */
/* 0x3FAC: 02 d0        rcall	.+4 */
/* 0x3FAE: 00 68        ori	r16, 0x80 */
/* 0x3FB0: 08 95        ret */
/* 0x3FB2: b5 df        rcall	.-150 */
/* 0x3FB4: 0f 73        andi	r16, 0x3f */
/* 0x3FB6: 08 95        ret */
/* 0x3FB8: 01 e0        ldi	r16, 0x1 */
/* 0x3FBA: 10 e0        ldi	r17, 0x0 */
/* 0x3FBC: 20 e0        ldi	r18, 0x0 */
/* 0x3FBE: 30 e0        ldi	r19, 0x0 */
/* 0x3FC0: 0e 94 2d 32  <unknown> */
/* 0x3FC4: 00 22        and	r0, r16 */
/* 0x3FC6: 11 22        and	r1, r17 */
/* 0x3FC8: 22 22        and	r2, r18 */
/* 0x3FCA: 33 22        and	r3, r19 */
/* 0x3FCC: 01 28        or	r0, r1 */
/* 0x3FCE: 02 28        or	r0, r2 */
/* 0x3FD0: 03 28        or	r0, r3 */
/* 0x3FD2: 08 95        ret */
/* 0x3FD4: 10 dd        rcall	.-1504 */
/* 0x3FD6: 00 2e        mov	r0, r16 */
/* 0x3FD8: 00 e2        ldi	r16, 0x20 */
/* 0x3FDA: 00 22        and	r0, r16 */
/* 0x3FDC: ab df        rcall	.-170 */
/* 0x3FDE: f0 e0        ldi	r31, 0x0 */
/* 0x3FE0: e0 2f        mov	r30, r16 */
/* 0x3FE2: e9 5f        subi	r30, 0xf9 */
/* 0x3FE4: f8 4f        sbci	r31, 0xf8 */
/* 0x3FE6: 00 81        ldd	r16, Z+0 */
/* 0x3FE8: 94 cc        rjmp	.-1752 */
/* 0x3FEA: 2f b6        in	r2, 0x3f */
/* 0x3FEC: f8 94        cli */
/* 0x3FEE: e0 e0        ldi	r30, 0x0 */
/* 0x3FF0: 4e 2f        mov	r20, r30 */
/* 0x3FF2: 8d d0        rcall	.+282 */
/* 0x3FF4: 4a 5f        subi	r20, 0xfa */
/* 0x3FF6: 75 d0        rcall	.+234 */
/* 0x3FF8: ab 01 4a 5f  <unknown> */
/* 0x3FFC: 70 d0        rcall	.+224 */
/* 0x3FFE: 00 7c        andi	r16, 0xc0 */
/* 0x4000: 55 d0        rcall	.+170 */
/* 0x4002: 77 d0        rcall	.+238 */
/* 0x4004: 4f 5f        subi	r20, 0xff */
/* 0x4006: 73 d0        rcall	.+230 */
/* 0x4008: 00 7e        andi	r16, 0xe0 */
/* 0x400A: 5e d0        rcall	.+188 */
/* 0x400C: 49 5f        subi	r20, 0xf9 */
/* 0x400E: 71 d0        rcall	.+226 */
/* 0x4010: 49 5f        subi	r20, 0xf9 */
/* 0x4012: 5d d0        rcall	.+186 */
/* 0x4014: 6e d0        rcall	.+220 */
/* 0x4016: 48 5f        subi	r20, 0xf8 */
/* 0x4018: 73 d0        rcall	.+230 */
/* 0x401A: 76 d0        rcall	.+236 */
/* 0x401C: 6f d0        rcall	.+222 */
/* 0x401E: 52 d0        rcall	.+164 */
/* 0x4020: ab 01 4e 5f  <unknown> */
/* 0x4024: 61 d0        rcall	.+194 */
/* 0x4026: 00 7e        andi	r16, 0xe0 */
/* 0x4028: 01 60        ori	r16, 0x1 */
/* 0x402A: ab 01 47 5f  <unknown> */
/* 0x402E: 68 d0        rcall	.+208 */
/* 0x4030: 46 5f        subi	r20, 0xf6 */
/* 0x4032: 57 d0        rcall	.+174 */
/* 0x4034: 01 60        ori	r16, 0x1 */
/* 0x4036: ab 01 46 5f  <unknown> */
/* 0x403A: 7a df        rcall	.-268 */
/* 0x403C: 01 e1        ldi	r16, 0x11 */
/* 0x403E: ab 01 4c 5f  <unknown> */
/* 0x4042: b9 dc        rcall	.-1678 */
/* 0x4044: ab 01 44 5f  <unknown> */
/* 0x4048: 73 df        rcall	.-282 */
/* 0x404A: 10 e0        ldi	r17, 0x0 */
/* 0x404C: ab 01 43 5f  <unknown> */
/* 0x4050: 35 d0        rcall	.+106 */
/* 0x4052: 41 5f        subi	r20, 0xf1 */
/* 0x4054: 33 d0        rcall	.+102 */
/* 0x4056: 45 5f        subi	r20, 0xf5 */
/* 0x4058: 42 d0        rcall	.+132 */
/* 0x405A: 00 6c        ori	r16, 0xc0 */
/* 0x405C: 27 d0        rcall	.+78 */
/* 0x405E: 3d d0        rcall	.+122 */
/* 0x4060: a9 dc        rcall	.-1710 */
/* 0x4062: 20 e0        ldi	r18, 0x0 */
/* 0x4064: 30 e0        ldi	r19, 0x0 */
/* 0x4066: ab 01 25 d0  <unknown> */
/* 0x406A: ab 01 4b d0  <unknown> */
/* 0x406E: 0f 77        andi	r16, 0x7f */
/* 0x4070: 45 d0        rcall	.+138 */
/* 0x4072: 4b 5f        subi	r20, 0xfb */
/* 0x4074: 2f d0        rcall	.+94 */
/* 0x4076: 29 d0        rcall	.+82 */
/* 0x4078: 4e 5f        subi	r20, 0xfe */
/* 0x407A: 51 df        rcall	.-350 */
/* 0x407C: 00 68        ori	r16, 0x80 */
/* 0x407E: ab 01 4e 5f  <unknown> */
/* 0x4082: 35 d0        rcall	.+106 */
/* 0x4084: 0f 73        andi	r16, 0x3f */
/* 0x4086: 00 68        ori	r16, 0x80 */
/* 0x4088: 1f d0        rcall	.+62 */
/* 0x408A: 4a 5f        subi	r20, 0xfa */
/* 0x408C: 23 d0        rcall	.+70 */
/* 0x408E: 4a 5f        subi	r20, 0xfa */
/* 0x4090: 1e d0        rcall	.+60 */
/* 0x4092: 23 d0        rcall	.+70 */
/* 0x4094: 48 5f        subi	r20, 0xf8 */
/* 0x4096: 28 d0        rcall	.+80 */
/* 0x4098: 0f 71        andi	r16, 0x1f */
/* 0x409A: 67 5f        subi	r22, 0xf7 */
/* 0x409C: 7f 4f        sbci	r23, 0xff */
/* 0x409E: 35 df        rcall	.-406 */
/* 0x40A0: e3 95        inc	r30 */
/* 0x40A2: e0 32        cpi	r30, 0x20 */
/* 0x40A4: 08 f4        brsh	.+2 */
/* 0x40A6: a4 cf        rjmp	.-184 */
/* 0x40A8: 2f be        out	0x3f, r2 */
/* 0x40AA: 08 95        ret */
/* 0x40AC: 2e df        rcall	.-420 */
/* 0x40AE: ab 01 4f 5f  <unknown> */
/* 0x40B2: 08 95        ret */
/* 0x40BC: 5f 4f        sbci	r21, 0xff */
/* 0x40BE: 0e 94 a4 31  <unknown> */
/* 0x40C2: 18 c0        rjmp	.+48 */
/* 0x40C4: 4e 5f        subi	r20, 0xfe */
/* 0x40C6: 21 c0        rjmp	.+66 */
/* 0x40C8: ab 01 4b 5f  <unknown> */
/* 0x40CC: 19 c0        rjmp	.+50 */
/* 0x40CE: 18 d0        rcall	.+48 */
/* 0x40D0: 48 5f        subi	r20, 0xf8 */
/* 0x40D2: 08 95        ret */
/* 0x40D4: 24 df        rcall	.-440 */
/* 0x40D6: 0f 7d        andi	r16, 0xdf */
/* 0x40D8: 0d c0        rjmp	.+26 */
/* 0x40DA: 6b df        rcall	.-298 */
/* 0x40DC: 0b c0        rjmp	.+22 */
/* 0x40DE: 10 d0        rcall	.+32 */
/* 0x40E0: da cc        rjmp	.-1612 */
/* 0x40E2: 1d df        rcall	.-454 */
/* 0x40E4: 00 7e        andi	r16, 0xe0 */
/* 0x40E6: 08 95        ret */
/* 0x40E8: 0b d0        rcall	.+22 */
/* 0x40EA: 47 5f        subi	r20, 0xf7 */
/* 0x40EC: 18 cf        rjmp	.-464 */
/* 0x40EE: 08 d0        rcall	.+16 */
/* 0x40F0: 83 cc        rjmp	.-1786 */
/* 0x40F2: 02 d0        rcall	.+4 */
/* 0x40F4: ab 01 08 95  <unknown> */
/* 0x40F8: 12 df        rcall	.-476 */
/* 0x40FA: a5 cc        rjmp	.-1718 */
/* 0x40FC: ab 01 4d 5f  <unknown> */
/* 0x4100: 17 df        rcall	.-466 */
/* 0x4102: f8 cf        rjmp	.-16 */
/* 0x4108: 4d 5f        subi	r20, 0xfd */
/* 0x410A: 09 df        rcall	.-494 */
/* 0x410C: b5 cc        rjmp	.-1686 */
/* 0x410E: 96 dc        rcall	.-1748 */
/* 0x4110: 6c e4        ldi	r22, 0x4c */
/* 0x4112: 70 e0        ldi	r23, 0x0 */
/* 0x4114: 60 0f        add	r22, r16 */
/* 0x4116: 71 1f        adc	r23, r17 */
/* 0x4118: ed cf        rjmp	.-38 */
/* 0x4168: 9a 93        st	-Y, r25 */
/* 0x416A: 8a 93        st	-Y, r24 */
/* 0x416C: c8 01 11 e0  <unknown> */
/* 0x4170: bf d3        rcall	.+1918 */
/* 0x4172: 8c 01 89 91  <unknown> */
/* 0x4176: 99 91        ld	r25, Y+ */
/* 0x4178: 08 95        ret */
/* 0x41BC: 0e 94 e5 34  <unknown> */
/* 0x41C0: 61 97 db df  <unknown> */
/* 0x41C4: 0e 94 c6 0e  <unknown> */
/* 0x41C8: 0e 94 fb 15  <unknown> */
/* 0x41CC: 0e 94 ca 06  <unknown> */
/* 0x41D0: 0e 94 11 10  <unknown> */
/* 0x41D4: 07 e0        ldi	r16, 0x7 */
/* 0x41D6: a0 2e        mov	r10, r16 */
/* 0x41D8: 07 e0        ldi	r16, 0x7 */
/* 0x41DA: b0 2e        mov	r11, r16 */
/* 0x41DC: 99 d3        rcall	.+1842 */
/* 0x41DE: 30 d7        rcall	.+3680 */
/* 0x41E0: 0e 94 fd 11  <unknown> */
/* 0x41E4: 0e 94 1f 10  <unknown> */
/* 0x41E8: 05 30        cpi	r16, 0x5 */
/* 0x41EA: f9 f5        brne	.+126 */
/* 0x41EC: 01 e0        ldi	r16, 0x1 */
/* 0x41EE: 4c ee        ldi	r20, 0xec */
/* 0x41F0: 52 e0        ldi	r21, 0x2 */
/* 0x41F2: 0e 94 f2 29  <unknown> */
/* 0x41F6: 0e 94 f0 29  <unknown> */
/* 0x41FA: 06 e9        ldi	r16, 0x96 */
/* 0x41FC: 4e ee        ldi	r20, 0xee */
/* 0x41FE: 52 e0        ldi	r21, 0x2 */
/* 0x4200: 0e 94 f2 29  <unknown> */
/* 0x4204: 4f ee        ldi	r20, 0xef */
/* 0x4206: 52 e0        ldi	r21, 0x2 */
/* 0x4208: 0e 94 f2 29  <unknown> */
/* 0x420C: 09 e6        ldi	r16, 0x69 */
/* 0x420E: 08 bd        out	0x28, r16 */
/* 0x4210: 0c bf        out	0x3c, r16 */
/* 0x4212: 8c 9a        sbi	0x11, 0x4 */
/* 0x4214: 10 e0        ldi	r17, 0x0 */
/* 0x4216: 03 e0        ldi	r16, 0x3 */
/* 0x4218: 0e 94 76 29  <unknown> */
/* 0x421C: 0d e9        ldi	r16, 0x9d */
/* 0x421E: 17 e0        ldi	r17, 0x7 */
/* 0x4220: 0e 94 71 29  <unknown> */
/* 0x4224: 0e 94 96 29  <unknown> */
/* 0x4228: 07 ea        ldi	r16, 0xa7 */
/* 0x422A: 17 e0        ldi	r17, 0x7 */
/* 0x422C: 74 d6        rcall	.+3304 */
/* 0x422E: 50 d3        rcall	.+1696 */
/* 0x4230: 0e 94 f5 1f  <unknown> */
/* 0x4234: 0e 94 e7 06  <unknown> */
/* 0x4238: 0e 94 44 15  <unknown> */
/* 0x423C: 01 d7        rcall	.+3586 */
/* 0x423E: 0e 94 6d 12  <unknown> */
/* 0x4242: 20 e0        ldi	r18, 0x0 */
/* 0x4244: 60 e0        ldi	r22, 0x0 */
/* 0x4246: 30 e0        ldi	r19, 0x0 */
/* 0x4248: 89 01 0e 94  <unknown> */
/* 0x424C: 89 29        or	r24, r9 */
/* 0x424E: 0e 94 83 29  <unknown> */
/* 0x4252: 46 0f        add	r20, r22 */
/* 0x4254: 53 1f        adc	r21, r19 */
/* 0x4256: 00 e0        ldi	r16, 0x0 */
/* 0x4258: 0e 94 f2 29  <unknown> */
/* 0x425C: 63 95        inc	r22 */
/* 0x425E: 68 30        cpi	r22, 0x8 */
/* 0x4260: 90 f3        brlo	.-28 */
/* 0x4262: 23 95        inc	r18 */
/* 0x4264: 20 32        cpi	r18, 0x20 */
/* 0x4266: 70 f3        brlo	.-36 */
/* 0x4268: 8c 98        cbi	0x11, 0x4 */
/* 0x426A: f5 01 00 a1  <unknown> */
/* 0x426E: 07 fd        sbrc	r16, 0x7 */
/* 0x4270: 07 c0        rjmp	.+14 */
/* 0x4272: 07 a1 03 71  <unknown> */
/* 0x4276: 00 31        cpi	r16, 0x10 */
/* 0x4278: 19 f4        brne	.+6 */
/* 0x427A: 02 a1 06 ff  <unknown> */
/* 0x427E: 0d c0        rjmp	.+26 */
/* 0x4280: 00 a1 0f 77  <unknown> */
/* 0x4284: 00 a3 07 a1  <unknown> */
/* 0x4288: 0c 7f        andi	r16, 0xfc */
/* 0x428A: 07 a3 00 61  <unknown> */
/* 0x428E: 07 a3 02 a1  <unknown> */
/* 0x4292: 0f 7b        andi	r16, 0xbf */
/* 0x4294: 02 a3 a1 d5  <unknown> */
/* 0x4298: 1b d3        rcall	.+1590 */
/* 0x429A: 80 e0        ldi	r24, 0x0 */
/* 0x429C: 31 e1        ldi	r19, 0x11 */
/* 0x429E: 83 9f 20 2d  <unknown> */
/* 0x42A2: 28 5f        subi	r18, 0xf8 */
/* 0x42A4: 8e 01 35 d3  <unknown> */
/* 0x42A8: 0e 94 74 29  <unknown> */
/* 0x42AC: 08 81        ldd	r16, Y+0 */
/* 0x42AE: 00 23        tst	r16 */
/* 0x42B0: 41 f4        brne	.+16 */
/* 0x42B2: 28 e9        ldi	r18, 0x98 */
/* 0x42B4: 3b e0        ldi	r19, 0xb */
/* 0x42B6: 48 2f        mov	r20, r24 */
/* 0x42B8: 50 e0        ldi	r21, 0x0 */
/* 0x42BA: 01 e1        ldi	r16, 0x11 */
/* 0x42BC: 8b d5        rcall	.+2838 */
/* 0x42BE: 29 d6        rcall	.+3154 */
/* 0x42C0: 0c c0        rjmp	.+24 */
/* 0x42C2: a0 e0        ldi	r26, 0x0 */
/* 0x42C4: fe 01 b0 e0  <unknown> */
/* 0x42C8: ea 0f        add	r30, r26 */
/* 0x42CA: fb 1f        adc	r31, r27 */
/* 0x42CC: 00 81        ldd	r16, Z+0 */
/* 0x42CE: 00 23        tst	r16 */
/* 0x42D0: 21 f0        breq	.+8 */
/* 0x42D2: b4 d6        rcall	.+3432 */
/* 0x42D4: a3 95        inc	r26 */
/* 0x42D6: a0 31        cpi	r26, 0x10 */
/* 0x42D8: a8 f3        brlo	.-22 */
/* 0x42DA: 83 95        inc	r24 */
/* 0x42DC: 82 30        cpi	r24, 0x2 */
/* 0x42DE: f0 f2        brlo	.-68 */
/* 0x42E0: 0e 94 4c 2a  <unknown> */
/* 0x42E4: 8c 98        cbi	0x11, 0x4 */
/* 0x42E6: 0e 94 fa 2c  <unknown> */
/* 0x42EA: d9 f0        breq	.+54 */
/* 0x42EC: 2f ef        ldi	r18, 0xff */
/* 0x42EE: 8c 9a        sbi	0x11, 0x4 */
/* 0x42F0: 10 e0        ldi	r17, 0x0 */
/* 0x42F2: 08 c0        rjmp	.+16 */
/* 0x42F4: 08 bd        out	0x28, r16 */
/* 0x42F6: 43 ec        ldi	r20, 0xc3 */
/* 0x42F8: 59 e0        ldi	r21, 0x9 */
/* 0x42FA: 41 50        subi	r20, 0x1 */
/* 0x42FC: 50 40        sbci	r21, 0x0 */
/* 0x42FE: e9 f7        brne	.-6 */
/* 0x4300: 00 c0        rjmp	.+0 */
/* 0x4302: 00 00        nop */
/* 0x4304: 13 95        inc	r17 */
/* 0x4306: 59 f0        breq	.+22 */
/* 0x4308: 01 2f        mov	r16, r17 */
/* 0x430A: 0f 73        andi	r16, 0x3f */
/* 0x430C: 09 f4        brne	.+2 */
/* 0x430E: 20 95        com	r18 */
/* 0x4310: 01 2f        mov	r16, r17 */
/* 0x4312: 00 0f        lsl	r16 */
/* 0x4314: 00 0f        lsl	r16 */
/* 0x4316: 22 23        tst	r18 */
/* 0x4318: 69 f3        breq	.-38 */
/* 0x431A: 00 95        com	r16 */
/* 0x431C: eb cf        rjmp	.-42 */
/* 0x431E: 0e 94 f4 29  <unknown> */
/* 0x4322: 0e 94 94 13  <unknown> */
/* 0x4326: d8 01 25 eb  <unknown> */
/* 0x432A: 37 e0        ldi	r19, 0x7 */
/* 0x432C: 0e 94 39 14  <unknown> */
/* 0x4330: 00 e2        ldi	r16, 0x20 */
/* 0x4332: 0e 94 ea 29  <unknown> */
/* 0x4336: ef d2        rcall	.+1502 */
/* 0x4338: 8d 01 0e 94  <unknown> */
/* 0x433C: bc 13        cpse	r27, r28 */
/* 0x433E: eb d2        rcall	.+1494 */
/* 0x4340: 95 d2        rcall	.+1322 */
/* 0x4342: 90 e0        ldi	r25, 0x0 */
/* 0x4344: 20 e0        ldi	r18, 0x0 */
/* 0x4346: 09 2f        mov	r16, r25 */
/* 0x4348: dd d7        rcall	.+4026 */
/* 0x434A: 30 e0        ldi	r19, 0x0 */
/* 0x434C: 42 0f        add	r20, r18 */
/* 0x434E: 53 1f        adc	r21, r19 */
/* 0x4350: bb d7        rcall	.+3958 */
/* 0x4352: 02 d3        rcall	.+1540 */
/* 0x4354: 23 95        inc	r18 */
/* 0x4356: 28 30        cpi	r18, 0x8 */
/* 0x4358: b0 f3        brlo	.-20 */
/* 0x435A: 8e d2        rcall	.+1308 */
/* 0x435C: 29 f0        breq	.+10 */
/* 0x435E: ae d7        rcall	.+3932 */
/* 0x4360: 22 e0        ldi	r18, 0x2 */
/* 0x4362: 92 9f f0 01  <unknown> */
/* 0x4366: 7d d2        rcall	.+1274 */
/* 0x4368: 49 2f        mov	r20, r25 */
/* 0x436A: 50 e0        ldi	r21, 0x0 */
/* 0x436C: 4f 5f        subi	r20, 0xff */
/* 0x436E: 5f 4f        sbci	r21, 0xff */
/* 0x4370: 65 2f        mov	r22, r21 */
/* 0x4372: 66 0f        lsl	r22 */
/* 0x4374: 66 0b        sbc	r22, r22 */
/* 0x4376: 76 2f        mov	r23, r22 */
/* 0x4378: 79 d2        rcall	.+1266 */
/* 0x437A: 93 95        inc	r25 */
/* 0x437C: 90 32        cpi	r25, 0x20 */
/* 0x437E: 10 f3        brlo	.-60 */
/* 0x4380: 0a 2f        mov	r16, r26 */
/* 0x4382: 0b 2b        or	r16, r27 */
/* 0x4384: 31 f0        breq	.+12 */
/* 0x4386: 8d 01 0e 94  <unknown> */
/* 0x438A: b9 13        cpse	r27, r25 */
/* 0x438C: 8d 01 0e 94  <unknown> */
/* 0x4390: 76 31        cpi	r23, 0x16 */
/* 0x4392: 83 e0        ldi	r24, 0x3 */
/* 0x4394: 01 e0        ldi	r16, 0x1 */
/* 0x4396: 0e 94 f8 0f  <unknown> */
/* 0x439A: 0f e4        ldi	r16, 0x4f */
/* 0x439C: 13 ec        ldi	r17, 0xc3 */
/* 0x439E: 01 50        subi	r16, 0x1 */
/* 0x43A0: 10 40        sbci	r17, 0x0 */
/* 0x43A2: e9 f7        brne	.-6 */
/* 0x43A4: 00 c0        rjmp	.+0 */
/* 0x43A6: 00 00        nop */
/* 0x43A8: 8a 95        dec	r24 */
/* 0x43AA: a1 f7        brne	.-24 */
/* 0x43AC: 0e 94 f6 2c  <unknown> */
/* 0x43B0: 00 93 3c 07  <unknown> */
/* 0x43B4: 78 94        sei */
/* 0x43B6: 33 c0        rjmp	.+102 */
/* 0x43B8: 0b e8        ldi	r16, 0x8b */
/* 0x43BA: 18 e0        ldi	r17, 0x8 */
/* 0x43BC: ac d5        rcall	.+2904 */
/* 0x43BE: 40 e1        ldi	r20, 0x10 */
/* 0x43C0: 50 e0        ldi	r21, 0x0 */
/* 0x43C2: 48 0d        add	r20, r8 */
/* 0x43C4: 59 1d        adc	r21, r9 */
/* 0x43C6: 80 d7        rcall	.+3840 */
/* 0x43C8: 37 d6        rcall	.+3182 */
/* 0x43CA: 44 d2        rcall	.+1160 */
/* 0x43CC: 8c 01 a3 d5  <unknown> */
/* 0x43D0: 28 96 01 e0  <unknown> */
/* 0x43D4: 80 0e        add	r8, r16 */
/* 0x43D6: 00 e0        ldi	r16, 0x0 */
/* 0x43D8: 90 1e        adc	r9, r16 */
/* 0x43DA: 02 e0        ldi	r16, 0x2 */
/* 0x43DC: 80 16        cp	r8, r16 */
/* 0x43DE: 00 e0        ldi	r16, 0x0 */
/* 0x43E0: 90 06        cpc	r9, r16 */
/* 0x43E2: 08 f4        brsh	.+2 */
/* 0x43E4: a6 c1        rjmp	.+844 */
/* 0x43E6: 00 91 3b 07  <unknown> */
/* 0x43EA: 0c 15        cp	r16, r12 */
/* 0x43EC: 50 f0        brlo	.+20 */
/* 0x43EE: dd 20        tst	r13 */
/* 0x43F0: 41 f4        brne	.+16 */
/* 0x43F2: 0e 94 f6 2c  <unknown> */
/* 0x43F6: 00 93 3f 07  <unknown> */
/* 0x43FA: 4c d2        rcall	.+1176 */
/* 0x43FC: 10 f0        brlo	.+4 */
/* 0x43FE: 00 e0        ldi	r16, 0x0 */
/* 0x4400: 05 ab 10 d6  <unknown> */
/* 0x4404: 29 f4        brne	.+10 */
/* 0x4406: 01 e0        ldi	r16, 0x1 */
/* 0x4408: cd d2        rcall	.+1434 */
/* 0x440A: 01 e0        ldi	r16, 0x1 */
/* 0x440C: 00 93 3a 07  <unknown> */
/* 0x4410: 06 d6        rcall	.+3084 */
/* 0x4412: 00 23        tst	r16 */
/* 0x4414: 19 f4        brne	.+6 */
/* 0x4416: 04 e6        ldi	r16, 0x64 */
/* 0x4418: 0e 94 f7 2c  <unknown> */
/* 0x441C: c6 d4        rcall	.+2444 */
/* 0x441E: f5 01 06 a9  <unknown> */
/* 0x4422: 03 95        inc	r16 */
/* 0x4424: 06 ab 03 70  <unknown> */
/* 0x4428: 0e 94 d1 06  <unknown> */
/* 0x442C: 42 d7        rcall	.+3716 */
/* 0x442E: 0e 94 5e 2a  <unknown> */
/* 0x4432: f8 94        cli */
/* 0x4434: f4 d5        rcall	.+3048 */
/* 0x4436: 06 30        cpi	r16, 0x6 */
/* 0x4438: 19 f0        breq	.+6 */
/* 0x443A: 0e 94 fa 2c  <unknown> */
/* 0x443E: 21 f5        brne	.+72 */
/* 0x4440: 0e 94 93 0f  <unknown> */
/* 0x4444: c8 01 69 d5  <unknown> */
/* 0x4448: 0d eb        ldi	r16, 0xbd */
/* 0x444A: 17 e0        ldi	r17, 0x7 */
/* 0x444C: 64 d5        rcall	.+2760 */
/* 0x444E: 8c 9a        sbi	0x11, 0x4 */
/* 0x4450: 06 ee        ldi	r16, 0xe6 */
/* 0x4452: 08 bd        out	0x28, r16 */
/* 0x4454: 00 e0        ldi	r16, 0x0 */
/* 0x4456: c4 d7        rcall	.+3976 */
/* 0x4458: 78 94        sei */
/* 0x445A: 0c c0        rjmp	.+24 */
/* 0x445C: 92 d4        rcall	.+2340 */
/* 0x445E: 41 f0        breq	.+16 */
/* 0x4460: 57 d2        rcall	.+1198 */
/* 0x4462: 11 e0        ldi	r17, 0x1 */
/* 0x4464: 04 e0        ldi	r16, 0x4 */
/* 0x4466: 7c d2        rcall	.+1272 */
/* 0x4468: 0e ec        ldi	r16, 0xce */
/* 0x446A: 17 e0        ldi	r17, 0x7 */
/* 0x446C: 14 d5        rcall	.+2600 */
/* 0x446E: 9d d4        rcall	.+2362 */
/* 0x4470: 0e 94 e0 1d  <unknown> */
/* 0x4474: 1e d7        rcall	.+3644 */
/* 0x4476: 06 30        cpi	r16, 0x6 */
/* 0x4478: 89 f7        brne	.-30 */
/* 0x447A: f8 94        cli */
/* 0x447C: 01 e0        ldi	r16, 0x1 */
/* 0x447E: b0 d7        rcall	.+3936 */
/* 0x4480: b3 d7        rcall	.+3942 */
/* 0x4482: 8c 01 0e 94  <unknown> */
/* 0x4486: a7 0f        add	r26, r23 */
/* 0x4488: 78 94        sei */
/* 0x448A: 00 91 38 07  <unknown> */
/* 0x448E: 00 23        tst	r16 */
/* 0x4490: 81 f5        brne	.+96 */
/* 0x4492: 1f d7        rcall	.+3646 */
/* 0x4494: 0a 95        dec	r16 */
/* 0x4496: 19 f0        breq	.+6 */
/* 0x4498: 0a 95        dec	r16 */
/* 0x449A: e9 f0        breq	.+58 */
/* 0x449C: 2a c0        rjmp	.+84 */
/* 0x449E: 20 91 3e 07  <unknown> */
/* 0x44A2: 30 e0        ldi	r19, 0x0 */
/* 0x44A4: 0f ef        ldi	r16, 0xff */
/* 0x44A6: f9 01 e9 5f  <unknown> */
/* 0x44AA: f8 4f        sbci	r31, 0xf8 */
/* 0x44AC: 00 83        std	Z+0, r16 */
/* 0x44AE: 08 81        ldd	r16, Y+0 */
/* 0x44B0: 19 81        ldd	r17, Y+1 */
/* 0x44B2: 22 0f        lsl	r18 */
/* 0x44B4: 33 1f        rol	r19 */
/* 0x44B6: f9 01 d4 d1  <unknown> */
/* 0x44BA: 90 e2        ldi	r25, 0x20 */
/* 0x44BC: 05 c0        rjmp	.+10 */
/* 0x44BE: f7 d6        rcall	.+3566 */
/* 0x44C0: db d1        rcall	.+950 */
/* 0x44C2: b9 f4        brne	.+46 */
/* 0x44C4: 99 23        tst	r25 */
/* 0x44C6: a9 f0        breq	.+42 */
/* 0x44C8: ef d1        rcall	.+990 */
/* 0x44CA: 37 d2        rcall	.+1134 */
/* 0x44CC: f0 f3        brlo	.-4 */
/* 0x44CE: d4 d1        rcall	.+936 */
/* 0x44D0: b1 f7        brne	.-20 */
/* 0x44D2: f6 d1        rcall	.+1004 */
/* 0x44D4: f5 cf        rjmp	.-22 */
/* 0x44D6: f4 d1        rcall	.+1000 */
/* 0x44D8: 90 e2        ldi	r25, 0x20 */
/* 0x44DA: e6 d1        rcall	.+972 */
/* 0x44DC: 2e d2        rcall	.+1116 */
/* 0x44DE: f0 f3        brlo	.-4 */
/* 0x44E0: cb d1        rcall	.+918 */
/* 0x44E2: 11 f4        brne	.+4 */
/* 0x44E4: ed d1        rcall	.+986 */
/* 0x44E6: 01 c0        rjmp	.+2 */
/* 0x44E8: e2 d6        rcall	.+3524 */
/* 0x44EA: c6 d1        rcall	.+908 */
/* 0x44EC: 11 f4        brne	.+4 */
/* 0x44EE: 99 23        tst	r25 */
/* 0x44F0: a1 f7        brne	.-24 */
/* 0x44F2: 47 d4        rcall	.+2190 */
/* 0x44F4: 09 f0        breq	.+2 */
/* 0x44F6: 0c d2        rcall	.+1048 */
/* 0x44F8: 0e 94 e0 1d  <unknown> */
/* 0x44FC: 00 91 3a 07  <unknown> */
/* 0x4500: 00 23        tst	r16 */
/* 0x4502: 21 f0        breq	.+8 */
/* 0x4504: 0a 95        dec	r16 */
/* 0x4506: 09 f4        brne	.+2 */
/* 0x4508: 90 c1        rjmp	.+800 */
/* 0x450A: 89 cf        rjmp	.-238 */
/* 0x450C: f8 94        cli */
/* 0x450E: 00 91 3c 07  <unknown> */
/* 0x4512: 10 e0        ldi	r17, 0x0 */
/* 0x4514: 45 e4        ldi	r20, 0x45 */
/* 0x4516: 50 e0        ldi	r21, 0x0 */
/* 0x4518: 40 0f        add	r20, r16 */
/* 0x451A: 51 1f        adc	r21, r17 */
/* 0x451C: d5 d6        rcall	.+3498 */
/* 0x451E: c0 2e        mov	r12, r16 */
/* 0x4520: dd 24        clr	r13 */
/* 0x4522: d3 94        inc	r13 */
/* 0x4524: d3 d6        rcall	.+3494 */
/* 0x4526: 45 e4        ldi	r20, 0x45 */
/* 0x4528: 50 e0        ldi	r21, 0x0 */
/* 0x452A: 48 0f        add	r20, r24 */
/* 0x452C: 59 1f        adc	r21, r25 */
/* 0x452E: cc d6        rcall	.+3480 */
/* 0x4530: 00 23        tst	r16 */
/* 0x4532: 09 f0        breq	.+2 */
/* 0x4534: dd 24        clr	r13 */
/* 0x4536: 01 96 87 30  <unknown> */
/* 0x453A: 91 07        cpc	r25, r17 */
/* 0x453C: a0 f3        brlo	.-24 */
/* 0x453E: 78 94        sei */
/* 0x4540: dd 20        tst	r13 */
/* 0x4542: c1 f0        breq	.+48 */
/* 0x4544: 6c d5        rcall	.+2776 */
/* 0x4546: 0f 70        andi	r16, 0xf */
/* 0x4548: 04 30        cpi	r16, 0x4 */
/* 0x454A: 31 f4        brne	.+12 */
/* 0x454C: 10 93 3f 07  <unknown> */
/* 0x4550: a1 d1        rcall	.+834 */
/* 0x4552: 70 f0        brlo	.+28 */
/* 0x4554: 15 ab 0c c0  <unknown> */
/* 0x4558: 01 30        cpi	r16, 0x1 */
/* 0x455A: 51 f4        brne	.+20 */
/* 0x455C: 10 93 3f 07  <unknown> */
/* 0x4560: f5 01 05 a9  <unknown> */
/* 0x4564: 0a 95        dec	r16 */
/* 0x4566: 05 ab 0f 3f  <unknown> */
/* 0x456A: 11 f4        brne	.+4 */
/* 0x456C: 06 e0        ldi	r16, 0x6 */
/* 0x456E: 05 ab 10 93  <unknown> */
/* 0x4572: 3b 07        cpc	r19, r27 */
/* 0x4574: cc 20        tst	r12 */
/* 0x4576: 19 f4        brne	.+6 */
/* 0x4578: dd 20        tst	r13 */
/* 0x457A: 09 f4        brne	.+2 */
/* 0x457C: 3a cf        rjmp	.-396 */
/* 0x457E: 00 91 3f 07  <unknown> */
/* 0x4582: 10 91 35 07  <unknown> */
/* 0x4586: 20 91 3c 07  <unknown> */
/* 0x458A: 22 23        tst	r18 */
/* 0x458C: 91 f0        breq	.+36 */
/* 0x458E: 2a 95        dec	r18 */
/* 0x4590: a9 f0        breq	.+42 */
/* 0x4592: 2a 95        dec	r18 */
/* 0x4594: 09 f4        brne	.+2 */
/* 0x4596: 48 c0        rjmp	.+144 */
/* 0x4598: 2a 95        dec	r18 */
/* 0x459A: 09 f4        brne	.+2 */
/* 0x459C: 7f c0        rjmp	.+254 */
/* 0x459E: 2a 95        dec	r18 */
/* 0x45A0: 09 f4        brne	.+2 */
/* 0x45A2: 98 c0        rjmp	.+304 */
/* 0x45A4: 2a 95        dec	r18 */
/* 0x45A6: 09 f4        brne	.+2 */
/* 0x45A8: a6 c0        rjmp	.+332 */
/* 0x45AA: 2a 95        dec	r18 */
/* 0x45AC: 09 f4        brne	.+2 */
/* 0x45AE: bc c0        rjmp	.+376 */
/* 0x45B0: 1a cf        rjmp	.-460 */
/* 0x45B2: 00 23        tst	r16 */
/* 0x45B4: 19 f4        brne	.+6 */
/* 0x45B6: 03 eb        ldi	r16, 0xb3 */
/* 0x45B8: 18 e0        ldi	r17, 0x8 */
/* 0x45BA: 04 c0        rjmp	.+8 */
/* 0x45BC: 00 23        tst	r16 */
/* 0x45BE: 19 f4        brne	.+6 */
/* 0x45C0: 03 ef        ldi	r16, 0xf3 */
/* 0x45C2: 18 e0        ldi	r17, 0x8 */
/* 0x45C4: 41 d1        rcall	.+642 */
/* 0x45C6: 82 d6        rcall	.+3332 */
/* 0x45C8: 08 c0        rjmp	.+16 */
/* 0x45CA: 04 ee        ldi	r16, 0xe4 */
/* 0x45CC: 17 e0        ldi	r17, 0x7 */
/* 0x45CE: a3 d4        rcall	.+2374 */
/* 0x45D0: 01 96 84 30  <unknown> */
/* 0x45D4: 83 d6        rcall	.+3334 */
/* 0x45D6: 08 f0        brlo	.+2 */
/* 0x45D8: 06 cf        rjmp	.-500 */
/* 0x45DA: 91 d1        rcall	.+802 */
/* 0x45DC: 82 9b        sbis	0x10, 0x2 */
/* 0x45DE: 0c c0        rjmp	.+24 */
/* 0x45F8: 7f d1        rcall	.+766 */
/* 0x45FA: 7a d1        rcall	.+756 */
/* 0x45FC: 00 91 3c 07  <unknown> */
/* 0x4600: 14 e0        ldi	r17, 0x4 */
/* 0x4602: 01 9f 8c 01  <unknown> */
/* 0x4606: 00 0d        add	r16, r0 */
/* 0x4608: 11 1d        adc	r17, r1 */
/* 0x460A: f8 01 e9 5f  <unknown> */
/* 0x460E: f8 4f        sbci	r31, 0xf8 */
/* 0x4610: 20 81        ldd	r18, Z+0 */
/* 0x4612: 22 23        tst	r18 */
/* 0x4614: d1 f2        breq	.-76 */
/* 0x4616: 0e 94 6c 2c  <unknown> */
/* 0x461A: f8 01 e9 53  <unknown> */
/* 0x461E: f9 4f        sbci	r31, 0xf9 */
/* 0x4620: 00 81        ldd	r16, Z+0 */
/* 0x4622: 11 81        ldd	r17, Z+1 */
/* 0x4624: 02 d5        rcall	.+2564 */
/* 0x4626: d4 cf        rjmp	.-88 */
/* 0x4628: 11 23        tst	r17 */
/* 0x462A: 09 f4        brne	.+2 */
/* 0x462C: dc ce        rjmp	.-584 */
/* 0x462E: 00 23        tst	r16 */
/* 0x4630: 19 f4        brne	.+6 */
/* 0x4632: 03 e3        ldi	r16, 0x33 */
/* 0x4634: 19 e0        ldi	r17, 0x9 */
/* 0x4636: 08 d1        rcall	.+528 */
/* 0x4638: 49 d6        rcall	.+3218 */
/* 0x463A: 08 c0        rjmp	.+16 */
/* 0x463C: 04 ee        ldi	r16, 0xe4 */
/* 0x463E: 17 e0        ldi	r17, 0x7 */
/* 0x4640: 6a d4        rcall	.+2260 */
/* 0x4642: 01 96 84 30  <unknown> */
/* 0x4646: 4a d6        rcall	.+3220 */
/* 0x4648: 08 f0        brlo	.+2 */
/* 0x464A: cd ce        rjmp	.-614 */
/* 0x464C: 58 d1        rcall	.+688 */
/* 0x464E: 82 9b        sbis	0x10, 0x2 */
/* 0x4650: 0e c0        rjmp	.+28 */
/* 0x466E: 08 2f        mov	r16, r24 */
/* 0x4670: 09 2b        or	r16, r25 */
/* 0x4672: 11 e0        ldi	r17, 0x1 */
/* 0x4674: 11 f4        brne	.+4 */
/* 0x4676: 00 e0        ldi	r16, 0x0 */
/* 0x4678: 03 c0        rjmp	.+6 */
/* 0x467A: 06 e0        ldi	r16, 0x6 */
/* 0x467C: 3b d1        rcall	.+630 */
/* 0x467E: 0c 5f        subi	r16, 0xfc */
/* 0x4680: 37 d1        rcall	.+622 */
/* 0x4682: f5 01 e8 0f  <unknown> */
/* 0x4686: f9 1f        adc	r31, r25 */
/* 0x4688: 00 85        ldd	r16, Z+0 */
/* 0x468A: 00 23        tst	r16 */
/* 0x468C: b9 f2        breq	.-82 */
/* 0x468E: 2b d1        rcall	.+598 */
/* 0x4690: e9 53        subi	r30, 0x39 */
/* 0x4692: f9 4f        sbci	r31, 0xf9 */
/* 0x4694: 00 89        ldd	r16, Z+0 */
/* 0x4696: 11 89        ldd	r17, Z+1 */
/* 0x4698: c8 d4        rcall	.+2448 */
/* 0x469A: d3 cf        rjmp	.-90 */
/* 0x469C: 11 23        tst	r17 */
/* 0x469E: 09 f4        brne	.+2 */
/* 0x46A0: a2 ce        rjmp	.-700 */
/* 0x46A2: 10 e0        ldi	r17, 0x0 */
/* 0x46A4: 00 e0        ldi	r16, 0x0 */
/* 0x46A6: 5c d1        rcall	.+696 */
/* 0x46A8: 0c ee        ldi	r16, 0xec */
/* 0x46AA: 17 e0        ldi	r17, 0x7 */
/* 0x46AC: f4 d3        rcall	.+2024 */
/* 0x46AE: 4a d3        rcall	.+1684 */
/* 0x46B0: 23 d6        rcall	.+3142 */
/* 0x46B2: 02 0f        add	r16, r18 */
/* 0x46B4: 13 1f        adc	r17, r19 */
/* 0x46B6: 3c d6        rcall	.+3192 */
/* 0x46B8: 7c d3        rcall	.+1784 */
/* 0x46BA: 0b ef        ldi	r16, 0xfb */
/* 0x46BC: 17 e0        ldi	r17, 0x7 */
/* 0x46BE: 2b d4        rcall	.+2134 */
/* 0x46C0: 9f d3        rcall	.+1854 */
/* 0x46C2: 27 d4        rcall	.+2126 */
/* 0x46C4: 61 d3        rcall	.+1730 */
/* 0x46C6: 7a d3        rcall	.+1780 */
/* 0x46C8: 00 e0        ldi	r16, 0x0 */
/* 0x46CA: 18 e0        ldi	r17, 0x8 */
/* 0x46CC: 24 d4        rcall	.+2120 */
/* 0x46CE: 22 96 6c d3  <unknown> */
/* 0x46D2: 89 ce        rjmp	.-750 */
/* 0x46D4: 11 23        tst	r17 */
/* 0x46D6: 09 f4        brne	.+2 */
/* 0x46D8: 86 ce        rjmp	.-756 */
/* 0x46DA: f8 d5        rcall	.+3056 */
/* 0x46DC: 05 d6        rcall	.+3082 */
/* 0x46DE: 03 d1        rcall	.+518 */
/* 0x46E0: 23 d1        rcall	.+582 */
/* 0x46E2: c7 d0        rcall	.+398 */
/* 0x46E4: 08 e0        ldi	r16, 0x8 */
/* 0x46E6: 18 e0        ldi	r17, 0x8 */
/* 0x46E8: a4 d4        rcall	.+2376 */
/* 0x46EA: 01 96 82 30  <unknown> */
/* 0x46EE: f6 d5        rcall	.+3052 */
/* 0x46F0: 08 f0        brlo	.+2 */
/* 0x46F2: 79 ce        rjmp	.-782 */
/* 0x46F4: f3 cf        rjmp	.-26 */
/* 0x46F6: 11 23        tst	r17 */
/* 0x46F8: 09 f4        brne	.+2 */
/* 0x46FA: 75 ce        rjmp	.-790 */
/* 0x46FC: e7 d5        rcall	.+3022 */
/* 0x46FE: f4 d5        rcall	.+3048 */
/* 0x4700: 8c 01 0d d1  <unknown> */
/* 0x4704: d6 d3        rcall	.+1964 */
/* 0x4706: 9e d0        rcall	.+316 */
/* 0x4708: 8d d3        rcall	.+1818 */
/* 0x470A: 60 e8        ldi	r22, 0x80 */
/* 0x470C: 7a e3        ldi	r23, 0x3a */
/* 0x470E: 9a d0        rcall	.+308 */
/* 0x4710: 3a 93        st	-Y, r19 */
/* 0x4712: 2a 93        st	-Y, r18 */
/* 0x4714: ae d0        rcall	.+348 */
/* 0x4716: 09 e1        ldi	r16, 0x19 */
/* 0x4718: 18 e0        ldi	r17, 0x8 */
/* 0x471A: bd d3        rcall	.+1914 */
/* 0x471C: 01 96 82 30  <unknown> */
/* 0x4720: dd d5        rcall	.+3002 */
/* 0x4722: 08 f0        brlo	.+2 */
/* 0x4724: 60 ce        rjmp	.-832 */
/* 0x4726: eb cf        rjmp	.-42 */
/* 0x4728: 11 23        tst	r17 */
/* 0x472A: 09 f4        brne	.+2 */
/* 0x472C: 5c ce        rjmp	.-840 */
/* 0x472E: 88 24        clr	r8 */
/* 0x4730: 99 24        clr	r9 */
/* 0x4732: 43 e0        ldi	r20, 0x3 */
/* 0x4734: 84 01 0e 94  <unknown> */
/* 0x4738: d5 31        cpi	r29, 0x15 */
/* 0x473A: 40 e0        ldi	r20, 0x0 */
/* 0x473C: 50 e0        ldi	r21, 0x0 */
/* 0x473E: b0 d0        rcall	.+352 */
/* 0x4740: c8 01 d9 01  <unknown> */
/* 0x4744: 44 e0        ldi	r20, 0x4 */
/* 0x4746: 50 e0        ldi	r21, 0x0 */
/* 0x4748: 84 01 0e 94  <unknown> */
/* 0x474C: 6c 2c        mov	r6, r12 */
/* 0x474E: 0e 94 6c 2c  <unknown> */
/* 0x4752: 0e 94 6c 2c  <unknown> */
/* 0x4756: a4 d0        rcall	.+328 */
/* 0x4758: ac 01 bd 01  <unknown> */
/* 0x475C: 0e 94 4b 33  <unknown> */
/* 0x4760: a8 01 b9 01  <unknown> */
/* 0x4764: 00 e0        ldi	r16, 0x0 */
/* 0x4766: 10 e0        ldi	r17, 0x0 */
/* 0x4768: 20 e8        ldi	r18, 0x80 */
/* 0x476A: 3a e3        ldi	r19, 0x3a */
/* 0x476C: 6b d0        rcall	.+214 */
/* 0x476E: 28 01 39 01  <unknown> */
/* 0x4772: 84 01 d4 d0  <unknown> */
/* 0x4776: a2 01 b3 01  <unknown> */
/* 0x477A: 64 d0        rcall	.+200 */
/* 0x477C: ac 01 bd 01  <unknown> */
/* 0x4780: 0e 94 07 33  <unknown> */
/* 0x4784: 28 01 39 01  <unknown> */
/* 0x4788: 42 e1        ldi	r20, 0x12 */
/* 0x478A: 50 e0        ldi	r21, 0x0 */
/* 0x478C: 48 0d        add	r20, r8 */
/* 0x478E: 59 1d        adc	r21, r9 */
/* 0x4790: 9b d5        rcall	.+2870 */
/* 0x4792: 00 23        tst	r16 */
/* 0x4794: 59 f0        breq	.+22 */
/* 0x4796: 0a 95        dec	r16 */
/* 0x4798: 61 f0        breq	.+24 */
/* 0x479A: 02 50        subi	r16, 0x2 */
/* 0x479C: 81 f0        breq	.+32 */
/* 0x479E: 0a 95        dec	r16 */
/* 0x47A0: 89 f0        breq	.+34 */
/* 0x47A2: 0a 95        dec	r16 */
/* 0x47A4: 91 f0        breq	.+36 */
/* 0x47A6: 0a 95        dec	r16 */
/* 0x47A8: 99 f0        breq	.+38 */
/* 0x47AA: 06 c0        rjmp	.+12 */
/* 0x47AC: 80 e3        ldi	r24, 0x30 */
/* 0x47AE: 98 e0        ldi	r25, 0x8 */
/* 0x47B0: 11 c0        rjmp	.+34 */
/* 0x47B2: 8b e3        ldi	r24, 0x3b */
/* 0x47B4: 98 e0        ldi	r25, 0x8 */
/* 0x47B6: 0e c0        rjmp	.+28 */
/* 0x47B8: 86 e4        ldi	r24, 0x46 */
/* 0x47BA: 98 e0        ldi	r25, 0x8 */
/* 0x47BC: 0b c0        rjmp	.+22 */
/* 0x47BE: 81 e5        ldi	r24, 0x51 */
/* 0x47C0: 98 e0        ldi	r25, 0x8 */
/* 0x47C2: 08 c0        rjmp	.+16 */
/* 0x47C4: 8c e5        ldi	r24, 0x5c */
/* 0x47C6: 98 e0        ldi	r25, 0x8 */
/* 0x47C8: 05 c0        rjmp	.+10 */
/* 0x47CA: 87 e6        ldi	r24, 0x67 */
/* 0x47CC: 98 e0        ldi	r25, 0x8 */
/* 0x47CE: 02 c0        rjmp	.+4 */
/* 0x47D0: 82 e7        ldi	r24, 0x72 */
/* 0x47D2: 98 e0        ldi	r25, 0x8 */
/* 0x47D4: 18 2d        mov	r17, r8 */
/* 0x47D6: 89 d5        rcall	.+2834 */
/* 0x47D8: d4 01 11 96  <unknown> */
/* 0x47DC: 40 e2        ldi	r20, 0x20 */
/* 0x47DE: 5c eb        ldi	r21, 0xbc */
/* 0x47E0: 6e eb        ldi	r22, 0xbe */
/* 0x47E2: 7c e4        ldi	r23, 0x4c */
/* 0x47E4: 82 01 93 01  <unknown> */
/* 0x47E8: 2b d0        rcall	.+86 */
/* 0x47EA: 30 f0        brlo	.+12 */
/* 0x47EC: 47 e1        ldi	r20, 0x17 */
/* 0x47EE: 57 eb        ldi	r21, 0xb7 */
/* 0x47F0: 61 ed        ldi	r22, 0xd1 */
/* 0x47F2: 78 e3        ldi	r23, 0x38 */
/* 0x47F4: 23 d0        rcall	.+70 */
/* 0x47F6: 18 f4        brsh	.+6 */
/* 0x47F8: 8e d0        rcall	.+284 */
/* 0x47FA: 22 d0        rcall	.+68 */
/* 0x47FC: 88 f0        brlo	.+34 */
/* 0x47FE: 4f e7        ldi	r20, 0x7f */
/* 0x4800: 56 e9        ldi	r21, 0x96 */
/* 0x4802: 68 e1        ldi	r22, 0x18 */
/* 0x4804: 7b ec        ldi	r23, 0xcb */
/* 0x4806: 1a d0        rcall	.+52 */
/* 0x4808: 38 f0        brlo	.+14 */
/* 0x480A: 46 e1        ldi	r20, 0x16 */
/* 0x480C: 57 eb        ldi	r21, 0xb7 */
/* 0x480E: 61 ed        ldi	r22, 0xd1 */
/* 0x4810: 78 eb        ldi	r23, 0xb8 */
/* 0x4812: 16 d0        rcall	.+44 */
/* 0x4814: 08 f0        brlo	.+2 */
/* 0x4816: d0 cd        rjmp	.-1120 */
/* 0x4818: 7e d0        rcall	.+252 */
/* 0x481A: 10 d0        rcall	.+32 */
/* 0x481C: 08 f0        brlo	.+2 */
/* 0x481E: cc cd        rjmp	.-1128 */
/* 0x4820: 19 d0        rcall	.+50 */
/* 0x4822: 0d e7        ldi	r16, 0x7d */
/* 0x4824: 18 e0        ldi	r17, 0x8 */
/* 0x4826: 37 d3        rcall	.+1646 */
/* 0x4828: d4 cd        rjmp	.-1112 */
/* 0x482A: 00 e0        ldi	r16, 0x0 */
/* 0x482C: bb d0        rcall	.+374 */
/* 0x482E: 01 30        cpi	r16, 0x1 */
/* 0x4830: 09 f0        breq	.+2 */
/* 0x4832: f5 cd        rjmp	.-1046 */
/* 0x4834: 00 e0        ldi	r16, 0x0 */
/* 0x4836: 00 93 3a 07  <unknown> */
/* 0x483A: f1 cd        rjmp	.-1054 */
/* 0x483C: 0c 94 6a 34  <unknown> */
/* 0x4840: 0c 94 82 34  <unknown> */
/* 0x4844: 0c 94 68 33  <unknown> */
/* 0x4848: 0e 94 52 0f  <unknown> */
/* 0x484C: 01 e0        ldi	r16, 0x1 */
/* 0x484E: 00 93 3f 07  <unknown> */
/* 0x4852: 08 95        ret */
/* 0x4854: 7a 92        st	-Y, r7 */
/* 0x4856: 6a 92        st	-Y, r6 */
/* 0x4858: 5a 92        st	-Y, r5 */
/* 0x485A: 4a 92        st	-Y, r4 */
/* 0x485C: ba 93        st	-Y, r27 */
/* 0x485E: aa 93        st	-Y, r26 */
/* 0x4860: 08 95        ret */
/* 0x4862: e9 53        subi	r30, 0x39 */
/* 0x4864: f9 4f        sbci	r31, 0xf9 */
/* 0x4866: 00 83        std	Z+0, r16 */
/* 0x4868: 11 83        std	Z+1, r17 */
/* 0x486A: 08 95        ret */
/* 0x486C: 8d 01 0c 94  <unknown> */
/* 0x4870: cb 13        cpse	r28, r27 */
/* 0x4872: b3 d5        rcall	.+2918 */
/* 0x4874: fc 01 17 c5  <unknown> */
/* 0x4878: e1 e8        ldi	r30, 0x81 */
/* 0x487A: f6 e0        ldi	r31, 0x6 */
/* 0x487C: 00 81        ldd	r16, Z+0 */
/* 0x487E: 11 81        ldd	r17, Z+1 */
/* 0x4880: 22 81        ldd	r18, Z+2 */
/* 0x4882: 33 81        ldd	r19, Z+3 */
/* 0x4884: 44 81        ldd	r20, Z+4 */
/* 0x4886: 55 81        ldd	r21, Z+5 */
/* 0x4888: 66 81        ldd	r22, Z+6 */
/* 0x488A: 77 81        ldd	r23, Z+7 */
/* 0x488C: e7 e6        ldi	r30, 0x67 */
/* 0x488E: f6 e0        ldi	r31, 0x6 */
/* 0x4890: 0c 94 09 35  <unknown> */
/* 0x4894: f5 01 05 a9  <unknown> */
/* 0x4898: 03 95        inc	r16 */
/* 0x489A: 05 ab 07 30  <unknown> */
/* 0x489E: 08 95        ret */
/* 0x48A0: 40 0f        add	r20, r16 */
/* 0x48A2: 51 1f        adc	r21, r17 */
/* 0x48A4: 0c 94 8e 31  <unknown> */
/* 0x48A8: 9a 95        dec	r25 */
/* 0x48AA: f5 01 07 a9  <unknown> */
/* 0x48AE: 03 95        inc	r16 */
/* 0x48B0: 07 ab 00 32  <unknown> */
/* 0x48B4: 10 f0        brlo	.+4 */
/* 0x48B6: 00 e0        ldi	r16, 0x0 */
/* 0x48B8: 07 ab 20 e0  <unknown> */
/* 0x48BC: 30 e0        ldi	r19, 0x0 */
/* 0x48BE: 08 95        ret */
/* 0x48C0: 00 e0        ldi	r16, 0x0 */
/* 0x48C2: e0 91 3e 07  <unknown> */
/* 0x48C6: f0 e0        ldi	r31, 0x0 */
/* 0x48C8: e9 5f        subi	r30, 0xf9 */
/* 0x48CA: f8 4f        sbci	r31, 0xf8 */
/* 0x48CC: 00 83        std	Z+0, r16 */
/* 0x48CE: 08 95        ret */
/* 0x48D0: 88 e0        ldi	r24, 0x8 */
/* 0x48D2: 00 e0        ldi	r16, 0x0 */
/* 0x48D4: 08 83        std	Y+0, r16 */
/* 0x48D6: 31 e0        ldi	r19, 0x1 */
/* 0x48D8: 28 2f        mov	r18, r24 */
/* 0x48DA: 8e 01 85 d2  <unknown> */
/* 0x48DE: 83 95        inc	r24 */
/* 0x48E0: 8a 32        cpi	r24, 0x2a */
/* 0x48E2: b8 f3        brlo	.-18 */
/* 0x48E4: 08 95        ret */
/* 0x48E6: 8c 01 00 0f  <unknown> */
/* 0x48EA: 11 1f        rol	r17 */
/* 0x48EC: f8 01 08 95  <unknown> */
/* 0x48F0: 0c 94 70 0f  <unknown> */
/* 0x48F4: 0e 94 70 0f  <unknown> */
/* 0x48F8: 11 e0        ldi	r17, 0x1 */
/* 0x48FA: 08 2f        mov	r16, r24 */
/* 0x48FC: 08 95        ret */
/* 0x48FE: 8c 01 16 95  <unknown> */
/* 0x4902: 07 95        ror	r16 */
/* 0x4904: 10 2f        mov	r17, r16 */
/* 0x4906: 08 2f        mov	r16, r24 */
/* 0x4908: 00 fb        bst	r16, 0x0 */
/* 0x490A: 00 e0        ldi	r16, 0x0 */
/* 0x490C: 03 f9        bld	r16, 0x3 */
/* 0x490E: ee c4        rjmp	.+2524 */
/* 0x4910: 66 d2        rcall	.+1228 */
/* 0x4912: 0c 94 e9 08  <unknown> */
/* 0x4916: 86 d2        rcall	.+1292 */
/* 0x4918: 60 e0        ldi	r22, 0x0 */
/* 0x491A: 70 e0        ldi	r23, 0x0 */
/* 0x491C: 08 95        ret */
/* 0x4928: ed 58        subi	r30, 0x8d */
/* 0x492A: f9 4f        sbci	r31, 0xf9 */
/* 0x492C: 04 81        ldd	r16, Z+4 */
/* 0x492E: 15 81        ldd	r17, Z+5 */
/* 0x4930: 08 95        ret */
/* 0x4932: 20 e0        ldi	r18, 0x0 */
/* 0x4934: 30 e0        ldi	r19, 0x0 */
/* 0x4936: 0c 94 b3 32  <unknown> */
/* 0x493A: f8 94        cli */
/* 0x493C: 00 91 3e 07  <unknown> */
/* 0x4940: e1 d4        rcall	.+2498 */
/* 0x4942: 42 0f        add	r20, r18 */
/* 0x4944: 53 1f        adc	r21, r19 */
/* 0x4946: c0 d4        rcall	.+2432 */
/* 0x4948: 07 d0        rcall	.+14 */
/* 0x494A: 78 94        sei */
/* 0x494C: 2f 5f        subi	r18, 0xff */
/* 0x494E: 3f 4f        sbci	r19, 0xff */
/* 0x4950: 28 30        cpi	r18, 0x8 */
/* 0x4952: 00 e0        ldi	r16, 0x0 */
/* 0x4954: 30 07        cpc	r19, r16 */
/* 0x4956: 08 95        ret */
/* 0x4958: f9 01 ef 57  <unknown> */
/* 0x495C: f9 4f        sbci	r31, 0xf9 */
/* 0x495E: b6 cf        rjmp	.-148 */
/* 0x4960: c5 d4        rcall	.+2442 */
/* 0x4962: 20 91 29 07  <unknown> */
/* 0x4966: 30 91 28 07  <unknown> */
/* 0x496A: 40 91 27 07  <unknown> */
/* 0x496E: 04 2f        mov	r16, r20 */
/* 0x4970: 10 d0        rcall	.+32 */
/* 0x4972: 40 77        andi	r20, 0x70 */
/* 0x4974: 42 95        swap	r20 */
/* 0x4976: 50 e0        ldi	r21, 0x0 */
/* 0x4978: 0f d0        rcall	.+30 */
/* 0x497A: 03 2f        mov	r16, r19 */
/* 0x497C: 0a d0        rcall	.+20 */
/* 0x497E: 30 77        andi	r19, 0x70 */
/* 0x4980: 32 95        swap	r19 */
/* 0x4982: 43 2f        mov	r20, r19 */
/* 0x4984: 09 d0        rcall	.+18 */
/* 0x4986: 02 2f        mov	r16, r18 */
/* 0x4988: 04 d0        rcall	.+8 */
/* 0x498A: 20 73        andi	r18, 0x30 */
/* 0x498C: 22 95        swap	r18 */
/* 0x498E: 42 2f        mov	r20, r18 */
/* 0x4990: 03 c0        rjmp	.+6 */
/* 0x4992: 0f 70        andi	r16, 0xf */
/* 0x4994: 60 2f        mov	r22, r16 */
/* 0x4996: c1 cf        rjmp	.-126 */
/* 0x4998: 0a e0        ldi	r16, 0xa */
/* 0x499A: 1c d2        rcall	.+1080 */
/* 0x499C: 6c d4        rcall	.+2264 */
/* 0x499E: 7a 93        st	-Y, r23 */
/* 0x49A0: 6a 93        st	-Y, r22 */
/* 0x49A2: 08 95        ret */
/* 0x49A4: 05 d5        rcall	.+2570 */
/* 0x49A6: 59 f0        breq	.+22 */
/* 0x49A8: 0e 94 be 10  <unknown> */
/* 0x49AC: fd 01 00 a7  <unknown> */
/* 0x49B0: 11 a7 4c e0  <unknown> */
/* 0x49B4: 28 e1        ldi	r18, 0x18 */
/* 0x49B6: 3a e0        ldi	r19, 0xa */
/* 0x49B8: 0e 94 f5 10  <unknown> */
/* 0x49BC: 77 c0        rjmp	.+238 */
/* 0x49BE: 78 d0        rcall	.+240 */
/* 0x49C0: 0e 94 6f 11  <unknown> */
/* 0x49C4: 00 23        tst	r16 */
/* 0x49C6: 74 d0        rcall	.+232 */
/* 0x49C8: 99 f5        brne	.+102 */
/* 0x49CA: 0e 94 31 11  <unknown> */
/* 0x49CE: ea e0        ldi	r30, 0xa */
/* 0x49D0: fc e0        ldi	r31, 0xc */
/* 0x49D2: 0c 94 93 34  <unknown> */
/* 0x49E6: 00 e0        ldi	r16, 0x0 */
/* 0x49E8: 62 c0        rjmp	.+196 */
/* 0x4A30: 20 91 39 07  <unknown> */
/* 0x4A34: 2f 70        andi	r18, 0xf */
/* 0x4A36: 69 f0        breq	.+26 */
/* 0x4A38: 2a 95        dec	r18 */
/* 0x4A3A: 29 f0        breq	.+10 */
/* 0x4A3C: 23 50        subi	r18, 0x3 */
/* 0x4A3E: 39 f0        breq	.+14 */
/* 0x4A40: 2a 95        dec	r18 */
/* 0x4A42: 91 f1        breq	.+100 */
/* 0x4A44: d0 cf        rjmp	.-96 */
/* 0x4A46: 2f ef        ldi	r18, 0xff */
/* 0x4A48: 0e 94 fa 10  <unknown> */
/* 0x4A4C: cc cf        rjmp	.-104 */
/* 0x4A4E: 21 e0        ldi	r18, 0x1 */
/* 0x4A50: fb cf        rjmp	.-10 */
/* 0x4A52: 0e 94 31 11  <unknown> */
/* 0x4A56: e6 e2        ldi	r30, 0x26 */
/* 0x4A58: fc e0        ldi	r31, 0xc */
/* 0x4A5A: 0c 94 93 34  <unknown> */
/* 0x4AA8: 0e 94 c9 10  <unknown> */
/* 0x4AAC: 01 e0        ldi	r16, 0x1 */
/* 0x4AAE: 7d c4        rjmp	.+2298 */
/* 0x4AB0: fd 01 00 a5  <unknown> */
/* 0x4AB4: 11 a5 08 95  <unknown> */
/* 0x4AB8: 0e 94 ee 34  <unknown> */
/* 0x4ABC: a2 97 00 23  <unknown> */
/* 0x4AC0: 09 f0        breq	.+2 */
/* 0x4AC2: ab d2        rcall	.+1366 */
/* 0x4AC4: a7 e0        ldi	r26, 0x7 */
/* 0x4AC6: b7 e0        ldi	r27, 0x7 */
/* 0x4AC8: 90 91 39 07  <unknown> */
/* 0x4ACC: 9f 70        andi	r25, 0xf */
/* 0x4ACE: 92 30        cpi	r25, 0x2 */
/* 0x4AD0: 21 f4        brne	.+8 */
/* 0x4AD2: fd 01 01 ad  <unknown> */
/* 0x4AD6: 0a 95        dec	r16 */
/* 0x4AD8: 05 c0        rjmp	.+10 */
/* 0x4ADA: 93 30        cpi	r25, 0x3 */
/* 0x4ADC: 21 f4        brne	.+8 */
/* 0x4ADE: fd 01 01 ad  <unknown> */
/* 0x4AE2: 03 95        inc	r16 */
/* 0x4AE4: 01 af 00 91  <unknown> */
/* 0x4AE8: 40 07        cpc	r20, r16 */
/* 0x4AEA: 07 30        cpi	r16, 0x7 */
/* 0x4AEC: 38 f0        brlo	.+14 */
/* 0x4AEE: 0f 3f        cpi	r16, 0xff */
/* 0x4AF0: 11 f0        breq	.+4 */
/* 0x4AF2: 00 e0        ldi	r16, 0x0 */
/* 0x4AF4: 01 c0        rjmp	.+2 */
/* 0x4AF6: 06 e0        ldi	r16, 0x6 */
/* 0x4AF8: 00 93 40 07  <unknown> */
/* 0x4AFC: 42 d1        rcall	.+644 */
/* 0x4AFE: 29 f4        brne	.+10 */
/* 0x4B00: 91 30        cpi	r25, 0x1 */
/* 0x4B02: 19 f0        breq	.+6 */
/* 0x4B04: 94 30        cpi	r25, 0x4 */
/* 0x4B06: 09 f0        breq	.+2 */
/* 0x4B08: 0c c1        rjmp	.+536 */
/* 0x4B0A: 00 91 40 07  <unknown> */
/* 0x4B0E: 00 23        tst	r16 */
/* 0x4B10: 81 f0        breq	.+32 */
/* 0x4B12: 0a 95        dec	r16 */
/* 0x4B14: 09 f1        breq	.+66 */
/* 0x4B16: 0a 95        dec	r16 */
/* 0x4B18: 81 f1        breq	.+96 */
/* 0x4B1A: 0a 95        dec	r16 */
/* 0x4B1C: f9 f1        breq	.+126 */
/* 0x4B1E: 0a 95        dec	r16 */
/* 0x4B20: 09 f4        brne	.+2 */
/* 0x4B22: 52 c0        rjmp	.+164 */
/* 0x4B24: 0a 95        dec	r16 */
/* 0x4B26: 09 f4        brne	.+2 */
/* 0x4B28: 61 c0        rjmp	.+194 */
/* 0x4B2A: 0a 95        dec	r16 */
/* 0x4B2C: 09 f4        brne	.+2 */
/* 0x4B2E: 7d c0        rjmp	.+250 */
/* 0x4B30: 98 c0        rjmp	.+304 */
/* 0x4B32: 40 90 29 07  <unknown> */
/* 0x4B36: 0c d1        rcall	.+536 */
/* 0x4B38: 29 f4        brne	.+10 */
/* 0x4B3A: 83 95        inc	r24 */
/* 0x4B3C: 88 31        cpi	r24, 0x18 */
/* 0x4B3E: 40 f0        brlo	.+16 */
/* 0x4B40: 80 e0        ldi	r24, 0x0 */
/* 0x4B42: 06 c0        rjmp	.+12 */
/* 0x4B44: 94 30        cpi	r25, 0x4 */
/* 0x4B46: 21 f4        brne	.+8 */
/* 0x4B48: 8a 95        dec	r24 */
/* 0x4B4A: 8f 3f        cpi	r24, 0xff */
/* 0x4B4C: 09 f4        brne	.+2 */
/* 0x4B4E: 87 e1        ldi	r24, 0x17 */
/* 0x4B50: 10 d1        rcall	.+544 */
/* 0x4B52: 40 92 29 07  <unknown> */
/* 0x4B56: 85 c0        rjmp	.+266 */
/* 0x4B58: 40 90 28 07  <unknown> */
/* 0x4B5C: ee d0        rcall	.+476 */
/* 0x4B5E: fc d0        rcall	.+504 */
/* 0x4B60: 29 f4        brne	.+10 */
/* 0x4B62: 83 95        inc	r24 */
/* 0x4B64: 8c 33        cpi	r24, 0x3c */
/* 0x4B66: 28 f0        brlo	.+10 */
/* 0x4B68: 80 e0        ldi	r24, 0x0 */
/* 0x4B6A: 03 c0        rjmp	.+6 */
/* 0x4B6C: 94 30        cpi	r25, 0x4 */
/* 0x4B6E: 09 f4        brne	.+2 */
/* 0x4B70: 11 d1        rcall	.+546 */
/* 0x4B72: 3c d1        rcall	.+632 */
/* 0x4B74: 40 92 28 07  <unknown> */
/* 0x4B78: 74 c0        rjmp	.+232 */
/* 0x4B7A: 40 90 27 07  <unknown> */
/* 0x4B7E: dd d0        rcall	.+442 */
/* 0x4B80: eb d0        rcall	.+470 */
/* 0x4B82: 29 f4        brne	.+10 */
/* 0x4B84: 83 95        inc	r24 */
/* 0x4B86: 8c 33        cpi	r24, 0x3c */
/* 0x4B88: 28 f0        brlo	.+10 */
/* 0x4B8A: 80 e0        ldi	r24, 0x0 */
/* 0x4B8C: 03 c0        rjmp	.+6 */
/* 0x4B8E: 94 30        cpi	r25, 0x4 */
/* 0x4B90: 09 f4        brne	.+2 */
/* 0x4B92: 00 d1        rcall	.+512 */
/* 0x4B94: 2b d1        rcall	.+598 */
/* 0x4B96: 40 92 27 07  <unknown> */
/* 0x4B9A: 63 c0        rjmp	.+198 */
/* 0x4B9C: 00 91 2a 07  <unknown> */
/* 0x4BA0: 80 2f        mov	r24, r16 */
/* 0x4BA2: 87 70        andi	r24, 0x7 */
/* 0x4BA4: 91 30        cpi	r25, 0x1 */
/* 0x4BA6: 29 f4        brne	.+10 */
/* 0x4BA8: 83 95        inc	r24 */
/* 0x4BAA: 88 30        cpi	r24, 0x8 */
/* 0x4BAC: 38 f0        brlo	.+14 */
/* 0x4BAE: 81 e0        ldi	r24, 0x1 */
/* 0x4BB0: 05 c0        rjmp	.+10 */
/* 0x4BB2: 94 30        cpi	r25, 0x4 */
/* 0x4BB4: 19 f4        brne	.+6 */
/* 0x4BB6: 8a 95        dec	r24 */
/* 0x4BB8: 09 f4        brne	.+2 */
/* 0x4BBA: 87 e0        ldi	r24, 0x7 */
/* 0x4BBC: 08 7f        andi	r16, 0xf8 */
/* 0x4BBE: 87 70        andi	r24, 0x7 */
/* 0x4BC0: 08 2b        or	r16, r24 */
/* 0x4BC2: 00 93 2a 07  <unknown> */
/* 0x4BC6: 4d c0        rjmp	.+154 */
/* 0x4BC8: 40 90 2b 07  <unknown> */
/* 0x4BCC: c1 d0        rcall	.+386 */
/* 0x4BCE: 29 f4        brne	.+10 */
/* 0x4BD0: 83 95        inc	r24 */
/* 0x4BD2: 80 32        cpi	r24, 0x20 */
/* 0x4BD4: 38 f0        brlo	.+14 */
/* 0x4BD6: 81 e0        ldi	r24, 0x1 */
/* 0x4BD8: 05 c0        rjmp	.+10 */
/* 0x4BDA: 94 30        cpi	r25, 0x4 */
/* 0x4BDC: 19 f4        brne	.+6 */
/* 0x4BDE: 8a 95        dec	r24 */
/* 0x4BE0: 09 f4        brne	.+2 */
/* 0x4BE2: 8f e1        ldi	r24, 0x1f */
/* 0x4BE4: c6 d0        rcall	.+396 */
/* 0x4BE6: 40 92 2b 07  <unknown> */
/* 0x4BEA: 3b c0        rjmp	.+118 */
/* 0x4BEC: 40 90 2c 07  <unknown> */
/* 0x4BF0: 84 2d        mov	r24, r4 */
/* 0x4BF2: 8f 70        andi	r24, 0xf */
/* 0x4BF4: 14 2d        mov	r17, r4 */
/* 0x4BF6: 14 fb        bst	r17, 0x4 */
/* 0x4BF8: 10 e0        ldi	r17, 0x0 */
/* 0x4BFA: 10 f9        bld	r17, 0x0 */
/* 0x4BFC: bf d0        rcall	.+382 */
/* 0x4BFE: 29 f4        brne	.+10 */
/* 0x4C00: 83 95        inc	r24 */
/* 0x4C02: 8d 30        cpi	r24, 0xd */
/* 0x4C04: 38 f0        brlo	.+14 */
/* 0x4C06: 81 e0        ldi	r24, 0x1 */
/* 0x4C08: 05 c0        rjmp	.+10 */
/* 0x4C0A: 94 30        cpi	r25, 0x4 */
/* 0x4C0C: 19 f4        brne	.+6 */
/* 0x4C0E: 8a 95        dec	r24 */
/* 0x4C10: 09 f4        brne	.+2 */
/* 0x4C12: 8c e0        ldi	r24, 0xc */
/* 0x4C14: 00 ee        ldi	r16, 0xe0 */
/* 0x4C16: 40 22        and	r4, r16 */
/* 0x4C18: a5 d0        rcall	.+330 */
/* 0x4C1A: 4f 70        andi	r20, 0xf */
/* 0x4C1C: 44 2a        or	r4, r20 */
/* 0x4C1E: a6 d0        rcall	.+332 */
/* 0x4C20: 00 71        andi	r16, 0x10 */
/* 0x4C22: 40 2a        or	r4, r16 */
/* 0x4C24: 40 92 2c 07  <unknown> */
/* 0x4C28: 1c c0        rjmp	.+56 */
/* 0x4C2A: 10 91 2d 07  <unknown> */
/* 0x4C2E: 81 2f        mov	r24, r17 */
/* 0x4C30: 8f 70        andi	r24, 0xf */
/* 0x4C32: 12 95        swap	r17 */
/* 0x4C34: 1f 70        andi	r17, 0xf */
/* 0x4C36: a2 d0        rcall	.+324 */
/* 0x4C38: 29 f4        brne	.+10 */
/* 0x4C3A: 83 95        inc	r24 */
/* 0x4C3C: 84 36        cpi	r24, 0x64 */
/* 0x4C3E: 40 f0        brlo	.+16 */
/* 0x4C40: 80 e0        ldi	r24, 0x0 */
/* 0x4C42: 06 c0        rjmp	.+12 */
/* 0x4C44: 94 30        cpi	r25, 0x4 */
/* 0x4C46: 21 f4        brne	.+8 */
/* 0x4C48: 8a 95        dec	r24 */
/* 0x4C4A: 8f 3f        cpi	r24, 0xff */
/* 0x4C4C: 09 f4        brne	.+2 */
/* 0x4C4E: 83 e6        ldi	r24, 0x63 */
/* 0x4C50: 89 d0        rcall	.+274 */
/* 0x4C52: 44 2e        mov	r4, r20 */
/* 0x4C54: 0f e0        ldi	r16, 0xf */
/* 0x4C56: 40 22        and	r4, r16 */
/* 0x4C58: 89 d0        rcall	.+274 */
/* 0x4C5A: 00 7f        andi	r16, 0xf0 */
/* 0x4C5C: 40 2a        or	r4, r16 */
/* 0x4C5E: 40 92 2d 07  <unknown> */
/* 0x4C62: 94 30        cpi	r25, 0x4 */
/* 0x4C64: 11 f0        breq	.+4 */
/* 0x4C66: 91 30        cpi	r25, 0x1 */
/* 0x4C68: 09 f4        brne	.+2 */
/* 0x4C6A: b7 d0        rcall	.+366 */
/* 0x4C6C: 7a de        rcall	.-780 */
/* 0x4C6E: 2c ee        ldi	r18, 0xec */
/* 0x4C70: 37 e0        ldi	r19, 0x7 */
/* 0x4C72: 8e 01 09 5e  <unknown> */
/* 0x4C76: 5e d0        rcall	.+188 */
/* 0x4C78: 26 96 64 d0  <unknown> */
/* 0x4C7C: 3f d3        rcall	.+1662 */
/* 0x4C7E: 8e 01 06 5e  <unknown> */
/* 0x4C82: 58 d0        rcall	.+176 */
/* 0x4C84: 96 d0        rcall	.+300 */
/* 0x4C86: 2b ef        ldi	r18, 0xfb */
/* 0x4C88: 37 e0        ldi	r19, 0x7 */
/* 0x4C8A: 8e 01 0e 5f  <unknown> */
/* 0x4C8E: 52 d0        rcall	.+164 */
/* 0x4C90: b7 d0        rcall	.+366 */
/* 0x4C92: 20 0f        add	r18, r16 */
/* 0x4C94: 31 1f        adc	r19, r17 */
/* 0x4C96: 8e 01 0d 5f  <unknown> */
/* 0x4C9A: 4c d0        rcall	.+152 */
/* 0x4C9C: 75 d0        rcall	.+234 */
/* 0x4C9E: 8e d0        rcall	.+284 */
/* 0x4CA0: 20 e0        ldi	r18, 0x0 */
/* 0x4CA2: 38 e0        ldi	r19, 0x8 */
/* 0x4CA4: 8e 01 03 5f  <unknown> */
/* 0x4CA8: 45 d0        rcall	.+138 */
/* 0x4CAA: 22 96 82 99  <unknown> */
/* 0x4CAE: 2e c0        rjmp	.+92 */
/* 0x4D0C: 08 d1        rcall	.+528 */
/* 0x4D0E: 8e 01 0f 5e  <unknown> */
/* 0x4D12: 1f 4f        sbci	r17, 0xff */
/* 0x4D14: 0e 94 5d 35  <unknown> */
/* 0x4D18: 0c d3        rcall	.+1560 */
/* 0x4D1A: 8e 01 0e 94  <unknown> */
/* 0x4D1E: 5d 35        cpi	r21, 0x5d */
/* 0x4D20: 44 d0        rcall	.+136 */
/* 0x4D22: f4 d0        rcall	.+488 */
/* 0x4D24: 11 f4        brne	.+4 */
/* 0x4D26: 01 e0        ldi	r16, 0x1 */
/* 0x4D28: 01 c0        rjmp	.+2 */
/* 0x4D2A: 00 e0        ldi	r16, 0x0 */
/* 0x4D2C: a2 96 e5 e0  <unknown> */
/* 0x4D30: 0c 94 ff 34  <unknown> */
/* 0x4D34: 1f 4f        sbci	r17, 0xff */
/* 0x4D36: 0c 94 b5 35  <unknown> */
/* 0x4D3A: 84 2d        mov	r24, r4 */
/* 0x4D3C: 8f 70        andi	r24, 0xf */
/* 0x4D3E: 04 2d        mov	r16, r4 */
/* 0x4D40: 00 77        andi	r16, 0x70 */
/* 0x4D42: 08 95        ret */
/* 0x4D44: 28 e5        ldi	r18, 0x58 */
/* 0x4D46: 3b e0        ldi	r19, 0xb */
/* 0x4D48: 00 91 2a 07  <unknown> */
/* 0x4D4C: 07 70        andi	r16, 0x7 */
/* 0x4D4E: 08 95        ret */
/* 0x4D50: 84 2d        mov	r24, r4 */
/* 0x4D52: 8f 70        andi	r24, 0xf */
/* 0x4D54: 04 2d        mov	r16, r4 */
/* 0x4D56: 00 73        andi	r16, 0x30 */
/* 0x4D58: 02 95        swap	r16 */
/* 0x4D5A: 1a e0        ldi	r17, 0xa */
/* 0x4D5C: 01 9f 80 0d  <unknown> */
/* 0x4D60: 91 30        cpi	r25, 0x1 */
/* 0x4D62: 08 95        ret */
/* 0x4D64: 4a e0        ldi	r20, 0xa */
/* 0x4D66: 08 2f        mov	r16, r24 */
/* 0x4D68: 0c 94 bf 31  <unknown> */
/* 0x4D6C: fb df        rcall	.-10 */
/* 0x4D6E: 02 95        swap	r16 */
/* 0x4D70: 08 95        ret */
/* 0x4D72: 00 ec        ldi	r16, 0xc0 */
/* 0x4D74: 3f d0        rcall	.+126 */
/* 0x4D76: 00 73        andi	r16, 0x30 */
/* 0x4D78: 40 2a        or	r4, r16 */
/* 0x4D7A: 08 95        ret */
/* 0x4D7C: 0a e0        ldi	r16, 0xa */
/* 0x4D7E: 10 9f ee cf  <unknown> */
/* 0x4D82: 00 91 35 07  <unknown> */
/* 0x4D86: ea c5        rjmp	.+3028 */
/* 0x4D88: 40 91 2d 07  <unknown> */
/* 0x4D8C: 1e d0        rcall	.+60 */
/* 0x4D8E: 42 95        swap	r20 */
/* 0x4D90: 4f 70        andi	r20, 0xf */
/* 0x4D92: 08 95        ret */
/* 0x4D94: 8a 95        dec	r24 */
/* 0x4D96: 8f 3f        cpi	r24, 0xff */
/* 0x4D98: 09 f4        brne	.+2 */
/* 0x4D9A: 8b e3        ldi	r24, 0x3b */
/* 0x4D9C: 08 95        ret */
/* 0x4DAA: 00 e0        ldi	r16, 0x0 */
/* 0x4DAC: 00 93 35 07  <unknown> */
/* 0x4DB0: 08 95        ret */
/* 0x4DB2: 40 91 2b 07  <unknown> */
/* 0x4DB6: 09 d0        rcall	.+18 */
/* 0x4DB8: 40 73        andi	r20, 0x30 */
/* 0x4DBA: 42 95        swap	r20 */
/* 0x4DBC: 50 e0        ldi	r21, 0x0 */
/* 0x4DBE: 09 d0        rcall	.+18 */
/* 0x4DC0: 20 0f        add	r18, r16 */
/* 0x4DC2: 31 1f        adc	r19, r17 */
/* 0x4DC4: 3a 93        st	-Y, r19 */
/* 0x4DC6: 2a 93        st	-Y, r18 */
/* 0x4DC8: 08 95        ret */
/* 0x4DCA: 04 2f        mov	r16, r20 */
/* 0x4DCC: 0f 70        andi	r16, 0xf */
/* 0x4DCE: 20 2f        mov	r18, r16 */
/* 0x4DD0: 75 cd        rjmp	.-1302 */
/* 0x4DD2: 0a e0        ldi	r16, 0xa */
/* 0x4DD4: 10 e0        ldi	r17, 0x0 */
/* 0x4DD6: 0c 94 cd 31  <unknown> */
/* 0x4DDA: 01 d0        rcall	.+2 */
/* 0x4DDC: 05 c0        rjmp	.+10 */
/* 0x4DDE: 38 e0        ldi	r19, 0x8 */
/* 0x4DE0: 20 e0        ldi	r18, 0x0 */
/* 0x4DE2: 07 e2        ldi	r16, 0x27 */
/* 0x4DE4: 17 e0        ldi	r17, 0x7 */
/* 0x4DE6: 08 95        ret */
/* 0x4DE8: 0c 94 fa 08  <unknown> */
/* 0x4DEC: 00 e8        ldi	r16, 0x80 */
/* 0x4DEE: 02 d0        rcall	.+4 */
/* 0x4DF0: 00 77        andi	r16, 0x70 */
/* 0x4DF2: c2 cf        rjmp	.-124 */
/* 0x4DF4: 40 22        and	r4, r16 */
/* 0x4DF6: b6 df        rcall	.-148 */
/* 0x4DF8: 4f 70        andi	r20, 0xf */
/* 0x4DFA: 44 2a        or	r4, r20 */
/* 0x4DFC: b3 df        rcall	.-154 */
/* 0x4DFE: b7 cf        rjmp	.-146 */
/* 0x4E00: 22 96 2b ee  <unknown> */
/* 0x4E04: 3a e0        ldi	r19, 0xa */
/* 0x4E06: 60 91 2c 07  <unknown> */
/* 0x4E0A: 6f 70        andi	r22, 0xf */
/* 0x4E0C: 70 e0        ldi	r23, 0x0 */
/* 0x4E0E: 40 91 2c 07  <unknown> */
/* 0x4E12: 44 fb        bst	r20, 0x4 */
/* 0x4E14: 07 d0        rcall	.+14 */
/* 0x4E16: 40 f9        bld	r20, 0x0 */
/* 0x4E18: dc df        rcall	.-72 */
/* 0x4E1A: 2d d2        rcall	.+1114 */
/* 0x4E1C: 09 e0        ldi	r16, 0x9 */
/* 0x4E1E: 10 e0        ldi	r17, 0x0 */
/* 0x4E20: ab 01 d9 cf  <unknown> */
/* 0x4E24: 40 e0        ldi	r20, 0x0 */
/* 0x4E26: 50 e0        ldi	r21, 0x0 */
/* 0x4E28: 08 95        ret */
/* 0x4E96: 3f d0        rcall	.+126 */
/* 0x4E98: 26 96 08 95  <unknown> */
/* 0x4E9C: 4a dd        rcall	.-1388 */
/* 0x4E9E: 09 d0        rcall	.+18 */
/* 0x4EA0: 0e 94 68 33  <unknown> */
/* 0x4EA4: 40 e0        ldi	r20, 0x0 */
/* 0x4EA6: 50 ec        ldi	r21, 0xc0 */
/* 0x4EA8: 6f e7        ldi	r22, 0x7f */
/* 0x4EAA: 74 e4        ldi	r23, 0x44 */
/* 0x4EAC: 0e 94 e1 33  <unknown> */
/* 0x4EB0: 9a c5        rjmp	.+2868 */
/* 0x4EB2: b8 df        rcall	.-144 */
/* 0x4EB4: 60 ea        ldi	r22, 0xa0 */
/* 0x4EB6: 70 e4        ldi	r23, 0x40 */
/* 0x4EB8: 08 95        ret */
/* 0x4F0C: 88 d0        rcall	.+272 */
/* 0x4F0E: 05 30        cpi	r16, 0x5 */
/* 0x4F10: 08 95        ret */
/* 0x4F12: 02 0f        add	r16, r18 */
/* 0x4F14: 13 1f        adc	r17, r19 */
/* 0x4F16: 0c 94 70 35  <unknown> */
/* 0x4F1E: 10 e0        ldi	r17, 0x0 */
/* 0x4F20: e4 c1        rjmp	.+968 */
/* 0x501A: 0c 94 43 0f  <unknown> */
/* 0x501E: 00 91 39 07  <unknown> */
/* 0x5022: 08 95        ret */
/* 0x502A: 28 d1        rcall	.+592 */
/* 0x502C: dc d4        rcall	.+2488 */
/* 0x502E: 0c ed        ldi	r16, 0xdc */
/* 0x5030: 17 e0        ldi	r17, 0x7 */
/* 0x5032: 71 df        rcall	.-286 */
/* 0x5034: 24 96 08 95  <unknown> */
/* 0x5038: 10 e0        ldi	r17, 0x0 */
/* 0x503A: cf c1        rjmp	.+926 */
/* 0x503C: 10 e0        ldi	r17, 0x0 */
/* 0x503E: 94 c8        rjmp	.-3800 */
/* 0x5040: 07 e4        ldi	r16, 0x47 */
/* 0x5042: 17 e0        ldi	r17, 0x7 */
/* 0x5044: 08 95        ret */
/* 0x5276: 60 0f        add	r22, r16 */
/* 0x5278: 71 1f        adc	r23, r17 */
/* 0x527A: 08 95        ret */
/* 0x527C: 21 2f        mov	r18, r17 */
/* 0x527E: 22 0f        lsl	r18 */
/* 0x5280: 22 0b        sbc	r18, r18 */
/* 0x5282: 32 2f        mov	r19, r18 */
/* 0x5284: 0e 94 a8 32  <unknown> */
/* 0x5288: cd dd        rcall	.-1126 */
/* 0x528A: 68 ec        ldi	r22, 0xc8 */
/* 0x528C: 72 e4        ldi	r23, 0x42 */
/* 0x528E: 0c 94 e1 33  <unknown> */
/* 0x52A0: 0c 94 ef 34  <unknown> */
/* 0x52AE: 0c 94 86 0a  <unknown> */
/* 0x52B2: 0e 94 6d 10  <unknown> */
/* 0x52B6: 00 93 39 07  <unknown> */
/* 0x52BA: 08 95        ret */
/* 0x52BC: 0e 94 9f 09  <unknown> */
/* 0x52C0: 0c 94 ad 09  <unknown> */
/* 0x52C4: 4c 5f        subi	r20, 0xfc */
/* 0x52C6: 5f 4f        sbci	r21, 0xff */
/* 0x52C8: 0c 94 86 31  <unknown> */
/* 0x52CC: 80 e0        ldi	r24, 0x0 */
/* 0x52CE: 90 e0        ldi	r25, 0x0 */
/* 0x52D0: 08 95        ret */
/* 0x52D2: 8e 01 0c 94  <unknown> */
/* 0x52D6: f2 09        sbc	r31, r2 */
/* 0x52D8: 01 96 88 30  <unknown> */
/* 0x52DC: 00 e0        ldi	r16, 0x0 */
/* 0x52DE: 90 07        cpc	r25, r16 */
/* 0x52E0: 08 95        ret */
/* 0x52E2: 19 de        rcall	.-974 */
/* 0x52E4: 11 e0        ldi	r17, 0x1 */
/* 0x52E6: 08 95        ret */
/* 0x52E8: 18 2f        mov	r17, r24 */
/* 0x52EA: 00 e0        ldi	r16, 0x0 */
/* 0x52EC: 0c 94 29 0f  <unknown> */
/* 0x52F8: 10 e0        ldi	r17, 0x0 */
/* 0x52FA: 0b c0        rjmp	.+22 */
/* 0x52FC: 09 d0        rcall	.+18 */
/* 0x52FE: 20 0f        add	r18, r16 */
/* 0x5300: 31 1f        adc	r19, r17 */
/* 0x5302: 08 95        ret */
/* 0x5304: 05 d0        rcall	.+10 */
/* 0x5306: 40 ef        ldi	r20, 0xf0 */
/* 0x5308: 52 e0        ldi	r21, 0x2 */
/* 0x530A: 40 0f        add	r20, r16 */
/* 0x530C: 51 1f        adc	r21, r17 */
/* 0x530E: 08 95        ret */
/* 0x5310: 10 e0        ldi	r17, 0x0 */
/* 0x5312: 43 e0        ldi	r20, 0x3 */
/* 0x5314: 0c 94 d5 31  <unknown> */
/* 0x532C: 01 e0        ldi	r16, 0x1 */
/* 0x532E: de cf        rjmp	.-68 */
/* 0x5330: f2 dd        rcall	.-1052 */
/* 0x5332: 11 e0        ldi	r17, 0x1 */
/* 0x5334: da cf        rjmp	.-76 */
/* 0x53AA: a9 91        ld	r26, Y+ */
/* 0x53AC: b9 91        ld	r27, Y+ */
/* 0x53AE: 08 95        ret */
/* 0x53B0: ba 93        st	-Y, r27 */
/* 0x53B2: aa 93        st	-Y, r26 */
/* 0x53B4: a7 e0        ldi	r26, 0x7 */
/* 0x53B6: b7 e0        ldi	r27, 0x7 */
/* 0x53B8: d1 c2        rjmp	.+1442 */
/* 0x53D4: 10 e0        ldi	r17, 0x0 */
/* 0x53D6: 1a 93        st	-Y, r17 */
/* 0x53D8: 1a 93        st	-Y, r17 */
/* 0x53DA: 1a 93        st	-Y, r17 */
/* 0x53DC: 0a 93        st	-Y, r16 */
/* 0x53DE: 08 95        ret */
/* 0x53E0: 4d ee        ldi	r20, 0xed */
/* 0x53E2: 52 e0        ldi	r21, 0x2 */
/* 0x53E4: 0c 94 a0 31  <unknown> */
/* 0x53E8: 4e ee        ldi	r20, 0xee */
/* 0x53EA: 52 e0        ldi	r21, 0x2 */
/* 0x53EC: 6d df        rcall	.-294 */
/* 0x53EE: 00 95        com	r16 */
/* 0x53F0: 08 bd        out	0x28, r16 */
/* 0x53F2: 08 95        ret */
/* 0x5498: 4f ee        ldi	r20, 0xef */
/* 0x549A: 52 e0        ldi	r21, 0x2 */
/* 0x549C: 15 df        rcall	.-470 */
/* 0x549E: 00 95        com	r16 */
/* 0x54A0: 0c bf        out	0x3c, r16 */
/* 0x54A2: 08 95        ret */
/* 0x54BC: f1 de        rcall	.-542 */
/* 0x54BE: a3 97 8e 01  <unknown> */
/* 0x54C2: 0e 94 f2 15  <unknown> */
/* 0x54C6: 01 30        cpi	r16, 0x1 */
/* 0x54C8: 09 f0        breq	.+2 */
/* 0x54CA: be c1        rjmp	.+892 */
/* 0x54CC: 08 81        ldd	r16, Y+0 */
/* 0x54CE: e2 e4        ldi	r30, 0x42 */
/* 0x54D0: fc e0        ldi	r31, 0xc */
/* 0x54D2: 0c 94 93 34  <unknown> */
/* 0x5596: 0c e4        ldi	r16, 0x4c */
/* 0x5598: 9d d1        rcall	.+826 */
/* 0x559A: 80 e0        ldi	r24, 0x0 */
/* 0x559C: 48 2f        mov	r20, r24 */
/* 0x559E: c2 d1        rcall	.+900 */
/* 0x55A0: ac e4        ldi	r26, 0x4c */
/* 0x55A2: b0 e0        ldi	r27, 0x0 */
/* 0x55A4: a0 0f        add	r26, r16 */
/* 0x55A6: b1 1f        adc	r27, r17 */
/* 0x55A8: ad 01 4a 5f  <unknown> */
/* 0x55AC: a8 d1        rcall	.+848 */
/* 0x55AE: a4 d1        rcall	.+840 */
/* 0x55B0: 4f 5f        subi	r20, 0xff */
/* 0x55B2: a1 d1        rcall	.+834 */
/* 0x55B4: 4b 5f        subi	r20, 0xfb */
/* 0x55B6: a3 d1        rcall	.+838 */
/* 0x55B8: 49 5f        subi	r20, 0xf9 */
/* 0x55BA: 9d d1        rcall	.+826 */
/* 0x55BC: 48 5f        subi	r20, 0xf8 */
/* 0x55BE: 9b d1        rcall	.+822 */
/* 0x55C0: 47 5f        subi	r20, 0xf7 */
/* 0x55C2: 9d d1        rcall	.+826 */
/* 0x55C4: 46 5f        subi	r20, 0xf6 */
/* 0x55C6: 9b d1        rcall	.+822 */
/* 0x55C8: 7d de        rcall	.-774 */
/* 0x55CA: 73 d1        rcall	.+742 */
/* 0x55CC: 7b de        rcall	.-778 */
/* 0x55CE: 02 95        swap	r16 */
/* 0x55D0: 70 d1        rcall	.+736 */
/* 0x55D2: 4d 5f        subi	r20, 0xfd */
/* 0x55D4: 99 d1        rcall	.+818 */
/* 0x55D6: 4e 5f        subi	r20, 0xfe */
/* 0x55D8: 97 d1        rcall	.+814 */
/* 0x55DA: 44 5f        subi	r20, 0xf4 */
/* 0x55DC: 95 d1        rcall	.+810 */
/* 0x55DE: 45 5f        subi	r20, 0xf5 */
/* 0x55E0: 72 de        rcall	.-796 */
/* 0x55E2: 78 d1        rcall	.+752 */
/* 0x55E4: 6f d1        rcall	.+734 */
/* 0x55E6: 8d 01 03 5f  <unknown> */
/* 0x55EA: 1f 4f        sbci	r17, 0xff */
/* 0x55EC: 3b d1        rcall	.+630 */
/* 0x55EE: 6a d1        rcall	.+724 */
/* 0x55F0: 8d 01 01 5f  <unknown> */
/* 0x55F4: 59 d1        rcall	.+690 */
/* 0x55F6: 7a d1        rcall	.+756 */
/* 0x55F8: ad 01 4f 5f  <unknown> */
/* 0x55FC: 5f 4f        sbci	r21, 0xff */
/* 0x55FE: 76 d1        rcall	.+748 */
/* 0x5600: 24 e0        ldi	r18, 0x4 */
/* 0x5602: 30 e0        ldi	r19, 0x0 */
/* 0x5604: 8d 01 0f 5e  <unknown> */
/* 0x5608: 4f d1        rcall	.+670 */
/* 0x560A: 4e 5f        subi	r20, 0xfe */
/* 0x560C: 86 d1        rcall	.+780 */
/* 0x560E: 4d 5f        subi	r20, 0xfd */
/* 0x5610: 84 d1        rcall	.+776 */
/* 0x5612: 4a 5f        subi	r20, 0xfa */
/* 0x5614: 58 de        rcall	.-848 */
/* 0x5616: 10 2f        mov	r17, r16 */
/* 0x5618: 10 72        andi	r17, 0x20 */
/* 0x561A: 16 95        lsr	r17 */
/* 0x561C: 16 95        lsr	r17 */
/* 0x561E: 16 95        lsr	r17 */
/* 0x5620: ad 01 44 5f  <unknown> */
/* 0x5624: 50 de        rcall	.-864 */
/* 0x5626: 24 e0        ldi	r18, 0x4 */
/* 0x5628: 02 9f 02 e0  <unknown> */
/* 0x562C: 10 22        and	r1, r16 */
/* 0x562E: 11 29        or	r17, r1 */
/* 0x5630: 15 96 ad 01  <unknown> */
/* 0x5634: 49 de        rcall	.-878 */
/* 0x5636: 00 72        andi	r16, 0x20 */
/* 0x5638: 02 95        swap	r16 */
/* 0x563A: 06 95        lsr	r16 */
/* 0x563C: 01 2b        or	r16, r17 */
/* 0x563E: 4a d1        rcall	.+660 */
/* 0x5640: 83 95        inc	r24 */
/* 0x5642: 80 32        cpi	r24, 0x20 */
/* 0x5644: 08 f0        brlo	.+2 */
/* 0x5646: 00 c1        rjmp	.+512 */
/* 0x5648: a9 cf        rjmp	.-174 */
/* 0x579A: 04 e4        ldi	r16, 0x44 */
/* 0x579C: 9b d0        rcall	.+310 */
/* 0x579E: 20 e0        ldi	r18, 0x0 */
/* 0x57A0: 31 e0        ldi	r19, 0x1 */
/* 0x57A2: 00 ef        ldi	r16, 0xf0 */
/* 0x57A4: 12 e0        ldi	r17, 0x2 */
/* 0x57A6: 5e d0        rcall	.+188 */
/* 0x57A8: 4f c0        rjmp	.+158 */
/* 0x57AA: 04 e6        ldi	r16, 0x64 */
/* 0x57AC: 93 d0        rcall	.+294 */
/* 0x57AE: 00 91 8e 06  <unknown> */
/* 0x57B2: 90 d0        rcall	.+288 */
/* 0x57B4: 00 e0        ldi	r16, 0x0 */
/* 0x57B6: 00 93 8e 06  <unknown> */
/* 0x57BA: 46 c0        rjmp	.+140 */
/* 0x581E: 03 e5        ldi	r16, 0x53 */
/* 0x5820: 59 d0        rcall	.+178 */
/* 0x5822: 0e 94 93 0f  <unknown> */
/* 0x5826: c8 01 20 e6  <unknown> */
/* 0x582A: 30 e0        ldi	r19, 0x0 */
/* 0x582C: 0e 94 1b 16  <unknown> */
/* 0x5830: 8c 01 0e 94  <unknown> */
/* 0x5834: 76 31        cpi	r23, 0x16 */
/* 0x5836: 08 c0        rjmp	.+16 */
/* 0x5838: 03 e7        ldi	r16, 0x73 */
/* 0x583A: 4c d0        rcall	.+152 */
/* 0x583C: 28 e0        ldi	r18, 0x8 */
/* 0x583E: 30 e0        ldi	r19, 0x0 */
/* 0x5840: 03 e7        ldi	r16, 0x73 */
/* 0x5842: 16 e0        ldi	r17, 0x6 */
/* 0x5844: 0e 94 1b 16  <unknown> */
/* 0x5848: a3 96 de cb  <unknown> */
/* 0x584C: 28 e1        ldi	r18, 0x18 */
/* 0x584E: 30 e0        ldi	r19, 0x0 */
/* 0x5850: 0d e2        ldi	r16, 0x2d */
/* 0x5852: 10 e0        ldi	r17, 0x0 */
/* 0x5854: 08 95        ret */
/* 0x5864: 0c 94 04 16  <unknown> */
/* 0x58A8: 1f 4f        sbci	r17, 0xff */
/* 0x58AA: 0e 94 04 16  <unknown> */
/* 0x58AE: ad 01 08 95  <unknown> */
/* 0x58B2: 0f 70        andi	r16, 0xf */
/* 0x58B4: 26 c0        rjmp	.+76 */
/* 0x58C4: 22 e0        ldi	r18, 0x2 */
/* 0x58C6: 0c 94 5e 24  <unknown> */
/* 0x58D4: 0c 94 ee 15  <unknown> */
/* 0x58D8: 00 0f        lsl	r16 */
/* 0x58DA: 11 1f        rol	r17 */
/* 0x58DC: 08 95        ret */
/* 0x58EC: ed dc        rcall	.-1574 */
/* 0x58EE: 14 e0        ldi	r17, 0x4 */
/* 0x58F0: 01 9f 01 2d  <unknown> */
/* 0x58F4: ef cf        rjmp	.-34 */
/* 0x58F6: 5f 4f        sbci	r21, 0xff */
/* 0x58F8: e7 dc        rcall	.-1586 */
/* 0x58FA: 0f 73        andi	r16, 0x3f */
/* 0x58FC: 02 c0        rjmp	.+4 */
/* 0x58FE: e3 dc        rcall	.-1594 */
/* 0x5900: 0f 71        andi	r16, 0x1f */
/* 0x5902: 0e 94 ee 15  <unknown> */
/* 0x5906: d3 cf        rjmp	.-90 */
/* 0x5908: de dc        rcall	.-1604 */
/* 0x590A: 0f 77        andi	r16, 0x7f */
/* 0x590C: fa cf        rjmp	.-12 */
/* 0x591A: d5 dc        rcall	.-1622 */
/* 0x591C: 00 0f        lsl	r16 */
/* 0x591E: 00 e0        ldi	r16, 0x0 */
/* 0x5920: 00 1f        rol	r16 */
/* 0x5922: ef cf        rjmp	.-34 */
/* 0x5924: 50 e0        ldi	r21, 0x0 */
/* 0x5926: 05 e1        ldi	r16, 0x15 */
/* 0x5928: 55 ca        rjmp	.-2902 */
/* 0x595C: 00 23        tst	r16 */
/* 0x595E: 08 95        ret */
/* 0x5968: 8a 93        st	-Y, r24 */
/* 0x596A: fa 93        st	-Y, r31 */
/* 0x596C: ea 93        st	-Y, r30 */
/* 0x596E: 3a 92        st	-Y, r3 */
/* 0x5970: 2a 92        st	-Y, r2 */
/* 0x5972: 1a 92        st	-Y, r1 */
/* 0x5974: 0a 92        st	-Y, r0 */
/* 0x5976: 7a 93        st	-Y, r23 */
/* 0x5978: 6a 93        st	-Y, r22 */
/* 0x597A: 5a 93        st	-Y, r21 */
/* 0x597C: 4a 93        st	-Y, r20 */
/* 0x597E: 33 d0        rcall	.+102 */
/* 0x5980: 8f b7        in	r24, 0x3f */
/* 0x5982: 01 e0        ldi	r16, 0x1 */
/* 0x5984: 00 93 35 07  <unknown> */
/* 0x5988: 82 9b        sbis	0x10, 0x2 */
/* 0x598A: 0a c0        rjmp	.+20 */
/* 0x59A0: 00 91 37 07  <unknown> */
/* 0x59A4: 01 30        cpi	r16, 0x1 */
/* 0x59A6: 49 f4        brne	.+18 */
/* 0x59A8: 82 9b        sbis	0x10, 0x2 */
/* 0x59AA: 02 c0        rjmp	.+4 */
/* 0x59B0: 8c 9a        sbi	0x11, 0x4 */
/* 0x59B2: 05 e0        ldi	r16, 0x5 */
/* 0x59B4: 0e 94 f8 0f  <unknown> */
/* 0x59B8: 05 c0        rjmp	.+10 */
/* 0x59BA: f8 94        cli */
/* 0x59BC: 1b d0        rcall	.+54 */
/* 0x59BE: 09 f0        breq	.+2 */
/* 0x59C0: 8c 9a        sbi	0x11, 0x4 */
/* 0x59C2: 78 94        sei */
/* 0x59C4: 8f bf        out	0x3f, r24 */
/* 0x59C6: 09 91        ld	r16, Y+ */
/* 0x59C8: 19 91        ld	r17, Y+ */
/* 0x59CA: 29 91        ld	r18, Y+ */
/* 0x59CC: 39 91        ld	r19, Y+ */
/* 0x59CE: 49 91        ld	r20, Y+ */
/* 0x59D0: 59 91        ld	r21, Y+ */
/* 0x59D2: 69 91        ld	r22, Y+ */
/* 0x59D4: 79 91        ld	r23, Y+ */
/* 0x59D6: 09 90        ld	r0, Y+ */
/* 0x59D8: 19 90        ld	r1, Y+ */
/* 0x59DA: 29 90        ld	r2, Y+ */
/* 0x59DC: 39 90        ld	r3, Y+ */
/* 0x59DE: e9 91        ld	r30, Y+ */
/* 0x59E0: f9 91        ld	r31, Y+ */
/* 0x59E2: 89 91        ld	r24, Y+ */
/* 0x59E4: 18 95        reti */
/* 0x59E6: 3a 93        st	-Y, r19 */
/* 0x59E8: 2a 93        st	-Y, r18 */
/* 0x59EA: f7 cc        rjmp	.-1554 */
/* 0x59EC: 00 e0        ldi	r16, 0x0 */
/* 0x59EE: 00 93 3b 07  <unknown> */
/* 0x59F2: 08 95        ret */
/* 0x59F4: 4d ee        ldi	r20, 0xed */
/* 0x59F6: 52 e0        ldi	r21, 0x2 */
/* 0x59F8: 67 dc        rcall	.-1842 */
/* 0x59FA: b0 cf        rjmp	.-160 */
/* 0x59FC: 80 2f        mov	r24, r16 */
/* 0x59FE: 91 2f        mov	r25, r17 */
/* 0x5A00: 0e 94 36 31  <unknown> */
/* 0x5A04: 08 2f        mov	r16, r24 */
/* 0x5A06: 19 2f        mov	r17, r25 */
/* 0x5A08: 0c 94 d6 36  <unknown> */
/* 0x5C80: 0c 94 f4 34  <unknown> */
/* 0x5CC8: 50 e0        ldi	r21, 0x0 */
/* 0x5CCA: 08 95        ret */
/* 0x5CE2: 0e 94 e3 34  <unknown> */
/* 0x5CE6: ef 97 ef 97  <unknown> */
/* 0x5CEA: 6c 97 2a 87  <unknown> */
/* 0x5CEE: 3b 87        std	Y+3, r19 */
/* 0x5CF0: 48 87        std	Y+0, r20 */
/* 0x5CF2: 59 87        std	Y+1, r21 */
/* 0x5CF4: 78 01 6b 01  <unknown> */
/* 0x5CF8: 00 e0        ldi	r16, 0x0 */
/* 0x5CFA: 0d 83        std	Y+5, r16 */
/* 0x5CFC: 0e 83        std	Y+6, r16 */
/* 0x5CFE: 04 c0        rjmp	.+8 */
/* 0x5D00: 5b d2        rcall	.+1206 */
/* 0x5D02: 1f d2        rcall	.+1086 */
/* 0x5D04: 05 e2        ldi	r16, 0x25 */
/* 0x5D06: 27 d2        rcall	.+1102 */
/* 0x5D08: 00 e0        ldi	r16, 0x0 */
/* 0x5D0A: 0c 87        std	Y+4, r16 */
/* 0x5D0C: 0d 87        std	Y+5, r16 */
/* 0x5D0E: 02 c0        rjmp	.+4 */
/* 0x5D10: 18 d2        rcall	.+1072 */
/* 0x5D12: 21 d2        rcall	.+1090 */
/* 0x5D14: 0e d2        rcall	.+1052 */
/* 0x5D16: 05 32        cpi	r16, 0x25 */
/* 0x5D18: 49 f0        breq	.+18 */
/* 0x5D1A: 00 23        tst	r16 */
/* 0x5D1C: c9 f7        brne	.-14 */
/* 0x5D1E: 0d 81        ldd	r16, Y+5 */
/* 0x5D20: 1e 81        ldd	r17, Y+6 */
/* 0x5D22: ef 96 ef 96  <unknown> */
/* 0x5D26: 6c 96 e0 e1  <unknown> */
/* 0x5D2A: aa cf        rjmp	.-172 */
/* 0x5D2C: 04 91 05 32  <unknown> */
/* 0x5D30: 39 f3        breq	.-50 */
/* 0x5D32: 00 e0        ldi	r16, 0x0 */
/* 0x5D34: 0c 83        std	Y+4, r16 */
/* 0x5D36: 0b 83        std	Y+3, r16 */
/* 0x5D38: 0a 83        std	Y+2, r16 */
/* 0x5D3A: 09 83        std	Y+1, r16 */
/* 0x5D3C: 3e 01 04 e1  <unknown> */
/* 0x5D40: 1a d2        rcall	.+1076 */
/* 0x5D42: 0a eb        ldi	r16, 0xba */
/* 0x5D44: 1b e0        ldi	r17, 0xb */
/* 0x5D46: 0a 8b        std	Y+2, r16 */
/* 0x5D48: 1b 8b        std	Y+3, r17 */
/* 0x5D4A: 06 c0        rjmp	.+12 */
/* 0x5D4C: 09 81        ldd	r16, Y+1 */
/* 0x5D4E: 00 23        tst	r16 */
/* 0x5D50: 11 f4        brne	.+4 */
/* 0x5D52: 04 91 09 83  <unknown> */
/* 0x5D56: 30 d2        rcall	.+1120 */
/* 0x5D58: f1 d1        rcall	.+994 */
/* 0x5D5A: 00 52        subi	r16, 0x20 */
/* 0x5D5C: b9 f3        breq	.-18 */
/* 0x5D5E: 03 50        subi	r16, 0x3 */
/* 0x5D60: 59 f0        breq	.+22 */
/* 0x5D62: 08 50        subi	r16, 0x8 */
/* 0x5D64: b1 f3        breq	.-20 */
/* 0x5D66: 02 50        subi	r16, 0x2 */
/* 0x5D68: 19 f0        breq	.+6 */
/* 0x5D6A: 03 50        subi	r16, 0x3 */
/* 0x5D6C: 49 f0        breq	.+18 */
/* 0x5D6E: 0c c0        rjmp	.+24 */
/* 0x5D70: 0a 81        ldd	r16, Y+2 */
/* 0x5D72: 03 95        inc	r16 */
/* 0x5D74: 0a 83        std	Y+2, r16 */
/* 0x5D76: ef cf        rjmp	.-34 */
/* 0x5D78: 0b 81        ldd	r16, Y+3 */
/* 0x5D7A: 03 95        inc	r16 */
/* 0x5D7C: 0b 83        std	Y+3, r16 */
/* 0x5D7E: eb cf        rjmp	.-42 */
/* 0x5D80: 0c 81        ldd	r16, Y+4 */
/* 0x5D82: 03 95        inc	r16 */
/* 0x5D84: 0c 83        std	Y+4, r16 */
/* 0x5D86: e7 cf        rjmp	.-50 */
/* 0x5D88: 04 91 0a 32  <unknown> */
/* 0x5D8C: 79 f4        brne	.+30 */
/* 0x5D8E: f8 d1        rcall	.+1008 */
/* 0x5D90: ad 90        ld	r10, X+ */
/* 0x5D92: bd 90        ld	r11, X+ */
/* 0x5D94: bb d1        rcall	.+886 */
/* 0x5D96: bb 20        tst	r11 */
/* 0x5D98: 3a f4        brpl	.+14 */
/* 0x5D9A: b1 94        neg	r11 */
/* 0x5D9C: a1 94        neg	r10 */
/* 0x5D9E: 00 e0        ldi	r16, 0x0 */
/* 0x5DA0: b0 0a        sbc	r11, r16 */
/* 0x5DA2: 0a 81        ldd	r16, Y+2 */
/* 0x5DA4: 03 95        inc	r16 */
/* 0x5DA6: 0a 83        std	Y+2, r16 */
/* 0x5DA8: 07 d2        rcall	.+1038 */
/* 0x5DAA: 14 c0        rjmp	.+40 */
/* 0x5DAC: aa 24        clr	r10 */
/* 0x5DAE: bb 24        clr	r11 */
/* 0x5DB0: 0c c0        rjmp	.+24 */
/* 0x5DB2: a5 d1        rcall	.+842 */
/* 0x5DB4: 85 01 0e 94  <unknown> */
/* 0x5DB8: cd 31        cpi	r28, 0x1d */
/* 0x5DBA: a2 2e        mov	r10, r18 */
/* 0x5DBC: bb 24        clr	r11 */
/* 0x5DBE: a0 0e        add	r10, r16 */
/* 0x5DC0: b1 1e        adc	r11, r17 */
/* 0x5DC2: 00 ed        ldi	r16, 0xd0 */
/* 0x5DC4: a0 0e        add	r10, r16 */
/* 0x5DC6: 0f ef        ldi	r16, 0xff */
/* 0x5DC8: b0 1e        adc	r11, r16 */
/* 0x5DCA: b8 d1        rcall	.+880 */
/* 0x5DCC: 00 33        cpi	r16, 0x30 */
/* 0x5DCE: 10 f0        brlo	.+4 */
/* 0x5DD0: 0a 33        cpi	r16, 0x3a */
/* 0x5DD2: 78 f3        brlo	.-34 */
/* 0x5DD4: 0a 81        ldd	r16, Y+2 */
/* 0x5DD6: 00 23        tst	r16 */
/* 0x5DD8: 11 f0        breq	.+4 */
/* 0x5DDA: 00 e0        ldi	r16, 0x0 */
/* 0x5DDC: 0c 83        std	Y+4, r16 */
/* 0x5DDE: ae d1        rcall	.+860 */
/* 0x5DE0: 0e 32        cpi	r16, 0x2e */
/* 0x5DE2: f1 f4        brne	.+60 */
/* 0x5DE4: e9 d1        rcall	.+978 */
/* 0x5DE6: aa d1        rcall	.+852 */
/* 0x5DE8: 0a 32        cpi	r16, 0x2a */
/* 0x5DEA: 31 f4        brne	.+12 */
/* 0x5DEC: c9 d1        rcall	.+914 */
/* 0x5DEE: 8d 90        ld	r8, X+ */
/* 0x5DF0: 9d 90        ld	r9, X+ */
/* 0x5DF2: 8c d1        rcall	.+792 */
/* 0x5DF4: e1 d1        rcall	.+962 */
/* 0x5DF6: 17 c0        rjmp	.+46 */
/* 0x5DF8: 88 24        clr	r8 */
/* 0x5DFA: 99 24        clr	r9 */
/* 0x5DFC: 9f d1        rcall	.+830 */
/* 0x5DFE: 00 33        cpi	r16, 0x30 */
/* 0x5E00: 90 f0        brlo	.+36 */
/* 0x5E02: 0a 33        cpi	r16, 0x3a */
/* 0x5E04: 80 f4        brsh	.+32 */
/* 0x5E06: 7b d1        rcall	.+758 */
/* 0x5E08: 84 01 0e 94  <unknown> */
/* 0x5E0C: cd 31        cpi	r28, 0x1d */
/* 0x5E0E: 82 2e        mov	r8, r18 */
/* 0x5E10: 99 24        clr	r9 */
/* 0x5E12: 80 0e        add	r8, r16 */
/* 0x5E14: 91 1e        adc	r9, r17 */
/* 0x5E16: 00 ed        ldi	r16, 0xd0 */
/* 0x5E18: 80 0e        add	r8, r16 */
/* 0x5E1A: 0f ef        ldi	r16, 0xff */
/* 0x5E1C: 90 1e        adc	r9, r16 */
/* 0x5E1E: ee cf        rjmp	.-36 */
/* 0x5E20: 88 24        clr	r8 */
/* 0x5E22: 8a 94        dec	r8 */
/* 0x5E24: 98 2c        mov	r9, r8 */
/* 0x5E26: 80 e0        ldi	r24, 0x0 */
/* 0x5E28: 89 d1        rcall	.+786 */
/* 0x5E2A: 0c 54        subi	r16, 0x4c */
/* 0x5E2C: 21 f0        breq	.+8 */
/* 0x5E2E: 0c 51        subi	r16, 0x1c */
/* 0x5E30: 39 f0        breq	.+14 */
/* 0x5E32: 04 50        subi	r16, 0x4 */
/* 0x5E34: 41 f4        brne	.+16 */
/* 0x5E36: 81 e0        ldi	r24, 0x1 */
/* 0x5E38: e8 0e        add	r14, r24 */
/* 0x5E3A: 00 e0        ldi	r16, 0x0 */
/* 0x5E3C: f0 1e        adc	r15, r16 */
/* 0x5E3E: 03 c0        rjmp	.+6 */
/* 0x5E40: 01 e0        ldi	r16, 0x1 */
/* 0x5E42: e0 0e        add	r14, r16 */
/* 0x5E44: f8 1e        adc	r15, r24 */
/* 0x5E46: 75 d1        rcall	.+746 */
/* 0x5E48: e8 e8        ldi	r30, 0x88 */
/* 0x5E4A: fc e0        ldi	r31, 0xc */
/* 0x5E4C: 0c 94 93 34  <unknown> */
/* 0x60FE: 25 91 7f 01  <unknown> */
/* 0x6102: 4a e0        ldi	r20, 0xa */
/* 0x6104: e1 cd        rjmp	.-1086 */
/* 0x610C: a0 83        std	Z+0, r26 */
/* 0x610E: b1 83        std	Z+1, r27 */
/* 0x6110: 08 95        ret */
/* 0x6132: f7 01 05 91  <unknown> */
/* 0x6136: 7f 01 08 83  <unknown> */
/* 0x613A: 08 95        ret */
/* 0x613C: f7 01 04 91  <unknown> */
/* 0x6140: 08 95        ret */
/* 0x6142: 28 85        ldd	r18, Y+0 */
/* 0x6144: 39 85        ldd	r19, Y+1 */
/* 0x6146: 08 95        ret */
/* 0x6156: ea 85        ldd	r30, Y+2 */
/* 0x6158: fb 85        ldd	r31, Y+3 */
/* 0x615A: 09 95 0d 81  <unknown> */
/* 0x615E: 1e 81        ldd	r17, Y+6 */
/* 0x6160: 0f 5f        subi	r16, 0xff */
/* 0x6162: 1f 4f        sbci	r17, 0xff */
/* 0x6164: 0d 83        std	Y+5, r16 */
/* 0x6166: 1e 83        std	Y+6, r17 */
/* 0x6168: 08 95        ret */
/* 0x6176: 60 0e        add	r6, r16 */
/* 0x6178: 00 e0        ldi	r16, 0x0 */
/* 0x617A: 70 1e        adc	r7, r16 */
/* 0x617C: 08 95        ret */
/* 0x6180: f6 01 a0 81  <unknown> */
/* 0x6184: b1 81        ldd	r27, Z+1 */
/* 0x6186: 08 95        ret */
/* 0x61AE: f0 1e        adc	r15, r16 */
/* 0x61B0: 08 95        ret */
/* 0x61B8: 01 e0        ldi	r16, 0x1 */
/* 0x61BA: e0 0e        add	r14, r16 */
/* 0x61BC: 00 e0        ldi	r16, 0x0 */
/* 0x61BE: f7 cf        rjmp	.-18 */
/* 0x61E4: 01 e0        ldi	r16, 0x1 */
/* 0x61E6: 10 e0        ldi	r17, 0x0 */
/* 0x61E8: 0c 94 d6 36  <unknown> */
/* 0x61EC: 0e 94 eb 34  <unknown> */
/* 0x61F0: d8 01 29 01  <unknown> */
/* 0x61F4: 82 e0        ldi	r24, 0x2 */
/* 0x61F6: 3d 01 09 c0  <unknown> */
/* 0x61FA: 02 e0        ldi	r16, 0x2 */
/* 0x61FC: 60 0e        add	r6, r16 */
/* 0x61FE: 71 1e        adc	r7, r17 */
/* 0x6200: 82 30        cpi	r24, 0x2 */
/* 0x6202: 81 f0        breq	.+32 */
/* 0x6204: 02 e0        ldi	r16, 0x2 */
/* 0x6206: 60 0e        add	r6, r16 */
/* 0x6208: 00 e0        ldi	r16, 0x0 */
/* 0x620A: 70 1e        adc	r7, r16 */
/* 0x620C: 64 14        cp	r6, r4 */
/* 0x620E: 75 04        cpc	r7, r5 */
/* 0x6210: 79 f0        breq	.+30 */
/* 0x6212: f3 01 25 91  <unknown> */
/* 0x6216: 34 91 10 e0  <unknown> */
/* 0x621A: 20 30        cpi	r18, 0x0 */
/* 0x621C: 30 40        sbci	r19, 0x0 */
/* 0x621E: 69 f3        breq	.-38 */
/* 0x6220: 82 30        cpi	r24, 0x2 */
/* 0x6222: 81 f3        breq	.-32 */
/* 0x6224: f3 01 05 91  <unknown> */
/* 0x6228: f4 91 e0 2f  <unknown> */
/* 0x622C: 09 95 ea cf  <unknown> */
/* 0x6230: 8a 95        dec	r24 */
/* 0x6232: 09 f7        brne	.-62 */
/* 0x6234: e8 e0        ldi	r30, 0x8 */
/* 0x6236: 0c 94 fc 34  <unknown> */
/* 0x626C: ba 93        st	-Y, r27 */
/* 0x626E: aa 93        st	-Y, r26 */
/* 0x6270: 01 c0        rjmp	.+2 */
/* 0x62B8: 0f e5        ldi	r16, 0x5f */
/* 0x62BA: 0d bf        out	0x3d, r16 */
/* 0x62BC: 06 e0        ldi	r16, 0x6 */
/* 0x62BE: 0e bf        out	0x3e, r16 */
/* 0x62C0: c0 e6        ldi	r28, 0x60 */
/* 0x62C2: d3 e0        ldi	r29, 0x3 */
/* 0x62C4: 0e 94 1a 35  <unknown> */
/* 0x62C8: 00 23        tst	r16 */
/* 0x62CA: 11 f0        breq	.+4 */
/* 0x62CC: 0e 94 8d 35  <unknown> */
/* 0x62D0: 0c eb        ldi	r16, 0xbc */
/* 0x62D2: 1c e0        ldi	r17, 0xc */
/* 0x62D4: 2e eb        ldi	r18, 0xbe */
/* 0x62D6: 3c e0        ldi	r19, 0xc */
/* 0x62D8: 0e 94 f6 30  <unknown> */
/* 0x62DC: 0e 94 de 20  <unknown> */
/* 0x62E0: 0e 94 b8 31  <unknown> */
/* 0x62E4: 0c 94 fe 2c  <unknown> */
/* 0x62F8: e1 99        sbic	0x1c, 0x1 */
/* 0x62FA: fe cf        rjmp	.-4 */
/* 0x62FE: 4f 5f        subi	r20, 0xff */
/* 0x6300: 5f 4f        sbci	r21, 0xff */
/* 0x6302: fa df        rcall	.-12 */
/* 0x6304: 4e bb        out	0x1e, r20 */
/* 0x6306: 5f bb        out	0x1f, r21 */
/* 0x6308: e0 9a        sbi	0x1c, 0x0 */
/* 0x630A: 08 95        ret */
/* 0x630C: fa df        rcall	.-12 */
/* 0x630E: 0d b3        in	r16, 0x1d */
/* 0x6310: 08 95        ret */
/* 0x6312: f7 df        rcall	.-18 */
/* 0x6314: 0d b3        in	r16, 0x1d */
/* 0x6316: f3 df        rcall	.-26 */
/* 0x6318: 1d b3        in	r17, 0x1d */
/* 0x631A: 08 95        ret */
/* 0x631C: f2 df        rcall	.-28 */
/* 0x631E: 0d b3        in	r16, 0x1d */
/* 0x6320: ee df        rcall	.-36 */
/* 0x6322: 1d b3        in	r17, 0x1d */
/* 0x6324: ec df        rcall	.-40 */
/* 0x6326: 2d b3        in	r18, 0x1d */
/* 0x6328: ea df        rcall	.-44 */
/* 0x632A: 3d b3        in	r19, 0x1d */
/* 0x632C: 08 95        ret */
/* 0x632E: 4f 5f        subi	r20, 0xff */
/* 0x6330: 5f 4f        sbci	r21, 0xff */
/* 0x6332: 4e bb        out	0x1e, r20 */
/* 0x6334: 5f bb        out	0x1f, r21 */
/* 0x6336: f8 94        cli */
/* 0x6338: e2 9a        sbi	0x1c, 0x2 */
/* 0x633A: e1 9a        sbi	0x1c, 0x1 */
/* 0x633C: 0f be        out	0x3f, r0 */
/* 0x633E: 08 95        ret */
/* 0x6340: 0f b6        in	r0, 0x3f */
/* 0x6342: da df        rcall	.-76 */
/* 0x6344: 0d bb        out	0x1d, r16 */
/* 0x6346: f5 cf        rjmp	.-22 */
/* 0x6348: 0f b6        in	r0, 0x3f */
/* 0x634A: d6 df        rcall	.-84 */
/* 0x634C: 0d bb        out	0x1d, r16 */
/* 0x634E: f1 df        rcall	.-30 */
/* 0x6350: d3 df        rcall	.-90 */
/* 0x6352: 1d bb        out	0x1d, r17 */
/* 0x6354: ec cf        rjmp	.-40 */
/* 0x6356: 0f b6        in	r0, 0x3f */
/* 0x6358: cf df        rcall	.-98 */
/* 0x635A: 0d bb        out	0x1d, r16 */
/* 0x635C: ea df        rcall	.-44 */
/* 0x635E: cc df        rcall	.-104 */
/* 0x6360: 1d bb        out	0x1d, r17 */
/* 0x6362: e5 df        rcall	.-54 */
/* 0x6364: c9 df        rcall	.-110 */
/* 0x6366: 2d bb        out	0x1d, r18 */
/* 0x6368: e2 df        rcall	.-60 */
/* 0x636A: c6 df        rcall	.-116 */
/* 0x636C: 3d bb        out	0x1d, r19 */
/* 0x636E: df cf        rjmp	.-66 */
/* 0x6370: 0c 94 fe 2c  <unknown> */
/* 0x637E: 00 24        clr	r0 */
/* 0x6380: e8 e0        ldi	r30, 0x8 */
/* 0x6382: ea 95        dec	r30 */
/* 0x6384: 32 f0        brmi	.+12 */
/* 0x6386: 00 1f        rol	r16 */
/* 0x6388: 00 1c        rol	r0 */
/* 0x638A: 04 16        cp	r0, r20 */
/* 0x638C: d0 f3        brlo	.-12 */
/* 0x638E: 04 1a        sub	r0, r20 */
/* 0x6390: f8 cf        rjmp	.-16 */
/* 0x6392: 00 1f        rol	r16 */
/* 0x6394: 40 2d        mov	r20, r0 */
/* 0x6396: 00 95        com	r16 */
/* 0x6398: 08 95        ret */
/* 0x639A: 14 9f 10 2d  <unknown> */
/* 0x639E: 05 9f 10 0d  <unknown> */
/* 0x63A2: 04 9f 00 2d  <unknown> */
/* 0x63A6: 11 0d        add	r17, r1 */
/* 0x63A8: 08 95        ret */
/* 0x63AA: 4a 95        dec	r20 */
/* 0x63AC: 1a f0        brmi	.+6 */
/* 0x63AE: 00 0f        lsl	r16 */
/* 0x63B0: 11 1f        rol	r17 */
/* 0x63B2: fb cf        rjmp	.-10 */
/* 0x63B4: 08 95        ret */
/* 0x63C2: 00 24        clr	r0 */
/* 0x63C4: 11 24        clr	r1 */
/* 0x63C6: ef e0        ldi	r30, 0xf */
/* 0x63C8: 00 1f        rol	r16 */
/* 0x63CA: 11 1f        rol	r17 */
/* 0x63CC: 00 1c        rol	r0 */
/* 0x63CE: 11 1c        rol	r1 */
/* 0x63D0: 04 16        cp	r0, r20 */
/* 0x63D2: 15 06        cpc	r1, r21 */
/* 0x63D4: 10 f0        brlo	.+4 */
/* 0x63D6: 04 1a        sub	r0, r20 */
/* 0x63D8: 15 0a        sbc	r1, r21 */
/* 0x63DA: ea 95        dec	r30 */
/* 0x63DC: aa f7        brpl	.-22 */
/* 0x63DE: 00 1f        rol	r16 */
/* 0x63E0: 11 1f        rol	r17 */
/* 0x63E2: a0 01 00 95  <unknown> */
/* 0x63E6: 10 95        com	r17 */
/* 0x63E8: 08 95        ret */
/* 0x63EA: 51 95        neg	r21 */
/* 0x63EC: 41 95        neg	r20 */
/* 0x63EE: 50 40        sbci	r21, 0x0 */
/* 0x63F0: 08 95        ret */
/* 0x63F2: ff 27        clr	r31 */
/* 0x63F4: 55 23        tst	r21 */
/* 0x63F6: 12 f4        brpl	.+4 */
/* 0x63F8: f1 60        ori	r31, 0x1 */
/* 0x63FA: f7 df        rcall	.-18 */
/* 0x63FC: 11 23        tst	r17 */
/* 0x63FE: 12 f4        brpl	.+4 */
/* 0x6400: f0 95        com	r31 */
/* 0x6402: 07 d0        rcall	.+14 */
/* 0x6404: 0e 94 e1 31  <unknown> */
/* 0x6408: f0 fd        sbrc	r31, 0x0 */
/* 0x640A: 03 d0        rcall	.+6 */
/* 0x640C: f1 fd        sbrc	r31, 0x1 */
/* 0x640E: ed cf        rjmp	.-38 */
/* 0x6410: 08 95        ret */
/* 0x6412: 11 95        neg	r17 */
/* 0x6414: 01 95        neg	r16 */
/* 0x6416: 10 40        sbci	r17, 0x0 */
/* 0x6418: 08 95        ret */
/* 0x641A: 22 24        clr	r2 */
/* 0x641C: 34 9f 30 2d  <unknown> */
/* 0x6420: 25 9f 30 0d  <unknown> */
/* 0x6424: 16 9f 30 0d  <unknown> */
/* 0x6428: 07 9f 30 0d  <unknown> */
/* 0x642C: 24 9f 20 2d  <unknown> */
/* 0x6430: 31 0d        add	r19, r1 */
/* 0x6432: 15 9f 20 0d  <unknown> */
/* 0x6436: 31 1d        adc	r19, r1 */
/* 0x6438: 06 9f 20 0d  <unknown> */
/* 0x643C: 31 1d        adc	r19, r1 */
/* 0x643E: 14 9f 10 2d  <unknown> */
/* 0x6442: 21 0d        add	r18, r1 */
/* 0x6444: 32 1d        adc	r19, r2 */
/* 0x6446: 05 9f 10 0d  <unknown> */
/* 0x644A: 21 1d        adc	r18, r1 */
/* 0x644C: 32 1d        adc	r19, r2 */
/* 0x644E: 04 9f 00 2d  <unknown> */
/* 0x6452: 11 0d        add	r17, r1 */
/* 0x6454: 22 1d        adc	r18, r2 */
/* 0x6456: 32 1d        adc	r19, r2 */
/* 0x6458: 08 95        ret */
/* 0x645A: 4a 95        dec	r20 */
/* 0x645C: 2a f0        brmi	.+10 */
/* 0x645E: 00 0f        lsl	r16 */
/* 0x6460: 11 1f        rol	r17 */
/* 0x6462: 22 1f        rol	r18 */
/* 0x6464: 33 1f        rol	r19 */
/* 0x6466: f9 cf        rjmp	.-14 */
/* 0x6468: 08 95        ret */
/* 0x64C0: 30 95        com	r19 */
/* 0x64C2: 20 95        com	r18 */
/* 0x64C4: 10 95        com	r17 */
/* 0x64C6: 01 95        neg	r16 */
/* 0x64C8: 1f 4f        sbci	r17, 0xff */
/* 0x64CA: 2f 4f        sbci	r18, 0xff */
/* 0x64CC: 3f 4f        sbci	r19, 0xff */
/* 0x64CE: 08 95        ret */
/* 0x64D0: ff 27        clr	r31 */
/* 0x64D2: 11 24        clr	r1 */
/* 0x64D4: 77 fb        bst	r23, 0x7 */
/* 0x64D6: 66 0f        lsl	r22 */
/* 0x64D8: 77 1f        rol	r23 */
/* 0x64DA: 08 94        sec */
/* 0x64DC: 09 f4        brne	.+2 */
/* 0x64DE: 77 1f        rol	r23 */
/* 0x64E0: 67 95        ror	r22 */
/* 0x64E2: 17 f8        bld	r1, 0x7 */
/* 0x64E4: ee 27        clr	r30 */
/* 0x64E6: 00 24        clr	r0 */
/* 0x64E8: 37 fb        bst	r19, 0x7 */
/* 0x64EA: 22 0f        lsl	r18 */
/* 0x64EC: 33 1f        rol	r19 */
/* 0x64EE: 08 94        sec */
/* 0x64F0: 09 f4        brne	.+2 */
/* 0x64F2: 33 1f        rol	r19 */
/* 0x64F4: 27 95        ror	r18 */
/* 0x64F6: 07 f8        bld	r0, 0x7 */
/* 0x64F8: 08 95        ret */
/* 0x64FA: 27 fd        sbrc	r18, 0x7 */
/* 0x64FC: 0e c0        rjmp	.+28 */
/* 0x64FE: ee 0f        lsl	r30 */
/* 0x6500: 00 1f        rol	r16 */
/* 0x6502: 11 1f        rol	r17 */
/* 0x6504: 22 1f        rol	r18 */
/* 0x6506: 3a 95        dec	r19 */
/* 0x6508: 32 30        cpi	r19, 0x2 */
/* 0x650A: b8 f7        brsh	.-18 */
/* 0x650C: 33 23        tst	r19 */
/* 0x650E: 19 f4        brne	.+6 */
/* 0x6510: 27 fd        sbrc	r18, 0x7 */
/* 0x6512: 31 e0        ldi	r19, 0x1 */
/* 0x6514: 02 c0        rjmp	.+4 */
/* 0x6516: 27 ff        sbrs	r18, 0x7 */
/* 0x6518: 30 e0        ldi	r19, 0x0 */
/* 0x651A: e0 38        cpi	r30, 0x80 */
/* 0x651C: 21 f4        brne	.+8 */
/* 0x651E: 00 ff        sbrs	r16, 0x0 */
/* 0x6520: 08 94        sec */
/* 0x6522: 0e f4        brtc	.+2 */
/* 0x6524: 88 94        clc */
/* 0x6526: 0f 4f        sbci	r16, 0xff */
/* 0x6528: 1f 4f        sbci	r17, 0xff */
/* 0x652A: 2f 4f        sbci	r18, 0xff */
/* 0x652C: 3f 4f        sbci	r19, 0xff */
/* 0x652E: 32 30        cpi	r19, 0x2 */
/* 0x6530: 38 f4        brsh	.+14 */
/* 0x6532: 33 23        tst	r19 */
/* 0x6534: 19 f4        brne	.+6 */
/* 0x6536: 27 fd        sbrc	r18, 0x7 */
/* 0x6538: 31 e0        ldi	r19, 0x1 */
/* 0x653A: 02 c0        rjmp	.+4 */
/* 0x653C: 27 ff        sbrs	r18, 0x7 */
/* 0x653E: 30 e0        ldi	r19, 0x0 */
/* 0x6540: 3f 3f        cpi	r19, 0xff */
/* 0x6542: 29 f0        breq	.+10 */
/* 0x6544: 22 0f        lsl	r18 */
/* 0x6546: 00 0c        lsl	r0 */
/* 0x6548: 37 95        ror	r19 */
/* 0x654A: 27 95        ror	r18 */
/* 0x654C: 08 95        ret */
/* 0x654E: ac c0        rjmp	.+344 */
/* 0x6550: 03 2e        mov	r0, r19 */
/* 0x6552: 00 20        tst	r0 */
/* 0x6554: 12 f4        brpl	.+4 */
/* 0x6556: 0e 94 60 32  <unknown> */
/* 0x655A: e0 2f        mov	r30, r16 */
/* 0x655C: 01 2f        mov	r16, r17 */
/* 0x655E: 12 2f        mov	r17, r18 */
/* 0x6560: 23 2f        mov	r18, r19 */
/* 0x6562: 3e e9        ldi	r19, 0x9e */
/* 0x6564: d1 cf        rjmp	.-94 */
/* 0x6566: 00 24        clr	r0 */
/* 0x6568: f8 cf        rjmp	.-16 */
/* 0x65A0: f9 01 ee 0f  <unknown> */
/* 0x65A4: ff 1f        rol	r31 */
/* 0x65A6: 37 fb        bst	r19, 0x7 */
/* 0x65A8: ff 3f        cpi	r31, 0xff */
/* 0x65AA: 31 f0        breq	.+12 */
/* 0x65AC: ef 2b        or	r30, r31 */
/* 0x65AE: e1 2b        or	r30, r17 */
/* 0x65B0: e0 2b        or	r30, r16 */
/* 0x65B2: 88 94        clc */
/* 0x65B4: b8 94        clv */
/* 0x65B6: 08 95        ret */
/* 0x65B8: e0 2b        or	r30, r16 */
/* 0x65BA: e1 2b        or	r30, r17 */
/* 0x65BC: 21 f0        breq	.+8 */
/* 0x65BE: 08 94        sec */
/* 0x65C0: 98 94        clz */
/* 0x65C2: b8 94        clv */
/* 0x65C4: 08 95        ret */
/* 0x65C6: 98 94        clz */
/* 0x65C8: 88 94        clc */
/* 0x65CA: 38 94        sev */
/* 0x65CC: 08 95        ret */
/* 0x65CE: fb 01 ee 0f  <unknown> */
/* 0x65D2: ff 1f        rol	r31 */
/* 0x65D4: 77 fb        bst	r23, 0x7 */
/* 0x65D6: ff 3f        cpi	r31, 0xff */
/* 0x65D8: 31 f0        breq	.+12 */
/* 0x65DA: ef 2b        or	r30, r31 */
/* 0x65DC: e5 2b        or	r30, r21 */
/* 0x65DE: e4 2b        or	r30, r20 */
/* 0x65E0: 88 94        clc */
/* 0x65E2: b8 94        clv */
/* 0x65E4: 08 95        ret */
/* 0x65E6: e4 2b        or	r30, r20 */
/* 0x65E8: e5 2b        or	r30, r21 */
/* 0x65EA: 69 f3        breq	.-38 */
/* 0x65EC: e8 cf        rjmp	.-48 */
/* 0x65EE: ef df        rcall	.-34 */
/* 0x65F0: 68 f0        brlo	.+26 */
/* 0x65F2: 21 f4        brne	.+8 */
/* 0x65F4: 37 23        and	r19, r23 */
/* 0x65F6: 26 2f        mov	r18, r22 */
/* 0x65F8: 8a 01 08 95  <unknown> */
/* 0x65FC: 37 2f        mov	r19, r23 */
/* 0x65FE: fb cf        rjmp	.-10 */
/* 0x6600: e6 df        rcall	.-52 */
/* 0x6602: 20 f0        brlo	.+8 */
/* 0x6604: 0b f0        brvs	.+2 */
/* 0x6606: 08 95        ret */
/* 0x6608: 73 27        eor	r23, r19 */
/* 0x660A: ea f7        brpl	.-6 */
/* 0x660C: 51 c0        rjmp	.+162 */
/* 0x660E: c8 df        rcall	.-112 */
/* 0x6610: e8 f3        brlo	.-6 */
/* 0x6612: b3 f3        brvs	.-20 */
/* 0x6614: 61 f3        breq	.-40 */
/* 0x6616: db df        rcall	.-74 */
/* 0x6618: c8 f3        brlo	.-14 */
/* 0x661A: 83 f3        brvs	.-32 */
/* 0x661C: a1 f3        breq	.-24 */
/* 0x661E: 58 df        rcall	.-336 */
/* 0x6620: 40 17        cp	r20, r16 */
/* 0x6622: 51 07        cpc	r21, r17 */
/* 0x6624: 62 07        cpc	r22, r18 */
/* 0x6626: 73 07        cpc	r23, r19 */
/* 0x6628: 31 f4        brne	.+12 */
/* 0x662A: 01 14        cp	r0, r1 */
/* 0x662C: 11 f1        breq	.+68 */
/* 0x662E: 00 24        clr	r0 */
/* 0x6630: e8 94        clt */
/* 0x6632: 88 94        clc */
/* 0x6634: 2b c0        rjmp	.+86 */
/* 0x6636: 78 f0        brlo	.+30 */
/* 0x6638: 33 2e        mov	r3, r19 */
/* 0x663A: 37 2f        mov	r19, r23 */
/* 0x663C: 73 2d        mov	r23, r3 */
/* 0x663E: 32 2e        mov	r3, r18 */
/* 0x6640: 26 2f        mov	r18, r22 */
/* 0x6642: 63 2d        mov	r22, r3 */
/* 0x6644: 31 2e        mov	r3, r17 */
/* 0x6646: 15 2f        mov	r17, r21 */
/* 0x6648: 53 2d        mov	r21, r3 */
/* 0x664A: 30 2e        mov	r3, r16 */
/* 0x664C: 04 2f        mov	r16, r20 */
/* 0x664E: 43 2d        mov	r20, r3 */
/* 0x6650: 30 2c        mov	r3, r0 */
/* 0x6652: 01 2c        mov	r0, r1 */
/* 0x6654: 13 2c        mov	r1, r3 */
/* 0x6656: 37 17        cp	r19, r23 */
/* 0x6658: 39 f0        breq	.+14 */
/* 0x665A: 66 95        lsr	r22 */
/* 0x665C: 57 95        ror	r21 */
/* 0x665E: 47 95        ror	r20 */
/* 0x6660: f7 95        ror	r31 */
/* 0x6662: e0 40        sbci	r30, 0x0 */
/* 0x6664: 73 95        inc	r23 */
/* 0x6666: f7 cf        rjmp	.-18 */
/* 0x6668: e7 fb        bst	r30, 0x7 */
/* 0x666A: ee 0f        lsl	r30 */
/* 0x666C: e0 e0        ldi	r30, 0x0 */
/* 0x666E: 10 24        eor	r1, r0 */
/* 0x6670: 6a f0        brmi	.+26 */
/* 0x6672: ef 0f        add	r30, r31 */
/* 0x6674: 04 1f        adc	r16, r20 */
/* 0x6676: 15 1f        adc	r17, r21 */
/* 0x6678: 26 1f        adc	r18, r22 */
/* 0x667A: 60 f4        brsh	.+24 */
/* 0x667C: 27 95        ror	r18 */
/* 0x667E: 17 95        ror	r17 */
/* 0x6680: 07 95        ror	r16 */
/* 0x6682: e7 95        ror	r30 */
/* 0x6684: 08 f4        brsh	.+2 */
/* 0x6686: 68 94        set */
/* 0x6688: 33 95        inc	r19 */
/* 0x668A: 3e cf        rjmp	.-388 */
/* 0x668C: ef 0b        sbc	r30, r31 */
/* 0x668E: 04 0b        sbc	r16, r20 */
/* 0x6690: 15 0b        sbc	r17, r21 */
/* 0x6692: 26 0b        sbc	r18, r22 */
/* 0x6694: 39 cf        rjmp	.-398 */
/* 0x6696: e0 e8        ldi	r30, 0x80 */
/* 0x6698: 7e 27        eor	r23, r30 */
/* 0x669A: b9 cf        rjmp	.-142 */
/* 0x669C: 30 2d        mov	r19, r0 */
/* 0x669E: 30 78        andi	r19, 0x80 */
/* 0x66A0: 22 27        clr	r18 */
/* 0x66A2: 11 27        clr	r17 */
/* 0x66A4: 00 27        clr	r16 */
/* 0x66A6: 08 95        ret */
/* 0x66A8: 3f e7        ldi	r19, 0x7f */
/* 0x66AA: 30 29        or	r19, r0 */
/* 0x66AC: 20 e8        ldi	r18, 0x80 */
/* 0x66AE: f9 cf        rjmp	.-14 */
/* 0x66B0: 3f ef        ldi	r19, 0xff */
/* 0x66B2: 2f ef        ldi	r18, 0xff */
/* 0x66B4: f6 cf        rjmp	.-20 */
/* 0x66B6: 8b df        rcall	.-234 */
/* 0x66B8: d8 f3        brlo	.-10 */
/* 0x66BA: d1 f3        breq	.-12 */
/* 0x66BC: 70 78        andi	r23, 0x80 */
/* 0x66BE: 37 27        eor	r19, r23 */
/* 0x66C0: 08 95        ret */
/* 0x66C2: 85 df        rcall	.-246 */
/* 0x66C4: a8 f3        brlo	.-22 */
/* 0x66C6: a3 f3        brvs	.-24 */
/* 0x66C8: f9 cf        rjmp	.-14 */
/* 0x66CA: 30 78        andi	r19, 0x80 */
/* 0x66CC: 37 27        eor	r19, r23 */
/* 0x66CE: 93 cf        rjmp	.-218 */
/* 0x66D0: 67 df        rcall	.-306 */
/* 0x66D2: 70 f3        brlo	.-36 */
/* 0x66D4: 83 f3        brvs	.-32 */
/* 0x66D6: a9 f3        breq	.-22 */
/* 0x66D8: 7a df        rcall	.-268 */
/* 0x66DA: 50 f3        brlo	.-44 */
/* 0x66DC: b3 f3        brvs	.-20 */
/* 0x66DE: a9 f3        breq	.-22 */
/* 0x66E0: f7 de        rcall	.-530 */
/* 0x66E2: 01 24        eor	r0, r1 */
/* 0x66E4: e8 94        clt */
/* 0x66E6: 3f 57        subi	r19, 0x7f */
/* 0x66E8: e0 40        sbci	r30, 0x0 */
/* 0x66EA: 37 0f        add	r19, r23 */
/* 0x66EC: ef 1f        adc	r30, r31 */
/* 0x66EE: 12 f0        brmi	.+4 */
/* 0x66F0: d9 f6        brne	.-74 */
/* 0x66F2: 03 c0        rjmp	.+6 */
/* 0x66F4: 3a 3e        cpi	r19, 0xea */
/* 0x66F6: 90 f2        brlo	.-92 */
/* 0x66F8: 68 94        set */
/* 0x66FA: e0 e0        ldi	r30, 0x0 */
/* 0x66FC: 0a 92        st	-Y, r0 */
/* 0x66FE: aa 93        st	-Y, r26 */
/* 0x6700: 3a 93        st	-Y, r19 */
/* 0x6702: aa 27        clr	r26 */
/* 0x6704: 33 24        clr	r3 */
/* 0x6706: 22 24        clr	r2 */
/* 0x6708: 33 27        clr	r19 */
/* 0x670A: 04 9f f0 01  <unknown> */
/* 0x670E: 05 9f f0 0d  <unknown> */
/* 0x6712: 71 2d        mov	r23, r1 */
/* 0x6714: 73 1f        adc	r23, r19 */
/* 0x6716: 14 9f f0 0d  <unknown> */
/* 0x671A: 71 1d        adc	r23, r1 */
/* 0x671C: 22 1c        rol	r2 */
/* 0x671E: 06 9f 70 0d  <unknown> */
/* 0x6722: 21 1c        adc	r2, r1 */
/* 0x6724: 33 1c        rol	r3 */
/* 0x6726: 15 9f 70 0d  <unknown> */
/* 0x672A: 21 1c        adc	r2, r1 */
/* 0x672C: 33 1e        adc	r3, r19 */
/* 0x672E: 24 9f 70 0d  <unknown> */
/* 0x6732: 21 1c        adc	r2, r1 */
/* 0x6734: 33 1e        adc	r3, r19 */
/* 0x6736: 16 9f 20 0c  <unknown> */
/* 0x673A: 31 1c        adc	r3, r1 */
/* 0x673C: aa 1f        rol	r26 */
/* 0x673E: 25 9f 20 0c  <unknown> */
/* 0x6742: 31 1c        adc	r3, r1 */
/* 0x6744: a3 1f        adc	r26, r19 */
/* 0x6746: 26 9f 30 0c  <unknown> */
/* 0x674A: a1 1d        adc	r26, r1 */
/* 0x674C: 39 91        ld	r19, Y+ */
/* 0x674E: 5e f4        brtc	.+22 */
/* 0x6750: 33 95        inc	r19 */
/* 0x6752: a6 95        lsr	r26 */
/* 0x6754: 37 94        ror	r3 */
/* 0x6756: 27 94        ror	r2 */
/* 0x6758: 77 95        ror	r23 */
/* 0x675A: f7 95        ror	r31 */
/* 0x675C: e7 95        ror	r30 */
/* 0x675E: 33 95        inc	r19 */
/* 0x6760: 31 30        cpi	r19, 0x1 */
/* 0x6762: bc f3        brlt	.-18 */
/* 0x6764: 16 c0        rjmp	.+44 */
/* 0x6766: aa 23        tst	r26 */
/* 0x6768: 22 f0        brmi	.+8 */
/* 0x676A: 33 23        tst	r19 */
/* 0x676C: 51 f4        brne	.+20 */
/* 0x676E: 33 95        inc	r19 */
/* 0x6770: 10 c0        rjmp	.+32 */
/* 0x6772: 33 95        inc	r19 */
/* 0x6774: 71 f4        brne	.+28 */
/* 0x6776: a9 91        ld	r26, Y+ */
/* 0x6778: 09 90        ld	r0, Y+ */
/* 0x677A: 96 cf        rjmp	.-212 */
/* 0x677C: a7 fd        sbrc	r26, 0x7 */
/* 0x677E: 09 c0        rjmp	.+18 */
/* 0x6780: 3a 95        dec	r19 */
/* 0x6782: ee 0f        lsl	r30 */
/* 0x6784: ff 1f        rol	r31 */
/* 0x6786: 77 1f        rol	r23 */
/* 0x6788: 22 1c        rol	r2 */
/* 0x678A: 33 1c        rol	r3 */
/* 0x678C: aa 1f        rol	r26 */
/* 0x678E: 32 30        cpi	r19, 0x2 */
/* 0x6790: a8 f7        brsh	.-22 */
/* 0x6792: e8 94        clt */
/* 0x6794: fe 2b        or	r31, r30 */
/* 0x6796: 09 f0        breq	.+2 */
/* 0x6798: 68 94        set */
/* 0x679A: 2a 2f        mov	r18, r26 */
/* 0x679C: 81 01 e7 2f  <unknown> */
/* 0x67A0: a9 91        ld	r26, Y+ */
/* 0x67A2: 09 90        ld	r0, Y+ */
/* 0x67A4: ba ce        rjmp	.-652 */
/* 0x67A6: 13 df        rcall	.-474 */
/* 0x67A8: 10 f0        brlo	.+4 */
/* 0x67AA: 0b f0        brvs	.+2 */
/* 0x67AC: 87 cf        rjmp	.-242 */
/* 0x67AE: 80 cf        rjmp	.-256 */
/* 0x67B0: 0e df        rcall	.-484 */
/* 0x67B2: e9 f3        breq	.-6 */
/* 0x67B4: e0 f3        brlo	.-8 */
/* 0x67B6: 03 2e        mov	r0, r19 */
/* 0x67B8: 07 26        eor	r0, r23 */
/* 0x67BA: 70 cf        rjmp	.-288 */
/* 0x67BC: 03 2e        mov	r0, r19 */
/* 0x67BE: 07 26        eor	r0, r23 */
/* 0x67C0: 73 cf        rjmp	.-282 */
/* 0x67C2: ee de        rcall	.-548 */
/* 0x67C4: a0 f3        brlo	.-24 */
/* 0x67C6: 7b f3        brvs	.-34 */
/* 0x67C8: 99 f3        breq	.-26 */
/* 0x67CA: 01 df        rcall	.-510 */
/* 0x67CC: 80 f3        brlo	.-32 */
/* 0x67CE: 9b f3        brvs	.-26 */
/* 0x67D0: a9 f3        breq	.-22 */
/* 0x67D2: 7e de        rcall	.-772 */
/* 0x67D4: 01 24        eor	r0, r1 */
/* 0x67D6: 27 fd        sbrc	r18, 0x7 */
/* 0x67D8: 06 c0        rjmp	.+12 */
/* 0x67DA: 00 0f        lsl	r16 */
/* 0x67DC: 11 1f        rol	r17 */
/* 0x67DE: 22 1f        rol	r18 */
/* 0x67E0: 31 50        subi	r19, 0x1 */
/* 0x67E2: e0 40        sbci	r30, 0x0 */
/* 0x67E4: f8 cf        rjmp	.-16 */
/* 0x67E6: 67 fd        sbrc	r22, 0x7 */
/* 0x67E8: 06 c0        rjmp	.+12 */
/* 0x67EA: 44 0f        lsl	r20 */
/* 0x67EC: 55 1f        rol	r21 */
/* 0x67EE: 66 1f        rol	r22 */
/* 0x67F0: 71 50        subi	r23, 0x1 */
/* 0x67F2: f0 40        sbci	r31, 0x0 */
/* 0x67F4: f8 cf        rjmp	.-16 */
/* 0x67F6: e8 94        clt */
/* 0x67F8: 37 1b        sub	r19, r23 */
/* 0x67FA: ef 0b        sbc	r30, r31 */
/* 0x67FC: 31 58        subi	r19, 0x81 */
/* 0x67FE: ef 4f        sbci	r30, 0xff */
/* 0x6800: 2a f0        brmi	.+10 */
/* 0x6802: ee 23        tst	r30 */
/* 0x6804: e9 f6        brne	.-70 */
/* 0x6806: 3f 3f        cpi	r19, 0xff */
/* 0x6808: d9 f2        breq	.-74 */
/* 0x680A: 03 c0        rjmp	.+6 */
/* 0x680C: 3a 3e        cpi	r19, 0xea */
/* 0x680E: a8 f2        brlo	.-86 */
/* 0x6810: 68 94        set */
/* 0x6812: e0 e0        ldi	r30, 0x0 */
/* 0x6814: f0 e0        ldi	r31, 0x0 */
/* 0x6816: 11 24        clr	r1 */
/* 0x6818: 13 94        inc	r1 */
/* 0x681A: 40 17        cp	r20, r16 */
/* 0x681C: 51 07        cpc	r21, r17 */
/* 0x681E: 62 07        cpc	r22, r18 */
/* 0x6820: 38 f0        brlo	.+14 */
/* 0x6822: 31 50        subi	r19, 0x1 */
/* 0x6824: 08 f4        brsh	.+2 */
/* 0x6826: 68 94        set */
/* 0x6828: 00 0f        lsl	r16 */
/* 0x682A: 11 1f        rol	r17 */
/* 0x682C: 22 1f        rol	r18 */
/* 0x682E: ee 1f        rol	r30 */
/* 0x6830: 04 1b        sub	r16, r20 */
/* 0x6832: 15 0b        sbc	r17, r21 */
/* 0x6834: 26 0b        sbc	r18, r22 */
/* 0x6836: ef 0b        sbc	r30, r31 */
/* 0x6838: 00 0f        lsl	r16 */
/* 0x683A: 11 1f        rol	r17 */
/* 0x683C: 22 1f        rol	r18 */
/* 0x683E: ee 1f        rol	r30 */
/* 0x6840: aa 93        st	-Y, r26 */
/* 0x6842: 79 e1        ldi	r23, 0x19 */
/* 0x6844: 7a 95        dec	r23 */
/* 0x6846: aa f0        brmi	.+42 */
/* 0x6848: 04 17        cp	r16, r20 */
/* 0x684A: 15 07        cpc	r17, r21 */
/* 0x684C: 26 07        cpc	r18, r22 */
/* 0x684E: ef 07        cpc	r30, r31 */
/* 0x6850: 30 f0        brlo	.+12 */
/* 0x6852: 04 1b        sub	r16, r20 */
/* 0x6854: 15 0b        sbc	r17, r21 */
/* 0x6856: 26 0b        sbc	r18, r22 */
/* 0x6858: ef 0b        sbc	r30, r31 */
/* 0x685A: 08 94        sec */
/* 0x685C: 01 c0        rjmp	.+2 */
/* 0x685E: 88 94        clc */
/* 0x6860: 11 1c        rol	r1 */
/* 0x6862: 22 1c        rol	r2 */
/* 0x6864: 33 1c        rol	r3 */
/* 0x6866: aa 1f        rol	r26 */
/* 0x6868: 00 0f        lsl	r16 */
/* 0x686A: 11 1f        rol	r17 */
/* 0x686C: 22 1f        rol	r18 */
/* 0x686E: ee 1f        rol	r30 */
/* 0x6870: e9 cf        rjmp	.-46 */
/* 0x6872: f0 f9        bld	r31, 0x0 */
/* 0x6874: e8 94        clt */
/* 0x6876: e2 2b        or	r30, r18 */
/* 0x6878: e1 2b        or	r30, r17 */
/* 0x687A: e0 2b        or	r30, r16 */
/* 0x687C: 09 f0        breq	.+2 */
/* 0x687E: 68 94        set */
/* 0x6880: a6 95        lsr	r26 */
/* 0x6882: 37 94        ror	r3 */
/* 0x6884: 27 94        ror	r2 */
/* 0x6886: 17 94        ror	r1 */
/* 0x6888: e7 95        ror	r30 */
/* 0x688A: 08 f4        brsh	.+2 */
/* 0x688C: 68 94        set */
/* 0x688E: 73 95        inc	r23 */
/* 0x6890: b9 f3        breq	.-18 */
/* 0x6892: a9 91        ld	r26, Y+ */
/* 0x6894: 33 23        tst	r19 */
/* 0x6896: 11 f0        breq	.+4 */
/* 0x6898: f0 ff        sbrs	r31, 0x0 */
/* 0x689A: 09 c0        rjmp	.+18 */
/* 0x689C: 36 94        lsr	r3 */
/* 0x689E: 27 94        ror	r2 */
/* 0x68A0: 17 94        ror	r1 */
/* 0x68A2: e7 95        ror	r30 */
/* 0x68A4: 08 f4        brsh	.+2 */
/* 0x68A6: 68 94        set */
/* 0x68A8: 33 95        inc	r19 */
/* 0x68AA: 31 30        cpi	r19, 0x1 */
/* 0x68AC: bc f3        brlt	.-18 */
/* 0x68AE: 01 2d        mov	r16, r1 */
/* 0x68B0: 12 2d        mov	r17, r2 */
/* 0x68B2: 23 2d        mov	r18, r3 */
/* 0x68B4: 32 ce        rjmp	.-924 */
/* 0x68D4: 7c de        rcall	.-776 */
/* 0x68D6: a0 f0        brlo	.+40 */
/* 0x68D8: 63 de        rcall	.-826 */
/* 0x68DA: 90 f0        brlo	.+36 */
/* 0x68DC: 29 f0        breq	.+10 */
/* 0x68DE: e3 2f        mov	r30, r19 */
/* 0x68E0: e7 27        eor	r30, r23 */
/* 0x68E2: 3a f4        brpl	.+14 */
/* 0x68E4: 73 17        cp	r23, r19 */
/* 0x68E6: 08 95        ret */
/* 0x68E8: 72 de        rcall	.-796 */
/* 0x68EA: 51 f0        breq	.+20 */
/* 0x68EC: 4e f0        brts	.+18 */
/* 0x68EE: 08 94        sec */
/* 0x68F0: 08 95        ret */
/* 0x68F2: 04 17        cp	r16, r20 */
/* 0x68F4: 15 07        cpc	r17, r21 */
/* 0x68F6: 26 07        cpc	r18, r22 */
/* 0x68F8: 37 07        cpc	r19, r23 */
/* 0x68FA: 19 f0        breq	.+6 */
/* 0x68FC: 16 f4        brtc	.+4 */
/* 0x68FE: b8 f7        brsh	.-18 */
/* 0x6900: 88 94        clc */
/* 0x6902: 08 95        ret */
/* 0x6904: 64 de        rcall	.-824 */
/* 0x6906: e0 f3        brlo	.-8 */
/* 0x6908: 4b de        rcall	.-874 */
/* 0x690A: d0 f3        brlo	.-12 */
/* 0x690C: e7 df        rcall	.-50 */
/* 0x690E: c0 f3        brlo	.-16 */
/* 0x6910: 08 94        sec */
/* 0x6912: 08 95        ret */
/* 0x6926: f9 df        rcall	.-14 */
/* 0x6928: 04 1b        sub	r16, r20 */
/* 0x692A: 10 e0        ldi	r17, 0x0 */
/* 0x692C: 03 c0        rjmp	.+6 */
/* 0x6934: 20 e0        ldi	r18, 0x0 */
/* 0x6936: 30 e0        ldi	r19, 0x0 */
/* 0x6938: 05 c0        rjmp	.+10 */
/* 0x6944: b8 f0        brlo	.+46 */
/* 0x6946: 10 fc        sbrc	r1, 0x0 */
/* 0x6948: 17 c0        rjmp	.+46 */
/* 0x694A: 45 91 05 90  <unknown> */
/* 0x694E: e0 0f        add	r30, r16 */
/* 0x6950: f1 1f        adc	r31, r17 */
/* 0x6952: 04 17        cp	r16, r20 */
/* 0x6954: 10 05        cpc	r17, r0 */
/* 0x6956: 40 e0        ldi	r20, 0x0 */
/* 0x6958: 24 07        cpc	r18, r20 */
/* 0x695A: 34 07        cpc	r19, r20 */
/* 0x695C: 58 f4        brsh	.+22 */
/* 0x695E: 36 f4        brtc	.+12 */
/* 0x6960: 04 91 00 24  <unknown> */
/* 0x6964: f1 01 e0 1b  <unknown> */
/* 0x6968: f0 09        sbc	r31, r0 */
/* 0x696A: 09 94 e0 0f  <unknown> */
/* 0x6970: 25 90 35 90  <unknown> */
/* 0x6974: f1 01 09 94  <unknown> */
/* 0x6978: 11 f4        brne	.+4 */
/* 0x697A: d6 f7        brtc	.-12 */
/* 0x697C: f1 cf        rjmp	.-30 */
/* 0x697E: 31 96 0e f0  <unknown> */
/* 0x6982: 31 96 50 e0  <unknown> */
/* 0x6986: 60 e0        ldi	r22, 0x0 */
/* 0x6988: 70 e0        ldi	r23, 0x0 */
/* 0x698A: 45 91 4b 3f  <unknown> */
/* 0x698E: 48 f0        brlo	.+18 */
/* 0x6990: 89 f3        breq	.-30 */
/* 0x6992: 4f 3f        cpi	r20, 0xff */
/* 0x6994: 29 f0        breq	.+10 */
/* 0x6996: 4e 3f        cpi	r20, 0xfe */
/* 0x6998: 11 f0        breq	.+4 */
/* 0x699A: 75 91 65 91  <unknown> */
/* 0x699E: 55 91 45 91  <unknown> */
/* 0x69A2: 04 1b        sub	r16, r20 */
/* 0x69A4: 15 0b        sbc	r17, r21 */
/* 0x69A6: 26 0b        sbc	r18, r22 */
/* 0x69A8: 37 0b        sbc	r19, r23 */
/* 0x69AA: 39 f3        breq	.-50 */
/* 0x69AC: 18 f3        brlo	.-58 */
/* 0x69AE: e7 cf        rjmp	.-50 */
/* 0x69C6: fa 92        st	-Y, r15 */
/* 0x69C8: ea 92        st	-Y, r14 */
/* 0x69CA: da 92        st	-Y, r13 */
/* 0x69CC: ca 92        st	-Y, r12 */
/* 0x69CE: ba 92        st	-Y, r11 */
/* 0x69D0: aa 92        st	-Y, r10 */
/* 0x69D2: 9a 92        st	-Y, r9 */
/* 0x69D4: 8a 92        st	-Y, r8 */
/* 0x69D6: 7a 92        st	-Y, r7 */
/* 0x69D8: 6a 92        st	-Y, r6 */
/* 0x69DA: 5a 92        st	-Y, r5 */
/* 0x69DC: 4a 92        st	-Y, r4 */
/* 0x69DE: ba 93        st	-Y, r27 */
/* 0x69E0: aa 93        st	-Y, r26 */
/* 0x69E2: 9a 93        st	-Y, r25 */
/* 0x69E4: 8a 93        st	-Y, r24 */
/* 0x69E6: 08 95        ret */
/* 0x69E8: ff 84        ldd	r15, Y+7 */
/* 0x69EA: ee 84        ldd	r14, Y+6 */
/* 0x69EC: dd 84        ldd	r13, Y+5 */
/* 0x69EE: cc 84        ldd	r12, Y+4 */
/* 0x69F0: bb 84        ldd	r11, Y+3 */
/* 0x69F2: aa 84        ldd	r10, Y+2 */
/* 0x69F4: 99 84        ldd	r9, Y+1 */
/* 0x69F6: 88 84        ldd	r8, Y+0 */
/* 0x69F8: 7f 80        ldd	r7, Y+7 */
/* 0x69FA: 6e 80        ldd	r6, Y+6 */
/* 0x69FC: 5d 80        ldd	r5, Y+5 */
/* 0x69FE: 4c 80        ldd	r4, Y+4 */
/* 0x6A00: bb 81        ldd	r27, Y+3 */
/* 0x6A02: aa 81        ldd	r26, Y+2 */
/* 0x6A04: 99 81        ldd	r25, Y+1 */
/* 0x6A06: 88 81        ldd	r24, Y+0 */
/* 0x6A08: f0 e0        ldi	r31, 0x0 */
/* 0x6A0A: ec 0f        add	r30, r28 */
/* 0x6A0C: fd 1f        adc	r31, r29 */
/* 0x6A0E: ef 01 08 95  <unknown> */
/* 0x6A12: 80 81        ldd	r24, Z+0 */
/* 0x6A14: 08 17        cp	r16, r24 */
/* 0x6A16: 81 81        ldd	r24, Z+1 */
/* 0x6A18: 18 07        cpc	r17, r24 */
/* 0x6A1A: 82 81        ldd	r24, Z+2 */
/* 0x6A1C: 28 07        cpc	r18, r24 */
/* 0x6A1E: 83 81        ldd	r24, Z+3 */
/* 0x6A20: 38 07        cpc	r19, r24 */
/* 0x6A22: 84 81        ldd	r24, Z+4 */
/* 0x6A24: 48 07        cpc	r20, r24 */
/* 0x6A26: 85 81        ldd	r24, Z+5 */
/* 0x6A28: 58 07        cpc	r21, r24 */
/* 0x6A2A: 86 81        ldd	r24, Z+6 */
/* 0x6A2C: 68 07        cpc	r22, r24 */
/* 0x6A2E: 87 81        ldd	r24, Z+7 */
/* 0x6A30: 78 07        cpc	r23, r24 */
/* 0x6A32: 08 95        ret */
/* 0x6A34: 01 e0        ldi	r16, 0x1 */
/* 0x6A36: 08 95        ret */
/* 0x6A78: 0c 94 3e 35  <unknown> */
/* 0x6A7C: 9a 93        st	-Y, r25 */
/* 0x6A7E: 8a 93        st	-Y, r24 */
/* 0x6A80: c8 01 02 c0  <unknown> */
/* 0x6A84: 0e 94 5b 35  <unknown> */
/* 0x6A88: 8c 01 0e 94  <unknown> */
/* 0x6A8C: 90 37        cpi	r25, 0x70 */
/* 0x6A8E: 20 2f        mov	r18, r16 */
/* 0x6A90: 01 2b        or	r16, r17 */
/* 0x6A92: 69 f4        brne	.+26 */
/* 0x6A94: ec e7        ldi	r30, 0x7c */
/* 0x6A96: f7 e0        ldi	r31, 0x7 */
/* 0x6A98: 20 81        ldd	r18, Z+0 */
/* 0x6A9A: 31 81        ldd	r19, Z+1 */
/* 0x6A9C: 00 e0        ldi	r16, 0x0 */
/* 0x6A9E: 20 30        cpi	r18, 0x0 */
/* 0x6AA0: 30 07        cpc	r19, r16 */
/* 0x6AA2: 81 f3        breq	.-32 */
/* 0x6AA4: e0 91 7c 07  <unknown> */
/* 0x6AA8: f3 2f        mov	r31, r19 */
/* 0x6AAA: 09 95 ed cf  <unknown> */
/* 0x6AAE: 02 2f        mov	r16, r18 */
/* 0x6AB0: 89 91        ld	r24, Y+ */
/* 0x6AB2: 99 91        ld	r25, Y+ */
/* 0x6AB4: 08 95        ret */
/* 0x6AB6: 0c 94 f2 30  <unknown> */
/* 0x6ABA: 22 97 9e 01  <unknown> */
/* 0x6ABE: 2e 5f        subi	r18, 0xfe */
/* 0x6AC0: 3f 4f        sbci	r19, 0xff */
/* 0x6AC2: 28 83        std	Y+0, r18 */
/* 0x6AC4: 39 83        std	Y+1, r19 */
/* 0x6AC6: be 01 a8 01  <unknown> */
/* 0x6ACA: 21 e0        ldi	r18, 0x1 */
/* 0x6ACC: 30 e0        ldi	r19, 0x0 */
/* 0x6ACE: 04 ec        ldi	r16, 0xc4 */
/* 0x6AD0: 16 e3        ldi	r17, 0x36 */
/* 0x6AD2: 0e 94 0b 36  <unknown> */
/* 0x6AD6: 22 96 08 95  <unknown> */
/* 0x6ADA: 10 e0        ldi	r17, 0x0 */
/* 0x6ADC: 0c 94 b4 20  <unknown> */
/* 0x6AE0: 22 97 9e 01  <unknown> */
/* 0x6AE4: 2e 5f        subi	r18, 0xfe */
/* 0x6AE6: 3f 4f        sbci	r19, 0xff */
/* 0x6AE8: 28 83        std	Y+0, r18 */
/* 0x6AEA: 39 83        std	Y+1, r19 */
/* 0x6AEC: be 01 40 e0  <unknown> */
/* 0x6AF0: 50 e0        ldi	r21, 0x0 */
/* 0x6AF2: 2d e6        ldi	r18, 0x6d */
/* 0x6AF4: 35 e3        ldi	r19, 0x35 */
/* 0x6AF6: 0e 94 71 2e  <unknown> */
/* 0x6AFA: 22 96 08 95  <unknown> */
/* 0x6AFE: 20 e0        ldi	r18, 0x0 */
/* 0x6B00: 06 d0        rcall	.+12 */
/* 0x6B02: e9 f7        brne	.-6 */
/* 0x6B04: 08 95        ret */
/* 0x6B0E: 2d 93        st	X+, r18 */
/* 0x6B10: 01 50        subi	r16, 0x1 */
/* 0x6B12: 10 40        sbci	r17, 0x0 */
/* 0x6B14: 20 2f        mov	r18, r16 */
/* 0x6B16: 21 2b        or	r18, r17 */
/* 0x6B18: 08 95        ret */
/* 0x6B1A: 82 ed        ldi	r24, 0xd2 */
/* 0x6B1C: 9f e6        ldi	r25, 0x6f */
/* 0x6B1E: fc 01 05 91  <unknown> */
/* 0x6B22: 14 91 fc 01  <unknown> */
/* 0x6B26: 32 96 a5 91  <unknown> */
/* 0x6B2A: b4 91 fc 01  <unknown> */
/* 0x6B2E: 34 96 25 91  <unknown> */
/* 0x6B32: 34 91 42 2f  <unknown> */
/* 0x6B36: 43 2b        or	r20, r19 */
/* 0x6B38: 19 f0        breq	.+6 */
/* 0x6B3A: f9 01 e4 df  <unknown> */
/* 0x6B3E: 01 c0        rjmp	.+2 */
/* 0x6B40: de df        rcall	.-68 */
/* 0x6B42: 06 96 1f e6  <unknown> */
/* 0x6B46: 8e 3d        cpi	r24, 0xde */
/* 0x6B48: 91 07        cpc	r25, r17 */
/* 0x6B4A: 48 f3        brlo	.-46 */
/* 0x6B4C: 08 95        ret */
/* 0x6B6A: ba 93        st	-Y, r27 */
/* 0x6B6C: aa 93        st	-Y, r26 */
/* 0x6B6E: 24 97 0a 83  <unknown> */
/* 0x6B72: 1b 83        std	Y+3, r17 */
/* 0x6B74: 89 01 9e 01  <unknown> */
/* 0x6B78: 2a 5f        subi	r18, 0xfa */
/* 0x6B7A: 3f 4f        sbci	r19, 0xff */
/* 0x6B7C: 28 83        std	Y+0, r18 */
/* 0x6B7E: 39 83        std	Y+1, r19 */
/* 0x6B80: be 01 ae 01  <unknown> */
/* 0x6B84: 4e 5f        subi	r20, 0xfe */
/* 0x6B86: 5f 4f        sbci	r21, 0xff */
/* 0x6B88: 27 ea        ldi	r18, 0xa7 */
/* 0x6B8A: 35 e3        ldi	r19, 0x35 */
/* 0x6B8C: 0e 94 71 2e  <unknown> */
/* 0x6B90: 20 e0        ldi	r18, 0x0 */
/* 0x6B92: aa 81        ldd	r26, Y+2 */
/* 0x6B94: bb 81        ldd	r27, Y+3 */
/* 0x6B96: 2c 93        st	X, r18 */
/* 0x6B98: 24 96 a9 91  <unknown> */
/* 0x6B9C: b9 91        ld	r27, Y+ */
/* 0x6B9E: 08 95        ret */
/* 0x6BEC: 0e 94 ed 34  <unknown> */
/* 0x6BF0: d8 01 89 01  <unknown> */
/* 0x6BF4: ca 01 2b 01  <unknown> */
/* 0x6BF8: 08 c0        rjmp	.+16 */
/* 0x6BFA: fc 01 21 91  <unknown> */
/* 0x6BFE: cf 01 fd 01  <unknown> */
/* 0x6C02: 09 95 2f ef  <unknown> */
/* 0x6C06: 42 0e        add	r4, r18 */
/* 0x6C08: 52 1e        adc	r5, r18 */
/* 0x6C0A: 24 2d        mov	r18, r4 */
/* 0x6C0C: 25 29        or	r18, r5 */
/* 0x6C0E: a9 f7        brne	.-22 */
/* 0x6C10: e6 e0        ldi	r30, 0x6 */
/* 0x6C12: 0c 94 fe 34  <unknown> */
/* 0x6C16: 0e 94 e4 34  <unknown> */
/* 0x6C1A: 28 97 08 83  <unknown> */
/* 0x6C1E: 19 83        std	Y+1, r17 */
/* 0x6C20: c9 01 6a 01  <unknown> */
/* 0x6C24: 5b 01 04 c0  <unknown> */
/* 0x6C28: 97 d0        rcall	.+302 */
/* 0x6C2A: a6 01 9d d0  <unknown> */
/* 0x6C2E: 8f d0        rcall	.+286 */
/* 0x6C30: f6 01 00 81  <unknown> */
/* 0x6C34: 00 23        tst	r16 */
/* 0x6C36: 31 f4        brne	.+12 */
/* 0x6C38: 00 e0        ldi	r16, 0x0 */
/* 0x6C3A: 10 e0        ldi	r17, 0x0 */
/* 0x6C3C: 28 96 ef e0  <unknown> */
/* 0x6C40: 0c 94 f5 34  <unknown> */
/* 0x6C44: 05 32        cpi	r16, 0x25 */
/* 0x6C46: 81 f7        brne	.-32 */
/* 0x6C48: 82 d0        rcall	.+260 */
/* 0x6C4A: f6 01 41 90  <unknown> */
/* 0x6C4E: 6f 01 04 2d  <unknown> */
/* 0x6C52: 05 52        subi	r16, 0x25 */
/* 0x6C54: 09 f4        brne	.+2 */
/* 0x6C56: 77 c0        rjmp	.+238 */
/* 0x6C58: 03 53        subi	r16, 0x33 */
/* 0x6C5A: 09 f4        brne	.+2 */
/* 0x6C5C: 63 c0        rjmp	.+198 */
/* 0x6C5E: 0b 50        subi	r16, 0xb */
/* 0x6C60: a1 f0        breq	.+40 */
/* 0x6C62: 0a 95        dec	r16 */
/* 0x6C64: f1 f0        breq	.+60 */
/* 0x6C66: 05 50        subi	r16, 0x5 */
/* 0x6C68: e1 f0        breq	.+56 */
/* 0x6C6A: 06 50        subi	r16, 0x6 */
/* 0x6C6C: 09 f4        brne	.+2 */
/* 0x6C6E: 5a c0        rjmp	.+180 */
/* 0x6C70: 0a 95        dec	r16 */
/* 0x6C72: 09 f4        brne	.+2 */
/* 0x6C74: 59 c0        rjmp	.+178 */
/* 0x6C76: 03 50        subi	r16, 0x3 */
/* 0x6C78: 09 f4        brne	.+2 */
/* 0x6C7A: 5a c0        rjmp	.+180 */
/* 0x6C7C: 02 50        subi	r16, 0x2 */
/* 0x6C7E: 09 f4        brne	.+2 */
/* 0x6C80: 51 c0        rjmp	.+162 */
/* 0x6C82: 03 50        subi	r16, 0x3 */
/* 0x6C84: 09 f4        brne	.+2 */
/* 0x6C86: 4e c0        rjmp	.+156 */
/* 0x6C88: d3 cf        rjmp	.-90 */
/* 0x6C8A: 7a d0        rcall	.+244 */
/* 0x6C8C: 0d 91        ld	r16, X+ */
/* 0x6C8E: 11 96 a0 83  <unknown> */
/* 0x6C92: b1 83        std	Z+1, r27 */
/* 0x6C94: 0a 83        std	Y+2, r16 */
/* 0x6C96: 60 d0        rcall	.+192 */
/* 0x6C98: ae 01 4e 5f  <unknown> */
/* 0x6C9C: 5f 4f        sbci	r21, 0xff */
/* 0x6C9E: 64 d0        rcall	.+200 */
/* 0x6CA0: c7 cf        rjmp	.-114 */
/* 0x6CA2: 68 d0        rcall	.+208 */
/* 0x6CA4: 77 20        tst	r7 */
/* 0x6CA6: 22 f4        brpl	.+8 */
/* 0x6CA8: 57 d0        rcall	.+174 */
/* 0x6CAA: 4f e6        ldi	r20, 0x6f */
/* 0x6CAC: 56 e0        ldi	r21, 0x6 */
/* 0x6CAE: 5c d0        rcall	.+184 */
/* 0x6CB0: 0f e6        ldi	r16, 0x6f */
/* 0x6CB2: 40 16        cp	r4, r16 */
/* 0x6CB4: 11 f4        brne	.+4 */
/* 0x6CB6: 08 e0        ldi	r16, 0x8 */
/* 0x6CB8: 07 c0        rjmp	.+14 */
/* 0x6CBA: 04 2d        mov	r16, r4 */
/* 0x6CBC: 00 62        ori	r16, 0x20 */
/* 0x6CBE: 08 37        cpi	r16, 0x78 */
/* 0x6CC0: 11 f0        breq	.+4 */
/* 0x6CC2: 0a e0        ldi	r16, 0xa */
/* 0x6CC4: 01 c0        rjmp	.+2 */
/* 0x6CC6: 00 e1        ldi	r16, 0x10 */
/* 0x6CC8: e0 2e        mov	r14, r16 */
/* 0x6CCA: 06 e0        ldi	r16, 0x6 */
/* 0x6CCC: 80 2e        mov	r8, r16 */
/* 0x6CCE: 99 24        clr	r9 */
/* 0x6CD0: d3 01 04 e6  <unknown> */
/* 0x6CD4: 40 16        cp	r4, r16 */
/* 0x6CD6: 29 f4        brne	.+10 */
/* 0x6CD8: 77 20        tst	r7 */
/* 0x6CDA: 1a f4        brpl	.+6 */
/* 0x6CDC: b1 95        neg	r27 */
/* 0x6CDE: a1 95        neg	r26 */
/* 0x6CE0: b0 40        sbci	r27, 0x0 */
/* 0x6CE2: 0f ef        ldi	r16, 0xff */
/* 0x6CE4: 80 0e        add	r8, r16 */
/* 0x6CE6: 90 1e        adc	r9, r16 */
/* 0x6CE8: 3a d0        rcall	.+116 */
/* 0x6CEA: 40 5d        subi	r20, 0xd0 */
/* 0x6CEC: 4a 33        cpi	r20, 0x3a */
/* 0x6CEE: 18 f0        brlo	.+6 */
/* 0x6CF0: 04 2d        mov	r16, r4 */
/* 0x6CF2: 01 55        subi	r16, 0x51 */
/* 0x6CF4: 40 0f        add	r20, r16 */
/* 0x6CF6: 8e 01 0e 5f  <unknown> */
/* 0x6CFA: 1f 4f        sbci	r17, 0xff */
/* 0x6CFC: 08 0d        add	r16, r8 */
/* 0x6CFE: 19 1d        adc	r17, r9 */
/* 0x6D00: 38 01 f8 01  <unknown> */
/* 0x6D04: 40 83        std	Z+0, r20 */
/* 0x6D06: 2b d0        rcall	.+86 */
/* 0x6D08: d8 01 01 2b  <unknown> */
/* 0x6D0C: 29 f0        breq	.+10 */
/* 0x6D0E: 01 e0        ldi	r16, 0x1 */
/* 0x6D10: 80 16        cp	r8, r16 */
/* 0x6D12: 00 e0        ldi	r16, 0x0 */
/* 0x6D14: 90 06        cpc	r9, r16 */
/* 0x6D16: 2c f7        brge	.-54 */
/* 0x6D18: 66 e0        ldi	r22, 0x6 */
/* 0x6D1A: 70 e0        ldi	r23, 0x0 */
/* 0x6D1C: 68 19        sub	r22, r8 */
/* 0x6D1E: 79 09        sbc	r23, r9 */
/* 0x6D20: a3 01 bd cf  <unknown> */
/* 0x6D24: 27 d0        rcall	.+78 */
/* 0x6D26: c4 cf        rjmp	.-120 */
/* 0x6D28: 25 d0        rcall	.+74 */
/* 0x6D2A: 08 e7        ldi	r16, 0x78 */
/* 0x6D2C: 40 2e        mov	r4, r16 */
/* 0x6D2E: c0 cf        rjmp	.-128 */
/* 0x6D30: 27 d0        rcall	.+78 */
/* 0x6D32: 4d 90        ld	r4, X+ */
/* 0x6D34: 5d 90        ld	r5, X+ */
/* 0x6D36: a0 83        std	Z+0, r26 */
/* 0x6D38: b1 83        std	Z+1, r27 */
/* 0x6D3A: 82 01 0e 94  <unknown> */
/* 0x6D3E: d0 35        cpi	r29, 0x50 */
/* 0x6D40: b8 01 a2 01  <unknown> */
/* 0x6D44: ac cf        rjmp	.-168 */
/* 0x6D46: 08 d0        rcall	.+16 */
/* 0x6D48: 41 e7        ldi	r20, 0x71 */
/* 0x6D4A: 56 e0        ldi	r21, 0x6 */
/* 0x6D4C: a8 cf        rjmp	.-176 */
/* 0x6D4E: 01 e0        ldi	r16, 0x1 */
/* 0x6D50: c0 0e        add	r12, r16 */
/* 0x6D52: 00 e0        ldi	r16, 0x0 */
/* 0x6D54: d0 1e        adc	r13, r16 */
/* 0x6D56: 08 95        ret */
/* 0x6D58: 61 e0        ldi	r22, 0x1 */
/* 0x6D5A: 70 e0        ldi	r23, 0x0 */
/* 0x6D5C: 08 95        ret */
/* 0x6D5E: 4e 2d        mov	r20, r14 */
/* 0x6D60: 50 e0        ldi	r21, 0x0 */
/* 0x6D62: 8d 01 0c 94  <unknown> */
/* 0x6D66: e1 31        cpi	r30, 0x11 */
/* 0x6D68: 9c 01 08 81  <unknown> */
/* 0x6D6C: 19 81        ldd	r17, Y+1 */
/* 0x6D6E: 3e df        rcall	.-388 */
/* 0x6D70: c8 01 08 95  <unknown> */
/* 0x6D74: 05 d0        rcall	.+10 */
/* 0x6D76: 6d 90        ld	r6, X+ */
/* 0x6D78: 7d 90        ld	r7, X+ */
/* 0x6D7A: a0 83        std	Z+0, r26 */
/* 0x6D7C: b1 83        std	Z+1, r27 */
/* 0x6D7E: 08 95        ret */
/* 0x6D80: f5 01 a0 81  <unknown> */
/* 0x6D84: b1 81        ldd	r27, Z+1 */
/* 0x6D86: 08 95        ret */
/* 0x6DAC: ff cf        rjmp	.-2 */
