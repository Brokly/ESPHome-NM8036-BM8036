/* NM8036 1.95a: higher-level EEPROM address transformations.
 * These wrappers are derived from the actual caller instructions,
 * not inferred from the device manual. They supplement eeprom_exact.c.
 */
#include "nm8036_195_eeprom_exact.h"

/* 0x103A MOVW r20,r18; 0x103C SUBI r20,0xF0;
 * 0x103E SBCI r21,0xFF; 0x1040 JMP 0x630C.
 * Effective base = r19:r18 + 0x0010; EEPROM physical = base+1.
 */
uint8_t nm195_read_offset_11(const NM195_EepromBus *bus, uint16_t index) {
    return nm195_ee_read8(bus, (uint16_t)(index + 0x0010u));
}

/* 0x3F24 SUBI r20,0xF3; 0x3F26 SBCI r21,0xFF;
 * 0x3F28 JMP 0x6312. 16-bit EEPROM read at base+0x0D..+0x0E.
 */
uint16_t nm195_read16_offset_0d(const NM195_EepromBus *bus, uint16_t base) {
    return nm195_ee_read16(bus, (uint16_t)(base + 0x000cu));
}

/* 0x52C4 SUBI r20,0xFC; 0x52C6 SBCI r21,0xFF;
 * 0x52C8 JMP 0x630C. Physical EEPROM address = base+5.
 */
uint8_t nm195_read8_offset_05(const NM195_EepromBus *bus, uint16_t base) {
    return nm195_ee_read8(bus, (uint16_t)(base + 4u));
}

/* 0x1FC4 LDI r20,0xEC; 0x1FC6 LDI r21,0x02;
 * 0x1FC8 CALL 0x630C. Reads physical EEPROM address 0x02ED.
 * The meaning of the byte is not yet established.
 */
uint8_t nm195_read_eeprom_02ed(const NM195_EepromBus *bus) {
    return nm195_ee_read8(bus, 0x02ecu);
}

/* 0x53E0 LDI r20,0xED; 0x53E2 LDI r21,0x02;
 * 0x53E4 JMP 0x6340. Writes physical EEPROM address 0x02EE.
 */
void nm195_write_eeprom_02ee(const NM195_EepromBus *bus, uint8_t value) {
    nm195_ee_write8(bus, 0x02edu, value);
}
