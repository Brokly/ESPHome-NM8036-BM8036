#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "nm8036_195_eeprom_exact.h"
uint8_t nm195_read_offset_11(const NM195_EepromBus *, uint16_t);
uint16_t nm195_read16_offset_0d(const NM195_EepromBus *, uint16_t);
uint8_t nm195_read8_offset_05(const NM195_EepromBus *, uint16_t);
uint8_t nm195_read_eeprom_02ed(const NM195_EepromBus *);
void nm195_write_eeprom_02ee(const NM195_EepromBus *, uint8_t);
static uint16_t last;
static uint8_t rd(void *p,uint16_t a){(void)p;last=a;return (uint8_t)a;}
static void wr(void *p,uint16_t a,uint8_t v){(void)p;last=a;assert(v==0x5a);}
int main(void){NM195_EepromBus b={0,rd,wr};
 assert(nm195_read_offset_11(&b,0x20)==0x31 && last==0x31);
 assert(nm195_read16_offset_0d(&b,0x20)==0x2e2d && last==0x2e);
 assert(nm195_read8_offset_05(&b,0x20)==0x25 && last==0x25);
 assert(nm195_read_eeprom_02ed(&b)==0xed && last==0x2ed);
 nm195_write_eeprom_02ee(&b,0x5a);assert(last==0x2ee);
 puts("EEPROM caller offsets verified");return 0;}
