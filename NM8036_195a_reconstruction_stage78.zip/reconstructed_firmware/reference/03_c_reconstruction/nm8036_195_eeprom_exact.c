#include "nm8036_195_eeprom_exact.h"
/* AVR 0x62FE: SUBI r20,0xff / SBCI r21,0xff = address + 1.
 * AVR 0x6302: RCALL wait(0x62f8), OUT EEARL/H, SBI EECR,EERE.
 * AVR 0x630C: RCALL 0x6302; IN r16,EEDR.
 * EEPROM busy polling and interrupt-state preservation are the
 * responsibilities of the bus callbacks (the low-level hardware layer).
 */
static uint16_t next_addr(uint16_t base) {
    return (uint16_t)(base + UINT16_C(1));
}
uint8_t nm195_ee_read8(const NM195_EepromBus *bus, uint16_t base) {
    return bus->read_byte(bus->context, next_addr(base));
}
/* AVR 0x6312: call 0x6302, read EEDR into r16, call 0x6302
 * again, read EEDR into r17. The address register pair is modified
 * in-place by the first call, so the two accesses are consecutive. */
uint16_t nm195_ee_read16(const NM195_EepromBus *bus, uint16_t base) {
    uint8_t lo = nm195_ee_read8(bus, base);
    uint8_t hi = nm195_ee_read8(bus, next_addr(base));
    return (uint16_t)((uint16_t)lo | ((uint16_t)hi << 8));
}
/* AVR 0x631C: four reads into r16,r17,r18,r19, little-endian. */
uint32_t nm195_ee_read32(const NM195_EepromBus *bus, uint16_t base) {
    uint32_t value = 0;
    for (unsigned i = 0; i < 4; ++i) {
        uint16_t addr = (uint16_t)(base + (uint16_t)i);
        value |= (uint32_t)nm195_ee_read8(bus, addr) << (8u * i);
    }
    return value;
}
/* AVR 0x6340: save SREG; wait for EEWE; write EEDR;
 * jump to 0x632E, which increments address, writes EEARL/H,
 * CLI, sets EEMWE and EEWE, restores SREG. */
void nm195_ee_write8(const NM195_EepromBus *bus, uint16_t base, uint8_t value) {
    bus->write_byte(bus->context, next_addr(base), value);
}
/* AVR 0x6348: first byte from r16, second from r17.
 * AVR 0x6356: four bytes from r16,r17,r18,r19.
 * Writes are ordered; hardware callback must wait for EEWE as needed. */
void nm195_ee_write16(const NM195_EepromBus *bus, uint16_t base, uint16_t value) {
    nm195_ee_write8(bus, base, (uint8_t)value);
    nm195_ee_write8(bus, next_addr(base), (uint8_t)(value >> 8));
}
void nm195_ee_write32(const NM195_EepromBus *bus, uint16_t base, uint32_t value) {
    for (unsigned i = 0; i < 4; ++i) {
        uint16_t addr = (uint16_t)(base + (uint16_t)i);
        nm195_ee_write8(bus, addr, (uint8_t)(value >> (8u * i)));
    }
}
