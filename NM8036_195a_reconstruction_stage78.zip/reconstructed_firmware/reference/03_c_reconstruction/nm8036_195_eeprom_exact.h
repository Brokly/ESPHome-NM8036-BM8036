#ifndef NM8036_195_EEPROM_EXACT_H
#define NM8036_195_EEPROM_EXACT_H
#include <stdint.h>
/* Reconstructed byte-addressed EEPROM access from firmware v1.95a.
 * All functions use a BASE address; the first accessed EEPROM address
 * is BASE+1, not BASE. Arithmetic wraps at 16 bits (AVR register pair).
 * The 2/4-byte operations transfer bytes in register order r16,r17,...
 */
typedef struct {
    void *context;
    uint8_t (*read_byte)(void *, uint16_t);
    void (*write_byte)(void *, uint16_t, uint8_t);
} NM195_EepromBus;
uint8_t nm195_ee_read8(const NM195_EepromBus *bus, uint16_t base);
uint16_t nm195_ee_read16(const NM195_EepromBus *bus, uint16_t base);
uint32_t nm195_ee_read32(const NM195_EepromBus *bus, uint16_t base);
void nm195_ee_write8(const NM195_EepromBus *bus, uint16_t base, uint8_t value);
void nm195_ee_write16(const NM195_EepromBus *bus, uint16_t base, uint16_t value);
void nm195_ee_write32(const NM195_EepromBus *bus, uint16_t base, uint32_t value);
#endif
