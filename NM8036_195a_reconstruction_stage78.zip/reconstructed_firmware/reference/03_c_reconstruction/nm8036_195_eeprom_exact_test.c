#include "nm8036_195_eeprom_exact.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct {
    uint8_t data[65536];
    uint16_t addr[16];
    uint8_t values[16];
    unsigned count;
} Mock;
static uint8_t rd(void *ctx, uint16_t a) {
    Mock *m=ctx;
    assert(m->count<16);
    m->addr[m->count]=a;
    m->values[m->count++]=m->data[a];
    return m->data[a];
}
static void wr(void *ctx, uint16_t a, uint8_t v) {
    Mock *m=ctx;
    assert(m->count<16);
    m->addr[m->count]=a;
    m->values[m->count++]=v;
    m->data[a]=v;
}
int main(void) {
    Mock m={0};
    NM195_EepromBus bus={&m,rd,wr};
    nm195_ee_write32(&bus,0x0100,UINT32_C(0x78563412));
    assert(m.count==4);
    for(unsigned i=0;i<4;i++) {
        assert(m.addr[i]==0x0101+i);
        assert(m.values[i]==(uint8_t)(UINT32_C(0x78563412)>>(8*i)));
    }
    m.count=0;
    assert(nm195_ee_read32(&bus,0x0100)==UINT32_C(0x78563412));
    for(unsigned i=0;i<4;i++) assert(m.addr[i]==0x0101+i);
    m.count=0;
    nm195_ee_write16(&bus,0x0200,UINT16_C(0xabcd));
    assert(m.addr[0]==0x0201 && m.addr[1]==0x0202);
    m.count=0;
    assert(nm195_ee_read16(&bus,0x0200)==UINT16_C(0xabcd));
    m.count=0;
    nm195_ee_write8(&bus,0xffff,0x5a);
    assert(m.addr[0]==0x0000 && m.data[0]==0x5a);
    m.count=0;
    assert(nm195_ee_read8(&bus,0xffff)==0x5a && m.addr[0]==0x0000);
    puts("EEPROM exact access: all tests passed");
    return 0;
}
