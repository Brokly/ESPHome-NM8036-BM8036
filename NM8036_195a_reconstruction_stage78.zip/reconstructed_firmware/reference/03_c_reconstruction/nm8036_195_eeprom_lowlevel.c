/* NM8036 1.95a: EEPROM primitives reconstructed from AVR byte offsets
 * 0x62F8..0x6346. Target: ATmega32. Compile this unit with avr-gcc.
 * The read/write operations below follow the original peripheral sequence.
 * AVR interrupt-state handling is explicit: the original saves SREG in r0.
 * The original EEPROM write helper at 0x6340 does NOT poll EEWE after
 * starting the write, so completion is asynchronous.
 */
#include <stdint.h>
#ifdef __AVR__
#include <avr/io.h>
#include <avr/interrupt.h>
/* 0x62F8: SBIC EECR, EEWE; RJMP -4. */
static void nm195_eeprom_wait(void) {
    while (EECR & _BV(EEWE)) { }
}
/* 0x6302/0x630C: wait, set EEAR, trigger EERE, read EEDR. */
uint8_t nm195_eeprom_read(uint16_t address) {
    nm195_eeprom_wait();
    EEAR = address;
    EECR |= _BV(EERE);
    return EEDR;
}
/* 0x632E/0x6340: save SREG, wait, set EEAR, write EEDR,
 * CLI, set EEMWE and EEWE, restore SREG. */
void nm195_eeprom_write(uint16_t address, uint8_t value) {
    uint8_t saved = SREG;
    nm195_eeprom_wait();
    EEAR = address;
    EEDR = value;
    cli();
    EECR |= _BV(EEMWE);
    EECR |= _BV(EEWE);
    SREG = saved;
}
#endif
