/* NM8036/BM8036 v1.95a — PC protocol records, reconstructed from manual
 * (Appendix 5, commands L/W) and AVR instructions 0x564a..0x5796.
 * This module models the *wire format* exactly; internal EEPROM mapping is
 * intentionally not asserted. No compiler-dependent packed bitfields.
 */
#include <stdint.h>
#include <stddef.h>
#include <string.h>

enum { NM195_RECORD_BYTES = 27, NM195_RECORDS = 32,
       NM195_ALL_RECORD_BYTES = 864 };

typedef struct {
    uint8_t time_on_h, time_on_m, time_on_s;
    uint8_t time_off_h, time_off_m, time_off_s;
    uint8_t time_on_day, time_off_day;
    uint8_t time_on_month, time_off_month;
    uint8_t time_on_year, time_off_year;
    uint8_t time_load, time_loadsensor;
    uint16_t time_min, time_max;
    uint8_t time_mode, time_eze;
    uint32_t time_ezedata;
    uint8_t time_bud, enable, sensortype;
} NM195_Program;

/* Manual byte order for multibyte members follows the ATmega little-endian
 * convention; the manual does not explicitly prescribe endian order.
 * This assumption must be checked against L/W byte-level execution. */
void nm195_program_decode(NM195_Program *p, const uint8_t w[27]) {
    p->time_on_h=w[0]; p->time_on_m=w[1]; p->time_on_s=w[2];
    p->time_off_h=w[3]; p->time_off_m=w[4]; p->time_off_s=w[5];
    p->time_on_day=w[6]; p->time_off_day=w[7];
    p->time_on_month=w[8]; p->time_off_month=w[9];
    p->time_on_year=w[10]; p->time_off_year=w[11];
    p->time_load=w[12]; p->time_loadsensor=w[13];
    p->time_min=(uint16_t)((uint16_t)w[14] | ((uint16_t)w[15]<<8));
    p->time_max=(uint16_t)((uint16_t)w[16] | ((uint16_t)w[17]<<8));
    p->time_mode=w[18]; p->time_eze=w[19];
    p->time_ezedata=(uint32_t)w[20] | ((uint32_t)w[21]<<8) |
                    ((uint32_t)w[22]<<16) | ((uint32_t)w[23]<<24);
    p->time_bud=w[24]; p->enable=w[25]; p->sensortype=w[26];
}
void nm195_program_encode(uint8_t w[27], const NM195_Program *p) {
    w[0]=p->time_on_h; w[1]=p->time_on_m; w[2]=p->time_on_s;
    w[3]=p->time_off_h; w[4]=p->time_off_m; w[5]=p->time_off_s;
    w[6]=p->time_on_day; w[7]=p->time_off_day;
    w[8]=p->time_on_month; w[9]=p->time_off_month;
    w[10]=p->time_on_year; w[11]=p->time_off_year;
    w[12]=p->time_load; w[13]=p->time_loadsensor;
    w[14]=(uint8_t)p->time_min; w[15]=(uint8_t)(p->time_min>>8);
    w[16]=(uint8_t)p->time_max; w[17]=(uint8_t)(p->time_max>>8);
    w[18]=p->time_mode; w[19]=p->time_eze;
    w[20]=(uint8_t)p->time_ezedata;
    w[21]=(uint8_t)(p->time_ezedata>>8);
    w[22]=(uint8_t)(p->time_ezedata>>16);
    w[23]=(uint8_t)(p->time_ezedata>>24);
    w[24]=p->time_bud; w[25]=p->enable; w[26]=p->sensortype;
}

/* Confirmed AVR operations in W at 0x566c..0x56f2. These are *individual
 * updates to internal packed bytes*, not the full W implementation.
 * Preserve the old high bits where the firmware masks them in place.
 */
uint8_t nm195_merge_low6(uint8_t old, uint8_t wire) {
    /* 0x566e ANDI 0x3f, 0x5670 OR: caller supplies the high bits */
    return (uint8_t)((old & 0xc0u) | (wire & 0x3fu));
}
uint8_t nm195_merge_low7(uint8_t old, uint8_t wire) {
    /* 0x56d0 ANDI 0x80, 0x56d4 ANDI 0x7f, OR */
    return (uint8_t)((old & 0x80u) | (wire & 0x7fu));
}
uint8_t nm195_merge_low4_high4(uint8_t lo_source, uint8_t hi_source) {
    /* 0x56c2 ANDI 0x0f, 0x56c6 SWAP, 0x56c8 ANDI 0xf0 */
    return (uint8_t)((lo_source & 0x0fu) | ((hi_source & 0x0fu)<<4));
}
uint8_t nm195_merge_bit5(uint8_t old, uint8_t wire_bit0) {
    /* 0x5764 ANDI 0xdf, 0x5768 BST r17,0, 0x576c BLD r17,5 */
    return (uint8_t)((old & 0xdfu) | ((wire_bit0 & 1u)<<5));
}
uint8_t nm195_pack_three_flags(uint8_t a, uint8_t b, uint8_t c) {
    /* 0x5614..0x563e: three source bits become result bits 2,1,0 */
    return (uint8_t)(((a & 0x20u)>>3) | ((b & 0x80u)>>6) |
                     ((c & 0x20u)>>5));
}
