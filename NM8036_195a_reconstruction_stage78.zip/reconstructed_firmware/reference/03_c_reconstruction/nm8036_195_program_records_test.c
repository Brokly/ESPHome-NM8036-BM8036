#include <assert.h>
#include <stdint.h>
#include <string.h>
#include "nm8036_195_program_records.c"
int main(void) {
    uint8_t input[27], output[27]; NM195_Program p;
    for (unsigned seed=0;seed<256;seed++) {
        for (unsigned i=0;i<27;i++) input[i]=(uint8_t)(seed+17*i);
        nm195_program_decode(&p,input);
        nm195_program_encode(output,&p);
        assert(memcmp(input,output,27)==0);
    }
    for (unsigned x=0;x<256;x++) for (unsigned y=0;y<256;y++) {
        assert(nm195_merge_low6((uint8_t)x,(uint8_t)y)==((x&0xc0u)|(y&0x3fu)));
        assert(nm195_merge_low7((uint8_t)x,(uint8_t)y)==((x&0x80u)|(y&0x7fu)));
        assert(nm195_merge_bit5((uint8_t)x,(uint8_t)y)==((x&0xdfu)|((y&1u)<<5)));
        assert(nm195_merge_low4_high4((uint8_t)x,(uint8_t)y)==((x&15u)|((y&15u)<<4)));
    }
    assert(nm195_pack_three_flags(0x20,0x80,0x20)==7);
    assert(nm195_pack_three_flags(0,0,0)==0);
    return 0;
}
