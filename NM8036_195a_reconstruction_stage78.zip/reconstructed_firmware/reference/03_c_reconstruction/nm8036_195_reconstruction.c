/* NM8036 firmware 1.95a — PARTIAL, EVIDENCE-BASED C RECONSTRUCTION.
 * Input: nm8036_195_corrected.bin (28668 bytes), ATmega32 AVR.
 * This is NOT a complete original source and is NOT a drop-in replacement firmware.
 * Addresses in comments are BYTE addresses in the decoded flash image.
 * The original compiler's calling convention is not fully established.
 */
#include <stdint.h>
#include <stddef.h>

/* ATmega32 I/O register addresses (I/O space, not SRAM addresses). */
#define AVR_IO_SPL 0x3d
#define AVR_IO_SPH 0x3e
#define AVR_IO_SREG 0x3f

/* An abstract machine-state interface lets the proven reset logic be expressed
 * without pretending this host-side C file can run on the microcontroller. */
typedef struct {
    uint8_t io[64];
    uint8_t r[32];
} AvrState;

/* Flash 0x6A34: ldi r16,1; ret. Return-value register r16 is inferred. */
static uint8_t sub_6a34(void) { return 1; }

/* Flash 0x62B8–0x62E7: entry-point control-flow reconstruction.
 * The external functions below are NOT reconstructed; their address labels
 * are taken directly from absolute CALL/JMP instruction operands.
 * In the binary, 0x62C4 CALL 0x6A34 and 0x62CC CALL 0x6B1A.
 * 0x62D8 CALL 0x61EC; 0x62DC CALL 0x41BC; 0x62E0 CALL 0x6370;
 * 0x62E4 JMP 0x59FC.
 */
extern void sub_6b1a(void);
extern void sub_61ec(uint16_t pair_a, uint16_t pair_b);
extern void sub_41bc(void);
extern void sub_6370(void);
extern void sub_59fc(void);

void reconstructed_reset_entry(AvrState *m)
{
    /* 62B8: ldi r16,0x5f; out SPL,r16
     * 62BC: ldi r16,0x06; out SPH,r16
     * 62C0: ldi r28,0x60; ldi r29,0x03 */
    m->io[AVR_IO_SPL] = 0x5f;
    m->io[AVR_IO_SPH] = 0x06;
    m->r[28] = 0x60;
    m->r[29] = 0x03;

    /* 62C4 CALL 0x6A34; 62C8 TST r16; 62CA BREQ +4 */
    if (sub_6a34() != 0)
        sub_6b1a();

    /* 62D0..62D6: r16:r17=0x0CBC, r18:r19=0x0CBE.
     * Argument interpretation is tentative; values are exact. */
    sub_61ec(0x0cbc, 0x0cbe);
    sub_41bc();
    sub_6370();
    sub_59fc(); /* unconditional JMP; should not return */
}

/* 0x6A38–0x6A62: compare two byte buffers.
 * The code compares bytes, returns -1/0/+1 in r16:r17;
 * parameter-register mapping must be validated before ABI use.
 * See the assembly around 0x6A38 for exact control flow. */
int16_t reconstructed_compare_bytes(const uint8_t *a,
                                    const uint8_t *b, uint16_t n)
{
    for (uint16_t i = 0; i < n; ++i) {
        if (a[i] < b[i]) return -1;
        if (a[i] > b[i]) return 1;
    }
    return 0;
}

/* 0x6A66–0x6A76: Z pointer, r18 byte, r20:r21 count;
 * writes the same byte to successive addresses. */
void reconstructed_fill_bytes(uint8_t *dest, uint8_t value, uint16_t count)
{
    while (count--) *dest++ = value;
}

/* 0x62F8–0x62FC: wait until I/O bit 1 at 0x1C is CLEAR.
 * 62F8 SBIC 0x1C,1; 62FA RJMP -4; 62FC RET.
 * This is NOT identified as UART: the I/O address is 0x1C. */
void reconstructed_wait_io_bit_clear(volatile uint8_t *io_1c)
{
    while ((*io_1c & (1u << 1)) != 0) { }
}

/* UART commands V/L/D/S are known from the manual, NOT yet recovered from
 * the actual firmware's command dispatcher. No fabricated handlers here.
 * In particular, 'L' transfers 32 * 27 = 864 bytes, not 832. */
enum {
    NM8036_PROGRAM_COUNT = 32,
    NM8036_PROGRAM_RECORD_SIZE = 27,
    NM8036_PROGRAM_BYTES = 864,
    NM8036_ROM_BYTES = 256,
    NM8036_LCD_BYTES = 96
};
