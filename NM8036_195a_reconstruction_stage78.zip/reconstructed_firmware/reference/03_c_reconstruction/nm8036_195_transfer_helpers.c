#include "nm8036_195_transfer_helpers.h"
/* All offsets below are byte addresses in nm8036_195_corrected.bin.
 * 0x2BDC waits for UCSRA.UDRE then writes UDR.
 * 0x2C36 has a 16-bit counter r25:r24, pointer r27:r26 and a loop
 * calling 0x2BDC. The trailing JMP 0x69FC is compiler epilogue. */
void nm195_uart_send_sram(NM195_TransferIO *io, const uint8_t *src, uint16_t count) {
    for (uint16_t i = 0; i < count; ++i) io->uart_tx(io->context, src[i]);
}
/* 0x2C90 waits for UCSRA.RXC, reads UDR, and stores to Z+i.
 * Return value r16=1, including count=0. */
uint8_t nm195_uart_recv_sram(NM195_TransferIO *io, uint8_t *dst, uint16_t count) {
    for (uint16_t i = 0; i < count; ++i) dst[i] = io->uart_rx(io->context);
    return 1;
}
/* EEPROM helpers 0x630C/0x6340 increment the passed address
 * BEFORE accessing EEAR; base+i refers to EEPROM[base+i+1].
 * 0x2C08 saves SREG and executes CLI before loop. 0x2C20 calls
 * 0x630C (EEPROM byte read), then 0x2BDC (UART transmit). At end
 * SREG is restored; enter/leave callbacks must preserve this behavior.
 * EEPROM identified by EECR/EEDR/EEAR access at 0x62F8–0x6346. */
void nm195_uart_send_indirect(NM195_TransferIO *io, uint16_t base, uint16_t count) {
    io->enter_critical(io->context);
    for (uint16_t i = 0; i < count; ++i) {
        uint8_t value = io->eeprom_read(io->context, (uint16_t)(base + i + 1u));
        io->uart_tx(io->context, value);
    }
    io->leave_critical(io->context);
}
/* 0x2C5C–0x2C8E saves SREG, CLI, polls RXC, reads UDR, and calls
 * 0x6340 for each destination byte. r16=1 on completion.
 * The original preserves r24:r25 around the loop; its return ABI is
 * compiler-specific, so this reconstruction exposes only success. */
uint8_t nm195_uart_recv_indirect(NM195_TransferIO *io, uint16_t base, uint16_t count) {
    io->enter_critical(io->context);
    for (uint16_t i = 0; i < count; ++i) {
        uint8_t value = io->uart_rx(io->context);
        io->eeprom_write(io->context, (uint16_t)(base + i + 1u), value);
    }
    io->leave_critical(io->context);
    return 1;
}
