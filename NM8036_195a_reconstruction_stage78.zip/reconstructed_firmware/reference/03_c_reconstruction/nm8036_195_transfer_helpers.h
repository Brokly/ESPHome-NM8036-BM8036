#ifndef NM8036_195_TRANSFER_HELPERS_H
#define NM8036_195_TRANSFER_HELPERS_H
#include <stdint.h>
#include <stddef.h>
/* Reconstructed operations of firmware v1.95a. The callbacks describe
 * EEPROM access, established from EECR/EEDR/EEAR instructions at 0x62F8–0x6346. */
typedef struct {
    void *context;
    uint8_t (*uart_rx)(void *context);  /* blocking receive: wait for RXC */
    void (*uart_tx)(void *context, uint8_t byte); /* wait for UDRE */
    uint8_t (*eeprom_read)(void *context, uint16_t address); /* 0x630C: EERE / EEDR */
    void (*eeprom_write)(void *context, uint16_t address, uint8_t value); /* 0x6340: EEMWE / EEWE */
    void (*enter_critical)(void *context);
    void (*leave_critical)(void *context);
} NM195_TransferIO;

/* 0x2C36–0x2C58: read bytes from SRAM, send via UART. */
void nm195_uart_send_sram(NM195_TransferIO *io, const uint8_t *src, uint16_t count);
/* 0x2C90–0x2CB6: UART -> SRAM, direct ST Z+offset. */
uint8_t nm195_uart_recv_sram(NM195_TransferIO *io, uint8_t *dst, uint16_t count);
/* 0x2C08–0x2C32: EEPROM reads via 0x630C, send under CLI. */
void nm195_uart_send_indirect(NM195_TransferIO *io, uint16_t base, uint16_t count);
/* 0x2C5C–0x2C8E: receive under CLI, EEPROM writes via 0x6340. */
uint8_t nm195_uart_recv_indirect(NM195_TransferIO *io, uint16_t base, uint16_t count);
#endif
