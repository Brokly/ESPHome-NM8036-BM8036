#include "nm8036_195_transfer_helpers.h"
#include <assert.h>
#include <string.h>
typedef struct { uint8_t mem[256], tx[256], rx[256]; unsigned tx_n, rx_n, writes, reads, enter, leave, depth; } Mock;
static uint8_t rx(void *v) { Mock *m=v; assert(m->rx_n<256); return m->rx[m->rx_n++]; }
static void tx(void *v,uint8_t b) { Mock *m=v; assert(m->tx_n<256); m->tx[m->tx_n++]=b; }
static uint8_t rd(void *v,uint16_t a) { Mock *m=v; assert(m->depth && a<256); ++m->reads; return m->mem[a]; }
static void wr(void *v,uint16_t a,uint8_t b) { Mock *m=v; assert(m->depth && a<256); ++m->writes; m->mem[a]=b; }
static void enter(void *v) { Mock *m=v; assert(!m->depth); ++m->enter; ++m->depth; }
static void leave(void *v) { Mock *m=v; assert(m->depth); ++m->leave; --m->depth; }
int main(void) {
    Mock m={0}; NM195_TransferIO io={&m,rx,tx,rd,wr,enter,leave};
    uint8_t data[]={7,8,9}, dest[3]={0};
    nm195_uart_send_sram(&io,data,3); assert(m.tx_n==3 && !memcmp(m.tx,data,3));
    memcpy(m.rx,data,3); assert(nm195_uart_recv_sram(&io,dest,3)==1 && !memcmp(data,dest,3));
    memcpy(m.mem+11,data,3); nm195_uart_send_indirect(&io,10,3);
    assert(m.tx_n==6 && !memcmp(m.tx+3,data,3) && m.reads==3);
    m.rx_n=0; assert(nm195_uart_recv_indirect(&io,20,3)==1);
    assert(!memcmp(m.mem+21,data,3) && m.writes==3 && m.enter==2 && m.leave==2 && !m.depth);
    nm195_uart_send_indirect(&io,0,0);
    assert(nm195_uart_recv_indirect(&io,0,0)==1 && m.enter==4 && m.leave==4);
    return 0;
}
