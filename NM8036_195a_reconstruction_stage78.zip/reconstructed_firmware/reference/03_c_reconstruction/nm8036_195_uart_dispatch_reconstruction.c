/* NM8036 1.95a: evidence-based partial C reconstruction of UART command handlers.
 * Source: decoded AVR image nm8036_195_corrected.bin, byte offsets noted below.
 * This is NOT the complete firmware and is NOT guaranteed source-equivalent.
 * Functions are deliberately factored around observed register constants.
 */
#include <stdint.h>
#include <stddef.h>

typedef struct {
    void (*putc)(uint8_t byte, void *ctx);
    void (*send)(const uint8_t *data, size_t count, void *ctx);
    void *ctx;
    const uint8_t *sensor_roms; /* observed SRAM pointer 0x02F0, length 0x0100 */
    const uint8_t *adc_buffer;  /* observed SRAM pointer 0x0673, length 8 */
    const uint8_t *lcd_buffer;  /* exact pointer unresolved */
    volatile uint8_t *lcd_changed; /* observed absolute SRAM 0x068E */
    const uint8_t *programs;    /* layout/address unresolved */
} NM8036_UART;

/* AVR 0x579A..0x57A8: 'D', echo then 256 bytes from SRAM 0x02F0. */
void nm195_uart_D(NM8036_UART *u) {
    u->putc('D', u->ctx);
    u->send(u->sensor_roms, 256, u->ctx);
}

/* AVR 0x57AA..0x57BA: 'd', echo, flag, clear flag at SRAM 0x068E. */
void nm195_uart_d(NM8036_UART *u) {
    u->putc('d', u->ctx);
    u->putc(*u->lcd_changed, u->ctx);
    *u->lcd_changed = 0;
}

/* AVR 0x5838..0x5848: 's', echo then 8 bytes from SRAM 0x0673. */
void nm195_uart_s(NM8036_UART *u) {
    u->putc('s', u->ctx);
    u->send(u->adc_buffer, 8, u->ctx);
}

/* AVR 0x581E..0x5836: 'S', echo and call display helper at 0x1F26.
 * The assembly passes 0x0060 (96) to the transmit routine at 0x2C36.
 * The source pointer comes from another helper and is unresolved.
 */
void nm195_uart_S(NM8036_UART *u) {
    u->putc('S', u->ctx);
    u->send(u->lcd_buffer, 96, u->ctx);
}

/* AVR 0x5596 onward: 'L' echo followed by per-record field serialization.
 * This is NOT proven to be a flat 864-byte memcpy. Manual confirms 32*27.
 * Exact field ordering and source memory still require CFG reconstruction.
 */
void nm195_uart_L_known_prefix(NM8036_UART *u) {
    u->putc('L', u->ctx);
}

/* Dispatch shell covering only handlers supported by decoded instructions.
 * This is a reconstruction aid, not a substitute for the complete firmware.
 */
int nm195_dispatch_verified_subset(NM8036_UART *u, uint8_t command) {
    switch (command) {
    case 'D': nm195_uart_D(u); return 1;
    case 'd': nm195_uart_d(u); return 1;
    case 's': nm195_uart_s(u); return 1;
    case 'S': nm195_uart_S(u); return 1;
    default: return 0;
    }
}
