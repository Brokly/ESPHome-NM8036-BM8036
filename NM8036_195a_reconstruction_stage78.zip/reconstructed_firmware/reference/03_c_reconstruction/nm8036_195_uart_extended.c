/* NM8036 1.95a: expanded behavioral C reconstruction of UART command cases.
 * Derived from AVR offsets 0x5532..0x5848 in nm8036_195_corrected.bin.
 * Only cases with unambiguous byte counts/pointers are implemented here.
 * Not a complete source translation or drop-in AVR firmware.
 */
#include <stdint.h>
#include <stddef.h>

typedef struct {
    void *ctx;
    void (*tx)(void *ctx, uint8_t byte);
    void (*tx_buf)(void *ctx, const uint8_t *src, size_t count);
    void (*rx_buf)(void *ctx, uint8_t *dst, size_t count);
    uint8_t *sram; /* indexed by ATmega32 SRAM address, >= 0x073a bytes */
    const uint8_t *lcd_buf; /* pointer supplied by helper at AVR 0x1F26 */
    void (*boot_enter)(void *ctx); /* exact transition sequence unresolved */
} NM195;

static void echo(NM195 *m, uint8_t c) { m->tx(m->ctx, c); }
static void send_sram(NM195 *m, unsigned address, size_t count) {
    m->tx_buf(m->ctx, m->sram + address, count);
}

/* AVR 0x579A: 0x02F0, length 0x0100. */
static void command_D(NM195 *m) {
    echo(m, 'D');
    send_sram(m, 0x02F0, 256);
}
/* AVR 0x57AA: read and clear 0x068E. */
static void command_d(NM195 *m) {
    echo(m, 'd');
    echo(m, m->sram[0x068E]);
    m->sram[0x068E] = 0;
}
/* AVR 0x5838: 0x0673, length 8. */
static void command_s(NM195 *m) {
    echo(m, 's');
    send_sram(m, 0x0673, 8);
}
/* AVR 0x581E: display helper followed by 0x0060-byte send. */
static void command_S(NM195 *m) {
    echo(m, 'S');
    m->tx_buf(m->ctx, m->lcd_buf, 96);
}
/* AVR 0x580E: receives one byte into SRAM 0x0739. */
static void command_K(NM195 *m) {
    echo(m, 'K');
    m->rx_buf(m->ctx, m->sram + 0x0739, 1);
}
/* AVR 0x5532: echo E then transition; the transition is not yet translated. */
static void command_E(NM195 *m) {
    echo(m, 'E');
    if (m->boot_enter) m->boot_enter(m->ctx);
}
/* AVR 0x555A: version reply; string length and flash source require helper analysis. */
/* AVR 0x5596: L serializes 32 records with field-wise packing, not a flat send. */
/* AVR 0x57BC/0x57C8: H/h transfer 0x22=34 bytes, but source/destination
 * and helper side effects are not fully established. */

int nm195_uart_dispatch_extended(NM195 *m, uint8_t command) {
    switch (command) {
    case 'D': command_D(m); return 1;
    case 'd': command_d(m); return 1;
    case 's': command_s(m); return 1;
    case 'S': command_S(m); return 1;
    case 'K': command_K(m); return 1;
    case 'E': command_E(m); return 1;
    default: return 0;
    }
}
