/* NM8036 v1.95a — UART routines reconstructed from decoded AVR machine code.
 * Addresses refer to BYTE offsets in nm8036_195_corrected.bin.
 * This is a partial reconstruction, NOT complete firmware.
 * Compiles with avr-gcc for ATmega32 (when installed).
 */
#include <stdint.h>
#include <avr/io.h>

/* 0x2BDС..0x2BE2: wait for UDRE, transmit r16. */
void nm_uart_putc(uint8_t value) {
    while (!(UCSRA & _BV(UDRE))) { }
    UDR = value;
}

/* 0x2BE4..0x2BF4: nonblocking receive, returns availability separately.
 * Assembly: SBIC UCSRA,RXC; RJMP read; LDI r16,0; RET;
 *           IN r18,UDR; ST Z,r18; LDI r16,1; RET.
 * Pointer Z is supplied by the original caller (compiler-specific ABI).
 */
uint8_t nm_uart_try_getc(uint8_t *out) {
    if (!(UCSRA & _BV(RXC))) return 0;
    *out = UDR;
    return 1;
}

/* 0x2BF6..0x2C06: exact I/O register values from assembly.
 * UBRRL=12, UCSRA=2 (U2X=1), UCSRB=0x18 (RXEN|TXEN),
 * UCSRC=0x8E (URSEL|UCSZ1|UCSZ0|USBS): 8 data bits, 2 stop bits.
 * Baud depends on F_CPU: at 1 MHz and U2X=1, UBRR=12 yields ~9615 baud.
 */
void nm_uart_init(void) {
    UBRRL = 12;
    UCSRA = 2;
    UCSRB = 0x18;
    UCSRC = 0x8e;
}

/* 0x2C90..0x2CB6: blocking read of 'count' bytes into destination.
 * Original machine code uses caller's Z pointer and length registers.
 */
void nm_uart_read_exact(uint8_t *destination, uint16_t count) {
    for (uint16_t i = 0; i < count; ++i) {
        while (!(UCSRA & _BV(RXC))) { }
        destination[i] = UDR;
    }
}

/* 0x2C36..0x2C5A: send contiguous bytes from RAM buffer.
 * Actual register ABI not established; loop semantics established.
 */
void nm_uart_write_exact(const uint8_t *source, uint16_t count) {
    for (uint16_t i = 0; i < count; ++i) {
        nm_uart_putc(source[i]);
    }
}
