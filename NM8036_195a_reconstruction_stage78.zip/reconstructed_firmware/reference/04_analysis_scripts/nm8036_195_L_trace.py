from pathlib import Path
b=Path('/mnt/data/nm8036_195_corrected.bin').read_bytes()
lines=[]
for a in range(0x5596,0x564a,2):
 w=int.from_bytes(b[a:a+2],'little'); label=''
 if (w&0xf000)==0xd000:
  k=w&0xfff;k-=4096 if k&0x800 else 0
  label=f'RCALL 0x{a+2+2*k:04X}'
 elif (w&0xf000)==0xc000:
  k=w&0xfff;k-=4096 if k&0x800 else 0
  label=f'RJMP 0x{a+2+2*k:04X}'
 elif (w&0xf000)==0xe000:
  d=16+((w>>4)&15);K=(w&15)|((w>>4)&0xf0)
  label=f'LDI r{d},0x{K:02X}'
 elif (w&0xfe0f)==0x9403:
  label=f'INC r{(w>>4)&31}'
 elif (w&0xfc00)==0x2c00:
  label=f'MOV r{(w>>4)&31},r{(w&15)|((w>>5)&16)}'
 elif (w&0xff00)==0x0100:
  label=f'MOVW r{2*((w>>4)&15)},r{2*(w&15)}'
 elif (w&0xf000)==0x5000:
  K=(w&15)|((w>>4)&0xf0);label=f'SUBI r{16+((w>>4)&15)},0x{K:02X}'
 elif (w&0xf000)==0x4000:
  K=(w&15)|((w>>4)&0xf0);label=f'SBCI r{16+((w>>4)&15)},0x{K:02X}'
 elif (w&0xf000)==0x7000:
  K=(w&15)|((w>>4)&0xf0);label=f'ANDI r{16+((w>>4)&15)},0x{K:02X}'
 elif (w&0xf000)==0x3000:
  K=(w&15)|((w>>4)&0xf0);label=f'CPI r{16+((w>>4)&15)},0x{K:02X}'
 elif (w&0xfc00)==0x0c00:label='ADD'
 elif (w&0xfc00)==0x1c00:label='ADC'
 elif (w&0xfc00)==0x2800:label='OR'
 elif (w&0xfe0f)==0x9402:label=f'SWAP r{(w>>4)&31}'
 elif (w&0xfe0f)==0x9406:label=f'LSR r{(w>>4)&31}'
 elif (w&0xfe0f)==0x940a:label=f'DEC r{(w>>4)&31}'
 elif (w&0xf000)==0xf000:label='BRANCH'
 elif (w&0xfc00)==0x9c00:label='MUL'
 else:label='OTHER'
 lines.append(f'0x{a:04X}  {w:04X}  {label}')
Path('/mnt/data/nm8036_195_L_word_accurate.txt').write_text('\n'.join(lines)+'\n')
print('written',len(lines),'words')
