from pathlib import Path
from collections import Counter
b=Path(__file__).with_name('nm8036_195_corrected.bin').read_bytes()
N=len(b)
links=[]
for a in range(0,N-3,2):
    w=int.from_bytes(b[a:a+2],'little')
    if (w & 0xfe0e) == 0x940e or (w & 0xfe0e) == 0x940c:
        k=((w&0x1f0)>>3)|(w&1)
        dst=2*((k<<16)|int.from_bytes(b[a+2:a+4],'little'))
        links.append((a,'CALL' if w&2 else 'JMP',dst))
# Scan is deliberately linear: embedded data may look like code.
counts=Counter(dst for _,op,dst in links if op=='CALL')
lines=['# NM8036 1.95a — preliminary direct-call graph','',f'Firmware bytes: {N}',f'Linear CALL: {sum(op=="CALL" for _,op,_ in links)}',f'Linear JMP: {sum(op=="JMP" for _,op,_ in links)}','', 'This is an address-reference inventory, NOT a validated control-flow graph. Linear scanning can mistake data for instructions.','', '## Most referenced CALL destinations','', '| Byte address | CALL references |','|---|---:|']
for dst,num in counts.most_common(45): lines.append(f'| `0x{dst:04X}` | {num} |')
lines += ['', '## Selected known UART entry points and inbound direct CALLs','']
for dst in (0x2BDC,0x2BE4,0x2BF6,0x2C36,0x2C90):
    callers=[a for a,op,t in links if op=='CALL' and t==dst]
    lines.append(f'- `0x{dst:04X}`: {len(callers)} direct CALL(s), sites: '+(', '.join(f'0x{x:04X}' for x in callers[:25]) or 'none'))
lines += ['','## Reset target','', 'Reset vector at 0x0000 jumps to 0x62B8 (byte address).','', '## Full direct CALL/JMP references','', '| Site | Opcode | Target |','|---|---|---|']
for a,op,t in links: lines.append(f'| `0x{a:04X}` | {op} | `0x{t:04X}` |')
Path(__file__).with_name('nm8036_195_call_graph_preliminary.md').write_text('\n'.join(lines)+'\n')
print('Wrote report with',len(links),'direct references')
