from pathlib import Path
import csv
b=Path(__file__).with_name('nm8036_195_corrected.bin').read_bytes()
N=len(b)
rows=[]
for a in range(0,N-3,2):
    w=int.from_bytes(b[a:a+2],'little')
    if (w & 0xfe0e) not in (0x940c,0x940e): continue
    k=((w&0x1f0)>>3)|(w&1)
    dst=2*((k<<16)|int.from_bytes(b[a+2:a+4],'little'))
    rows.append((f'0x{a:04X}','CALL' if (w&2) else 'JMP',f'0x{dst:04X}',int(dst<N),int(dst%2==0)))
out=Path('/mnt/data/nm8036_195_direct_references.csv')
with out.open('w',newline='') as f:
    wr=csv.writer(f);wr.writerow(('site','opcode','target','within_image','aligned'));wr.writerows(rows)
print('image',N,'references',len(rows),'in-range',sum(r[3] for r in rows),'out-of-range',sum(not r[3] for r in rows))
for x in (0x2bdc,0x2be4,0x2bf6,0x2c36,0x2c90):
    print(hex(x),[r[0] for r in rows if r[2]==f'0x{x:04X}' and r[1]=='CALL'])
