from pathlib import Path
import re, json, collections
root=Path('/mnt/data'); b=(root/'nm8036_195_corrected.bin').read_bytes(); n=len(b)
lines=(root/'nm8036_195_corrected.asm').read_text().splitlines()
ins={}
pat=re.compile(r'^\s*([0-9a-f]+):\s+((?:[0-9a-f]{2} )+)\s+(.+?)\s*$')
for line in lines:
 m=pat.match(line)
 if m:
  a=int(m[1],16); raw=bytes.fromhex(m[2]); op=m[3].split('\t')[0].strip(); ins[a]=(raw,op,m[3].strip())
# ensure parser accuracy
assert 0 in ins and 0x62b8 in ins
vectors=[]
for a in range(0,0x58,2):
 if a not in ins: continue
 w=int.from_bytes(b[a:a+2],'little')
 if (w&0xfe0e)==0x940c:
  k=((w&0x1f0)>>3)|(w&1); target=2*((k<<16)|int.from_bytes(b[a+2:a+4],'little'));vectors.append((a,target))
seeds={t for _,t in vectors}; seeds.update([0x2bdc,0x2be4,0x2bf6,0x2c36,0x2c90,0x5596,0x579a,0x57aa,0x581e,0x5838]); seeds={x for x in seeds if x<n}
call_edges=set(); visited=set(); bad=[]; branches=set(); queue=collections.deque((x,'entry') for x in sorted(seeds)); starts=set(seeds)
while queue:
 a,reason=queue.popleft()
 if a in visited or a<0 or a>=n or a%2: continue
 if a not in ins: bad.append(a);continue
 visited.add(a); raw,op,txt=ins[a]; w=int.from_bytes(b[a:a+2],'little'); sz=len(raw); nxt=a+sz
 def push(x,why):
  if 0<=x<n and x%2==0:queue.append((x,why))
 if (w&0xfe0e) in (0x940c,0x940e) and sz==4:
  k=((w&0x1f0)>>3)|(w&1); target=2*((k<<16)|int.from_bytes(b[a+2:a+4],'little'))
  if (w&2):
   call_edges.add((a,target)); starts.add(target);push(target,'call');push(nxt,'return')
  else: branches.add((a,target));push(target,'jmp')
 elif w&0xf000==0xc000: # rjmp
  delta=w&0xfff;delta=delta-4096 if delta&2048 else delta;target=nxt+2*delta;branches.add((a,target));push(target,'rjmp')
 elif w&0xf000==0xd000:
  delta=w&0xfff;delta=delta-4096 if delta&2048 else delta;target=nxt+2*delta;call_edges.add((a,target));starts.add(target);push(target,'rcall');push(nxt,'return')
 elif (w&0xfc00) in (0xf000,0xf400):
  k=(w>>3)&0x7f;k=k-128 if k&64 else k;target=nxt+2*k;branches.add((a,target));push(target,'branch');push(nxt,'fallthrough')
 elif (w&0xfe08) in (0xfc00,0xfe00,0x1000) or (w&0xfc00)==0x1000: # skip family, next instr skipped
  push(nxt,'skip-fall');push(nxt+len(ins.get(nxt,(b'\0\0',))[0]),'skip-taken')
 elif w in (0x9508,0x9518,0x9409,0x9419,0x9588,0x9598): # ret/reti/ijmp/eijmp/sleep/break
  pass
 else:push(nxt,'linear')
# CSV index, basic call graph
import csv
with (root/'nm8036_195_reachable_instructions.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['address','bytes','instruction','is_reachable'])
 for a,(raw,op,txt) in sorted(ins.items()):wr.writerow([f'0x{a:04X}',raw.hex(' '),txt,int(a in visited)])
with (root/'nm8036_195_call_edges.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['call_site','target']);wr.writerows((f'0x{a:04X}',f'0x{t:04X}') for a,t in sorted(call_edges))
# generate C annotated function inventory, not fabricated high level semantics
out=['/* NM8036 1.95a: extracted control-flow and instruction evidence. */','/* NOT source-equivalent decompilation. Addresses are byte offsets. */','#include <stdint.h>','typedef struct { uint16_t address, target; } nm_call_edge;','static const nm_call_edge nm195_direct_calls[] = {']
for a,t in sorted(call_edges):out.append(f'    {{0x{a:04X}, 0x{t:04X}}},')
out+=['};','const unsigned nm195_direct_calls_count = sizeof nm195_direct_calls / sizeof nm195_direct_calls[0];','/* Reachable instruction listing, including indirect-branch limitations: */']
for a in sorted(visited):
 raw,op,txt=ins[a];out.append(f'/* 0x{a:04X}: {raw.hex(" "):<12} {txt.replace("*/","* /")} */')
(root/'nm8036_195_control_flow_evidence.c').write_text('\n'.join(out)+'\n')
report={'image_bytes':n,'disassembler_instruction_rows':len(ins),'reachable_from_vector_and_uart_seeds':len(visited),'direct_call_edges':len(call_edges),'direct_branch_edges':len(branches),'seed_addresses':[f'0x{x:04X}' for x in sorted(seeds)],'vector_jumps':[[f'0x{a:04X}',f'0x{t:04X}'] for a,t in vectors],'limitations':['Indirect JMP/CALL unresolved','Interrupt vectors plus known UART handlers used as seeds','Linear decoding of data may be misleading','Not a complete C decompilation']}
(root/'nm8036_195_cfg_results.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
