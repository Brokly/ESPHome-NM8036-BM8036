#!/usr/bin/env python3
"""Audit direct EEPROM primitive callers in NM8036 1.95a disassembly."""
import re,csv,pathlib
root=pathlib.Path('/mnt/data')
lines=(root/'nm8036_195_atmega32_full.asm').read_text().splitlines()
rx=re.compile(r'^\s*([0-9a-f]+):\s+(?:[0-9a-f]{2} )+\s+(.+)$')
parsed=[]
for line in lines:
 m=rx.match(line)
 if m: parsed.append((int(m[1],16),m[2].strip()))
targets={0x630c:'read8',0x6312:'read16',0x631c:'read32',0x6340:'write8',0x6348:'write16',0x6356:'write32',0x2c08:'send_eeprom_uart',0x2c5c:'recv_uart_eeprom'}
rows=[]
for i,(addr,ins) in enumerate(parsed):
 m=re.match(r'(call|jmp)\s+0x([0-9a-f]+)\b',ins)
 if not m or int(m[2],16) not in targets:continue
 pre=parsed[max(0,i-7):i]
 rows.append(dict(address=f'0x{addr:04X}',operation=targets[int(m[2],16)],target=f'0x{int(m[2],16):04X}',kind=m[1],context='; '.join(f'{a:04X} {s}' for a,s in pre)))
with (root/'nm8036_195_eeprom_callsites.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['address','operation','target','kind','context']);w.writeheader();w.writerows(rows)
from collections import Counter
c=Counter(x['operation'] for x in rows)
with (root/'nm8036_195_eeprom_callsites.md').open('w') as f:
 f.write('# Вызовы EEPROM в прошивке NM8036 1.95a\n\n')
 f.write('Источник: исправленный листинг AVR. Учтены только прямые `CALL`/`JMP`; `RCALL`/`RJMP` и косвенные вызовы здесь не учитываются. Контекст — семь предыдущих инструкций, не обязательно в одном базовом блоке.\n\n')
 f.write('Количество найденных прямых обращений: **%d**.\n\n'%len(rows))
 for name,n in sorted(c.items()):f.write(f'- `{name}`: {n}\n')
 f.write('\n## Адреса и ближайшие инструкции\n\n')
 for x in rows:f.write(f"- `{x['address']}` → `{x['operation']}` ({x['kind']} {x['target']}): `{x['context']}`\n")
print(len(rows),dict(c))
