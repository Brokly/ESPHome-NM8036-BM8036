#include <cstdint>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>

static std::vector<uint8_t> readFile(const std::string& name) {
    std::ifstream f(name, std::ios::binary);
    if (!f) throw std::runtime_error("Cannot open input: " + name);
    return {std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>()};
}
static void writeFile(const std::string& name, const std::vector<uint8_t>& data) {
    std::ofstream f(name, std::ios::binary);
    if (!f) throw std::runtime_error("Cannot create output: " + name);
    f.write(reinterpret_cast<const char*>(data.data()), data.size());
    if (!f) throw std::runtime_error("Write error");
}
int main(int argc, char** argv) {
    try {
        if (argc != 3) { std::cerr << "Usage: nm8036_decode input.cod output.bin\n"; return 2; }
        const auto c = readFile(argv[1]);
        if (c.size() <= 256) throw std::runtime_error(".cod is too short");
        std::vector<uint8_t> p(c.size()-256);
        for (size_t i=0; i<p.size(); ++i)
            p[i] = static_cast<uint8_t>(c[i+256] - c[i%256]);
        // Verify exactly: the original file must be recoverable from the output + seed.
        for (size_t i=0; i<p.size(); ++i)
            if (static_cast<uint8_t>(p[i] + c[i%256]) != c[i+256])
                throw std::runtime_error("Roundtrip check failed");
        writeFile(argv[2], p);
        std::cout << "Decoded " << p.size() << " bytes, roundtrip OK\n";
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
