#!/usr/bin/env python3
"""NM8036 .cod decoder: 256-byte static additive mask, followed by AVR firmware."""
from pathlib import Path
import argparse

def decode(c: bytes) -> bytes:
    if len(c) < 257: raise ValueError('Input too short')
    return bytes((v-c[i % 256]) & 255 for i,v in enumerate(c[256:]))

def encode(p: bytes, seed: bytes) -> bytes:
    if len(seed)!=256: raise ValueError('Seed must be 256 bytes')
    return seed+bytes((v+seed[i%256])&255 for i,v in enumerate(p))

def ihex(p: bytes):
    lines=[]
    for pos in range(0,len(p),16):
        chunk=p[pos:pos+16]
        record=bytes([len(chunk),(pos>>8)&255,pos&255,0])+chunk
        lines.append(':'+record.hex().upper()+f'{(-sum(record))&255:02X}')
    return '\n'.join(lines+[':00000001FF',''])

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('cod',type=Path);ap.add_argument('bin',type=Path);args=ap.parse_args()
    c=args.cod.read_bytes();p=decode(c)
    assert encode(p,c[:256])==c
    args.bin.write_bytes(p);args.bin.with_suffix('.hex').write_text(ihex(p))
    print(f'Decoded {len(p)} bytes, verified roundtrip; output {args.bin}')
