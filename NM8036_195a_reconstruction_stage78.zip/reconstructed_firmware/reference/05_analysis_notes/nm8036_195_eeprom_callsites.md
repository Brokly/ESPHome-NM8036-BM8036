# Вызовы EEPROM в прошивке NM8036 1.95a

Источник: исправленный листинг AVR. Учтены только прямые `CALL`/`JMP`; `RCALL`/`RJMP` и косвенные вызовы здесь не учитываются. Контекст — семь предыдущих инструкций, не обязательно в одном базовом блоке.

Количество найденных прямых обращений: **30**.

- `read16`: 2
- `read32`: 5
- `read8`: 6
- `recv_uart_eeprom`: 1
- `send_eeprom_uart`: 2
- `write16`: 4
- `write32`: 5
- `write8`: 5

## Адреса и ближайшие инструкции

- `0x0DE4` → `write32` (call 0x6356): `0DD6 ldi	r19, 0x3f; 0DD8 ldi	r20, 0x4; 0DDA mul	r22, r20; 0DDC ldi	r20, 0x0; 0DDE ldi	r21, 0x0; 0DE0 add	r20, r0; 0DE2 adc	r21, r1`
- `0x0E12` → `write8` (jmp 0x6340): `0E04 rcall	.+12; 0E06 ldi	r20, 0x13; 0E08 ldi	r21, 0x0; 0E0A rcall	.+6; 0E0C ldi	r16, 0x0; 0E0E ldi	r20, 0x14; 0E10 ldi	r21, 0x0`
- `0x1036` → `read32` (jmp 0x631C): `1026 adc	r21, r19; 1028 rcall	.+22; 102A call	0x1efa; 102E rcall	.+72; 1030 rjmp	.-140; 1032 add	r20, r16; 1034 adc	r21, r17`
- `0x1040` → `read8` (jmp 0x630C): `1030 rjmp	.-140; 1032 add	r20, r16; 1034 adc	r21, r17; 1036 jmp	0x631c; 103A movw	r20, r18; 103C subi	r20, 0xf0; 103E sbci	r21, 0xff`
- `0x10E2` → `read32` (call 0x631C): `10D0 breq	.+34; 10D2 call	0x1678; 10D6 rcall	.+182; 10D8 ldi	r18, 0x5e; 10DA ldi	r19, 0x1; 10DC call	0x1af6; 10E0 movw	r20, r24`
- `0x1108` → `write32` (call 0x6356): `10F6 call	0x1b9e; 10FA cpi	r16, 0x1; 10FC brne	.+26; 10FE cli; 1100 rcall	.+164; 1102 call	0x1a60; 1106 movw	r20, r24`
- `0x1FC8` → `read8` (call 0x630C): `1FBA cp	r16, r20; 1FBC cpc	r17, r21; 1FBE cpc	r18, r22; 1FC0 cpc	r19, r23; 1FC2 brsh	.+16; 1FC4 ldi	r20, 0xec; 1FC6 ldi	r21, 0x2`
- `0x23AC` → `write16` (jmp 0x6348): `239E ldi	r19, 0x2; 23A0 mul	r18, r19; 23A2 ret; 23A4 ldi	r20, 0x15; 23A6 ldi	r21, 0x0; 23A8 add	r20, r0; 23AA adc	r21, r1`
- `0x23F6` → `read16` (jmp 0x6312): `23E8 ret; 23EA ldi	r16, 0x2; 23EC mul	r18, r16; 23EE ldi	r20, 0x15; 23F0 ldi	r21, 0x0; 23F2 add	r20, r0; 23F4 adc	r21, r1`
- `0x2AB8` → `write8` (jmp 0x6340): `2AAA ldi	r21, 0x0; 2AAC rcall	.+10; 2AAE ldi	r20, 0x4a; 2AB0 ldi	r21, 0x0; 2AB2 rcall	.+4; 2AB4 ldi	r20, 0x4b; 2AB6 ldi	r21, 0x0`
- `0x2B82` → `read8` (call 0x630C): `2B72 ldi	r31, 0x6; 2B74 std	Z+0, r16; 2B76 std	Z+1, r17; 2B78 ldi	r18, 0x30; 2B7A ldi	r19, 0x4; 2B7C call	0x16e2; 2B80 movw	r20, r24`
- `0x2C20` → `read8` (call 0x630C): `2C12 movw	r4, r18; 2C14 ldi	r26, 0x0; 2C16 ldi	r27, 0x0; 2C18 rjmp	.+14; 2C1A movw	r20, r24; 2C1C add	r20, r26; 2C1E adc	r21, r27`
- `0x2C7A` → `write8` (call 0x6340): `2C6C sbis	0xb, 0x7; 2C6E rjmp	.-4; 2C70 in	r16, 0xc; 2C72 mov	r20, r22; 2C74 mov	r21, r17; 2C76 add	r20, r24; 2C78 adc	r21, r25`
- `0x3896` → `write32` (call 0x6356): `3888 or	r16, r0; 388A or	r17, r1; 388C or	r18, r2; 388E or	r19, r3; 3890 subi	r22, 0xef; 3892 sbci	r23, 0xff; 3894 movw	r20, r22`
- `0x38FE` → `read32` (jmp 0x631C): `38EE rjmp	.-164; 38F0 rcall	.+4; 38F2 cpi	r16, 0xb; 38F4 rjmp	.-34; 38F6 lds	r16, 0x6b8; 38FA ret; 38FC movw	r20, r22`
- `0x390A` → `write16` (jmp 0x6348): `38F6 lds	r16, 0x6b8; 38FA ret; 38FC movw	r20, r22; 38FE jmp	0x631c; 3902 rcall	.+1666; 3904 lds	r20, 0x6b8; 3908 ret`
- `0x3A96` → `read8` (jmp 0x630C): `3A88 andi	r16, 0x1f; 3A8A ld	r30, X+; 3A8C ld	r31, X; 3A8E sbiw	r26, 0x1; 3A90 ret; 3A92 rcall	.-92; 3A94 rcall	.-112`
- `0x3F0C` → `write8` (jmp 0x6340): `3EFE rjmp	.+154; 3F00 rcall	.+28; 3F02 andi	r16, 0x1f; 3F04 ret; 3F06 movw	r20, r24; 3F08 rjmp	.+2; 3F0A movw	r20, r22`
- `0x3F28` → `read16` (jmp 0x6312): `3F1A movw	r20, r24; 3F1C subi	r20, 0xfc; 3F1E sbci	r21, 0xff; 3F20 rjmp	.-1164; 3F22 movw	r20, r24; 3F24 subi	r20, 0xf3; 3F26 sbci	r21, 0xff`
- `0x3F86` → `read32` (call 0x631C): `3F76 ldi	r16, 0x47; 3F78 ldi	r17, 0x7; 3F7A call	0x2362; 3F7E rjmp	.-1646; 3F80 movw	r20, r24; 3F82 subi	r20, 0xef; 3F84 sbci	r21, 0xff`
- `0x40B8` → `write32` (jmp 0x6356): `40AA ret; 40AC rcall	.-420; 40AE movw	r20, r22; 40B0 subi	r20, 0xff; 40B2 ret; 40B4 subi	r20, 0xef; 40B6 sbci	r21, 0xff`
- `0x40BE` → `write16` (call 0x6348): `40AE movw	r20, r22; 40B0 subi	r20, 0xff; 40B2 ret; 40B4 subi	r20, 0xef; 40B6 sbci	r21, 0xff; 40B8 jmp	0x6356; 40BC sbci	r21, 0xff`
- `0x48A4` → `read32` (jmp 0x631C): `4896 ldd	r16, Z+53; 4898 inc	r16; 489A std	Z+53, r16; 489C cpi	r16, 0x7; 489E ret; 48A0 add	r20, r16; 48A2 adc	r21, r17`
- `0x52C8` → `read8` (jmp 0x630C): `52B2 call	0x20da; 52B6 sts	0x739, r16; 52BA ret; 52BC call	0x133e; 52C0 jmp	0x135a; 52C4 subi	r20, 0xfc; 52C6 sbci	r21, 0xff`
- `0x53E4` → `write8` (jmp 0x6340): `53D6 st	-Y, r17; 53D8 st	-Y, r17; 53DA st	-Y, r17; 53DC st	-Y, r16; 53DE ret; 53E0 ldi	r20, 0xed; 53E2 ldi	r21, 0x2`
- `0x5746` → `write32` (call 0x6356): `5738 ldd	r16, Y+22; 573A ldd	r17, Y+23; 573C ldd	r18, Y+24; 573E ldd	r19, Y+25; 5740 movw	r20, r22; 5742 subi	r20, 0xef; 5744 sbci	r21, 0xff`
- `0x5860` → `recv_uart_eeprom` (jmp 0x2C5C): `5852 ldi	r17, 0x0; 5854 ret; 5856 ldi	r18, 0x7; 5858 ldi	r19, 0x0; 585A ldi	r16, 0x45; 585C ldi	r17, 0x0; 585E ret`
- `0x5864` → `send_eeprom_uart` (jmp 0x2C08): `5854 ret; 5856 ldi	r18, 0x7; 5858 ldi	r19, 0x0; 585A ldi	r16, 0x45; 585C ldi	r17, 0x0; 585E ret; 5860 jmp	0x2c5c`
- `0x58AA` → `send_eeprom_uart` (call 0x2C08): `589C rcall	.+54; 589E ldi	r18, 0x8; 58A0 ldi	r19, 0x0; 58A2 ldi	r16, 0x27; 58A4 ldi	r17, 0x7; 58A6 ret; 58A8 sbci	r17, 0xff`
- `0x58B8` → `write16` (jmp 0x6348): `58A8 sbci	r17, 0xff; 58AA call	0x2c08; 58AE movw	r20, r26; 58B0 ret; 58B2 andi	r16, 0xf; 58B4 rjmp	.+76; 58B6 sbci	r21, 0xff`
