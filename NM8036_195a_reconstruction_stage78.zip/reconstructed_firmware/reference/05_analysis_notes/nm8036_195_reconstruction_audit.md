# NM8036 1.95a — audit of L handler and decoder

Inputs: `nm8036_195_corrected.bin`, `nm8036_195_corrected.asm`, `NMBM8036.pdf`.

## Confirmed corrections to earlier reconstruction

The LLVM AVR disassembly merges several *valid pairs of 16-bit instructions* into one `<unknown>` line. This causes incorrect reconstruction if the text listing is taken at face value. Re-reading the **raw little-endian 16-bit words** shows:

- `0x55A8: 0x01AD` = `MOVW r20,r26`; `0x55AA: 0x5F4A` = `SUBI r20,0xFA` (the disassembler displayed them as one unknown 4-byte instruction).
- `0x55CE: 0x9502` = `SWAP r16`? **No**: 0x9502 is `SWAP r16` (AVR opcode `1001 010d dddd 0010`). Earlier quick classification as `INC` was incorrect; correct classification is `SWAP`.
- `0x55D0: 0xD170` = `RCALL 0x58B2`.
- `0x55E6: 0x018D` = `MOVW r16,r26`; `0x55E8: 0x5F03` = `SUBI r16,0xF3`.
- `0x55F0: 0x018D` = `MOVW r16,r26`; `0x55F2: 0x5F01` = `SUBI r16,0xF1`.
- `0x55F8: 0x01AD` = `MOVW r20,r26`; `0x55FA: 0x5F4F` = `SUBI r20,0xFF`.
- `0x5604: 0x018D` = `MOVW r16,r26`; `0x5606: 0x5E0F` = `SUBI r16,0xEF`.

`0x5642: CPI r24,0x20` is consistent with the manual's 32 records. The 27-byte wire structure is documented in `nm8036_195_annotated_protocol.h`, but no exact internal-memory layout has been proved yet.

## Limits

`nm8036_195_L_verified.c` now records the **first part of the real register-level operation sequence** with explicit unresolved helper calls, rather than inventing the field serializer. It is *not* a complete translation, and its helper callback is not a hardware model.

`nm8036_195_L_word_accurate.txt` contains the 90 words of the complete `L` region for independent inspection. It is an instruction-word index, not a full decompiler.
