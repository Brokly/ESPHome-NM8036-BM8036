# NM8036 1.95a — reconstruction status

Source image: `nm8036_195_corrected.bin` (28,668 bytes). Only version 1.95a is used.

## Confirmed from AVR machine instructions

- Reset vector `0x0000` is `JMP 0x62B8` (`0C 94 5C 31`).
- `0x62B8`: `LDI r16,0x5F`, `OUT 0x3D,r16`; `LDI r16,0x06`, `OUT 0x3E,r16`: initial SP = `0x065F`.
- `0x62C0`: `LDI r28,0x60`, `LDI r29,0x03`: Y = `0x0360` (note this is a RAM pointer, **not evidence** for the UART L length).
- `0x62C4`: `CALL 0x6A34`; the target consists of `LDI r16,1; RET`.
- `0x62CC`: conditional `CALL 0x6B1A` (because the preceding return is 1, this branch is taken under the observed behavior).
- `0x62D0`–`0x62D6`: load r16:r17 = 0x0CBC and r18:r19 = 0x0CBE.
- `0x62D8`: `CALL 0x61EC`; `0x62DC`: `CALL 0x41BC`; `0x62E0`: `CALL 0x6370`; `0x62E4`: `JMP 0x59FC`.
- `0x6A38`–`0x6A62`: byte-wise comparison returning -1, 0, or +1 (the argument register convention is not yet resolved).
- `0x6A66`–`0x6A76`: fill byte loop, stores r18 through Z for r20:r21 iterations.
- `0x62F8`–`0x62FC`: wait for bit 1 of I/O register 0x1C to clear.

## Not yet reconstructed

UART dispatcher, buffer addresses, record layout implementation, RTC logic, display code, sensor logic, and complete call graph. The command letters and lengths from the manual are validation targets, not evidence of recovered firmware handlers.

## Limitations

The C file is a **partial semantic translation** of specific verified instruction ranges. It is not complete, not bit-for-bit equivalent to the firmware, and not intended to be flashed. Some helper function signatures are placeholders because the compiler ABI is unknown.
