# NM8036 1.95a — additional UART reconstruction

Verified against `nm8036_195_corrected.asm` / `.bin`.

| AVR address | Command | Concrete code evidence | Translation |
|---|---|---|---|
| 0x579A | D | LDI R18:R19 = 0x0100; R16:R17 = 0x02F0 | Echo and transmit 256 SRAM bytes |
| 0x57AA | d | LDS 0x068E; STS 0x068E, 0 | Echo, transmit flag, clear flag |
| 0x5838 | s | R18:R19 = 8; R16:R17 = 0x0673 | Echo and transmit 8 SRAM bytes |
| 0x581E | S | helper 0x1F26; R18:R19 = 0x0060; call 0x2C36 | Echo and transmit 96 LCD bytes |
| 0x580E | K | R18:R19 = 1; R16:R17 = 0x0739; call 0x5902 | Echo and receive one byte into SRAM |
| 0x5532 | E | LDI R16,0x45; RCALL transmit; boot transition | Echo and transition to bootloader (callback placeholder) |
| 0x57BC | H | LDI R18,0x22; receive helper | 34-byte transfer indicated; exact memory side effects pending |
| 0x57C8 | h | LDI R18,0x22; transmit helper | 34-byte transfer indicated; exact memory source pending |
| 0x5596 | L | Loop up to 0x20 records, field-wise operations | Not yet faithfully reconstructed |

The generated C compiles with `cc -std=c11 -Wall -Wextra -Werror -fsyntax-only`.
It is **not** a complete decompilation and does not reproduce hardware behavior in isolation.
