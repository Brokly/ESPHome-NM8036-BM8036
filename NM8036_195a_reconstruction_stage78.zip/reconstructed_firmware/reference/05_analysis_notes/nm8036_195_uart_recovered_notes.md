# NM8036 1.95a — recovered UART driver

Input: `/mnt/data/nm8036_195_corrected.bin` (28,668 bytes). Only 1.95a.

The code in `nm8036_195_uart_recovered.c` is a **semantic C reconstruction** of specific AVR routines, not the original source.

| AVR byte address | Verified behavior | C function |
|---|---|---|
| `0x2BDC` | Poll UCSRA bit 5 (UDRE), write r16 to UDR | `nm_uart_putc` |
| `0x2BE4` | Test UCSRA bit 7 (RXC), read UDR and store via Z; return flag | `nm_uart_try_getc` |
| `0x2BF6` | UBRRL=12; UCSRA=2; UCSRB=0x18; UCSRC=0x8E | `nm_uart_init` |
| `0x2C36` | Loop reading RAM bytes and transmit using `0x2BDC` | `nm_uart_write_exact` |
| `0x2C90` | Loop polling RXC, reading UDR and writing to Z-indexed RAM | `nm_uart_read_exact` |

**Caveats:** `llvm-objdump` displays some 32-bit AVR instructions as `<unknown>` and sometimes groups bytes unexpectedly; the above routine boundaries were inspected using raw opcode bytes and surrounding control flow. Function signatures and calling convention are adapted for readable C, not yet proven identical to the original compiler ABI. Do not flash this file.

**UART setting:** 8 data bits, two stop bits, U2X enabled, no parity. Baud depends on MCU clock; for F_CPU=1MHz, UBRRL=12 yields ~9615 baud, consistent with manual 9600.

**Remaining:** recover the command dispatcher and specific responses (`V`, `L` 864 bytes, `D` 256 bytes, `S` 96 bytes) from reachable code. These are not yet proven from the binary.
