# NM8036: differential evidence for additive cipher

Files: `nm8036_v14/flasher/8036.cod` (28898 bytes), `8036_195.cod` (28924 bytes).

Define for aligned windows `delta[t] = (B[j+t] - A[i+t]) mod 256`.
Test whether `delta[t] == delta[t+256]` and compare against XOR `B[j+t] ^ A[i+t]`.

| region | i in 1.4a | j in 1.95a | length | additive matches | XOR matches |
|---|---:|---:|---:|---:|---:|
| tail | 27139 | 26889 | 171 | 171 | 33 |
| early | 836 | 826 | 158 | 158 | 50 |
| start | 159 | 159 | 97 | 97 | 36 |

The result favors modular addition/subtraction over XOR as a model for the observed *differential invariant*. It does not recover absolute key bytes. In particular, if ciphertext is `C=P+K (mod 256)` and two aligned source segments have identical plaintext, delta reveals `K_B-K_A`, not either absolute key. Alignment of plaintext and the additive model are hypotheses, not independently verified.

Next: recover known plaintext (AVR vector table / UART handlers) or the on-chip bootloader to fix the key's absolute values. Do not confuse UART application protocol responses with bootloader transport framing.
