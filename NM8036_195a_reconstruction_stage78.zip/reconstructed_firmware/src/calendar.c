#include "nm_peripherals.h"

/* [БИНАРНИК] Таблица длительностей месяцев 0x0790..0x079C.
 * Вход календарной функции ограничен месяцами 0..12. */
static const uint8_t month_days[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};

/* [БИНАРНИК] 0x3AF4..0x3BAA. Сохраняет оригинальный расчёт:
 * добавка високосного дня при месяце 3 и годе, кратном четырём,
 * число полных високосных лет берётся как year >> 2. */
uint32_t nm_calendar_seconds(uint8_t year, uint8_t month, uint8_t day,
                             uint8_t hour, uint8_t minute, uint8_t second)
{
    uint32_t days = 365ul * year + (year >> 2) + day - 1u;
    for (uint8_t i = 1; i < month && i < sizeof month_days; i++)
        days += month_days[i];
    if (month == 3 && (year & 3u) == 0)
        days++;
    return days * 86400ul + 3600ul * hour + 60ul * minute + second;
}

static uint8_t bcd(uint8_t value)
{
    return 10u * (value >> 4) + (value & 15u);
}

/* [БИНАРНИК] 0x3BD0..0x3D3E, 0x3D88..0x3D94.
 * Календарная часть шага программы. Поля из EEPROM читаются в их
 * внутреннем упакованном виде. Полуинтервал [начало, конец),
 * при переходе через полночь ветвь 0x3D20 использует строгие сравнения.
 * [РУКОВОДСТВО] Периодичность по дням, дням недели и месяцам. */
bool nm_schedule_window(const NM8036 *m, uint8_t index, const uint8_t rtc[8])
{
    uint16_t base = 0x4cu + 21u * index;
    if (!(nm_ee_read(m, base + 3) & 0x80u))
        return false;
    uint8_t minute_on = nm_ee_read(m, base);
    uint8_t minute_off = nm_ee_read(m, base + 7);
    uint8_t period = nm_ee_read(m, base + 1) >> 6;
    uint8_t hour = bcd(rtc[2] & 0x3f);
    uint8_t minute = bcd(rtc[1] & 0x7f);
    uint8_t second = bcd(rtc[0] & 0x7f);
    uint8_t day = bcd(rtc[4] & 0x3f);
    uint8_t month = bcd(rtc[5] & 0x1f);
    uint8_t year = bcd(rtc[6]);
    uint8_t start_h = nm_ee_read(m, base + 6) & 31;
    uint8_t stop_h = nm_ee_read(m, base + 5) & 31;
    uint8_t start_s = nm_ee_read(m, base + 1) & 63;
    uint8_t stop_s = nm_ee_read(m, base + 8) & 63;
    if (period == 0) {
        uint8_t months = nm_ee_read(m, base + 4);
        uint32_t now = nm_calendar_seconds(year, month, day, hour, minute, second);
        uint32_t start = nm_calendar_seconds(nm_ee_read(m, base + 3) & 127,
            months & 15, nm_ee_read(m, base + 9) & 31, start_h, minute_on & 63, start_s);
        uint32_t stop = nm_calendar_seconds(nm_ee_read(m, base + 2) & 127,
            months >> 4, nm_ee_read(m, base + 10) & 31, stop_h, minute_off & 63, stop_s);
        return now >= start && now < stop;
    }
    uint8_t bit = (uint8_t)((period == 1 ? rtc[3] & 7u : period == 2 ? day : month) - 1u);
    /* Подпрограмма 0x645A прекращает сдвиги сразу для 0x81..0xFF
       и после переполнения регистра для счётчиков 32..128. */
    if (bit > 128)
        bit = 0;
    if (bit >= 32 || !(nm_ee_read(m, base + 17 + bit / 8u) & (1u << (bit & 7u))))
        return false;
    uint32_t now = 3600ul * hour + 60ul * minute + second;
    uint32_t start = 3600ul * start_h + 60ul * (minute_on & 63u) + start_s;
    uint32_t stop = 3600ul * stop_h + 60ul * (minute_off & 63u) + stop_s;
    return stop < start ? now < stop || now > start : now >= start && now < stop;
}

static int16_t read_signed_ee(const NM8036 *m, uint16_t address)
{
    uint8_t low = nm_ee_read(m, address);
    return (int16_t)(low | ((uint16_t)nm_ee_read(m, address + 1) << 8));
}

static int16_t read_signed_ram(const NM8036 *m, uint16_t address)
{
    volatile uint8_t *p = nm_ram(m, address);
    uint8_t low = p[0];
    return (int16_t)(low | ((uint16_t)p[1] << 8));
}

/* [БИНАРНИК] 0x3CCC..0x3E7C, 0x3FD4..0x3FE8.
 * Уставки нагрева/охлаждения со знаковым сравнением, гистерезисом
 * и логическим состоянием канала из предыдущего прохода. */
static bool thermostat(const NM8036 *m, uint16_t base, uint8_t mode, uint8_t channel)
{
    bool analog = (nm_ee_read(m, base + 5) & 0x20) != 0;
    uint8_t sensor = nm_ee_read(m, base + 11);
    if (!analog && *nm_ram(m, 0x0707 + sensor) == 0)
        return false;
    int16_t sample = analog ? read_signed_ram(m, 0x0677 + 2u * (sensor & 1u))
                            : read_signed_ram(m, 0x06c7 + 2u * sensor);
    int16_t low = read_signed_ee(m, base + 13);
    int16_t high = read_signed_ee(m, base + 15);
    if (nm_ee_read(m, base + 6) & 0x20) {
        int16_t reference = read_signed_ram(m, 0x06c7 + 2u * (uint8_t)low);
        low = (int16_t)((uint16_t)reference - 50u);
        high = (int16_t)((uint16_t)reference + 50u);
    }
    if (mode == 0) {
        if (sample <= low)
            return true;
        if (sample >= high)
            return false;
    } else {
        if (sample >= high)
            return true;
        if (sample <= low)
            return false;
    }
    return *nm_ram(m, 0x0747 + 37 + channel) != 0;
}

/* [БИНАРНИК] 0x3BC0..0x3EBC. Один вызов проходит одну запись.
 * После каждой группы из 32 записей логические запросы публикуются
 * сразу для всех 12 каналов. Физические выходы обновляет INT0.
 * read_key должен вернуть сырой код, как 0x203E. */
void nm_schedule_step(const NM8036 *m, uint8_t (*read_key)(const NM8036 *))
{
    uint8_t saved = m->irq_disable(m->context);
    volatile uint8_t *work = nm_ram(m, 0x06b9);
    uint8_t index = work[0];
    uint16_t base = 0x4cu + 21u * index;
    uint8_t channel_config = nm_ee_read(m, base + 12);
    uint8_t channel = channel_config & 127u;
    uint8_t mode = nm_ee_read(m, base) >> 6;

    if (nm_ee_read(m, base + 3) & 0x80u) {
        uint8_t rtc[8];
        for (uint8_t i = 0; i < 8; i++)
            rtc[i] = nm_ram(m, 0x0727)[i];
        bool active = false;
        if (nm_schedule_window(m, index, rtc)) {
            if (mode == 2) {
                uint8_t alarm = nm_ee_read(m, base + 5);
                if (!(alarm & 0xc0u)) {
                    alarm |= 0x40u;
                    nm_ee_write(m, base + 5, alarm);
                    *nm_ram(m, 0x0737) = 1;
                }
                if ((alarm & 0xc0u) == 0x40u && read_key(m) == 0) {
                    nm_ee_write(m, base + 5, (alarm & 0x3fu) | 0x80u);
                    *nm_ram(m, 0x0737) = 0;
                }
            } else if (nm_ee_read(m, 0x02ed)) {
                active = mode == 3 || thermostat(m, base, mode, channel);
            }
        } else if (mode == 2) {
            uint8_t alarm = nm_ee_read(m, base + 5);
            if ((alarm & 0xc0u) == 0x40u)
                *nm_ram(m, 0x0737) = 0;
            if (alarm & 0xc0u)
                nm_ee_write(m, base + 5, alarm & 0x3fu);
        }
        /* Руководство определяет только штатные номера каналов. */
        if (channel < 12) {
            uint8_t pending = work[1 + channel];
            work[1 + channel] = (channel_config & 0x80u) ? pending & active : pending | active;
        }
    }

    work[0]++;
    if (work[0] >= NM_RECORDS) {
        for (uint8_t i = 0; i < 12; i++) {
            nm_output_request(m, i, work[1 + i] != 0);
            work[1 + i] = 0;
        }
        work[0] = 0;
    }
    m->irq_restore(m->context, saved);
}
