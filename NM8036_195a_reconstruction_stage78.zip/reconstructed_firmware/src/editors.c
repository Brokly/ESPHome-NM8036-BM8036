#include "nm_editors.h"
#include <string.h>

static volatile uint8_t *pwm(const NM8036 *m, NMPwmSetting setting)
{
    return setting == NM_EDIT_BACKLIGHT ? m->backlight_pwm : m->contrast_pwm;
}

static volatile uint8_t *value(const NM8036 *m, NMPwmSetting setting)
{
    return nm_ram(m, 0x0745 + setting);
}

/* [БИНАРНИК] 0x5346..0x5352, 0x5404..0x5410.
 * Начальное значение берётся из инвертированного регистра ШИМ. */
void nm_pwm_editor_open(const NM8036 *m, NMPwmSetting setting)
{
    *value(m, setting) = (uint8_t)~*pwm(m, setting);
}

/* [БИНАРНИК] 0x5356..0x539D и 0x5414..0x5467. Пробное
 * значение применяется сразу. Клавиша 0 записывает EEPROM,
 * клавиша 5 восстанавливает ранее сохранённое значение. */
NMEditResult nm_pwm_editor_key(const NM8036 *m, NMPwmSetting setting, uint8_t key)
{
    bool brightness = setting == NM_EDIT_BACKLIGHT;
    uint8_t minimum = brightness ? 0 : 100;
    int8_t step = 0;
    switch (key) {
    case 2: step = brightness ? -5 : -3; break;
    case 3: step = brightness ? 5 : 3; break;
    case 0x82: step = brightness ? -20 : -10; break;
    case 0x83: step = brightness ? 20 : 10; break;
    default: break;
    }
    volatile uint8_t *current = value(m, setting);
    if (step) {
        int16_t next = (int16_t)*current + step;
        if (step < 0 && next < minimum)
            next = minimum;
        if (step > 0 && next > 255)
            next = 255;
        *current = (uint8_t)next;
    }
    *pwm(m, setting) = (uint8_t)~*current;
    uint16_t address = 0x02ee + setting;
    if (key == 0) {
        nm_ee_write(m, address, *current);
        return NM_EDIT_SAVED;
    }
    if (key == 5) {
        *pwm(m, setting) = (uint8_t)~nm_ee_read(m, address);
        return NM_EDIT_CANCELLED;
    }
    return NM_EDIT_ACTIVE;
}

/* [БИНАРНИК] 0x4EC6..0x4EE7. Здесь нет промежуточного
 * значения. Клавиши 1/4, включая повтор, сразу меняют EEPROM.
 * Нулевой код или 5 завершают экран, 0xFF ничего не меняет. */
bool nm_sound_editor_key(const NM8036 *m, uint8_t key)
{
    if (key == 0 || key == 5)
        return true;
    if (key != 0xff && ((key & 15u) == 1 || (key & 15u) == 4))
        nm_ee_write(m, 0x02ec, (nm_ee_read(m, 0x02ec) + 1u) & 1u);
    return false;
}

/* Текстовые метки из flash. Числовое поле повторяет назначение
 * экрана 0x2872, точная позиция числа требует проверки на LCD. */
void nm_pwm_editor_screen(const NM8036 *m, NMPwmSetting setting, uint8_t screen[32])
{
    static const uint8_t brightness[] = {0x20,0x20,0x20,0x20,0xdf,0xf0,0xea,0xee,0xf1,0xf2,0xfc};
    static const uint8_t contrast[] = {0x20,0xca,0xee,0xed,0xf2,0xf0,0xe0,0xf1,0xf2,0xed,0xee,0xf1,0xf2,0xfc};
    memset(screen, ' ', 32);
    if (setting == NM_EDIT_BACKLIGHT)
        memcpy(screen, brightness, sizeof brightness);
    else
        memcpy(screen, contrast, sizeof contrast);
    uint8_t number = *value(m, setting);
    screen[23] = number >= 100 ? '0' + number / 100 : ' ';
    screen[24] = number >= 10 ? '0' + number / 10 % 10 : ' ';
    screen[25] = '0' + number % 10;
}

void nm_sound_editor_screen(const NM8036 *m, uint8_t screen[32])
{
    static const uint8_t title[] = {0x20,0x20,0x20,0x20,0x20,0xc7,0xe2,0xf3,0xea};
    static const uint8_t on[] = {0x20,0x20,0x20,0x20,0xc2,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
    static const uint8_t off[] = {0x20,0x20,0x20,0x20,0xc2,0xfb,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
    memset(screen, ' ', 32);
    memcpy(screen, title, sizeof title);
    if (nm_ee_read(m, 0x02ec))
        memcpy(screen + 16, on, sizeof on);
    else
        memcpy(screen + 16, off, sizeof off);
}

/* [БИНАРНИК] 0x4AC4..0x4C6C.
 * 2/3 выбирают поле с переходом через край. 1/4 меняют
 * выбранное BCD-поле и сразу записывают восемь байтов DS1307.
 * Выход по 5 не отменяет записи, уже произведённые при изменении. */
bool nm_clock_editor_key(const NM8036 *m, uint8_t key)
{
    key &= 15u;
    if (key == 5)
        return true;
    volatile uint8_t *field = nm_ram(m, 0x0740);
    if (key == 2)
        (*field)--;
    if (key == 3)
        (*field)++;
    if (*field >= 7)
        *field = *field == 0xff ? 6 : 0;
    if (key != 1 && key != 4)
        return false;

    static const uint8_t offset[] = {2, 1, 0, 3, 4, 5, 6};
    static const uint8_t mask[] = {0x3f, 0x7f, 0x7f, 7, 0x3f, 0x1f, 0xff};
    static const uint8_t maximum[] = {23, 59, 59, 7, 31, 12, 99};
    uint8_t selected = *field;
    volatile uint8_t *rtc = nm_ram(m, 0x0727);
    uint8_t index = offset[selected];
    uint8_t raw = rtc[index] & mask[selected];
    uint8_t decimal = 10u * (raw >> 4) + (raw & 15u);
    uint8_t minimum = selected >= 3 && selected <= 5;
    if (key == 1) {
        decimal++;
        if (decimal > maximum[selected])
            decimal = minimum;
    } else {
        decimal--;
        if ((!minimum && decimal == 0xff) || (minimum && decimal == 0))
            decimal = maximum[selected];
    }
    uint8_t bcd = (uint8_t)(((decimal / 10u) << 4) | (decimal % 10u));
    rtc[index] = (rtc[index] & (uint8_t)~mask[selected]) | (bcd & mask[selected]);

    uint8_t block[8];
    for (uint8_t i = 0; i < sizeof block; i++)
        block[i] = rtc[i];
    m->rtc_write(m->context, 0, block, sizeof block);
    return false;
}

/* [БИНАРНИК] 0x172A..0x17FC, экземпляр числового редактора
 * из 0x2646. Границы активности 1..65535, паузы 0..65535.
 * Одиночные шаги допускают достижение границы, ускоренные —
 * только значения строго между границами. MENU передаёт исходное
 * поле возврата, заданное в 0x2668 равным 65535.
 */
bool nm_output_editor_key(uint8_t row, uint16_t *seconds, uint8_t key)
{
    const int32_t minimum = row < 12 ? 1 : 0;
    int32_t value = *seconds;
    int16_t delta;
    switch (key) {
    case 1:
        if (value < UINT16_MAX)
            (*seconds)++;
        break;
    case 4:
        if (value > minimum)
            (*seconds)--;
        break;
    case 2: delta = -100; goto accelerated;
    case 3: delta = 100; goto accelerated;
    case 0x81: delta = 10; goto accelerated;
    case 0x84: delta = -10; goto accelerated;
    case 0x82: delta = -1000; goto accelerated;
    case 0x83:
        delta = 1000;
accelerated:
        value += delta;
        if (value > minimum && value < UINT16_MAX)
            *seconds = (uint16_t)value;
        break;
    case 5:
        *seconds = UINT16_MAX;
        return true;
    }
    return (key & 15u) == 0;
}

/* [БИНАРНИК] 0x2DF2..0x2F75. Контекст оригинала +3..+8
 * хранит Ч:М:С, день, месяц и год, +9 — позицию. При каждом вызове
 * отбрасываются значения выше границ. Нуль дня и месяца
 * оригинал сохраняет до следующего нажатия. */
void nm_program_time_key(NMProgramTime *time, uint8_t key)
{
    static const uint8_t low[] = {0, 0, 0, 1, 1, 0};
    static const uint8_t high[] = {23, 59, 59, 31, 12, 99};
    for (uint8_t i = 0; i < 6; i++)
        if (time->field[i] > high[i])
            time->field[i] = low[i];

    key &= 15u;
    uint8_t cursor = time->cursor;
    if (key == 2)
        cursor--;
    else if (key == 3)
        cursor++;
    else if (cursor < 6) {
        uint8_t *p = &time->field[cursor];
        if (key == 1)
            *p = *p == high[cursor] ? low[cursor] : *p + 1u;
        else if (key == 4) {
            (*p)--;
            if (*p == (uint8_t)(low[cursor] - 1u))
                *p = high[cursor];
        }
    }
    time->cursor = cursor >= 101 ? 5 : cursor >= 6 ? 0 : cursor;
}

/* [БИНАРНИК] 0x352A..0x35F9. Контекст +2 и +4 содержит
 * знаковые слова уставок, +7 — выбранное поле. Стрелки по
 * вертикали меняют поле, по горизонтали — значение. */
void nm_program_threshold_key(NMThresholds *editor, uint8_t key)
{
    uint8_t action = key & 15u;
    if (action == 1 || action == 4)
        editor->selected ^= 1u;
    if (action != 2 && action != 3)
        return;

    uint16_t step = editor->analog ? 1u : 10u;
    if (key & 0x80u)
        step *= 10u;
    uint16_t value = (uint16_t)editor->value[editor->selected];
    value = action == 2 ? value - step : value + step;
    editor->value[editor->selected] = (int16_t)value;
    const int16_t low = editor->analog ? 0 : -5500;
    const int16_t high = editor->analog ? 1023 : 12500;
    for (uint8_t i = 0; i < 2; i++) {
        if (editor->value[i] < low)
            editor->value[i] = low;
        else if (editor->value[i] > high)
            editor->value[i] = high;
    }
}
