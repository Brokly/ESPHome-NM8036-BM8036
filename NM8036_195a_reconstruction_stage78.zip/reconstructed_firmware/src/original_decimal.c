#include "nm_original_decimal.h"
#include "nm_original_numeric.h"
#include <string.h>

static uint32_t scale_float(uint32_t word, uint32_t factor, bool divide)
{
    float a, b;
    memcpy(&a, &word, sizeof word);
    memcpy(&b, &factor, sizeof factor);
    float result = divide ? a / b : a * b;
    memcpy(&word, &result, sizeof word);
    return word;
}

/* Пакет масштабирования 0x5A5A–0x5ABE.
 * r24:r27 хранит модуль binary32, r8:r9 — десятичный порядок.
 * Сначала шаг 10^10, затем шаг 10. Константы округлены до
 * исходных слов, поэтому замена на вычисление log10 меняет результат.
 * +Inf сохраняет цикл деления оригинала. NaN минует сравнения. */
NMDecimalScale nm_avr_decimal_scale(uint32_t magnitude)
{
    NMDecimalScale result = {magnitude, 0};
    if (nm_avr_binary32_ge(magnitude, UINT32_C(0x3f800000))) {
        while (nm_avr_binary32_ge(result.magnitude, UINT32_C(0x51ba43b7))) {
            result.magnitude = scale_float(result.magnitude, UINT32_C(0x501502f9), true);
            result.exponent = (int16_t)((uint16_t)result.exponent + 10u);
        }
        while (nm_avr_binary32_ge(result.magnitude, UINT32_C(0x41200000))) {
            result.magnitude = scale_float(result.magnitude, UINT32_C(0x41200000), true);
            result.exponent = (int16_t)((uint16_t)result.exponent + 1u);
        }
    } else if (magnitude & UINT32_C(0x7fffffff)) {
        while (nm_avr_binary32_less(result.magnitude, UINT32_C(0x2edbe700))) {
            result.magnitude = scale_float(result.magnitude, UINT32_C(0x501502f9), false);
            result.exponent = (int16_t)((uint16_t)result.exponent - 10u);
        }
        while (nm_avr_binary32_less(result.magnitude, UINT32_C(0x3f800000))) {
            result.magnitude = scale_float(result.magnitude, UINT32_C(0x41200000), false);
            result.exponent = (int16_t)((uint16_t)result.exponent - 1u);
        }
    }
    return result;
}

/* 0x5B64–0x5B93. Буфер содержит минимум один знак. Десятичная
 * точка пропускается. Возврат true означает перенос через весь буфер. */
bool nm_avr_decimal_carry(uint8_t *digits, size_t length)
{
    bool carry = true;
    while (length) {
        uint8_t *digit = &digits[--length];
        if (*digit == '.')
            continue;
        *digit += carry;
        carry = *digit == ':';
        if (carry)
            *digit = '0';
    }
    return carry;
}

/* 0x5BEE–0x5C05. Нули удаляются с конца, затем одна точка.
 * Предусловие оригинала: среди предыдущих символов есть ненулевой байт. */
size_t nm_avr_decimal_trim(const uint8_t *digits, size_t length)
{
    while (digits[length - 1] == '0')
        --length;
    return length - (digits[length - 1] == '.');
}

/* 0x5C0C–0x5C7B. Буква режима, знак, минимум две цифры.
 * Отрицание выполняется в 16-битном слове. */
size_t nm_avr_decimal_exponent(uint8_t *output, uint8_t marker, int16_t exponent)
{
    uint16_t magnitude = (uint16_t)exponent;
    output[0] = marker;
    output[1] = exponent < 0 ? '-' : '+';
    if (exponent < 0)
        magnitude = (uint16_t)(0u - magnitude);
    uint8_t reverse[5];
    size_t size = 0;
    do {
        reverse[size++] = (uint8_t)('0' + magnitude % 10);
        magnitude /= 10;
    } while (magnitude || size < 2);
    for (size_t i = 0; i < size; ++i)
        output[2 + i] = reverse[size - i - 1];
    return size + 2;
}

/* 0x6084–0x60A3. r4:r5 — конец, r6:r7 — начало, r10:r11 —
 * ширина. Возвращается счётчик r24:r25. Вычитание знака выполняется
 * после сравнения, поэтому ширина впритык со знаком даёт 0xFFFF. */
uint16_t nm_avr_decimal_padding(uint16_t width, uint16_t length, uint16_t offset, bool sign)
{
    uint16_t count = length - offset;
    if ((width ^ 0x8000u) < (count ^ 0x8000u))
        return 0;
    return (uint16_t)(width - count - sign);
}

static uint16_t format_argument(const uint8_t *sram, uint16_t *argument)
{
    uint16_t at = *argument;
    *argument = at + 2u;
    return sram[at] | (uint16_t)sram[(uint16_t)(at + 1u)] << 8;
}

/* 0x6C16–0x6D87. Это отдельный форматтер строк SRAM.
 * r16:r17 — адрес callback в словах, r18:r19 — его состояние,
 * r20:r21 — строка, r22:r23 — адрес указателя аргументов.
 * Неизвестный спецификатор пропускается. Для d и i
 * старший бит вызывает '-', но модуль берётся
 * только для d. Сохраняется именно это различие. */
uint16_t nm_avr_format_ram(const uint8_t *sram, const uint8_t *format,
                           uint16_t *argument, uint16_t state,
                           NMFormatEmit emit, void *context)
{
    while (*format) {
        uint8_t ch = *format++;
        if (ch != '%') {
            state = emit(context,state,ch);
            continue;
        }
        ch = *format++;
        if (ch == '%') {
            state = emit(context,state,sram[0x0671]);
        } else if (ch == 'c') {
            state = emit(context,state,(uint8_t)format_argument(sram,argument));
        } else if (ch == 's') {
            uint16_t address = format_argument(sram,argument);
            while (sram[address])
                state = emit(context,state,sram[address++]);
        } else if (ch == 'd' || ch == 'i' || ch == 'o' || ch == 'u' ||
                   ch == 'x' || ch == 'X' || ch == 'p') {
            uint16_t value = format_argument(sram,argument);
            if (ch == 'p')
                ch = 'x';
            if ((ch == 'd' || ch == 'i') && (value & 0x8000u))
                state = emit(context,state,sram[0x066f]);
            if (ch == 'd' && (value & 0x8000u))
                value = (uint16_t)(0u - value);
            uint8_t base = ch == 'o' ? 8 : (ch == 'x' || ch == 'X' ? 16 : 10);
            uint8_t digits[6];
            uint8_t count = 0;
            do {
                uint8_t digit = value % base;
                digits[count++] = (uint8_t)('0' + digit +
                    (digit >= 10 ? ch - 'Q' : 0));
                value /= base;
            } while (value);
            while (count)
                state = emit(context,state,digits[--count]);
        }
    }
    return 0;
}

/* 0x5B14–0x5B63. Усечение, знаковое расширение младшего
 * слова, вычитание из текущей мантиссы, умножение остатка на 10.
 * У NaN арифметика оригинала возвращает каноническое 0xFFFF0000. */
bool nm_avr_decimal_digits(uint8_t *digits, uint16_t count, uint32_t magnitude,
                           bool point, bool sticky)
{
    for (uint16_t i = 0; i < count; ++i) {
        uint32_t integer = (uint16_t)nm_avr_binary32_to_int(magnitude);
        *digits++ = (uint8_t)('0' + integer);
        if (!i && point)
            *digits++ = '.';
        if (nm_avr_binary32_flags(magnitude) & 1u) {
            magnitude = UINT32_C(0xffff0000);
        } else {
            if (integer & 0x8000u)
                integer |= UINT32_C(0xffff0000);
            uint32_t raw = nm_avr_int_to_binary32(integer, true, sticky);
            float current, truncated;
            memcpy(&current,&magnitude,sizeof current);
            memcpy(&truncated,&raw,sizeof truncated);
            float remainder = current - truncated;
            memcpy(&magnitude,&remainder,sizeof remainder);
            magnitude = scale_float(magnitude,UINT32_C(0x41200000),false);
        }
    }
    return nm_avr_binary32_ge(magnitude, UINT32_C(0x40a00000));
}

/* 0x5B94–0x5BE5. В научной форме точка сохраняется на
 * месте и возрастает порядок. Для обычной записи сдвигается
 * вся строка. digits имеет место для дополнительного байта. */
size_t nm_avr_decimal_leading_carry(uint8_t *digits, size_t length,
                                     int16_t *exponent, bool scientific)
{
    if (scientific) {
        for (size_t i = length - 1; i > 1; --i)
            digits[i] = digits[i - 1] == '.' ? digits[i - 2] : digits[i - 1];
        *exponent = (int16_t)((uint16_t)*exponent + 1u);
    } else {
        memmove(digits + 1, digits, length++);
    }
    digits[0] = '1';
    return length;
}

/* Сквозной специализированный %9.2e из 0x01A7. Это
 * фиксированный путь Flash-форматтера, без остальных спецификаторов.
 * На обозначенном пути оригинал скрывает знак отрицательного нуля. */
void nm_avr_format_e92(uint8_t output[10], uint32_t word, bool sticky)
{
    bool negative = nm_avr_binary32_less(word, 0);
    NMDecimalScale v = nm_avr_decimal_scale(negative ? word ^ UINT32_C(0x80000000) : word);
    output[0] = negative ? '-' : ' ';
    if (nm_avr_decimal_digits(output + 1, 3, v.magnitude, true, sticky) &&
        nm_avr_decimal_carry(output + 1, 4))
        nm_avr_decimal_leading_carry(output + 1, 4, &v.exponent, true);
    output[5 + nm_avr_decimal_exponent(output + 5, 'e', v.exponent)] = 0;
}

static uint16_t parse_digits(const uint8_t **format)
{
    uint16_t value = 0;
    while (**format >= '0' && **format <= '9')
        value = (uint16_t)(10u * value + *(*format)++ - '0');
    return value;
}

/* 0x5D32–0x5E47. Вход после процента, выход после
 * спецификатора. r10:r11 ширина, r8:r9 точность, r24
 * широкий аргумент. Счётчики флагов Y+2..4 могут переполняться. */
NMFlashFormat nm_avr_flash_format_parse(const uint8_t **format,
                                        const uint8_t *sram, uint16_t *argument)
{
    NMFlashFormat out = {.precision = UINT16_MAX};
    for (;;) {
        uint8_t byte = **format;
        if (byte == '+' || (byte == ' ' && !out.sign))
            out.sign = byte;
        else if (byte == '-')
            ++out.left;
        else if (byte == '#')
            ++out.alternate;
        else if (byte == '0')
            ++out.zero;
        else if (byte != ' ')
            break;
        ++*format;
    }
    if (**format == '*') {
        ++*format;
        out.width = format_argument(sram,argument);
        if (out.width & 0x8000u) {
            out.width = (uint16_t)(0u - out.width);
            ++out.left;
        }
    } else {
        out.width = parse_digits(format);
    }
    if (out.left)
        out.zero = 0;
    if (**format == '.') {
        ++*format;
        if (**format == '*') {
            ++*format;
            out.precision = format_argument(sram,argument);
        } else {
            out.precision = parse_digits(format);
        }
    }
    if (**format == 'L' || **format == 'l' || **format == 'h') {
        out.wide = **format != 'h';
        ++*format;
    }
    out.specifier = *(*format)++;
    return out;
}

/* 0x5E50–0x5E75. %n потребляет адрес из SRAM.
 * Для длинного значения исходный счётчик расширяется со знаком. */
void nm_avr_flash_format_count(uint8_t *sram, uint16_t *argument, uint16_t count, bool wide)
{
    uint16_t destination = format_argument(sram,argument);
    sram[destination] = (uint8_t)count;
    sram[(uint16_t)(destination + 1u)] = count >> 8;
    if (wide) {
        uint8_t sign = count & 0x8000u ? 0xff : 0;
        sram[(uint16_t)(destination + 2u)] = sign;
        sram[(uint16_t)(destination + 3u)] = sign;
    }
}

/* 0x5E76–0x5E85. %c читает младший байт слова аргумента.
 * Дальше он попадает в общий вывод с длиной 1. */
uint8_t nm_avr_flash_format_char(const uint8_t *sram, uint16_t *argument)
{
    return (uint8_t)format_argument(sram,argument);
}

/* 0x5E86–0x5ED3. %s берёт адрес строки SRAM из аргумента.
 * Нулевой указатель заменяется строкой Flash 0x0BDC, даже
 * если задана точность меньше 13. Отрицательная точность
 * для непустого адреса становится лимитом 10000. */
NMFlashString nm_avr_flash_format_string(const uint8_t *sram, uint16_t *argument,
                                          uint16_t precision)
{
    uint16_t address = format_argument(sram,argument);
    if (!address)
        return (NMFlashString){0x0bdc,13,true};
    if (precision & 0x8000u)
        precision = 10000;
    uint16_t length = 0;
    while (length < precision && sram[(uint16_t)(address + length)])
        ++length;
    return (NMFlashString){address,length,false};
}

/* 0x60A4–0x60F3. Сначала пробелы для правого выравнивания,
 * затем знак и данные. Для левого выравнивания пробелы идут
 * после данных. Счётчик ширины трактуется как слово со знаком. */
static void flash_emit_field(const uint8_t *bytes, uint16_t length,
                             NMFlashFormat spec, uint16_t state,
                             NMFormatEmit emit, void *context, uint16_t *count)
{
    uint16_t padding = nm_avr_decimal_padding(spec.width,length,0,spec.sign != 0);
    if (padding & 0x8000u)
        padding = 0;
    if (!spec.left) {
        for (uint16_t i = 0; i < padding; ++i)
            emit(context,state,' ');
    }
    if (spec.sign)
        emit(context,state,spec.sign);
    for (uint16_t i = 0; i < length; ++i)
        emit(context,state,bytes[i]);
    if (spec.left) {
        for (uint16_t i = 0; i < padding; ++i)
            emit(context,state,' ');
    }
    *count = (uint16_t)(*count + padding + length + (spec.sign != 0));
}

/* 0x5ED4–0x5FFF. Разбор целого, вывод цифр в обратном
 * порядке, дополнение нулями и префикс для восьмеричного
 * или шестнадцатеричного представления. Точность задана
 * 16-битным словом, отрицательное значение означает автоподбор. */
static bool flash_emit_integer(NMFlashFormat spec, const uint8_t *sram,
                               uint16_t *argument, uint16_t state,
                               NMFormatEmit emit, void *context, uint16_t *count)
{
    uint8_t ch = spec.specifier;
    bool signed_decimal = ch == 'd' || ch == 'i';
    bool pointer = ch == 'p';
    uint8_t base = ch == 'o' ? 8 : (signed_decimal || ch == 'u' ? 10 : 16);
    uint16_t precision = spec.precision;
    if (ch == 'o' && spec.alternate && !precision)
        precision = 1;
    bool explicit_precision = !(precision & 0x8000u);
    /* В этой модели поддерживается размер, вмещающийся в буфер AVR. */
    if (explicit_precision && precision > 120)
        return false;

    uint32_t value = format_argument(sram,argument);
    if (spec.wide && !pointer)
        value |= (uint32_t)format_argument(sram,argument) << 16;
    else if (signed_decimal && (value & 0x8000u))
        value |= UINT32_C(0xffff0000);
    if (pointer)
        spec.sign = 0;
    if (signed_decimal && (value >> 31)) {
        value = 0u - value;
        spec.sign = '-';
    }
    bool nonzero = value != 0;
    uint8_t buffer[11], *end = buffer + sizeof buffer, *start = end;
    const char *digits = ch == 'x' ? "0123456789abcdef" : "0123456789ABCDEF";
    if (precision || nonzero) {
        do {
            *--start = digits[value % base];
            value /= base;
        } while (value);
    }
    uint16_t minimum = explicit_precision ? precision : 0;
    if (!explicit_precision && spec.zero)
        minimum = nm_avr_decimal_padding(spec.width,0,0,spec.sign != 0);
    /* Нули по ширине можно выдать сразу, сохранив порядок AVR:
     * префикс идёт перед ними и не вычитается из заданной ширины. */
    if (minimum & 0x8000u)
        minimum = 0;
    uint16_t digit_count = (uint16_t)(end - start);
    uint16_t zeros = minimum > digit_count ? minimum - digit_count : 0;
    uint8_t prefix = 0;
    if (spec.alternate && nonzero) {
        if (ch == 'x' || ch == 'X')
            prefix = 2;
        else if (ch == 'o' && !zeros && *start != '0')
            prefix = 1;
    }
    uint16_t padding = nm_avr_decimal_padding(spec.width,
        (uint16_t)(digit_count + zeros + prefix),0,spec.sign != 0);
    if (padding & 0x8000u)
        padding = 0;
    if (!spec.left)
        for (uint16_t i = 0; i < padding; ++i)
            emit(context,state,' ');
    if (spec.sign)
        emit(context,state,spec.sign);
    if (prefix)
        emit(context,state,'0');
    if (prefix == 2)
        emit(context,state,ch);
    for (uint16_t i = 0; i < zeros; ++i)
        emit(context,state,'0');
    while (start != end)
        emit(context,state,*start++);
    if (spec.left)
        for (uint16_t i = 0; i < padding; ++i)
            emit(context,state,' ');
    *count = (uint16_t)(*count + padding + digit_count + zeros + prefix + (spec.sign != 0));
    return true;
}

/* 0x6000–0x606F: разбор вида дробного числа, знак, промежуточный
 * буфер и дополнение нулями. Для %g порядок проверяется до
 * округления (0x5A2C–0x5A59). Знак выводится отдельно от числа. */
static bool flash_emit_float(NMFlashFormat spec, const uint8_t *sram,
                             uint16_t *argument, uint16_t state,
                             NMFormatEmit emit, void *context, uint16_t *count)
{
    uint16_t precision = spec.precision & 0x8000u ? 6 : spec.precision;
    if (precision > 80)
        return false;
    uint32_t word = format_argument(sram,argument);
    word |= (uint32_t)format_argument(sram,argument) << 16;
    if (nm_avr_binary32_less(word,0)) {
        word ^= UINT32_C(0x80000000);
        spec.sign = '-';
    }
    NMDecimalScale scaled = nm_avr_decimal_scale(word);
    bool general = spec.specifier == 'g' || spec.specifier == 'G';
    if (general && !precision)
        precision = 1;
    bool scientific = spec.specifier != 'f';
    if (general) {
        if (scaled.exponent >= -4 && scaled.exponent < (int16_t)precision) {
            scientific = false;
            precision = (uint16_t)((int16_t)precision - scaled.exponent);
        }
        --precision;
    }
    bool point = precision || spec.alternate;
    uint8_t text[126];
    size_t length;
    bool round;
    if (scientific) {
        length = precision + 1u + point;
        round = nm_avr_decimal_digits(text,precision+1u,scaled.magnitude,point,false);
    } else {
        /* 0x5AC2–0x5B13: десятичный порядок задаёт число позиций
         * до точки или число нулей перед первой значащей цифрой. */
        uint16_t whole = scaled.exponent < 0 ? 1 : (uint16_t)(scaled.exponent + 1);
        length = whole + point + precision;
        uint16_t head = scaled.exponent < 0 ? (uint16_t)(-scaled.exponent) : 0;
        uint16_t positions = whole + precision;
        if (head > positions) {
            memset(text,'0',positions);
            round = false;
        } else {
            memset(text,'0',head);
            round = nm_avr_decimal_digits(text+head,positions-head,scaled.magnitude,false,false);
        }
        if (point) {
            memmove(text+whole+1,text+whole,precision);
            text[whole] = '.';
        }
    }
    if (round && nm_avr_decimal_carry(text,length))
        length = nm_avr_decimal_leading_carry(text,length,&scaled.exponent,scientific);
    if (general && !spec.alternate && point)
        length = nm_avr_decimal_trim(text,length);
    if (scientific) {
        uint8_t marker = spec.specifier == 'E' || spec.specifier == 'G' ? 'E' : 'e';
        length += nm_avr_decimal_exponent(text+length,marker,scaled.exponent);
    }

    /* 0x605C–0x606F: ширина учитывает знак. Нулевые байты
     * выдаются после знака, перед мантиссой. */
    if (spec.zero && !spec.left) {
        uint16_t zeros = nm_avr_decimal_padding(spec.width,(uint16_t)length,0,spec.sign != 0);
        if (!(zeros & 0x8000u) && zeros) {
            if (spec.sign)
                emit(context,state,spec.sign);
            for (uint16_t i = 0; i < zeros; ++i)
                emit(context,state,'0');
            *count = (uint16_t)(*count + zeros + (spec.sign != 0));
            spec.sign = 0;
            spec.width = 0;
        }
    }
    flash_emit_field(text,(uint16_t)length,spec,state,emit,context,count);
    return true;
}

/* Частичный перенос диспетчера Flash 0x5CE2: поддержаны
 * литералы, %%, %n, %c, %s, целые и научная запись.
 * false сообщает, что встретилась форма без C-переноса. */
bool nm_avr_flash_format(const uint8_t *flash, const uint8_t *format,
                         uint8_t *sram, uint16_t *argument, uint16_t state,
                         NMFormatEmit emit, void *context, uint16_t *count)
{
    *count = 0;
    while (*format) {
        uint8_t byte = *format++;
        if (byte != '%' || *format == '%') {
            if (byte == '%')
                ++format;
            emit(context,state,byte);
            ++*count;
            continue;
        }
        NMFlashFormat spec = nm_avr_flash_format_parse(&format,sram,argument);
        if (spec.specifier == 'n') {
            nm_avr_flash_format_count(sram,argument,*count,spec.wide);
        } else if (spec.specifier == 'c') {
            byte = nm_avr_flash_format_char(sram,argument);
            flash_emit_field(&byte,1,spec,state,emit,context,count);
        } else if (spec.specifier == 's') {
            NMFlashString string = nm_avr_flash_format_string(sram,argument,spec.precision);
            const uint8_t *base = string.flash ? flash : sram;
            flash_emit_field(base + string.address,string.length,spec,state,emit,context,count);
        } else if (spec.specifier && strchr("diouxXp",spec.specifier)) {
            if (!flash_emit_integer(spec,sram,argument,state,emit,context,count))
                return false;
        } else if (spec.specifier && strchr("eEfgG",spec.specifier)) {
            if (!flash_emit_float(spec,sram,argument,state,emit,context,count))
                return false;
        } else if (spec.specifier) {
            /* 0x6072–0x6083. Для неизвестного формата исходник
             * выводит три байта из Flash, без чтения аргумента. */
            flash_emit_field(flash + 0x0beb,3,spec,state,emit,context,count);
        } else {
            return false;
        }
    }
    return true;
}
