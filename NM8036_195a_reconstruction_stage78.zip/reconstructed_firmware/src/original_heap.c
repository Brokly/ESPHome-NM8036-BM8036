#include "nm_original_helpers.h"

/* Байтовые адреса SRAM оригинального приложения. Параметр sram
 * указывает на начало адресного пространства, адрес 0. */
enum { HEAP_HINT = 0x0780, HEAP_HEAD = 0x0782, HEAP_INITIALIZED = 0x077e };

static uint16_t load_word(const volatile uint8_t *sram, uint16_t address)
{
    uint8_t low = sram[address];
    return low | ((uint16_t)sram[(uint16_t)(address + 1u)] << 8);
}

static void store_word(volatile uint8_t *sram, uint16_t address, uint16_t value)
{
    sram[address] = (uint8_t)value;
    sram[(uint16_t)(address + 1u)] = (uint8_t)(value >> 8);
}

/* 0x6BC6–0x6BEA. Первичное выделение арены 0x0360–0x055F.
 * 0x077E хранит базу и запрещает повторную инициализацию. */
uint16_t nm_avr_heap_init(volatile uint8_t *sram)
{
    if (load_word(sram, HEAP_INITIALIZED))
        return 0;
    store_word(sram, HEAP_INITIALIZED, 0x0360);
    store_word(sram, 0x0360, 0x0200);
    return 0x0360;
}

/* 0x6DAE–0x6E7C. Размер в заголовке включает его два байта.
 * У свободного блока первые два байта бывших данных содержат
 * адрес следующего блока. Список отсортирован по адресу. */
void nm_avr_heap_free(volatile uint8_t *sram, uint16_t payload)
{
    if (!payload)
        return;
    uint16_t block = payload - 2u;
    uint16_t size = load_word(sram, block);
    if (size < 4)
        return;

    uint16_t left = HEAP_HINT;
    uint16_t right = load_word(sram, HEAP_HEAD);
    while (right && right <= block) {
        left = right;
        right = load_word(sram, left + 2u);
    }
    if (left != HEAP_HINT) {
        uint16_t left_size = load_word(sram, left);
        uint16_t left_end = left + left_size;
        if (block < left_end)
            return;
        if (left_end == block) {
            size += left_size;
            store_word(sram, left, size);
            block = left;
        } else {
            if (right && right < (uint16_t)(block + size))
                return;
            store_word(sram, block + 2u, right);
            store_word(sram, left + 2u, block);
        }
    } else {
        store_word(sram, block + 2u, right);
        store_word(sram, HEAP_HEAD, block);
    }

    if (right && right == (uint16_t)(block + size)) {
        store_word(sram, HEAP_HINT, 0);
        store_word(sram, block, size + load_word(sram, right));
        store_word(sram, block + 2u, load_word(sram, right + 2u));
    }
}

/* 0x6E7E–0x6FC6. Поиск начинает с сохранённого звена,
 * обходит хвост списка, затем его начало до того же блока.
 * Первый запрос без подходящего блока пробует инициализировать арену. */
uint16_t nm_avr_heap_alloc(volatile uint8_t *sram, uint16_t size)
{
    if (size > UINT16_MAX - 2u)
        return 0;
    uint16_t needed = size + 2u;
    if (needed < 4)
        needed = 4;
    uint16_t link;
    uint16_t block;
    for (;;) {
        uint16_t hint = load_word(sram, HEAP_HINT);
        link = hint ? hint : HEAP_HEAD;
        uint16_t first = load_word(sram, link);
        block = first;
        while (block && load_word(sram, block) < needed) {
            link = block + 2u;
            block = load_word(sram, link);
        }
        if (!block && hint) {
            link = HEAP_HEAD;
            block = load_word(sram, link);
            while (block != first && load_word(sram, block) < needed) {
                link = block + 2u;
                block = load_word(sram, link);
            }
            if (block == first)
                block = 0;
        }
        if (block)
            break;
        uint16_t arena = nm_avr_heap_init(sram);
        if (!arena)
            return 0;
        nm_avr_heap_free(sram, arena + 2u);
    }
    uint16_t available = load_word(sram, block);
    uint16_t next = load_word(sram, block + 2u);
    uint16_t remaining = available - needed;
    if (remaining >= 4) {
        uint16_t split = block + needed;
        store_word(sram, link, split);
        store_word(sram, split + 2u, next);
        store_word(sram, split, remaining);
        store_word(sram, block, needed);
    } else {
        store_word(sram, link, next);
    }
    next = load_word(sram, link);
    store_word(sram, HEAP_HINT, next && load_word(sram, next + 2u) ? next + 2u : 0);
    return block + 2u;
}

/* 0x6A78–0x6AB8, 0x61E4–0x61EB, 0x6DAC. При нехватке
 * памяти адрес обработчика читается из 0x077C перед каждой
 * попыткой. Нулевой адрес переводит оригинал в вечное ожидание.
 * Вызывающий C предоставляет адаптер для адресов слов Flash AVR. */
uint16_t nm_avr_heap_alloc_retry(volatile uint8_t *sram, uint16_t size,
                                 NMHeapFailureHandler handler, void *context)
{
    uint16_t block;
    while (!(block = nm_avr_heap_alloc(sram, size))) {
        uint16_t address = load_word(sram, 0x077c);
        if (!address)
            for (;;) {}
        handler(context, address);
    }
    return block;
}
