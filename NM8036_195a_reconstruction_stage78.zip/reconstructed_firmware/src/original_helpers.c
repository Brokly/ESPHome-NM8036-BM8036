#include "nm_original_helpers.h"

/* 0x6374–0x637C, 0x63AA–0x63C0, 0x645A–0x6478.
 * DEC перед проверкой N: 0x80 обозначает 128 шагов, а
 * 0x81–0xFF, как и 0x00, оставляют входное слово прежним.
 * Вход r16..r19, счётчик r20, выход в тех же младших регистрах. */
static uint8_t shift_count(uint8_t count)
{
    return count > 0x80 ? 0 : count;
}

uint8_t nm_avr_shl8(uint8_t value, uint8_t count)
{
    count = shift_count(count);
    return count < 8 ? (uint8_t)(value << count) : 0;
}

uint16_t nm_avr_shl16(uint16_t value, uint8_t count)
{
    count = shift_count(count);
    return count < 16 ? (uint16_t)((uint32_t)value << count) : 0;
}

uint16_t nm_avr_asr16(uint16_t value, uint8_t count)
{
    count = shift_count(count);
    uint16_t sign = value & 0x8000u ? UINT16_MAX : 0;
    if (count >= 16)
        return sign;
    return ((value ^ sign) >> count) ^ sign;
}

uint32_t nm_avr_shl32(uint32_t value, uint8_t count)
{
    count = shift_count(count);
    return count < 32 ? value << count : 0;
}

uint32_t nm_avr_lsr32(uint32_t value, uint8_t count)
{
    count = shift_count(count);
    return count < 32 ? value >> count : 0;
}

/* 0x639A–0x63A8 и 0x641A–0x6458. Остаётся только младшее
 * слово произведения; побочные регистры MUL временные. */
uint16_t nm_avr_mul16(uint16_t left, uint16_t right)
{
    return (uint16_t)((uint32_t)left * right);
}

uint32_t nm_avr_mul32(uint32_t left, uint32_t right)
{
    return left * right;
}

/* 0x637E–0x6398, 0x63C2–0x63E8 и 0x647A–0x64BE.
 * Делитель r20..r23 заменяется остатком, делимое — частным.
 * При делителе 0 каждый раз вычитается ноль. Все биты
 * частного устанавливаются, а остаток равен делимому. */
uint8_t nm_avr_div8(uint8_t dividend, uint8_t divisor, uint8_t *remainder)
{
    *remainder = divisor ? dividend % divisor : dividend;
    return divisor ? dividend / divisor : UINT8_MAX;
}

uint16_t nm_avr_div16(uint16_t dividend, uint16_t divisor, uint16_t *remainder)
{
    *remainder = divisor ? dividend % divisor : dividend;
    return divisor ? dividend / divisor : UINT16_MAX;
}

uint32_t nm_avr_div32(uint32_t dividend, uint32_t divisor, uint32_t *remainder)
{
    *remainder = divisor ? dividend % divisor : dividend;
    return divisor ? dividend / divisor : UINT32_MAX;
}

/* 0x63EA–0x6418. Деление модулей и восстановление знаков:
 * остаток имеет знак делимого. Модуль INT16_MIN и частное
 * INT16_MIN/-1 обрабатываются по модулю 65536, как в AVR. */
uint16_t nm_avr_sdiv16(uint16_t dividend, uint16_t divisor, uint16_t *remainder)
{
    const uint16_t sign = 0x8000u;
    uint16_t magnitude_a = dividend & sign ? (uint16_t)(0u - dividend) : dividend;
    uint16_t magnitude_b = divisor & sign ? (uint16_t)(0u - divisor) : divisor;
    uint16_t quotient = nm_avr_div16(magnitude_a, magnitude_b, remainder);
    if (dividend & sign)
        *remainder = (uint16_t)(0u - *remainder);
    return (dividend ^ divisor) & sign ? (uint16_t)(0u - quotient) : quotient;
}

/* 0x64C0–0x64CE, смена знака 32-битного слова r16–r19. */
uint32_t nm_avr_neg32(uint32_t value)
{
    return 0u - value;
}

/* 0x6A38–0x6A64. Сравнение беззнаковых байтов до первого
 * различия. Возвращает строго -1, 0 или 1, включая длину 0. */
int nm_avr_compare_bytes(const uint8_t *left, const uint8_t *right, uint16_t count)
{
    for (; count; --count, ++left, ++right)
        if (*left != *right)
            return *left < *right ? -1 : 1;
    return 0;
}

/* 0x6A66–0x6A76. Запись r18 в r20:r21 байтов начиная
 * с адреса r16:r17. При нулевой длине SRAM не меняется. */
void nm_avr_fill_bytes(uint8_t *buffer, uint8_t byte, uint16_t count)
{
    while (count--)
        *buffer++ = byte;
}
