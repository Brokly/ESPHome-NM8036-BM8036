#include "nm_program_fields.h"

/* 0x3A1C–0x3A2B, 0x3A38–0x3A43.
 * Индекс из 0x06B4. Запись EEPROM занимает 21 байт;
 * r16:r17 содержит смещение, r20:r21 — адрес с 0x4C. */
uint16_t nm_avr_program_record_base(uint8_t index)
{
    return 0x4cu + 21u * index;
}

/* 0x3A4A–0x3A59. Режим периода — старшие биты
 * байта EEPROM +1, ноль соответствует флагу Z. */
uint8_t nm_avr_program_period_mode(const NM8036 *m)
{
    uint16_t address = nm_avr_program_record_base(*nm_ram(m,0x06b4));
    return nm_ee_read(m,address+1u) >> 6;
}

/* 0x3922–0x392B. Младшие шесть бит поля заменяются,
 * старшие два бита прежнего байта сохраняются. */
uint8_t nm_avr_program_merge_time(uint8_t previous, uint8_t field)
{
    return (previous & 0xc0u) | (field & 0x3fu);
}

/* 0x392C–0x3933. Указатель на редактор уже разрешён из X. */
void nm_avr_program_record_key(uint8_t editor[8], uint8_t key)
{
    editor[7] = key & 15u;
}

/* 0x3962–0x3975. Два входа пишут 0x03FF в +2 либо +4. */
void nm_avr_program_limit(uint8_t editor[6], bool upper)
{
    uint8_t offset = upper ? 4 : 2;
    editor[offset] = 0xff;
    editor[offset+1] = 3;
}
