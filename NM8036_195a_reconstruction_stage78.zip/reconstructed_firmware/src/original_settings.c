#include "nm_editors.h"

/* 0x53E0–0x53E7. Записывается весь байт 0x02ED,
 * даже если вызывающий код передал значение вне 0/1. */
void nm_avr_backlight_store_enabled(const NM8036 *m, uint8_t enabled)
{
    nm_ee_write(m,0x02ed,enabled);
}

/* 0x53E8–0x53F3. Действующий PWM восстанавливается из
 * инвертированного значения EEPROM 0x02EE. */
void nm_avr_backlight_restore_pwm(const NM8036 *m)
{
    *m->backlight_pwm = (uint8_t)~nm_ee_read(m,0x02ee);
}

/* 0x4DF4–0x4DFF. Десятки и единицы получаются от одного
 * беззнакового деления. Старые служебные биты берутся по маске. */
static uint8_t rtc_pack_field(uint8_t previous, uint8_t value, uint8_t keep, uint8_t tens)
{
    return (previous & keep) | ((value / 10u * 16u) & tens) | (value % 10u);
}

/* 0x4D72–0x4D7B. Сохраняются два старших бита регистра часов. */
uint8_t nm_avr_rtc_pack_hours(uint8_t previous, uint8_t hour)
{
    return rtc_pack_field(previous,hour,0xc0,0x30);
}

/* 0x4DEC–0x4DF3. Для минут и секунд сохраняется только бит 7. */
uint8_t nm_avr_rtc_pack_minutes_seconds(uint8_t previous, uint8_t value)
{
    return rtc_pack_field(previous,value,0x80,0x70);
}
