#include "nm_peripherals.h"

static uint16_t read_word(const NM8036 *m, uint16_t address)
{
    uint8_t low = nm_ee_read(m, address);
    return low | ((uint16_t)nm_ee_read(m, address + 1) << 8);
}

static volatile uint8_t *output_port(const NM8036 *m, uint8_t channel)
{
    if (channel >= 4 && channel < 8)
        return m->porta;
    return channel < 10 ? m->portc : m->portd;
}

static uint8_t output_mask(uint8_t channel)
{
    static const uint8_t bits[] = {7, 6, 5, 4, 7, 6, 5, 4, 2, 3, 3, 6};
    return (uint8_t)(1u << bits[channel]);
}

/* [БИНАРНИК] 0x2414..0x2480. 0x2482..0x24D8 читает те же
 * защёлки PORT, поэтому отчёт не зависит от уровня на входных контактах. */
void nm_output_set(const NM8036 *m, uint8_t channel, bool active)
{
    if (channel >= 12)
        return;
    volatile uint8_t *port = output_port(m, channel);
    uint8_t mask = output_mask(channel);
    if (active)
        *port |= mask;
    else
        *port &= (uint8_t)~mask;
}

/* [БИНАРНИК] 0x54EE..0x552C. Ручной запрос канала имеет
 * приоритет в обоих отчётах, затем учитывается общий режим блока.
 * Младшие 12 бит формируются заново, старшие четыре происходят из Y+1.
 * [РУКОВОДСТВО] Прил. 5, команды l, z. */
uint16_t nm_outputs_report(const NM8036 *m, uint16_t seed, bool physical)
{
    volatile uint8_t *state = nm_ram(m, 0x0747);
    for (uint8_t channel = 0; channel < 12; channel++) {
        bool active = state[37 + channel] != 0;
        if (!active && (physical || state[36]))
            active = (*output_port(m, channel) & output_mask(channel)) != 0;
        seed = (uint16_t)((seed << 1) | active);
    }
    return seed;
}

static void put_counter(volatile uint8_t *p, uint16_t value)
{
    p[0] = (uint8_t)value;
    p[1] = (uint8_t)(value >> 8);
}

/* [БИНАРНИК] 0x23C0..0x2412. При запуске для каждой нагрузки
 * выставляется активная фаза и загружается её время из EEPROM. */
void nm_outputs_init(const NM8036 *m)
{
    volatile uint8_t *state = nm_ram(m, 0x0747);
    for (uint8_t channel = 0; channel < 12; channel++) {
        uint8_t saved = m->irq_disable(m->context);
        state[24 + channel] = 1;
        put_counter(state + 2 * channel, read_word(m, 0x15 + 2 * channel));
        m->irq_restore(m->context, saved);
    }
}

/* [БИНАРНИК] 0x233C..0x235A. Общий режим записывается после
 * обновления всех двенадцати линий. */
void nm_outputs_force(const NM8036 *m, uint8_t mode)
{
    uint8_t saved = m->irq_disable(m->context);
    for (uint8_t channel = 0; channel < 12; channel++)
        nm_output_set(m, channel, false);
    *nm_ram(m, 0x0747 + 36) = mode;
    m->irq_restore(m->context, saved);
}

/* [БИНАРНИК] 0x2508..0x25A8. Счётчики — 16-битные с циклическим
 * переполнением. Нулевая пауза оставляет фазу включения.
 * На PORT записывается побитовое И фазы и логического запроса. */
void nm_outputs_tick(const NM8036 *m)
{
    uint8_t saved = m->irq_disable(m->context);
    volatile uint8_t *state = nm_ram(m, 0x0747);
    if (state[36] == 0) {
        for (uint8_t channel = 0; channel < 12; channel++) {
            volatile uint8_t *timer = state + 2 * channel;
            uint16_t count = timer[0] | ((uint16_t)timer[1] << 8);
            count--;
            put_counter(timer, count);
            if (count == 0) {
                uint16_t address = 0x15 + 2 * channel;
                if (state[24 + channel] != 0) {
                    count = read_word(m, address + 24);
                    if (count != 0)
                        state[24 + channel] = 0;
                } else {
                    state[24 + channel] = 1;
                }
                if (count == 0)
                    count = read_word(m, address);
                put_counter(timer, count);
            }
            nm_output_set(m, channel, (state[24 + channel] & state[37 + channel]) != 0);
        }
    }
    m->irq_restore(m->context, saved);
}

/* [БИНАРНИК] 0x2312..0x233A. Сигнал только при изменении
 * логического запроса. Физическую линию меняет импульсный цикл. */
void nm_output_request(const NM8036 *m, uint8_t channel, bool active)
{
    if (channel >= 12)
        return;
    volatile uint8_t *request = nm_ram(m, 0x0747 + 37 + channel);
    if ((*request != 0) == active)
        return;
    *request = active;
    nm_tone(m, active ? 10 : 3);
}

/* [БИНАРНИК] 0x236E..0x238F, 0x23EA..0x23F9.
 * Первые 12 слов задают включение, следующие 12 — паузу. */
uint16_t nm_output_duration(const NM8036 *m, uint8_t row)
{
    uint8_t saved = m->irq_disable(m->context);
    uint16_t seconds = read_word(m, 0x15 + 2u * row);
    m->irq_restore(m->context, saved);
    return seconds;
}

/* [БИНАРНИК] 0x26B6..0x26EC, 0x2606..0x2618.
 * Редактор немедленно сохраняет значение при ENTER и при MENU.
 * После принятия исходник заново запускает активную фазу всех линий. */
void nm_output_save_duration(const NM8036 *m, uint8_t row, uint16_t seconds)
{
    uint16_t address = 0x15 + 2u * row;
    uint8_t saved = m->irq_disable(m->context);
    nm_ee_write(m, address, (uint8_t)seconds);
    nm_ee_write(m, address + 1u, (uint8_t)(seconds >> 8));
    m->irq_restore(m->context, saved);
    nm_outputs_init(m);
}

/* [БИНАРНИК] 0x2482..0x24D8. Ручной режим показывает состояние
 * защёлки порта, а не последний запрос планировщика. */
bool nm_output_physical(const NM8036 *m, uint8_t channel)
{
    return channel < 12 && (*output_port(m, channel) & output_mask(channel)) != 0;
}

/* [БИНАРНИК] 0x4F2E..0x4F6E, 0x500E..0x5018.
 * 0x076B блокирует автоматическую запись линий из INT0.
 * Вход и выход гасят линии, запросы планировщика остаются в RAM. */
void nm_manual_outputs_open(const NM8036 *m)
{
    *nm_ram(m, 0x0741) = 0;
    *nm_ram(m, 0x0742) = 0;
    nm_outputs_force(m, 1);
}

bool nm_manual_outputs_key(const NM8036 *m, uint8_t key)
{
    uint8_t row = *nm_ram(m, 0x0741);
    uint8_t cursor = *nm_ram(m, 0x0742);
    uint8_t channel = row + cursor;
    switch (key & 15u) {
    case 0:
        nm_output_set(m, channel, !nm_output_physical(m, channel));
        break;
    case 5:
        nm_outputs_force(m, 0);
        return true;
    case 1:
        if (cursor)
            *nm_ram(m, 0x0742) = 0;
        else if (row)
            (*nm_ram(m, 0x0741))--;
        break;
    case 4:
        if (channel < 11) {
            if (cursor)
                (*nm_ram(m, 0x0741))++;
            else
                *nm_ram(m, 0x0742) = 1;
        }
        break;
    }
    return false;
}


/* [БИНАРНИК] 0x4FC0..0x5004. Формат 0x0992 применяется
 * с колонки 2 после очистки LCD. Символ 0 ставится отдельно. */
void nm_manual_outputs_screen(const NM8036 *m, uint8_t screen[32])
{
    static const uint8_t row_template[16] = {
        ' ',' ',0xc2,0xfb,0xf5,0xee,0xe4,' ','#',' ',' ',' ','=',' ','0',' '
    };
    uint8_t first = *nm_ram(m, 0x0741);
    uint8_t cursor = *nm_ram(m, 0x0742);
    for (uint8_t line = 0; line < 2; line++) {
        uint8_t *row = screen + 16u * line;
        uint8_t channel = first + line;
        for (uint8_t i = 0; i < 16; i++)
            row[i] = row_template[i];
        uint8_t number = channel + 1u;
        if (number >= 10)
            row[9] = '0' + number / 10u;
        row[10] = '0' + number % 10u;
        row[14] += nm_output_physical(m, channel);
        if (line == cursor)
            row[0] = 0;
    }
}
