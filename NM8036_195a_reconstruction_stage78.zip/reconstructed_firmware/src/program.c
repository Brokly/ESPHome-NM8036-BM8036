#include "nm8036.h"
#include "nm_editors.h"

/* [БИНАРНИК] 0x5924 → 0x4DD4, 0x55A0, 0x5656. EEPROM от 0x4C,
 * по 21 байту на запись. Число 32 задаёт цикл чтения (0x5642). */
static uint16_t record_address(uint8_t index)
{
    return 0x4cu + 21u * index;
}

/* [БИНАРНИК] 0x2C08..0x2C34. При пакетной передаче EEPROM
 * исходный код удерживает прерывания выключенными на всём диапазоне. */
static void send_field(const NM8036 *m, uint16_t address, uint8_t count)
{
    uint8_t state = m->irq_disable(m->context);
    while (count--)
        m->send(m->context, nm_ee_read(m, address++));
    m->irq_restore(m->context, state);
}

/* [БИНАРНИК] 0x5596..0x5648, маски в 0x58EC..0x590C и 0x591A.
 * [РУКОВОДСТВО] Прил. 5, команда L. Для каждой из 32 записей
 * часы, минуты, календарные поля и параметры выходят в порядке протокола. */
void nm_program_send(const NM8036 *m)
{
    m->send(m->context, 'L');
    for (uint8_t index = 0; index < NM_RECORDS; index++) {
        uint16_t base = record_address(index);
        static const uint8_t offsets[] = {6, 0, 1, 5, 7, 8, 9, 10};
        static const uint8_t masks[] = {31, 63, 63, 31, 63, 63, 31, 31};
        for (uint8_t i = 0; i < sizeof offsets; i++)
            m->send(m->context, nm_ee_read(m, base + offsets[i]) & masks[i]);

        m->send(m->context, nm_ee_read(m, base + 4) & 15);
        m->send(m->context, nm_ee_read(m, base + 4) >> 4);
        m->send(m->context, nm_ee_read(m, base + 3) & 127);
        m->send(m->context, nm_ee_read(m, base + 2) & 127);
        m->send(m->context, nm_ee_read(m, base + 12) & 127);
        m->send(m->context, nm_ee_read(m, base + 11));
        send_field(m, base + 13, 2);
        send_field(m, base + 15, 2);
        m->send(m->context, nm_ee_read(m, base) >> 6);
        m->send(m->context, nm_ee_read(m, base + 1) >> 6);
        send_field(m, base + 17, 4);
        m->send(m->context, nm_ee_read(m, base + 2) >> 7);
        m->send(m->context, nm_ee_read(m, base + 3) >> 7);
        uint8_t flags = (nm_ee_read(m, base + 6) & 0x20u) >> 3;
        flags |= (nm_ee_read(m, base + 12) & 0x80u) >> 6;
        flags |= (nm_ee_read(m, base + 5) & 0x20u) >> 5;
        m->send(m->context, flags);
    }
}

static void merge(const NM8036 *m, uint16_t address, uint8_t mask, uint8_t data)
{
    nm_ee_write(m, address, (nm_ee_read(m, address) & (uint8_t)~mask) | (data & mask));
}

/* [БИНАРНИК] 0x5652..0x5796, 0x5932..0x5952.
 * Сохраняются не затронутые масками разряды и порядок физических записей.
 * Запись интервала начинается с младшего байта, затем идёт старший.
 * [РУКОВОДСТВО] Прил. 5, W. Документированный индекс 0..31. */
void nm_program_write(const NM8036 *m, uint8_t index, const uint8_t w[NM_WIRE_RECORD])
{
    uint16_t base = record_address(index);
    merge(m, base + 6, 31, w[0]);
    merge(m, base, 63, w[1]);
    merge(m, base + 1, 63, w[2]);
    merge(m, base + 5, 31, w[3]);
    merge(m, base + 7, 63, w[4]);
    merge(m, base + 8, 63, w[5]);
    merge(m, base + 9, 31, w[6]);
    merge(m, base + 10, 31, w[7]);
    nm_ee_write(m, base + 4, (w[8] & 15) | ((w[9] & 15) << 4));
    merge(m, base + 3, 127, w[10]);
    merge(m, base + 2, 127, w[11]);
    merge(m, base + 12, 127, w[12]);
    nm_ee_write(m, base + 11, w[13]);
    for (uint8_t i = 0; i < 4; i++)
        nm_ee_write(m, base + 13 + i, w[14 + i]);
    merge(m, base, 0xc0, (uint8_t)(w[18] << 6));
    merge(m, base + 1, 0xc0, (uint8_t)(w[19] << 6));
    for (uint8_t i = 0; i < 4; i++)
        nm_ee_write(m, base + 17 + i, w[20 + i]);
    merge(m, base + 2, 0x80, (uint8_t)(w[24] << 7));
    merge(m, base + 3, 0x80, (uint8_t)(w[25] << 7));
    merge(m, base + 5, 0x20, (uint8_t)((w[26] & 1u) << 5));
    merge(m, base + 12, 0x80, (uint8_t)((w[26] & 2u) << 6));
    merge(m, base + 6, 0x20, (uint8_t)((w[26] & 4u) << 3));
}

/* [БИНАРНИК] 0x3FEA..0x4107. Конечное состояние 32 записей после
 * заводского сброса. Режим 3, начало/конец в полночь, 1 января;
 * служебные старшие биты часов и отдельных полей сохраняются.
 * Промежуточные повторные записи одного адреса свёрнуты. */
void nm_factory_program_defaults(const NM8036 *m)
{
    static const uint8_t preserve[21] = {
        0, 0, 0, 0, 0, 0, 0xc0, 0xc0, 0, 0, 0xe0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    static const uint8_t defaults[21] = {
        0xc0, 0, 0x80, 0, 0x11, 0x80, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    uint8_t saved = m->irq_disable(m->context);
    for (uint8_t i = 0; i < NM_RECORDS; i++) {
        uint16_t base = record_address(i);
        for (uint8_t field = 0; field < sizeof defaults; field++) {
            uint8_t data = defaults[field];
            if (preserve[field])
                data |= nm_ee_read(m, base + field) & preserve[field];
            nm_ee_write(m, base + field, data);
        }
    }
    m->irq_restore(m->context, saved);
}

/* [БИНАРНИК] 0x2FEE..0x3000, 0x3044..0x306C.
 * Номер выбранной записи (0..31) хранится в SRAM 0x06B4.
 * Обе оси клавиатуры листают записи, младший полубайт задаёт
 * направление и для первичного нажатия, и для автоповтора. */
uint8_t nm_program_select(const NM8036 *m, uint8_t key)
{
    volatile uint8_t *index = nm_ram(m, 0x06b4);
    key &= 15u;
    if (key == 1 || key == 2)
        *index = (*index - 1u) & 31u;
    else if (key == 3 || key == 4)
        *index = (*index + 1u) & 31u;
    return *index;
}

/* [БИНАРНИК] 0x30A4..0x30B0, 0x4104..0x4107.
 * Флаг разрешения — бит 7 байта +3, остаётся в EEPROM при выходе.
 * Младшие семь бит этого байта принадлежат календарному условию. */
void nm_program_toggle(const NM8036 *m, uint8_t index)
{
    uint8_t irq = m->irq_disable(m->context);
    uint16_t address = record_address(index) + 3u;
    nm_ee_write(m, address, nm_ee_read(m, address) ^ 0x80u);
    m->irq_restore(m->context, irq);
}

static void two_digits(uint8_t *p, uint8_t number)
{
    p[0] = '0' + number / 10u;
    p[1] = '0' + number % 10u;
}

/* [БИНАРНИК] 0x2F88..0x2FE8. Форматы flash 0x04D8, 0x04DD,
 * 0x04E2, 0x04F6. Кириллица передаётся в кодировке LCD оригинала. */
void nm_program_overview(const NM8036 *m, uint8_t index, uint8_t screen[32])
{
    const uint16_t base = record_address(index);
    for (uint8_t i = 0; i < 32; i++)
        screen[i] = ' ';
    two_digits(screen, index + 1u);
    if (!(nm_ee_read(m, base + 3u) & 0x80u)) {
        static const uint8_t disabled[] = { '-',0xcd,0xc5,' ',0xc0,0xca,0xd2,0xc8,0xc2,0xc5,0xcd,'-' };
        for (uint8_t i = 0; i < sizeof disabled; i++)
            screen[16u + i] = disabled[i];
    } else {
        const uint8_t output = (nm_ee_read(m, base + 12u) & 127u) + 1u;
        two_digits(screen + 2, output);
        if (output < 10)
            screen[2] = ' ';
        two_digits(screen + 16, nm_ee_read(m, base + 6u) & 31u);
        screen[18] = ':';
        two_digits(screen + 19, nm_ee_read(m, base) & 63u);
        two_digits(screen + 22, nm_ee_read(m, base + 5u) & 31u);
        screen[24] = ':';
        two_digits(screen + 25, nm_ee_read(m, base + 7u) & 63u);
    }
}

bool nm_program_enabled(const NM8036 *m, uint8_t index)
{
    return (nm_ee_read(m, record_address(index) + 3u) & 0x80u) != 0;
}

/* [БИНАРНИК] 0x30DA..0x3114, 0x3174..0x3198.
 * Старт и стоп хранятся в разных полях одной 21-байтовой записи. */
void nm_program_time_load(const NM8036 *m, uint8_t index, bool stop, NMProgramTime *time)
{
    uint16_t base = record_address(index);
    *time = (NMProgramTime){{
        nm_ee_read(m, base + (stop ? 5u : 6u)) & 31u,
        nm_ee_read(m, base + (stop ? 7u : 0u)) & 63u,
        nm_ee_read(m, base + (stop ? 8u : 1u)) & 63u,
        nm_ee_read(m, base + (stop ? 10u : 9u)) & 31u,
        (nm_ee_read(m, base + 4u) >> (stop ? 4u : 0u)) & 15u,
        nm_ee_read(m, base + (stop ? 2u : 3u)) & 127u
    }, 0};
}

/* [БИНАРНИК] 0x3132..0x3172 и 0x31A4..0x31DE.
 * Каждый ENTER записывает только текущее окно. Флаги режима,
 * условия и разрешения лежат в старших битах тех же ячеек. */
void nm_program_time_save(const NM8036 *m, uint8_t index, bool stop,
                          const NMProgramTime *time)
{
    uint16_t base = record_address(index);
    const uint8_t *f = time->field;
    uint8_t irq = m->irq_disable(m->context);
    merge(m, base + (stop ? 5u : 6u), 31, f[0]);
    merge(m, base + (stop ? 7u : 0u), 63, f[1]);
    merge(m, base + (stop ? 8u : 1u), 63, f[2]);
    merge(m, base + (stop ? 10u : 9u), 31, f[3]);
    merge(m, base + 4u, stop ? 0xf0 : 0x0f, (uint8_t)(f[4] << (stop ? 4u : 0u)));
    merge(m, base + (stop ? 2u : 3u), 127, f[5]);
    m->irq_restore(m->context, irq);
}

/* [БИНАРНИК] 0x3228..0x3256, 0x3304..0x3306.
 * Стрелки вверх и вниз меняют номер выхода в пределах 0..11.
 * Младшие семь бит EEPROM +12 — номер, старший бит — режим И/ИЛИ.
 * Для номера вне штатного диапазона исходник допускает уменьшение,
 * а увеличение блокирует до возвращения в диапазон. */
void nm_program_output_key(const NM8036 *m, uint8_t index, uint8_t key)
{
    key &= 15u;
    uint8_t irq = m->irq_disable(m->context);
    uint16_t address = record_address(index) + 12u;
    uint8_t current = nm_ee_read(m, address);
    uint8_t channel = current & 127u;
    if (key == 1 && channel < 11u)
        nm_ee_write(m, address, current + 1u);
    else if (key == 4 && channel)
        nm_ee_write(m, address, current - 1u);
    m->irq_restore(m->context, irq);
}

/* [БИНАРНИК] 0x3258..0x326E, 0x3306. Цикл из четырёх
 * типов использует переполнение двух старших битов EEPROM +0.
 * Младшие шесть бит — минуты начала окна. */
void nm_program_kind_key(const NM8036 *m, uint8_t index, uint8_t key)
{
    key &= 15u;
    if (key != 1 && key != 4)
        return;
    uint8_t irq = m->irq_disable(m->context);
    uint16_t address = record_address(index);
    uint8_t current = nm_ee_read(m, address);
    nm_ee_write(m, address, (uint8_t)(current + (key == 1 ? 64u : 192u)));
    m->irq_restore(m->context, irq);
}

/* [БИНАРНИК] 0x3270..0x3306. Номер цифрового датчика лежит
 * в EEPROM +11. Ненулевое семейство в таблице ROM 0x02F0 означает
 * занятый слот. При движении вверх используется переход 31 → 0,
 * одиночное движение вниз циклическое, удержание вниз останавливается на 0.
 * Для входа АЦП остаётся только младший бит номера. */
void nm_program_sensor_key(const NM8036 *m, uint8_t index, uint8_t key)
{
    if (key != 1 && key != 4 && key != 0x81 && key != 0x84)
        return;
    uint8_t irq = m->irq_disable(m->context);
    uint16_t base = record_address(index);
    uint8_t sensor = nm_ee_read(m, base + 11);
    bool up = (key & 15u) == 1;
    for (uint8_t tries = 0; tries < 32; tries++) {
        if (key == 0x84 && !sensor)
            break;
        sensor = (uint8_t)(sensor + (up ? 1 : -1));
        if (sensor >= 32)
            sensor &= 31u;
        nm_ee_write(m, base + 11, sensor);
        if (nm_ee_read(m, base + 5) & 0x20u) {
            nm_ee_write(m, base + 11, sensor & 1u);
            break;
        }
        if (nm_ee_read(m, 0x02f0u + 8u * sensor))
            break;
    }
    m->irq_restore(m->context, irq);
}

/* [БИНАРНИК] 0x32D4..0x3306. Бит 5 EEPROM +5 выбирает АЦП.
 * При переходе к АЦП номера >=2 приводятся к 0 или 1. */
void nm_program_source_key(const NM8036 *m, uint8_t index, uint8_t key)
{
    if (key != 1 && key != 4 && key != 0x81 && key != 0x84)
        return;
    uint8_t irq = m->irq_disable(m->context);
    uint16_t base = record_address(index);
    uint8_t source = nm_ee_read(m, base + 5) ^ 0x20u;
    nm_ee_write(m, base + 5, source);
    uint8_t sensor = nm_ee_read(m, base + 11);
    if ((source & 0x20u) && sensor >= 2)
        nm_ee_write(m, base + 11, sensor & 1u);
    m->irq_restore(m->context, irq);
}

void nm_program_thresholds_load(const NM8036 *m, uint8_t index, NMThresholds *editor)
{
    uint16_t base = record_address(index);
    editor->analog = (nm_ee_read(m, base + 5) & 0x20u) != 0;
    editor->selected = 0;
    for (uint8_t i = 0; i < 2; i++) {
        uint16_t address = base + 13u + 2u * i;
        uint8_t low = nm_ee_read(m, address);
        editor->value[i] = (int16_t)(low | ((uint16_t)nm_ee_read(m, address + 1u) << 8));
        /* 0x3492..0x34B8 приводит сохранённые отсчёты АЦП
         * к физическому диапазону ещё при входе в редактор. */
        if (editor->analog && editor->value[i] < 0)
            editor->value[i] = 0;
        if (editor->analog && editor->value[i] > 1023)
            editor->value[i] = 1023;
    }
}

/* [БИНАРНИК] 0x3708..0x3734. ENTER записывает оба слова,
 * MENU выбирает выход из редактора до изменения EEPROM. */
void nm_program_thresholds_save(const NM8036 *m, uint8_t index, const NMThresholds *editor)
{
    uint16_t base = record_address(index);
    uint8_t irq = m->irq_disable(m->context);
    for (uint8_t i = 0; i < 2; i++) {
        uint16_t address = base + 13u + 2u * i;
        uint16_t value = (uint16_t)editor->value[i];
        nm_ee_write(m, address, (uint8_t)value);
        nm_ee_write(m, address + 1u, (uint8_t)(value >> 8));
    }
    m->irq_restore(m->context, irq);
}

/* [БИНАРНИК] 0x3416..0x3422, 0x34BC..0x34D6, 0x3742..0x374E.
 * Режим относительного сравнения сохраняется сразу. Номер
 * второго датчика занимает слово нижнего порога, старший байт 0. */
void nm_program_relative_toggle(const NM8036 *m, uint8_t index)
{
    uint16_t address = record_address(index) + 6u;
    nm_ee_write(m, address, nm_ee_read(m, address) ^ 0x20u);
}

void nm_program_reference_key(const NM8036 *m, uint8_t index, uint8_t key)
{
    key &= 15u;
    if (key != 2 && key != 3)
        return;
    uint16_t address = record_address(index) + 13u;
    uint8_t sensor = nm_ee_read(m, address);
    nm_ee_write(m, address, (sensor + (key == 2 ? 31u : 1u)) & 31u);
    nm_ee_write(m, address + 1u, 0);
}

void nm_program_logic_toggle(const NM8036 *m, uint8_t index)
{
    uint16_t address = record_address(index) + 12u;
    nm_ee_write(m, address, nm_ee_read(m, address) ^ 0x80u);
}

/* [БИНАРНИК] 0x3780..0x37AA. Старшие два бита EEPROM +1:
 * без повторов, дни недели, дни месяца, месяцы. Смена режима
 * очищает четыре байта маски и устанавливает позицию в 0. */
uint8_t nm_program_period_key(const NM8036 *m, uint8_t index, uint8_t key)
{
    uint16_t base = record_address(index);
    uint8_t packed = nm_ee_read(m, base + 1u);
    if (key == 2 || key == 3) {
        packed = (uint8_t)(packed + (key == 2 ? 192u : 64u));
        nm_ee_write(m, base + 1u, packed);
        for (uint8_t i = 0; i < 4; i++)
            nm_ee_write(m, base + 17u + i, 0);
        *nm_ram(m, 0x06b8) = 0;
    }
    return packed >> 6;
}

/* [БИНАРНИК] 0x382C..0x3899. Стрелки выбирают элемент, ENTER
 * инвертирует его бит. Соседние элементы остаются в EEPROM. */
void nm_program_period_item(const NM8036 *m, uint8_t index, uint8_t period, uint8_t key)
{
    static const uint8_t last[] = {0, 6, 30, 11};
    if (period == 0 || period > 3)
        return;
    volatile uint8_t *position = nm_ram(m, 0x06b8);
    key &= 15u;
    if (key == 1 && *position < last[period])
        (*position)++;
    else if (key == 4 && *position)
        (*position)--;
    else if (key == 0 && *position <= last[period]) {
        uint16_t address = record_address(index) + 17u + *position / 8u;
        nm_ee_write(m, address, nm_ee_read(m, address) ^ (1u << (*position & 7u)));
    }
}

/* [БИНАРНИК] 0x33D8..0x3404, 0x3FA8..0x3FB0.
 * ENTER оставляет младшие шесть бит EEPROM +5, снимает бит 6
 * и выставляет бит 7 даже для записи, которая не является будильником.
 * Код следующего состояния записывается в SRAM 0x06B6. */
uint8_t nm_program_control_confirm(const NM8036 *m, uint8_t index)
{
    uint16_t base = record_address(index);
    uint8_t options = (nm_ee_read(m, base + 5u) & 63u) | 128u;
    nm_ee_write(m, base + 5u, options);
    uint8_t next = 5;
    if (nm_ee_read(m, base) & 0x80u)
        next = 8;
    else if (options & 0x20u)
        next = 7;
    *nm_ram(m, 0x06b6) = next;
    return next;
}
