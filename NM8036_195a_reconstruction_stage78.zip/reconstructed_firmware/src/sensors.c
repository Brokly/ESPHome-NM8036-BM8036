#include "nm_peripherals.h"

/* [БИНАРНИК] 0x411A..0x4158, побитовая Dallas CRC-8.
 * [РУКОВОДСТВО] Цифровые датчики Dallas на общей шине. */
uint8_t nm_dallas_crc(const uint8_t *data, uint8_t count)
{
    uint8_t crc = 0;
    while (count--) {
        crc ^= *data++;
        for (uint8_t bit = 0; bit < 8; bit++)
            crc = (crc >> 1) ^ ((crc & 1u) ? 0x8c : 0);
    }
    return crc;
}

/* [БИНАРНИК] 0x1464..0x1498. Нулевой кадр отбрасывается
 * отдельно, хотя он даёт нулевую контрольную сумму. */
bool nm_dallas_scratchpad_valid(const uint8_t bytes[9])
{
    if (nm_dallas_crc(bytes, 9))
        return false;
    uint8_t nonzero = 0;
    for (uint8_t i = 0; i < 9; i++)
        nonzero |= bytes[i];
    return nonzero != 0;
}

/* [БИНАРНИК] 0x149A..0x14DA, 0x14E4..0x150A. Для семейства 0x10
 * используется счётчик остатка. Разность счётчиков расширяется
 * со знаком по флагу заёма в AVR. Дробь отбрасывается.
 * [РУКОВОДСТВО] Единицы UART t — сотые градуса. */
int16_t nm_dallas_temperature(uint8_t family, const uint8_t bytes[9])
{
    uint16_t raw = bytes[0] | ((uint16_t)bytes[1] << 8);
    if (family == 0x10) {
        int16_t whole = (int16_t)(raw & 0xfffeu);
        int16_t numerator = 100 * ((int16_t)bytes[7] - bytes[6]);
        /* При нулевом делителе арифметическая подпрограмма AVR
         * возвращает -1 для неотрицательного числителя и +1 для отрицательного. */
        int16_t correction = bytes[7] ? numerator / bytes[7] : (numerator < 0 ? 1 : -1);
        return (int16_t)((int32_t)whole * 50 + correction - 25);
    }
    return (int16_t)((int16_t)(raw & 0xfff0u) / 16 * 100 + (raw & 15u) * 100u / 16u);
}
