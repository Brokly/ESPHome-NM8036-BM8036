#include "nm_peripherals.h"

/* [БИНАРНИК] 0x62C4..0x62CC, 0x6A34..0x6A36, 0x6AFE..0x6B4C.
 * Обе записи таблицы flash 0x6FD2..0x6FDD. Первая обнуляет 273 байта.
 * Вторая переносит 19 байт инициализированного состояния из flash.
 * Стек и таблицу векторов настраивает CRT при компоновке под avr-gcc. */
void nm_startup_memory(const NM8036 *m)
{
    static const uint8_t initial[] = {
        0x01, 0x78, 0x07, 0x47, 0x07, 0x88, 0x11, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x2d, 0x00, 0x25, 0x00
    };
    for (uint16_t address = 0x0673; address < 0x0784; address++)
        *nm_ram(m, address) = 0;
    for (uint8_t i = 0; i < sizeof initial; i++)
        *nm_ram(m, 0x0660 + i) = initial[i];
}
