#include "nm_peripherals.h"

static uint32_t counter_read(const volatile uint8_t *p)
{
    uint32_t value = 0;
    for (uint8_t i = 0; i < 4; i++)
        value |= (uint32_t)p[i] << (8 * i);
    return value;
}

static void counter_write(volatile uint8_t *p, uint32_t value)
{
    for (uint8_t i = 0; i < 4; i++)
        p[i] = (uint8_t)(value >> (8 * i));
}

/* [БИНАРНИК] 0x2022..0x203C, первая задержка и период автоповтора. */
void nm_key_timing_init(const NM8036 *m)
{
    counter_write(nm_ram(m, 0x068f), 61);
    counter_write(nm_ram(m, 0x0693), 6);
}

/* [БИНАРНИК] 0x1FF0..0x2020, граничный тик для звукового сигнала. */
void nm_tone(const NM8036 *m, uint8_t duration)
{
    counter_write(nm_ram(m, 0x069b), counter_read(nm_ram(m, 0x0697)) + 6u * duration);
}

/* [БИНАРНИК] TIMER2 COMP, вектор 0x0014 → 0x1F88..0x1FEE.
 * Сигнал управляет DDRD5 через SBI/CBI по адресу ввода-вывода 0x11. */
void nm_timer2_tick(const NM8036 *m, volatile uint8_t *ddrd)
{
    uint32_t tick = counter_read(nm_ram(m, 0x0697)) + 1;
    counter_write(nm_ram(m, 0x0697), tick);
    if (tick < counter_read(nm_ram(m, 0x069b)) && nm_ee_read(m, 0x02ec))
        *ddrd |= 1u << 5;
    else
        *ddrd &= (uint8_t)~(1u << 5);
}

/* [БИНАРНИК] INT0, 0x0004 → 0x5968..0x59E4.
 * Считывание PIND отдельно в каждом условии сохраняет различие фронтов.
 * [РУКОВОДСТВО] DS1307 выдаёт тактовый сигнал через SQW. */
void nm_rtc_edge(const NM8036 *m, volatile uint8_t *ddrd, const volatile uint8_t *pind)
{
    *nm_ram(m, 0x0735) = 1;
    if (*pind & (1u << 2)) {
        (*nm_ram(m, 0x073b))++;
        *nm_ram(m, 0x0736) = 1;
        nm_outputs_tick(m);
    }
    if (*nm_ram(m, 0x0737) == 1) {
        if (*pind & (1u << 2)) {
            *ddrd &= (uint8_t)~(1u << 4);
        } else {
            *ddrd |= 1u << 4;
            nm_tone(m, 5);
        }
    } else if (nm_ee_read(m, 0x02ed)) {
        *ddrd |= 1u << 4;
    }
}

/* [БИНАРНИК] 0x203E..0x20D8. Два отсчёта должны отличаться
 * не более чем на два кода. Интервалы полуоткрытые.
 * [РУКОВОДСТВО] Клавиши подключены через резистивную цепочку к АЦП. */
uint8_t nm_key_decode(uint16_t first, uint16_t second)
{
    uint16_t difference = (uint16_t)(first - second);
    if (difference > 2 && difference < UINT16_MAX - 1)
        return 0xff;
    static const uint16_t low[] = {866, 841, 801, 761, 671, 501, 0};
    static const uint16_t high[] = {900, 865, 840, 780, 690, 520, 30};
    for (uint8_t key = 0; key < 7; key++)
        if (second >= low[key] && second < high[key])
            return key;
    return 0xff;
}

/* [БИНАРНИК] 0x20DA..0x217A. При новом коде сохраняется время
 * начала удержания, повтор имеет установленный бит 7. */
uint8_t nm_key_event(const NM8036 *m, uint8_t key)
{
    volatile uint8_t *state = nm_ram(m, 0x068f);
    uint32_t now = counter_read(state + 8);
    if (state[24] != key) {
        state[24] = key;
        counter_write(state + 20, now);
    } else {
        if (now - counter_read(state + 20) <= counter_read(state) ||
            now - counter_read(state + 16) <= counter_read(state + 4))
            return 0xff;
    }
    bool repeated = counter_read(state + 20) != now;
    counter_write(state + 16, now);
    if (key != 0xff)
        counter_write(state + 12, now + 2);
    return repeated ? key | 0x80u : key;
}
