#include "nm8036.h"
#include "nm_peripherals.h"
#include <stddef.h>

static void send_ram(const NM8036 *m, const volatile uint8_t *data, uint8_t size)
{
    while (size--)
        m->send(m->context, *data++);
}

static void receive_ram(const NM8036 *m, volatile uint8_t *data, uint8_t size)
{
    while (size--)
        *data++ = m->receive(m->context);
}

/* [БИНАРНИК] 0x2C08..0x2C34 и 0x2C5C..0x2C8E.
 * Первый адрес передаётся напрямую. Блок по UART обменивается при CLI. */
static void transfer_ee(const NM8036 *m, bool write, uint16_t start, uint16_t size)
{
    uint8_t state = m->irq_disable(m->context);
    while (size--) {
        if (write)
            nm_ee_write(m, start, m->receive(m->context));
        else
            m->send(m->context, nm_ee_read(m, start));
        start++;
    }
    m->irq_restore(m->context, state);
}

/* [БИНАРНИК] 0x54CC..0x584A и таблица flash 0x0C42.
 * [РУКОВОДСТВО] Прил. 5. Возвращает false для команд, чей обработчик
 * ещё требует переноса. Требуемые интерфейсы оборудования проверяются
 * до передачи эха, чтобы интегратор не получал ложного подтверждения. */
bool nm_command(const NM8036 *m, uint8_t command)
{
    uint8_t buffer[96];
    switch (command) {
    case 'E':
        /* 0x5532..0x5557. Адаптер проходит весь переход до 0x7000. */
        if (!m->boot_enter)
            return false;
        m->boot_enter(m);
        return true;
    case 'V': {
        /* 0x555A..0x557C. Строка дисплея в оригинальной кодировке. */
        static const uint8_t version[] = {
            0x20, 0xc2, 0xe5, 0xf0, 0xf1, 0xe8, 0xff, 0x20, '1', '.', '9', '5'
        };
        m->send(m->context, 'V');
        m->send(m->context, sizeof version);
        send_ram(m, version, sizeof version);
        return true;
    }
    case 'L':
        nm_program_send(m);
        return true;
    case 'W': {
        /* 0x564A. Эхо перед индексом, затем 27 байт полей. */
        m->send(m->context, 'W');
        uint8_t index = m->receive(m->context);
        receive_ram(m, buffer, NM_WIRE_RECORD);
        nm_program_write(m, index, buffer);
        return true;
    }
    case 'D':
        /* 0x579A. Переход 0x5864 ведёт в EEPROM, номера Dallas 32×8. */
        m->send(m->context, 'D');
        transfer_ee(m, false, 0x02f0, 256);
        return true;
    case 'd':
        /* 0x57AA. Чтение флага и сброс после отправки. */
        m->send(m->context, 'd');
        m->send(m->context, *nm_ram(m, 0x068e));
        *nm_ram(m, 0x068e) = 0;
        return true;
    case 'K':
        /* 0x580E. Код будет обработан основным циклом. */
        m->send(m->context, 'K');
        *nm_ram(m, 0x0739) = m->receive(m->context);
        return true;
    case 's':
        /* 0x5838. Четыре слова АЦП из SRAM. */
        m->send(m->context, 's');
        send_ram(m, nm_ram(m, 0x0673), 8);
        return true;
    case 'l': case 'z': {
        if (!m->porta || !m->portc || !m->portd)
            return false;
        uint16_t bits = nm_outputs_report(m, m->output_reply_seed, command == 'z');
        m->send(m->context, (uint8_t)bits);
        m->send(m->context, (uint8_t)(bits >> 8));
        return true;
    }
    case 'b':
        /* 0x552E → 0x583E. Первый результат того же массива. */
        send_ram(m, nm_ram(m, 0x0673), 2);
        return true;
    case 't':
        /* 0x54D6. Температура, 32 знаковых слова. */
        m->send(m->context, NM_RECORDS);
        send_ram(m, nm_ram(m, 0x06c7), 64);
        return true;
    case 'v':
        /* 0x54E2. 32 байта состояния датчиков. */
        m->send(m->context, NM_RECORDS);
        send_ram(m, nm_ram(m, 0x0707), 32);
        return true;
    case 'I': case 'i': {
        /* 0x57D4..0x57F8, 0x5856, 0x58BC..0x58D0. */
        bool write = command == 'I';
        m->send(m->context, command);
        transfer_ee(m, write, 0x00, 16);
        transfer_ee(m, write, 0x10, 2);
        transfer_ee(m, write, 0x12, 2);
        transfer_ee(m, write, 0x45, 7);
        return true;
    }
    case 'a': case 'A':
        /* 0x57FA..0x580C, 0x584C и 0x5884. */
        m->send(m->context, command);
        transfer_ee(m, command == 'A', 0x15, 24);
        transfer_ee(m, command == 'A', 0x2d, 24);
        return true;
    case 'c':
        /* 0x557E → 0x589C. Ответ из буфера, обновляемого основным циклом. */
        m->send(m->context, 'c');
        send_ram(m, nm_ram(m, 0x0727), 8);
        return true;
    case 'T':
        /* 0x5584. Сначала обновляется буфер времени, затем RTC. */
        if (m->rtc_write == NULL)
            return false;
        m->send(m->context, 'T');
        receive_ram(m, nm_ram(m, 0x0727), 8);
        for (uint8_t i = 0; i < 8; i++)
            buffer[i] = nm_ram(m, 0x0727)[i];
        m->rtc_write(m->context, 0, buffer, 8);
        return true;
    case 'H':
        /* 0x57BC. Две строки хранятся в RAM DS1307 от регистра 8. */
        if (m->rtc_write == NULL)
            return false;
        m->send(m->context, 'H');
        receive_ram(m, buffer, 34);
        m->rtc_write(m->context, 8, buffer, 34);
        return true;
    case 'h':
        /* 0x57C8. Чтение той же области RTC. */
        if (m->rtc_read == NULL)
            return false;
        m->send(m->context, 'h');
        m->rtc_read(m->context, 8, buffer, 34);
        send_ram(m, buffer, 34);
        return true;
    case 'S':
        /* 0x581E. Снимок 64 байт CGRAM и двух строк по 16. */
        if (m->lcd_read == NULL)
            return false;
        m->send(m->context, 'S');
        m->lcd_read(m, buffer);
        send_ram(m, buffer, 96);
        return true;
    default:
        return false;
    }
}
