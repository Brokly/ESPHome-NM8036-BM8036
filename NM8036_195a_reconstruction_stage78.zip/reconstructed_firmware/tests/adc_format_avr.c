/* Испытательная прошивка вызывает реальную avr-libc, результат читает simavr. */
#include <avr/pgmspace.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "adc_format_vectors.h"

#define VECTOR(bits) (uint32_t)(bits),
static const uint32_t vectors[] PROGMEM = {FORMAT_VECTORS(VECTOR)};
#undef VECTOR

int main(void)
{
    for (uint8_t i = 0; i < sizeof vectors / sizeof *vectors; ++i) {
        uint32_t bits = pgm_read_dword(&vectors[i]);
        float value;
        memcpy(&value, &bits, sizeof value);
        dtostre(value, (char *)(uintptr_t)(0x400 + 16u*i), 3, 0);
    }
    *(volatile uint8_t *)(uintptr_t)0x600 = 0xa5;
    for (;;)
        ;
}
