#ifndef DALLAS_BUS_H
#define DALLAS_BUS_H
#include "nm_dallas.h"
#include <assert.h>

typedef struct {
    uint8_t rom[3][8];
    uint8_t devices, active, position, phase, command;
    unsigned resets, reads, writes;
} DallasBus;

static bool search_reset(void *context)
{
    DallasBus *b = context;
    b->resets++;
    b->position = b->phase = b->command = 0;
    b->active = (uint8_t)((1u << b->devices) - 1u);
    return b->active != 0;
}

static bool sensor_bit(const DallasBus *b, uint8_t device)
{
    return (b->rom[device][b->position >> 3] >> (b->position & 7u)) & 1u;
}

static bool search_read(void *context)
{
    DallasBus *b = context;
    b->reads++;
    assert(b->phase == 8 || b->phase == 9);
    bool inverse = b->phase++ == 9;
    for (uint8_t i = 0; i < b->devices; i++)
        if ((b->active & (1u << i)) && sensor_bit(b, i) == inverse)
            return false;
    return true;
}

static void search_write(void *context, bool bit)
{
    DallasBus *b = context;
    b->writes++;
    if (b->phase < 8) {
        b->command |= (uint8_t)(bit << b->phase++);
        if (b->phase == 8)
            assert(b->command == 0xf0);
        return;
    }
    assert(b->phase == 10);
    for (uint8_t i = 0; i < b->devices; i++)
        if (sensor_bit(b, i) != bit)
            b->active &= (uint8_t)~(1u << i);
    b->phase = 8;
    b->position++;
}
#endif
