#ifndef FIXTURE_H
#define FIXTURE_H
#include "nm8036.h"
#include <assert.h>

typedef struct {
    uint8_t ee[1024], ram[2048], tx[1024], rx[96];
    unsigned tx_count, rx_count;
    uint8_t irq;
    uint8_t porta, portc, portd;
} Fixture;

static uint8_t ee_read(void *ctx, uint16_t address)
{
    return ((Fixture *)ctx)->ee[address];
}

static void ee_write(void *ctx, uint16_t address, uint8_t value)
{
    ((Fixture *)ctx)->ee[address] = value;
}

static void send(void *ctx, uint8_t value)
{
    Fixture *f = ctx;
    assert(f->tx_count < sizeof f->tx);
    f->tx[f->tx_count++] = value;
}

static uint8_t receive(void *ctx)
{
    Fixture *f = ctx;
    assert(f->rx_count < sizeof f->rx);
    return f->rx[f->rx_count++];
}

static uint8_t irq_disable(void *ctx)
{
    Fixture *f = ctx;
    uint8_t prior = f->irq;
    f->irq = 0;
    return prior;
}

static void irq_restore(void *ctx, uint8_t state)
{
    ((Fixture *)ctx)->irq = state;
}

static NM8036 fixture_device(Fixture *f)
{
    return (NM8036){.context = f, .sram = f->ram, .receive = receive, .send = send,
        .porta = &f->porta, .portc = &f->portc, .portd = &f->portd,
        .ee_read = ee_read, .ee_write = ee_write,
        .irq_disable = irq_disable, .irq_restore = irq_restore};
}
#endif
