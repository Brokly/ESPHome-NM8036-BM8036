#include "fixture.h"
#include "nm_peripherals.h"
#include <stdio.h>
#include <string.h>

static void test_keyboard(void)
{
    assert(nm_key_decode(866, 866) == 0);
    assert(nm_key_decode(865, 865) == 0xff);
    assert(nm_key_decode(866, 869) == 0xff);
    assert(nm_key_decode(868, 866) == 0);
    assert(nm_key_decode(864, 866) == 0);
    assert(nm_key_decode(24, 24) == 6);
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    nm_key_timing_init(&m);
    assert(nm_key_event(&m, 0xff) == 0xff);
    assert(nm_key_event(&m, 1) == 1);
    f.ee[0x2ec] = 1;
    nm_tone(&m, 1);
    uint8_t ddrd = 0;
    nm_timer2_tick(&m, &ddrd);
    assert(ddrd == 0x20);
    for (unsigned i = 1; i < 61; i++)
        nm_timer2_tick(&m, &ddrd);
    assert(ddrd == 0 && nm_key_event(&m, 1) == 0xff);
    nm_timer2_tick(&m, &ddrd);
    assert(nm_key_event(&m, 1) == 0x81);
}

static void test_outputs(void)
{
    Fixture f = {.irq = 0x80};
    NM8036 m = fixture_device(&f);
    f.ee[0x15] = 2;
    f.ee[0x2d] = 1;
    nm_outputs_init(&m);
    nm_output_request(&m, 0, true);
    nm_output_request(&m, 4, true);
    assert(nm_outputs_report(&m, 0, false) == 0x0880);
    nm_outputs_tick(&m);
    assert(f.portc == 0x80 && f.porta == 0x80 && f.irq == 0x80);
    nm_outputs_tick(&m);
    assert(f.portc == 0 && f.porta == 0x80);
    nm_outputs_tick(&m);
    assert(f.portc == 0x80 && f.porta == 0x80);
    nm_outputs_force(&m, 1);
    assert(f.portc == 0 && f.porta == 0);
    nm_outputs_tick(&m);
    assert(f.portc == 0);
    uint8_t direction = 0, pins = 4;
    nm_rtc_edge(&m, &direction, &pins);
    assert(*nm_ram(&m, 0x0735) == 1);
    assert(*nm_ram(&m, 0x073b) == 1);
    assert(*nm_ram(&m, 0x0736) == 1);
}

static void test_sensors(void)
{
    static const uint8_t vector[] = "123456789";
    assert(nm_dallas_crc(vector, 9) == 0xa1);
    uint8_t memory[9] = {0};
    assert(!nm_dallas_scratchpad_valid(memory));
    memory[0] = 0x91;
    memory[1] = 0x01;
    memory[8] = nm_dallas_crc(memory, 8);
    assert(nm_dallas_scratchpad_valid(memory));
    assert(nm_dallas_temperature(0x28, memory) == 2506);
    memory[0] = 0xff;
    memory[1] = 0xff;
    assert(nm_dallas_temperature(0x28, memory) == -7);
    memory[0] = 50;
    memory[1] = 0;
    memory[6] = 12;
    memory[7] = 16;
    assert(nm_dallas_temperature(0x10, memory) == 2500);
}

static uint8_t key_none(const NM8036 *m)
{
    (void)m;
    return 0xff;
}

static void test_schedule(void)
{
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    uint8_t record[27] = {0};
    record[0] = 23;
    record[3] = 2;
    record[18] = 3;
    record[19] = 2;
    record[20] = 1;
    record[25] = 1;
    nm_program_write(&m, 0, record);
    const uint8_t rtc[8] = {0, 0, 0x01, 1, 1, 1, 0, 0x90};
    for (unsigned i = 0; i < 8; i++)
        nm_ram(&m, 0x0727)[i] = rtc[i];
    f.ee[0x02ed] = 1;
    assert(nm_schedule_window(&m, 0, rtc));
    for (unsigned i = 0; i < 32; i++)
        nm_schedule_step(&m, key_none);
    assert(*nm_ram(&m, 0x0747 + 37) == 1);
    assert(*nm_ram(&m, 0x06b9) == 0);
    f.ee[0x02ed] = 0;
    for (unsigned i = 0; i < 32; i++)
        nm_schedule_step(&m, key_none);
    assert(*nm_ram(&m, 0x0747 + 37) == 0);
}

int main(void)
{
    test_keyboard();
    test_outputs();
    test_sensors();
    test_schedule();
    Fixture f = {0};
    NM8036 m = fixture_device(&f);
    assert(!nm_command(&m, '?'));
    assert(!nm_command(&m, 'H'));
    assert(f.tx_count == 0);
    puts("Тесты C прошли");
}
