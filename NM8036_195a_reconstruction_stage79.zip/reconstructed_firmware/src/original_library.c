#include "nm_original_library.h"

static uint16_t read_word(const uint8_t *memory, uint16_t address)
{
    return memory[address] | (uint16_t)memory[(uint16_t)(address + 1)] << 8;
}

static void write_word(uint8_t *ram, uint16_t address, uint16_t value)
{
    ram[address] = (uint8_t)value;
    ram[(uint16_t)(address + 1)] = (uint8_t)(value >> 8);
}

/* 0x61EC–0x6239. В первом проходе ненулевые слова пропускаются,
 * а слово после нулевого маркера вызывается. Во втором проходе
 * вызываются одиночные ненулевые слова, пары с маркером пропускаются.
 * Адреса словные, r16:r17 перед вызовом содержит младший байт адреса. */
void nm_avr_start_callbacks(const uint8_t *flash, uint16_t first, uint16_t end,
                            NMOriginalInvoke invoke, void *context)
{
    for (uint16_t at = first; at != end; at += 2) {
        if (!read_word(flash,at)) {
            at += 2;
            uint16_t target = read_word(flash,at);
            invoke(context,target,(uint8_t)target);
        }
    }
    for (uint16_t at = first; at != end; at += 2) {
        uint16_t target = read_word(flash,at);
        if (target)
            invoke(context,target,(uint8_t)target);
        else
            at += 2;
    }
}

enum { exit_head = 0x077a };

/* 0x623A–0x626B, 0x62A8–0x62B7. В первом поле записи лежит
 * указатель на ячейку связи. Вставка помещает запись в начало списка.
 * false соответствует переходу к функции завершения с кодом 1. */
bool nm_avr_exit_register(uint8_t *ram, uint16_t node)
{
    uint16_t link = read_word(ram,node);
    if (read_word(ram,link) || node == read_word(ram,exit_head))
        return false;
    write_word(ram,link,read_word(ram,exit_head));
    write_word(ram,exit_head,node);
    return true;
}

/* 0x626C–0x62A7. Снять голову до вызова обработчика, чтобы обработчик
 * мог изменить список. Передаётся слово с node+2, в том числе нулевое. */
void nm_avr_exit_callbacks(uint8_t *ram, NMOriginalInvoke invoke, void *context)
{
    uint16_t node;
    while ((node = read_word(ram,exit_head)) != 0) {
        uint16_t link = read_word(ram,node);
        write_word(ram,exit_head,read_word(ram,link));
        invoke(context,read_word(ram,node + 4),read_word(ram,node + 2));
    }
}

/* 0x69B0–0x69C5. Цикл LPM выполняет первое копирование до проверки
 * длины. Нулевой счётчик даёт 65536 итераций с оборачиванием адреса. */
void nm_avr_copy_flash(uint8_t *ram, uint16_t destination, const uint8_t *flash,
                       uint16_t source, uint16_t count)
{
    do {
        ram[destination++] = flash[source++];
    } while (--count);
}

/* 0x6A12–0x6A33. Цепочка CP/CPC сравнивает два 64-битных слова
 * little-endian. Для равенства сравниваются все восемь байтов ROM. */
int nm_avr_compare_rom(const uint8_t left[8], const uint8_t right[8])
{
    for (unsigned i = 8; i != 0; --i) {
        if (left[i - 1] != right[i - 1])
            return left[i - 1] < right[i - 1] ? -1 : 1;
    }
    return 0;
}

/* 0x6BA0–0x6BC5. Обе версии ищут ноль и возвращают длину без
 * терминатора. Аргумент memory выбирает SRAM или снимок Flash. */
uint16_t nm_avr_string_length(const uint8_t *memory, uint16_t address)
{
    uint16_t end = address;
    while (memory[end])
        ++end;
    return (uint16_t)(end - address);
}
