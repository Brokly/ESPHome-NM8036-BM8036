#include "nm_editors.h"

/* [БИНАРНИК] 0x3012, вход в список с нулевым индексом. */
void nm_program_editor_open(const NM8036 *m)
{
    *nm_ram(m, 0x06b4) = 0;
    *nm_ram(m, 0x06b6) = NM_PROGRAM_LIST;
}

/* Рабочие пороги оригинала переживают выход из редактора.
 * Прямой переход 0x33FC использует их без чтения EEPROM. */
static void threshold_buffer(const NM8036 *m, NMThresholds *thresholds, bool load)
{
    volatile uint8_t *p = nm_ram(m, 0x06b0);
    for (uint8_t i = 0; i < 2; i++, p += 2) {
        if (load)
            thresholds->value[i] = (int16_t)(p[0] | ((uint16_t)p[1] << 8));
        else {
            uint16_t value = (uint16_t)thresholds->value[i];
            p[0] = (uint8_t)value;
            p[1] = value >> 8;
        }
    }
}

/* [БИНАРНИК] 0x301A..0x3040, 0x3810..0x3818. Номер
 * состояния в SRAM 0x06B6 выбирает ветвь таблицы 0x0BF0.
 * Отдельно учитываются младший полубайт клавиши и полный код. */
bool nm_program_editor_step(const NM8036 *m, NMProgramEditor *editor, uint8_t key)
{
    uint8_t saved = m->irq_disable(m->context);
    uint8_t view = *nm_ram(m, 0x06b6);
    uint8_t index = *nm_ram(m, 0x06b4);
    uint8_t action = key & 15u;
    if (view == NM_PROGRAM_LIST) {
        if (action == 5) {
            m->irq_restore(m->context, saved);
            return true;
        }
        if (action == 0)
            view = NM_PROGRAM_ENABLE;
        else
            (void)nm_program_select(m, key);
    } else if (view == NM_PROGRAM_ENABLE) {
        if (action >= 1 && action <= 4)
            nm_program_toggle(m, index);
        else if (key == 5 || (action == 0 && !nm_program_enabled(m, index)))
            view = NM_PROGRAM_LIST;
        else if (action == 0) {
            nm_program_time_load(m, index, false, &editor->time);
            view = NM_PROGRAM_START;
        }
    } else if (view == NM_PROGRAM_CONTROL) {
        if (key == 5)
            view = NM_PROGRAM_LIST;
        else if (action == 2 || action == 3)
            *nm_ram(m, 0x06b5) = (*nm_ram(m, 0x06b5) + (action == 2 ? 3u : 1u)) & 3u;
        else if (action == 1 || action == 4) {
            switch (*nm_ram(m, 0x06b5)) {
            case 0: nm_program_output_key(m, index, key); break;
            case 1: nm_program_kind_key(m, index, key); break;
            case 2: nm_program_sensor_key(m, index, key); break;
            case 3: nm_program_source_key(m, index, key); break;
            }
        } else if (key == 0) {
            uint8_t next = nm_program_control_confirm(m, index);
            if (next == 8)
                view = NM_PROGRAM_LOGIC;
            else if (next == 7) {
                editor->thresholds.analog = true;
                threshold_buffer(m, &editor->thresholds, true);
                view = NM_PROGRAM_THRESHOLDS;
            } else
                view = NM_PROGRAM_COMPARE;
        }
    } else if (view >= NM_PROGRAM_COMPARE && view <= NM_PROGRAM_PERIOD) {
        uint16_t base = 0x4cu + 21u * index;
        /* 0x3776: на экране И/ИЛИ MENU оставляет состояние 8. */
        if (key == 5 && view != NM_PROGRAM_LOGIC) {
            view = NM_PROGRAM_LIST;
        } else if (view == NM_PROGRAM_COMPARE) {
            if (action == 1 || action == 4)
                nm_program_relative_toggle(m, index);
            else if (key == 0) {
                if (nm_ee_read(m, base + 6u) & 0x20u)
                    view = NM_PROGRAM_REFERENCE;
                else {
                    nm_program_thresholds_load(m, index, &editor->thresholds);
                    threshold_buffer(m, &editor->thresholds, false);
                    view = NM_PROGRAM_THRESHOLDS;
                }
            }
        } else if (view == NM_PROGRAM_REFERENCE) {
            nm_program_reference_key(m, index, key);
            if (key == 0)
                view = NM_PROGRAM_LOGIC;
        } else if (view == NM_PROGRAM_THRESHOLDS) {
            editor->thresholds.selected = *nm_ram(m, 0x06b5) & 1u;
            nm_program_threshold_key(&editor->thresholds, key);
            threshold_buffer(m, &editor->thresholds, false);
            *nm_ram(m, 0x06b5) = editor->thresholds.selected;
            if (key == 0) {
                nm_program_thresholds_save(m, index, &editor->thresholds);
                view = NM_PROGRAM_LOGIC;
            }
        } else if (view == NM_PROGRAM_LOGIC) {
            if (action == 1 || action == 4)
                nm_program_logic_toggle(m, index);
            else if (key == 0) {
                view = NM_PROGRAM_PERIOD;
            }
        } else {
            uint8_t period = nm_program_period_key(m, index, key);
            if (!period && key == 0)
                view = NM_PROGRAM_LIST;
            else
                nm_program_period_item(m, index, period, key);
        }
    } else if (view == NM_PROGRAM_START || view == NM_PROGRAM_STOP) {
        nm_program_time_key(&editor->time, key);
        if (key == 5)
            view = NM_PROGRAM_LIST;
        else if (key == 0) {
            bool stop = view == NM_PROGRAM_STOP;
            nm_program_time_save(m, index, stop, &editor->time);
            if (stop) {
                view = NM_PROGRAM_CONTROL;
                *nm_ram(m, 0x06b5) = 0;
            } else {
                /* 0x3174..0x3198 обновляет поля того же окна, +9 остаётся. */
                uint8_t cursor = editor->time.cursor;
                nm_program_time_load(m, index, true, &editor->time);
                editor->time.cursor = cursor;
                view = NM_PROGRAM_STOP;
            }
        }
    }
    *nm_ram(m, 0x06b6) = view;
    m->irq_restore(m->context, saved);
    return false;
}

/* [БИНАРНИК] 0x306E..0x3084, шаблоны 0x0528/0x0535/0x0546. */
void nm_program_enable_screen(const NM8036 *m, uint8_t index, uint8_t screen[32])
{
    static const uint8_t title[] = {0xd8,0xc0,0xc3};
    static const uint8_t on[] = {0xc2,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
    static const uint8_t off[] = {0xc2,0xfb,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
    for (uint8_t i = 0; i < 32; i++)
        screen[i] = ' ';
    for (uint8_t i = 0; i < sizeof title; i++)
        screen[5+i] = title[i];
    uint8_t number = index + 1u;
    screen[9] = number < 10 ? ' ' : '0' + number / 10u;
    screen[10] = '0' + number % 10u;
    bool enabled = nm_program_enabled(m, index);
    const uint8_t *label = enabled ? on : off;
    uint8_t length = enabled ? sizeof on : sizeof off;
    for (uint8_t i = 0; i < length; i++)
        screen[20+i] = label[i];
}
