#!/usr/bin/env python3
"""Проверка отдельного реестра ABI по результату основного аудита."""
import csv
from pathlib import Path

root = Path(__file__).resolve().parent
with (root / "instructions.csv").open() as table:
    instructions = {int(row["address"], 16): row for row in csv.DictReader(table)}

claimed = set()
total = 0
for line in (root / "avr_abi.tsv").read_text().splitlines():
    if not line or line.startswith("#"):
        continue
    start_text, stop_text, description = line.split("\t")
    start, stop = int(start_text, 16), int(stop_text, 16)
    cursor = start
    while cursor < stop:
        row = instructions[cursor]
        assert not row["module"], (start_text, row["address"])
        assert cursor not in claimed, row["address"]
        claimed.add(cursor)
        cursor += int(row["size"])
    assert cursor == stop, stop_text
    total += stop-start
    print(start_text, stop_text, stop-start, description)
print("Байт ABI вне реестра C:", total)
