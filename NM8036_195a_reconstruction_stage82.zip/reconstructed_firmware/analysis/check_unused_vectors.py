#!/usr/bin/env python3
"""Проверяет маршруты незадействованных прерываний в собранном образе."""
from pathlib import Path
import sys

image = Path(sys.argv[1]).read_bytes()
original = Path(__file__).with_name("original.bin").read_bytes()

def word(data, address):
    return int.from_bytes(data[address:address+2], "little")

def jump(data, address):
    assert word(data,address) == 0x940c, hex(address)
    return 2 * word(data,address+2)

vectors = [i for i in range(4,0x54,4) if word(original,i) == 0x9518]
assert len(vectors) == 17
for address in vectors:
    trampoline = jump(image,address)
    handler = jump(image,trampoline)
    assert word(image,handler) == 0x9518, hex(address)
    print(f"0x{address:04x} → 0x{trampoline:04x} → 0x{handler:04x} RETI")
