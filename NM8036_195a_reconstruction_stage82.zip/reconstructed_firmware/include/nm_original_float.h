#ifndef NM_ORIGINAL_FLOAT_H
#define NM_ORIGINAL_FLOAT_H
#include <stdint.h>
uint32_t nm_avr_float_add(uint32_t left, uint32_t right);
uint32_t nm_avr_float_subtract(uint32_t left, uint32_t right);
uint32_t nm_avr_float_multiply(uint32_t left, uint32_t right);
uint32_t nm_avr_float_divide(uint32_t left, uint32_t right);
#endif
