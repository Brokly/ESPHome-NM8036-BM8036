#ifndef NM_ORIGINAL_FRAGMENTS_H
#define NM_ORIGINAL_FRAGMENTS_H

#include "nm_original_status.h"

uint16_t nm_avr_open_word_editor(const NMNumericDisplay *lcd, uint8_t *ram,
                                 NMNumericAlloc allocate, NMNumericSnapshot snapshot,
                                 bool single_digit);
void nm_avr_update_digit_title(const NMNumericDisplay *lcd, const uint8_t *flash,
                              uint8_t field[22], uint16_t title);
void nm_avr_update_digit_value(const NMNumericDisplay *lcd, const uint8_t *flash,
                              uint8_t field[22], uint8_t value);
bool nm_avr_output_delay_open(const NM8036 *m, const NMNumericDisplay *lcd,
                              const uint8_t *flash, uint8_t *ram, uint8_t selection,
                              NMNumericAlloc allocate, NMNumericSnapshot snapshot);
uint32_t nm_avr_literal_argument(uint8_t negative, uint16_t number);
uint8_t nm_avr_program_commit_control(const NM8036 *m, uint16_t option,
                                     uint8_t field, bool five_bits);
bool nm_avr_program_write_selector(const NM8036 *m, uint16_t record, uint8_t value);
uint16_t nm_avr_program_indexed_text(uint16_t base, uint16_t stride, uint16_t index);
uint8_t nm_avr_program_titled_field(const NM8036 *m, const NMNumericDisplay *lcd,
                                    const uint8_t *flash, uint8_t *ram,
                                    uint16_t format, uint16_t arguments, uint16_t display_number);
bool nm_avr_sample_registered(const NM8036 *m, const NMOneWire *bus, uint8_t slot);
uint8_t nm_avr_effective_rtc_hour(uint8_t units, uint8_t decades);
uint32_t nm_avr_adc_multiply_word(uint32_t left, uint32_t right);
typedef struct { uint8_t value; uint16_t next_address; } NMProgramByte;
NMProgramByte nm_avr_program_read_byte(const NM8036 *m, uint16_t record, uint8_t entry);
uint8_t nm_avr_program_test_flags(const NM8036 *m, uint16_t address, uint8_t mask);
uint16_t nm_avr_uart_frame_target(const uint8_t *flash, const uint8_t frame[35], uint8_t received);
bool nm_avr_dallas_restart_selection(const NM8036 *m, uint8_t count, uint8_t key);
void nm_avr_dallas_print_temperature(const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, uint16_t at, int16_t value);
void nm_avr_lcd_restore_cgram(const NMNumericDisplay *lcd, const uint8_t saved[64]);
bool nm_avr_program_redraw_request(const NM8036 *m, uint8_t requested);
void nm_avr_program_select_draw(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, void (*draw_row)(void *, uint8_t));
void nm_avr_program_first_condition(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram);
uint8_t nm_avr_adc_decoration(const NM8036 *m, uint16_t channel, uint32_t measurement, uint32_t *saved);
bool nm_avr_adc_operand_compare(uint32_t left, uint32_t right, bool at_least);
uint8_t nm_avr_dallas_dialog_sample(const NM8036 *m, const NMOneWire *bus, volatile uint8_t value[2]);
bool nm_avr_pwm_end_display(const NMNumericDisplay *lcd, uint8_t *ram, uint16_t scale, NMNumericRestore restore);
uint8_t nm_avr_pwm_apply_word(const NM8036 *m, uint8_t *field, bool contrast, int16_t step);
uint16_t nm_avr_pwm_active_field(const NM8036 *m, uint8_t *key);
bool nm_avr_program_page_active(const NM8036 *m, uint8_t key, uint8_t page);
bool nm_avr_program_print_accept(const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, uint16_t format, uint16_t argument, uint8_t key);
uint16_t nm_avr_program_header_begin(const NM8036 *m, const NMNumericDisplay *lcd, uint8_t word[2]);
#endif
