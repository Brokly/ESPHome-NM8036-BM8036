#ifndef NM_ORIGINAL_LIBRARY_H
#define NM_ORIGINAL_LIBRARY_H

#include <stdbool.h>
#include <stdint.h>

typedef void (*NMOriginalInvoke)(void *context, uint16_t word_address, uint16_t argument);

void nm_avr_start_callbacks(const uint8_t *flash, uint16_t first, uint16_t end,
                            NMOriginalInvoke invoke, void *context);
bool nm_avr_exit_register(uint8_t *ram, uint16_t node);
void nm_avr_exit_callbacks(uint8_t *ram, NMOriginalInvoke invoke, void *context);
void nm_avr_copy_flash(uint8_t *ram, uint16_t destination, const uint8_t *flash,
                       uint16_t source, uint16_t count);
int nm_avr_compare_rom(const uint8_t left[8], const uint8_t right[8]);
uint16_t nm_avr_string_length(const uint8_t *memory, uint16_t address);

_Noreturn void nm_avr_exit_application(uint8_t *ram, NMOriginalInvoke invoke, void *context);
void nm_avr_exit_register_or_halt(uint8_t *ram, uint16_t node);
#endif
