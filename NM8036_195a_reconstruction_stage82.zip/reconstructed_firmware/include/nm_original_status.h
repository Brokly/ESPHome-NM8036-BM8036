#ifndef NM_ORIGINAL_STATUS_H
#define NM_ORIGINAL_STATUS_H

#include "nm_numeric_display.h"
#include "nm_dallas.h"

typedef void (*NMStatusFormat)(void *context, uint16_t format, const uint8_t *arguments);
uint32_t nm_avr_status_voltage(uint16_t raw);
bool nm_avr_status_screen(const NM8036 *m, const NMNumericDisplay *lcd,
                          bool closing, bool sqw, NMStatusFormat format);
bool nm_avr_program_menu(const NM8036 *m, bool closing, NMAdcSettingsStep step,
                          void (*close)(void *), void *context);
uint16_t nm_avr_status_second_adc(const NM8036 *m, uint16_t index);
uint8_t nm_avr_status_hour(uint8_t bcd, bool hour12, uint8_t *flags);
uint8_t nm_avr_status_previous_second(uint8_t second);
uint8_t nm_avr_status_month(uint8_t bcd, uint8_t *decade);
void nm_avr_status_snapshot_exit(volatile uint8_t *key);
typedef struct {
    NMNumericAlloc open;
    NMNumericRestore restore;

    NMNumericRestore release;
} NMStatusStorage;
void nm_avr_startup_scan(const NM8036 *m, const NMOneWire *bus,
                         const NMNumericDisplay *lcd, const uint8_t *flash,
                         uint8_t *sram, NMStatusStorage storage);
bool nm_avr_status_flash_format(const NMNumericDisplay *lcd, const uint8_t *flash,
                                uint8_t *ram, uint16_t address, uint16_t arguments);
void nm_avr_dallas_dialog_open(const NM8036 *m, const NMOneWire *bus, const NMNumericDisplay *lcd,
                               const uint8_t *flash, uint8_t *sram, NMNumericAlloc allocate);
void nm_avr_dallas_measure_selected(const NM8036 *m, const NMOneWire *bus, int16_t *temperature);
bool nm_avr_rtc_menu_finish(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t screen[34]);
void nm_avr_rtc_menu_enter(const NMNumericDisplay *lcd, bool opening);
uint8_t nm_avr_rtc_encode_hour(uint8_t previous, uint8_t hour, bool hour12);
uint8_t nm_avr_home_active_route(const NM8036 *m);
uint8_t nm_avr_dallas_dialog_route(const NM8036 *m);
void nm_avr_status_rtc_rows(const NM8036 *m, const uint8_t *flash, uint8_t *ram, uint16_t frame);
void nm_avr_status_rtc_highlight(uint8_t *ram, uint16_t frame, uint8_t field);
uint16_t nm_avr_status_object_open(const NMNumericDisplay *lcd, uint8_t *ram, NMNumericAlloc allocate, NMNumericSnapshot snapshot);
void nm_avr_status_object_close(const NMNumericDisplay *lcd, const uint8_t *ram, uint16_t object, NMNumericRestore restore, NMNumericRestore release);
void nm_avr_program_source_line(const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, uint16_t format, uint8_t number);
bool nm_avr_program_initial_screen(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, bool opening);
void nm_avr_program_logic_screen(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram);
void nm_avr_status_uart_frame(uint8_t *frame, uint8_t (*receive)(void *, uint8_t *), void (*dispatch)(void *, uint8_t), void *context);
uint16_t nm_avr_pwm_begin_display(const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, bool contrast, NMNumericAlloc allocate, NMNumericSnapshot snapshot);
#endif
