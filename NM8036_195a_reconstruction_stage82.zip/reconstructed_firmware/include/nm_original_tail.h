#ifndef NM_ORIGINAL_TAIL_H
#define NM_ORIGINAL_TAIL_H
#include "nm_original_fragments.h"

uint16_t nm_avr_tail_delay_address(uint16_t base);
uint16_t nm_avr_tail_child(const uint8_t *parent);
void nm_avr_tail_child_limits(uint8_t *ram, const uint8_t *parent, uint8_t maximum);
void nm_avr_tail_lcd_cursor(const NMNumericDisplay *lcd, bool blink);
uint8_t nm_avr_tail_list_active(const uint8_t list[3]);
uint16_t nm_avr_tail_allocate_calendar(const NMNumericDisplay *lcd, NMNumericAlloc allocate);
bool nm_avr_tail_calendar_key(void *context, uint16_t child, uint8_t key,
                              void (*edit)(void *, uint16_t, uint8_t));
uint8_t nm_avr_tail_program_key(const uint8_t record[8]);
uint8_t nm_avr_tail_move_program(const NM8036 *m, uint8_t raw, uint8_t page);
uint16_t nm_avr_tail_program_commit(const NM8036 *m, uint16_t address, uint16_t next,
                                    uint8_t original_flags, uint8_t selected);
uint8_t nm_avr_tail_program_flag20(const NM8036 *m, uint16_t address);
uint8_t nm_avr_tail_program_output(const NM8036 *m, uint16_t address);
uint8_t nm_avr_tail_dallas_key(const NM8036 *m);
void nm_avr_tail_dallas_close(void *context, uint16_t cache, NMNumericRestore release);
uint8_t nm_avr_tail_rtc_hour_bits(uint8_t bcd, uint8_t *units);
void nm_avr_tail_program_period(const NMNumericDisplay *lcd,
                                const uint8_t *flash, uint8_t *ram, uint16_t index);
uint8_t nm_avr_tail_program_compare(const NM8036 *m, uint16_t record);
bool nm_avr_tail_dallas_enter(const NM8036 *m, const NMOneWire *bus, const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, NMNumericAlloc allocate, bool opening);
void nm_avr_tail_output_request(const NM8036 *m, uint8_t channel, bool active);
void nm_avr_tail_output_mode(const NM8036 *m, uint8_t mode);
uint8_t nm_avr_tail_alarm(const NM8036 *m, uint16_t record);
void nm_avr_tail_store_coefficient(const NM8036 *m, uint16_t record, uint8_t byte);
uint16_t nm_avr_tail_aux_display(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, uint16_t index, uint16_t format, const uint8_t argument[6], uint16_t at);
uint16_t nm_avr_tail_bar_update(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, uint16_t scale, uint32_t word);
uint8_t nm_avr_tail_program_commit_read(const NM8036 *m, uint16_t address, uint16_t next, uint8_t value, bool following);
void nm_avr_tail_program_open_zero(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, void (*draw_row)(void *, uint8_t));
uint8_t nm_avr_tail_scale_select(uint8_t mode);
uint16_t nm_avr_tail_split_option(uint8_t low, uint8_t high);
uint8_t nm_avr_tail_setup_screen(const NMNumericDisplay *lcd, uint8_t column, uint8_t data, uint8_t byte);
uint32_t nm_avr_tail_calendar_boundary(const NM8036 *m, uint16_t address, uint8_t day, uint8_t hour, uint8_t minute);
uint16_t nm_avr_tail_program_pair(const NM8036 *m, uint16_t address, uint16_t record);
uint16_t nm_avr_tail_program_word13(const NM8036 *m, uint16_t record);
void nm_avr_tail_write_flags(const NM8036 *m, uint16_t record, uint8_t flags);
uint16_t nm_avr_tail_program_address(uint8_t program);
uint32_t nm_avr_tail_extend_byte(uint8_t byte);
void nm_avr_tail_clear_home(const NMNumericDisplay *lcd);
void nm_avr_tail_blank_pair(uint8_t field[2]);
uint8_t nm_avr_tail_selected_flags(const NM8036 *m);
void nm_avr_tail_first_row(const NMNumericDisplay *lcd);
bool nm_avr_tail_prepare_adc(uint8_t row, uint16_t *channel);
bool nm_avr_tail_rtc_redraw(const NM8036 *m);
uint8_t nm_avr_tail_dallas_title(const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t *ram, uint16_t title);
void nm_avr_tail_decimal_words(const uint8_t field[20], uint8_t words[10]);
uint16_t nm_avr_tail_scientific_caption(const NMNumericDisplay *lcd, const uint8_t field[20]);
void nm_avr_tail_scientific_digits(const NMNumericDisplay *lcd, const uint8_t *flash, const uint8_t field[20]);
void nm_avr_tail_store_long(uint8_t bytes[4], uint32_t value);
uint16_t nm_avr_tail_record_offset(uint16_t index, uint8_t *base);
void nm_avr_tail_commit_high(const NM8036 *m, uint16_t address, bool borrow, uint8_t value);
void nm_avr_tail_scientific_position(const NMNumericDisplay *lcd, const uint8_t position[2]);
void nm_avr_tail_write_character(const NMNumericDisplay *lcd, uint8_t byte);
uint32_t nm_avr_tail_current_stamp(uint8_t year, uint8_t month, uint8_t day, uint8_t hour, uint16_t minute_second);
uint16_t nm_avr_tail_stamp_fields(const NM8036 *m, uint16_t day_address, uint8_t packed);
uint32_t nm_avr_tail_saved_stamp(const NM8036 *m, uint16_t address, uint8_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t minute);
void nm_avr_tail_output_list(const NM8036 *m, uint8_t *ram, bool move, uint8_t operand, void (*redraw)(void *, uint16_t), void *context);
void nm_avr_tail_program_reset_page(const NM8036 *m);
bool nm_avr_tail_program_show_page(bool entered, uint8_t dirty);
uint16_t nm_avr_tail_dallas_number(uint8_t index);
bool nm_avr_tail_format_program(const uint8_t *flash, uint16_t format, uint8_t *ram, uint16_t arguments, uint16_t destination, bool borrow, uint16_t *count);
bool nm_avr_tail_menu_enter(uint8_t opening);
bool nm_avr_tail_manual_outputs(const NM8036 *m, const NMNumericDisplay *lcd, bool opening);
void nm_avr_tail_restore_object(void *context, const uint8_t object[2], NMNumericRestore restore);
#endif
