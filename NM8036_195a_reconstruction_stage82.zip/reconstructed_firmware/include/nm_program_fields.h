#ifndef NM_PROGRAM_FIELDS_H
#define NM_PROGRAM_FIELDS_H
#include "nm8036.h"

uint16_t nm_avr_program_record_base(uint8_t index);
uint8_t nm_avr_program_period_mode(const NM8036 *m);
uint8_t nm_avr_program_merge_time(uint8_t previous, uint8_t field);
void nm_avr_program_record_key(uint8_t editor[8], uint8_t key);
void nm_avr_program_limit(uint8_t editor[6], bool upper);
uint32_t nm_avr_program_eeprom_read(const NM8036 *m, uint16_t address, uint8_t width);
void nm_avr_program_eeprom_write(const NM8036 *m, uint16_t address, uint32_t value, uint8_t width);
uint8_t nm_avr_program_selected_byte(const NM8036 *m, uint16_t offset);
uint8_t nm_avr_program_editor_insert(uint8_t *editor, uint8_t offset, uint8_t code, uint8_t mask);
uint8_t nm_avr_program_bit_from_mask(uint32_t mask, uint8_t shift);
uint16_t nm_avr_program_unbased_offset(uint8_t index, uint16_t offset);
uint8_t nm_avr_program_flag(const NM8036 *m, uint16_t address);
void nm_avr_program_set_flag(const NM8036 *m, uint16_t address, uint8_t value);
bool nm_avr_program_exact_key(uint8_t raw, uint8_t expected);
uint8_t nm_avr_program_merge_source(const uint8_t *editor, uint8_t high);
uint16_t nm_avr_program_number(uint8_t index);
void nm_avr_program_write_field(const NM8036 *m, uint16_t address, uint8_t high, uint8_t low, uint8_t mask);
uint16_t nm_avr_program_split_field(uint16_t value);
uint8_t nm_avr_program_six_bits(const NM8036 *m, uint16_t address);
typedef struct {
    uint8_t head, flag11, source12, source12_low, output5;
    uint16_t word15;
} NMOriginalProgramFields;
uint32_t nm_avr_program_threshold_word(const NM8036 *m, uint16_t address, uint8_t *flag);
uint8_t nm_avr_program_read_source(const NM8036 *m, uint16_t record, uint8_t offset);
uint16_t nm_avr_program_commit_selector(const NM8036 *m, uint16_t record, uint8_t offset, uint8_t high, uint8_t low, uint8_t mask);
void nm_avr_program_load_fields(const NM8036 *m, uint16_t record, NMOriginalProgramFields *out);
uint8_t nm_avr_program_transfer_sources(const NM8036 *m, uint8_t *editor,
                                        uint8_t first_offset, uint8_t second_offset);
#endif
