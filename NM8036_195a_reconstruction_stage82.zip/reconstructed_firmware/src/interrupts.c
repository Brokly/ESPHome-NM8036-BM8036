#include "nm_peripherals.h"

#ifdef __AVR__
#include <avr/interrupt.h>
#include <avr/io.h>

/* Привязка модели перед разрешением прерываний. Срок жизни
 * переданного объекта должен охватывать всю работу обработчиков. */
static const NM8036 *device;

void nm_atmega32_attach_interrupts(const NM8036 *m)
{
    device = m;
}

/* [БИНАРНИК] 0x0014 → 0x1F88. TIMSK 0x40 включает TOIE2. Пролог/эпилог AVR создаёт компилятор. */
ISR(TIMER2_OVF_vect)
{
    nm_timer2_tick(device, &DDRD);
}

/* [БИНАРНИК] 0x0004 → 0x5968. Подключается явно при интеграции. */
ISR(INT0_vect)
{
    nm_rtc_edge(device, &DDRD, &PIND);
}
/* Байтовые адреса 0x0008, 0x000C, 0x0010, 0x0018–0x003C,
 * 0x0044–0x0050 с шагом 4. Пустые векторы оригинала выполняют
 * RETI. Один общий обработчик воспроизводит возврат avr-libc. */
EMPTY_INTERRUPT(BADISR_vect)
#endif
