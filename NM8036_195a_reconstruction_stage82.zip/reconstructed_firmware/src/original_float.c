#include "nm_original_float.h"
#include <float.h>
#include <string.h>
 
_Static_assert(sizeof(float) == sizeof(uint32_t) && FLT_RADIX == 2 &&
               FLT_MANT_DIG == 24 && FLT_MAX_EXP == 128, "binary32 required");

static uint32_t bits(float value)
{
    uint32_t word;
    memcpy(&word,&value,sizeof word);
    return word;
}

static float number(uint32_t word)
{
    float value;
    memcpy(&value,&word,sizeof value);
    return value;
}

static uint32_t canonical(uint32_t word)
{
    /* 0x66B0–0x66B5: общий NaN имеет единственное представление. */
    return (word & UINT32_C(0x7fffffff)) > UINT32_C(0x7f800000) ?
           UINT32_C(0xffff0000) : word;
}

/* 0x65EE–0x6695. Обычное сложение binary32 использует
 * выравнивание меньшей мантиссы и округление к ближайшему. */
uint32_t nm_avr_float_add(uint32_t left, uint32_t right)
{
    return canonical(bits(number(left)+number(right)));
}

/* 0x6696–0x669B. Вычитание меняет знак второго операнда. */
uint32_t nm_avr_float_subtract(uint32_t left, uint32_t right)
{
    return nm_avr_float_add(left,right ^ UINT32_C(0x80000000));
}

static unsigned exponent(uint32_t word)
{
    return (word >> 23) & 255u;
}

static int normalized_exponent(uint32_t word)
{
    unsigned exp = exponent(word);
    if (exp)
        return (int)exp;
    uint32_t fraction = word & UINT32_C(0x7fffff);
    int adjusted = 1;
    while (fraction < UINT32_C(0x800000)) {
        fraction <<= 1;
        --adjusted;
    }
    return adjusted;
}

/* 0x66B6–0x67A5. Произведение мантисс, знак XOR. */
uint32_t nm_avr_float_multiply(uint32_t left, uint32_t right)
{
    unsigned left_exp = exponent(left), right_exp = exponent(right);
    if (left_exp != 255 && right_exp != 255) {
        int combined = (int)(left_exp ? left_exp : 1) +
                       (int)(right_exp ? right_exp : 1) - 127;
        /* 0x66F4–0x66F6: раннее отсечение до округления. */
        if (combined < -22)
            return (left ^ right) & UINT32_C(0x80000000);
    }
    return canonical(bits(number(left)*number(right)));
}

/* 0x67A6–0x68B5. Деление нормализованных мантисс
 * с округлением результата, включая знаковые нули. */
uint32_t nm_avr_float_divide(uint32_t left, uint32_t right)
{
    const uint32_t sign = (left ^ right) & UINT32_C(0x80000000);
    const uint32_t magnitude = UINT32_C(0x7fffffff);
    if (exponent(left) != 255 && exponent(right) != 255 &&
        (left & magnitude) && (right & magnitude)) {
        int combined = normalized_exponent(left) - normalized_exponent(right) + 127;
        /* 0x6802–0x6810: предел проверяется до поправки
         * порядка по отношению мантисс. */
        if (combined >= 255)
            return sign | UINT32_C(0x7f800000);
        if (combined < -22)
            return sign;
    }
    return canonical(bits(number(left)/number(right)));
}
