#include "nm_original_fragments.h"
#include "nm_program_fields.h"
#include "nm_original_display_routes.h"
#include "nm_original_float.h"
#include "nm_original_library.h"
#include "nm_original_numeric.h"
#include <string.h>

static void store16(uint8_t *p, uint16_t word)
{
    p[0] = (uint8_t)word;
    p[1] = (uint8_t)(word >> 8);
}

/* 0x185A–0x1891. После снимка дисплея записываются адрес
 * таблицы callback, нижняя граница и верхняя граница редактора. */
uint16_t nm_avr_open_word_editor(const NMNumericDisplay *lcd, uint8_t *ram,
                                 NMNumericAlloc allocate, NMNumericSnapshot snapshot,
                                 bool single_digit)
{
    /* 0x1642–0x1657: при отказе выделения состояние LCD не меняется. */
    uint16_t address = allocate(lcd->context,22);
    if (!address)
        return 0;
    uint8_t *field = ram + address;
    store16(field,snapshot(lcd->context));
    store16(field+20,single_digit ? 0x0182 : 0x0180);
    if (!single_digit)
        lcd->write(lcd->context,1,0);
    for (uint8_t i = 2; i < 10; ++i)
        field[i] = 0;
    field[6] = single_digit ? 9 : 100;
    store16(field+18,0);
    return address;
}

/* 0x18B8–0x18D3. Вторая точка входа обновляет описание.
 * Обе передают управление выбранному обработчику отрисовки. */
static void draw_field(const NMNumericDisplay *lcd, const uint8_t *flash, uint8_t field[22])
{
    uint16_t table = field[20] | (uint16_t)field[21] << 8;
    uint16_t callback = (flash[table] | (uint16_t)flash[table+1] << 8) * 2u;
    if (callback == 0x16ea)
        nm_avr_editor_redraw_word(lcd,field,flash);
    else if (callback == 0x18d4)
        nm_avr_editor_redraw_digit(lcd,field);
}

void nm_avr_update_digit_title(const NMNumericDisplay *lcd, const uint8_t *flash,
                              uint8_t field[22], uint16_t title)
{
    store16(field+18,title);
    draw_field(lcd,flash,field);
}

/* 0x18A8–0x18C5. Данные и резервная копия заполняются
 * одним байтом с нулевым расширением независимо друг от друга. */
void nm_avr_update_digit_value(const NMNumericDisplay *lcd, const uint8_t *flash,
                              uint8_t field[22], uint8_t value)
{
    field[10] = field[14] = value;
    for (uint8_t i = 1; i < 4; ++i)
        field[10+i] = field[14+i] = 0;
    draw_field(lcd,flash,field);
}

/* 0x2658–0x26B5, 0x26F8–0x2705. Для 12 физических
 * выходов адрес задержки начинается с 0x15, для остальных с 0x2D.
 * Максимум 65535, минимум для физических выходов равен 1.
 * Флаг прерываний восстанавливается при выходе (0x26F0). */
bool nm_avr_output_delay_open(const NM8036 *m, const NMNumericDisplay *lcd,
                              const uint8_t *flash, uint8_t *ram, uint8_t selection,
                              NMNumericAlloc allocate, NMNumericSnapshot snapshot)
{
    uint8_t irq = m->irq_disable(m->context);
    uint16_t field_address = nm_avr_open_word_editor(lcd,ram,allocate,snapshot,false);
    *nm_ram(m,0x067d) = (uint8_t)field_address;
    *nm_ram(m,0x067e) = (uint8_t)(field_address >> 8);
    uint8_t *field = ram + field_address;
    bool physical = selection < 12;
    uint16_t address = (physical ? 0x15u : 0x2du) + 2u*(physical ? selection : selection - 12u);
    nm_avr_display_field_limits(field,physical,65535);
    store16(field+18,0x022f);
    uint16_t delay = nm_ee_read(m,address) | (uint16_t)nm_ee_read(m,address+1) << 8;
    store16(field+10,delay);
    store16(field+12,0);
    store16(field+14,delay);
    store16(field+16,0);
    draw_field(lcd,flash,field);
    m->irq_restore(m->context,irq);
    return true;
}

/* 0x1B5C–0x1B67. Нулевой байт означает '+', любой
 * ненулевой — '-'. Для sprintf знак занимает полное слово. */
uint32_t nm_avr_literal_argument(uint8_t negative, uint16_t number)
{
    return (negative ? '-' : '+') | (uint32_t)number << 16;
}

/* 0x39C8–0x39D9. До записи читается исходный байт для
 * сохранения старших флагов. Возвращается объединённый байт. */
uint8_t nm_avr_program_commit_control(const NM8036 *m, uint16_t option,
                                     uint8_t field, bool five_bits)
{
    uint8_t mask = five_bits ? 0x1f : 0x3f;
    uint8_t merged = (nm_ee_read(m,option) & (uint8_t)~mask) | (field & mask);
    return merged;
}

/* 0x39B4–0x39B9. Смещение +1 от адреса, переданного в r20:r21. */
bool nm_avr_program_write_selector(const NM8036 *m, uint16_t record, uint8_t value)
{
    nm_ee_write(m,record+1,value);
    return false;
}

/* 0x3A9A–0x3AA3. Младший байт шага умножается на индекс;
 * 16-битное переполнение соответствует длине адреса Flash. */
uint16_t nm_avr_program_indexed_text(uint16_t base, uint16_t stride, uint16_t index)
{
    return (uint16_t)(base + (uint32_t)(uint8_t)stride*index);
}

/* 0x3ADA–0x3AF3. После заголовка очищается вторая строка
 * и возвращается байт EEPROM +11 выбранной программы. */
uint8_t nm_avr_program_titled_field(const NM8036 *m, const NMNumericDisplay *lcd,
                                    const uint8_t *flash, uint8_t *ram,
                                    uint16_t format, uint16_t arguments, uint16_t display_number)
{
    nm_avr_status_flash_format(lcd,flash,ram,format,arguments);
    nm_avr_lcd_fill_spaces(lcd,0,15,1);
    lcd->position(lcd->context,0,1);
    store16(ram+arguments-2,display_number);
    return nm_avr_program_selected_byte(m,11);
}

/* 0x435A–0x4367 и 0x4862–0x486B. ROM уже прочитан в
 * 0x0681. Пустой слот не меняет слово температуры в SRAM. */
bool nm_avr_sample_registered(const NM8036 *m, const NMOneWire *bus, uint8_t slot)
{
    uint8_t rom[8], empty[8];
    for (unsigned i = 0; i < 8; ++i) {
        rom[i] = *nm_ram(m,0x0681+i);
        empty[i] = *nm_ram(m,0x0667+i);
    }
    if (!nm_avr_compare_rom(rom,empty))
        return false;
    int16_t sample;
    nm_avr_dallas_measure_selected(m,bus,&sample);
    *nm_ram(m,0x06c7u+2u*slot) = (uint8_t)sample;
    *nm_ram(m,0x06c8u+2u*slot) = (uint8_t)((uint16_t)sample >> 8);
    return true;
}

/* 0x4D7C–0x4D81. Десятки передаются отдельно, результат
 * вычисляется в байте и может переполниться. */
uint8_t nm_avr_effective_rtc_hour(uint8_t units, uint8_t decades)
{
    return (uint8_t)(units+10u*decades);
}

/* 0x4844–0x4847. Последняя арифметическая ветвь страницы
 * АЦП передаёт два слова binary32 общему умножителю. */
uint32_t nm_avr_adc_multiply_word(uint32_t left, uint32_t right)
{
    return nm_avr_float_multiply(left,right);
}

/* 0x3F3A–0x3F6D, 0x3FB2–0x3FB7, 0x4108–0x410D.
 * Таблица описывает отдельные точки входа чтения. next_address
 * — адрес, оставляемый для соседнего поля, если он используется. */
NMProgramByte nm_avr_program_read_byte(const NM8036 *m, uint16_t record, uint8_t entry)
{
    static const uint8_t offsets[] = {3,8,1,1,0,7};
    static const uint8_t masks[] = {0x80,0x3f,0xff,0x3f,0x3f,0x3f};
    static const uint8_t next[] = {3,8,1,1,6,5};
    /* Два последних входа меняют только младший байт следующего адреса. */
    NMProgramByte result = {nm_ee_read(m,record+offsets[entry]) & masks[entry],
                            (uint16_t)(entry < 4 ? record+next[entry] : (record & 0xff00u) | (uint8_t)(record+next[entry]))};
    return result;
}

/* 0x3EE2–0x3EED, 0x3F10–0x3F13. Для группы 0x20 и 0xC0
 * сохраняются биты исходного байта, а не результат сравнения 0/1. */
uint8_t nm_avr_program_test_flags(const NM8036 *m, uint16_t address, uint8_t mask)
{
    return nm_ee_read(m,address) & mask;
}

/* 0x54BC–0x54D5. Результат приёмника 1 означает готовый
 * кадр; таблица 0x0C42 разрешает командный байт в адрес. */
uint16_t nm_avr_uart_frame_target(const uint8_t *flash, const uint8_t frame[35], uint8_t received)
{
    return received == 1 ? nm_avr_switch_target(flash,0x0c42,1,frame[0]) : 0x5848;
}

/* 0x51A6–0x51B7. Сначала ограничивается номер ROM,
 * затем 0xFF выбирает выход из диалога. */
bool nm_avr_dallas_restart_selection(const NM8036 *m, uint8_t count, uint8_t key)
{
    if (*nm_ram(m,0x0680) >= count)
        *nm_ram(m,0x0680) = 0;
    return key == 0xff;
}

/* 0x502A–0x5037. Передача значения со знаком через
 * четырёхбайтовый аргумент исходного формата температуры. */
void nm_avr_dallas_print_temperature(const NMNumericDisplay *lcd, const uint8_t *flash,
                                      uint8_t *ram, uint16_t at, int16_t value)
{
    float converted = nm_avr_dallas_temperature_text(value);
    uint32_t bits;
    memcpy(&bits,&converted,sizeof bits);
    store16(ram+at,(uint16_t)bits);
    store16(ram+at+2,(uint16_t)(bits >> 16));
    nm_avr_status_flash_format(lcd,flash,ram,0x07dc,at);
}

/* 0x1EB0–0x1EBF. Перед восстановлением восьми глифов
 * передаётся команда установки нулевого адреса CGRAM. */
void nm_avr_lcd_restore_cgram(const NMNumericDisplay *lcd, const uint8_t saved[64])
{
    lcd->write(lcd->context,0x40,0);
    for (unsigned i = 0; i < 64; ++i)
        lcd->write(lcd->context,saved[i],1);
}

/* 0x2F76–0x2F87. Сторожевой байт 0xFF пропускает обработку
 * лишь при очищенном флаге повторной отрисовки. */
bool nm_avr_program_redraw_request(const NM8036 *m, uint8_t requested)
{
    return *nm_ram(m,0x0735) || requested != 0xff;
}

/* 0x3000–0x3011, 0x3ACC–0x3AD9. Напечатать заголовок,
 * затем передать текущий номер без смещения обработчику списка. */
void nm_avr_program_select_draw(const NM8036 *m, const NMNumericDisplay *lcd,
                                const uint8_t *flash, uint8_t *ram,
                                void (*draw_row)(void *, uint8_t))
{
    lcd->position(lcd->context,0,0);
    nm_avr_status_flash_format(lcd,flash,ram,0x0504,0);
    lcd->position(lcd->context,0,1);
    draw_row(lcd->context,*nm_ram(m,0x06b4));
}

/* 0x3132–0x313F. При переходе редактор открывает третью
 * карточку, печатает её заголовок в начале первой строки. */
void nm_avr_program_first_condition(const NM8036 *m, const NMNumericDisplay *lcd,
                                      const uint8_t *flash, uint8_t *ram)
{
    *nm_ram(m,0x06b6) = 3;
    lcd->position(lcd->context,0,0);
    nm_avr_status_flash_format(lcd,flash,ram,0x0567,0);
}

/* 0x4784–0x4791. Копия измерения остаётся в слове binary32,
 * а байт выбора извлекается из EEPROM +0x12. */
uint8_t nm_avr_adc_decoration(const NM8036 *m, uint16_t channel,
                              uint32_t measurement, uint32_t *saved)
{
    *saved = measurement;
    return nm_ee_read(m,(uint16_t)(0x12u+channel));
}

/* 0x483C–0x4847. В оригинале это три точки входа
 * в общие математические функции, у NaN оба сравнения ложны. */
bool nm_avr_adc_operand_compare(uint32_t left, uint32_t right, bool at_least)
{
    return at_least ? nm_avr_binary32_ge(left,right) : nm_avr_binary32_less(left,right);
}

/* 0x52D2–0x52D7. Пробный результат хранится отдельно от
 * таблицы фонового опроса, в двухбайтовом временном слове. */
uint8_t nm_avr_dallas_dialog_sample(const NM8036 *m, const NMOneWire *bus,
                                    volatile uint8_t value[2])
{
    return nm_dallas_poll_sample(m,bus,value);
}

/* 0x548E–0x5497. Закрытие шкалы восстанавливает снимок,
 * освобождает поле и сигнализирует диспетчеру об окончании. */
bool nm_avr_pwm_end_display(const NMNumericDisplay *lcd, uint8_t *ram,
                            uint16_t scale, NMNumericRestore restore)
{
    nm_avr_display_bar_close(lcd,ram,scale,restore);
    return true;
}

/* 0x53A2–0x53A9, 0x53BA–0x53CB, 0x5486–0x548D.
 * Шаг имеет знак, значение редактируется в 0x0745/0x0746,
 * а поле шкалы хранит расширенные промежуточные аргументы. */
uint8_t nm_avr_pwm_apply_word(const NM8036 *m, uint8_t *field, bool contrast, int16_t step)
{
    volatile uint8_t *setting = nm_ram(m,contrast ? 0x0746 : 0x0745);
    uint8_t current = *setting;
    nm_avr_display_byte_adjust(field,&current,step);
    *setting = current;
    return current;
}

/* 0x546C–0x5479. Нулевой байт клавиши не интерпретируется
 * как нажатие при отрисовке шкалы. */
uint16_t nm_avr_pwm_active_field(const NM8036 *m, uint8_t *key)
{
    *key = *nm_ram(m,0x0739);
    return *nm_ram(m,0x0733) | (uint16_t)*nm_ram(m,0x0734) << 8;
}

/* 0x3456–0x345F, 0x3516–0x352B. После перерисовки
 * снимается запрос обновления. При нулевой клавише вызывающий
 * редактор выбирает следующую страницу, при ненулевой остаётся. */
bool nm_avr_program_page_active(const NM8036 *m, uint8_t key, uint8_t page)
{
    *nm_ram(m,0x06b7) = 0;
    if (key)
        return true;
    *nm_ram(m,0x06b6) = page;
    return false;
}

/* 0x3AA4–0x3AB7 и 0x3AB8–0x3ACA. В одном случае
 * печать сопровождается проверкой полного кода клавиши 4.
 * В другом экран очищается и готовится аргумент номера программы. */
bool nm_avr_program_print_accept(const NMNumericDisplay *lcd, const uint8_t *flash,
                                  uint8_t *ram, uint16_t format, uint16_t argument, uint8_t key)
{
    nm_avr_status_flash_format(lcd,flash,ram,format,argument);
    return key == 4;
}

uint16_t nm_avr_program_header_begin(const NM8036 *m, const NMNumericDisplay *lcd,
                                      uint8_t word[2])
{
    lcd->write(lcd->context,1,0);
    lcd->position(lcd->context,0,0);
    uint16_t number = nm_avr_program_number(*nm_ram(m,0x06b4));
    store16(word,number);
    return number;
}
