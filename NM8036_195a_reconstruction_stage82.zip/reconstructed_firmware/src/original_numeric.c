#include "nm_original_numeric.h"
#include <string.h>

static uint32_t editor_word(const uint8_t *field)
{
    return (uint32_t)field[0] | (uint32_t)field[1] << 8 |
           (uint32_t)field[2] << 16 | (uint32_t)field[3] << 24;
}

static void set_editor_word(uint8_t *field, uint32_t value)
{
    for (uint8_t i = 0; i < 4; ++i)
        field[i] = (uint8_t)(value >> (8u*i));
}

/* 0x1892–0x18A6. r16:r17 адрес, r18/r19 младшие байты
 * границ. Старшие байты обеих границ очищаются. */
void nm_avr_editor_set_limits(uint8_t field[22], uint8_t lower, uint8_t upper)
{
    set_editor_word(field + 2, lower);
    set_editor_word(field + 6, upper);
}

/* 0x18EE–0x1988. Сравнения CP/CPC + BRGE знаковые.
 * r18 содержит клавишу. Результат сообщает вызывающему коду
 * о завершении и вызове отрисовки через таблицу 0x198A. */
NMNumericEditResult nm_avr_editor_adjust_word(uint8_t field[22], uint8_t key)
{
    const uint32_t sign = UINT32_C(0x80000000);
    uint32_t value = editor_word(field + 10);
    switch (key & 15u) {
    case 1:
        if ((value ^ sign) < (editor_word(field + 6) ^ sign))
            set_editor_word(field + 10, value + 1u);
        return (NMNumericEditResult){false, true};
    case 4: {
        uint32_t lower = editor_word(field + 2);
        if ((lower ^ sign) < (value ^ sign))
            set_editor_word(field + 10, value - 1u);
        return (NMNumericEditResult){false, true};
    }
    case 5:
        set_editor_word(field + 10, editor_word(field + 14));
        return (NMNumericEditResult){true, false};
    case 0:
    case 2:
    case 3:
        return (NMNumericEditResult){true, false};
    default:
        return (NMNumericEditResult){false, false};
    }
}

/* 0x1A0E–0x1A54. Выделение цифр и знаков из результата %9.2e.
 * Исходник вычитает ASCII '0' с переполнением байта. */
void nm_avr_scientific_digits(uint8_t field[20], const uint8_t text[9])
{
    static const uint8_t columns[] = {1, 3, 4, 7, 8};
    for (uint8_t i = 0; i < 5; ++i)
        field[4 + i] = (uint8_t)(text[columns[i]] - '0');
    field[2] = text[0] == '-';
    field[3] = text[6] == '-';
}

/* 0x1BB4–0x1BC7, 0x1BD0–0x1BDD. Таблицы Flash 0x01AD и 0x01B6.
 * Вход — позиция 0–8. Дробная точка и буква e пропускаются. */
uint8_t nm_avr_scientific_cursor(uint8_t cursor, bool next)
{
    static const uint8_t forward[] = {1,3,0,4,6,0,7,8,0};
    static const uint8_t back[] = {8,0,0,1,3,0,4,6,7};
    return next ? forward[cursor] : back[cursor];
}

/* 0x1D14–0x1D4F. Ограничение цифр после правки.
 * Сохраняется исходная граница 3.40e38. */
void nm_avr_scientific_limit(uint8_t field[20])
{
    if (field[7] != 3 || field[8] < 8)
        return;
    field[8] = 8;
    if (field[4] > 3 || (field[4] == 3 && field[5] >= 5)) {
        field[4] = 3;
        field[5] = 4;
    }
    if (field[4] == 3 && field[5] == 4)
        field[6] = 0;
}

/* 0x1A60–0x1AF5. Мантисса и порядок из SRAM. Десятичный
 * порядок складывается в байте r24, затем применяется по одному
 * множителю за раз. Порядок операций важен для округления. */
uint32_t nm_avr_scientific_value(const uint8_t field[20])
{
    uint16_t digits = 100u * field[4] + 10u * field[5] + field[6];
    float value = (float)digits / 100.0f;
    if (field[2])
        value *= -1.0f;
    uint8_t exponent = (uint8_t)(10u * field[7] + field[8]);
    while (exponent--)
        value = field[3] ? value / 10.0f : value * 10.0f;
    uint32_t bits;
    memcpy(&bits, &value, sizeof bits);
    return bits;
}

/* 0x6550–0x6568, с нормализацией в 0x64FA–0x654E.
 * На равном расстоянии T=1 округляет модуль вверх.
 * При T=0 выбирается чётная мантисса.
 * Отрицательный минимум конвертируется через модуль uint32_t. */
uint32_t nm_avr_int_to_binary32(uint32_t word, bool is_signed, bool sticky)
{
    const uint32_t sign = is_signed ? word & UINT32_C(0x80000000) : 0;
    uint32_t magnitude = sign ? 0u - word : word;
    if (!magnitude)
        return 0;
    uint8_t exponent = 0;
    for (uint32_t probe = magnitude; probe > 1; probe >>= 1)
        ++exponent;
    if (exponent > 23) {
        uint8_t shift = exponent - 23;
        uint32_t midpoint = UINT32_C(1) << (shift - 1u);
        uint32_t discarded = magnitude & ((midpoint << 1) - 1u);
        magnitude >>= shift;
        if (discarded > midpoint || (discarded == midpoint && (sticky || (magnitude & 1u))))
            ++magnitude;
    } else {
        magnitude <<= 23 - exponent;
    }
    return sign | (((uint32_t)(exponent + 126u) << 23) + magnitude);
}

/* 0x656A–0x659F. Обрезка к нулю. Для больших чисел и
 * экспоненты 255 положительный результат 0x7FFFFFFF,
 * отрицательный 0x80000000, включая NaN. */
uint32_t nm_avr_binary32_to_int(uint32_t word)
{
    uint8_t exponent = (uint8_t)(word >> 23);
    bool negative = (word >> 31) != 0;
    if (exponent < 127)
        return 0;
    if (exponent >= 158)
        return negative ? UINT32_C(0x80000000) : UINT32_C(0x7fffffff);
    uint32_t magnitude = ((word & UINT32_C(0x7fffff)) | UINT32_C(0x800000)) << 8;
    magnitude >>= 158u - exponent;
    return negative ? 0u - magnitude : magnitude;
}

/* 0x65A0–0x65ED, два входа для r16–r19 и r20–r23.
 * Сохраняем значимые флаги SREG: T=знак, C=NaN,
 * Z=±0, V=±Inf. N/S/H потребителям не передаются. */
uint8_t nm_avr_binary32_flags(uint32_t word)
{
    uint8_t flags = word >> 31 ? 0x40 : 0;
    uint32_t magnitude = word & UINT32_C(0x7fffffff);
    if (magnitude > UINT32_C(0x7f800000))
        return flags | 1u;
    if (magnitude == UINT32_C(0x7f800000))
        return flags | 8u;
    return magnitude ? flags : flags | 2u;
}

/* 0x68C0–0x6913. Знак нуля не влияет на сравнение.
 * NaN у любого операнда делает все три предиката ложными. */
bool nm_avr_binary32_equal(uint32_t left, uint32_t right)
{
    uint8_t left_flags = nm_avr_binary32_flags(left);
    uint8_t right_flags = nm_avr_binary32_flags(right);
    /* 0x68B6–0x68BB: при левом нуле классифицируется правый,
     * при NaN сравнение всегда очищает результат равенства. */
    if (left_flags & 2u)
        return (right_flags & 2u) != 0;
    return !((left_flags | right_flags) & 1u) && left == right;
}

bool nm_avr_binary32_less(uint32_t left, uint32_t right)
{
    if ((nm_avr_binary32_flags(left) | nm_avr_binary32_flags(right)) & 1u)
        return false;
    if (!((left | right) & UINT32_C(0x7fffffff)))
        return false;
    if ((left ^ right) >> 31)
        return (left >> 31) != 0;
    return left >> 31 ? left > right : left < right;
}

bool nm_avr_binary32_ge(uint32_t left, uint32_t right)
{
    if ((nm_avr_binary32_flags(left) | nm_avr_binary32_flags(right)) & 1u)
        return false;
    return !nm_avr_binary32_less(left, right);
}

/* 0x103A–0x1043. Адрес интервала в EEPROM получается
 * прибавлением 0x10 к 16-битному индексу. */
uint8_t nm_avr_display_interval_read(const NM8036 *m, uint16_t index)
{
    return nm_ee_read(m,(uint16_t)(0x10u + index));
}

/* 0x0FD8–0x1011. Правка байта EEPROM 0x10+index.
 * Стрелки сначала записывают результат 8-битной арифметики.
 * Второй проход возвращает его в диапазон 8–119 отдельной записью. */
void nm_avr_display_interval_key(const NM8036 *m, uint8_t index, uint8_t key)
{
    key &= 15u;
    uint16_t address = 0x10u + index;
    uint8_t value = nm_ee_read(m, address);
    if (key == 2 || key == 4) {
        --value;
        nm_ee_write(m, address, value);
    }
    if (key == 1 || key == 3) {
        ++value;
        nm_ee_write(m, address, value);
    }
    value = nm_ee_read(m, address);
    if (value >= 120)
        nm_ee_write(m, address, 8);
    else if (value < 8)
        nm_ee_write(m, address, 119);
}
