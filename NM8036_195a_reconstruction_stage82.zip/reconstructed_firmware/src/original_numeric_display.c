#include "nm_original_tail.h"
#include "nm_numeric_display.h"
#include "nm_original_decimal.h"
#include "nm_original_numeric.h"
#include "nm_stage14.h"
#include "nm_editors.h"
#include "nm_original_helpers.h"
#include <string.h>

static uint16_t text_address(const uint8_t *bytes)
{
    return bytes[0] | (uint16_t)bytes[1] << 8;
}

static void text(const NMNumericDisplay *lcd, const uint8_t *bytes)
{
    while (*bytes)
        lcd->write(lcd->context, *bytes++, 1);
}

static void decimal(const NMNumericDisplay *lcd, uint32_t value)
{
    uint8_t reverse[10];
    uint8_t count = 0;
    do {
        reverse[count++] = '0' + value % 10u;
        value /= 10u;
    } while (value);
    while (count)
        lcd->write(lcd->context, reverse[--count], 1);
}

static void title(const NMNumericDisplay *lcd, const uint8_t *flash, uint16_t address)
{
    lcd->position(lcd->context, address ? 0 : 1, 0);
    text(lcd, flash + (address ? address : 0x018a));
}

/* 0x16EA–0x1725. Значение r16–r19 читается из +10,
 * выводится как %ld по Flash 0x0186. Заголовок из +18. */
void nm_avr_editor_redraw_word(const NMNumericDisplay *lcd, const uint8_t field[22],
                               const uint8_t *flash)
{
    uint32_t value = (uint32_t)field[10] | (uint32_t)field[11] << 8 |
                     (uint32_t)field[12] << 16 | (uint32_t)field[13] << 24;
    lcd->write(lcd->context, 1, 0);
    lcd->position(lcd->context, 7, 1);
    if (value >> 31) {
        lcd->write(lcd->context, '-', 1);
        value = 0u - value;
    }
    decimal(lcd, value);
    title(lcd, flash, text_address(field + 18));
}

/* 0x18D4–0x18ED. Колонка и строка в +18/+19,
 * код курсора 0x0F и младший байт значения с прибавлением '0'. */
void nm_avr_editor_redraw_digit(const NMNumericDisplay *lcd, const uint8_t field[22])
{
    lcd->position(lcd->context, field[18], field[19]);
    lcd->write(lcd->context, 0x0f, 0);
    lcd->write(lcd->context, (uint8_t)(field[10] + '0'), 1);
    lcd->position(lcd->context, field[18], field[19]);
}

/* 0x1AFE–0x1B55. Вывод отдельных знаков и полей
 * %d.%d%de %d%d, возврат курсора в base+offset. */
void nm_avr_editor_redraw_scientific(const NMNumericDisplay *lcd, const uint8_t field[20],
                                     const uint8_t *flash)
{
    uint8_t base = field[10];
    nm_avr_tail_scientific_position(lcd,field+10);
    nm_avr_tail_write_character(lcd,field[2] ? '-' : '+');
    decimal(lcd, field[4]);
    lcd->write(lcd->context, '.', 1);
    decimal(lcd, field[5]);
    decimal(lcd, field[6]);
    lcd->write(lcd->context, 'e', 1);
    lcd->write(lcd->context, ' ', 1);
    decimal(lcd, field[7]);
    decimal(lcd, field[8]);
    lcd->position(lcd->context, (uint8_t)(base + 6u), 1);
    nm_avr_tail_write_character(lcd,field[3] ? '-' : '+');
    title(lcd, flash, text_address(field + 15));
    lcd->position(lcd->context, (uint8_t)(base + field[9]), 1);
}

/* 0x47D4–0x47DB. Номер канала в r8:r9, строка — его
 * младший байт, передаваемый в 0x52EA. Печатаемый номер с единицы. */
uint16_t nm_avr_adc_position(const NMNumericDisplay *lcd, uint16_t channel)
{
    lcd->position(lcd->context, 0, (uint8_t)channel);
    return (uint16_t)(channel + 1u);
}

/* 0x4820–0x4829 и 0x4854–0x4861. r26:r27 — номер
 * канала, r4–r7 — binary32. Передача аргументов в формате
 * 0x087D. Управление главной страницей после вывода остаётся
 * за вызывающим кодом (переход 0x43D2). */
void nm_avr_adc_scientific_draw(uint16_t channel_number, uint32_t binary32,
                                NMAdcFormat format, void *context)
{
    format(context, 0x087d, channel_number, binary32);
}

/* 0x6D88–0x6DAB. Оригинальный 0x4168 передаёт один байт
 * через LCD и возвращает тот же байт r24, сохранённый в стеке.
 * Поэтому счётчик callback остаётся прежним. */
static uint16_t lcd_format_emit(void *context, uint16_t state, uint8_t byte)
{
    const NMNumericDisplay *lcd = context;
    lcd->write(lcd->context, byte, 1);
    return state;
}

/* 0x6ABA–0x6AD9. Формат из SRAM, указатель аргументов
 * из Y исходного ABI. Начальное состояние LCD равно 1. */
void nm_avr_lcd_format_ram(const NMNumericDisplay *lcd, const uint8_t *sram,
                           const uint8_t *format, uint16_t argument)
{
    (void)nm_avr_format_ram(sram, format, &argument, 1, lcd_format_emit, (void *)lcd);
}

/* 0x1848–0x1859. После выделения буфера и снимка LCD
 * установить границы 0–9 и адрес формата цифры во Flash.
 * Снимок в байтах 0–1 и рабочие байты 10–17 сохраняются. */
void nm_avr_scientific_init_digit(uint8_t child[22])
{
    for (uint8_t i = 2; i < 10; ++i)
        child[i] = 0;
    child[6] = 9;
    child[18] = child[19] = 0;
    child[20] = 0x82;
    child[21] = 0x01;
}

/* 0x1CA4–0x1CC5. Дочернее поле уже выделено. Сначала
 * отрисовка с новой позицией, затем с цифрой и её резервной копией. */
void nm_avr_scientific_open_digit(const NMNumericDisplay *lcd, uint8_t parent[20],
                                   uint8_t child[22], uint8_t value)
{
    child[18] = (uint8_t)(parent[10] + parent[9]);
    child[19] = parent[11];
    nm_avr_editor_redraw_digit(lcd, child);
    for (uint8_t i = 10; i < 18; ++i)
        child[i] = 0;
    child[10] = child[14] = value;
    nm_avr_editor_redraw_digit(lcd, child);
    parent[14] = 1;
}

/* 0x1C30–0x1CA3: сначала родительская отрисовка по callback,
 * затем открытие поля для курсора вне двух позиций знака.
 * 0x1642 и 0x1846 выделяют 22 байта и сохраняют снимок LCD.
 * allocate соответствует 0x6A7C и возвращает только ненулевой адрес,
 * snapshot соответствует 0x1F26.
 * Указатель в родителе хранится как байтовый адрес AVR. */
bool nm_avr_scientific_begin_digit(const NMNumericDisplay *lcd, uint8_t *sram,
                                  uint8_t parent[20], const uint8_t *flash, uint8_t value,
                                  NMNumericAlloc allocate, NMNumericSnapshot snapshot)
{
    nm_avr_editor_redraw_scientific(lcd, parent, flash);
    if (parent[9] == 0 || parent[9] == 6)
        return false;

    uint16_t address = allocate(lcd->context, 22);
    parent[12] = (uint8_t)address;
    parent[13] = (uint8_t)(address >> 8);
    uint8_t *child = sram + address;
    uint16_t saved = snapshot(lcd->context);
    child[0] = (uint8_t)saved;
    child[1] = (uint8_t)(saved >> 8);
    nm_avr_scientific_init_digit(child);
    nm_avr_digit_limits(parent, child);
    nm_avr_scientific_open_digit(lcd, parent, child, value);
    return true;
}

/* 0x1D50–0x1D57. Вернуть снимок LCD, освободить снимок
 * и поле, установить режим 0x0E и заново нарисовать родителя.
 * restore воспроизводит 0x1F4E, включая освобождение снимка.
 * Сохранённый адрес поля в родителе оригинал не обнуляет. */
void nm_avr_scientific_end_digit(const NMNumericDisplay *lcd, uint8_t *sram,
                                const uint8_t parent[20], const uint8_t *flash,
                                NMNumericRestore restore)
{
    uint16_t address = nm_avr_tail_child(parent);
    if (address) {
        restore(lcd->context, text_address(sram + address));
        nm_avr_heap_free(sram, address);
    }
    lcd->write(lcd->context, 0x0e, 0);
    nm_avr_editor_redraw_scientific(lcd, parent, flash);
}

/* 0x1CC6–0x1CD3. Если дочернее поле не активно или
 * только открыто, код 0 или 5 завершает родительский редактор.
 * Остальные клавиши оставляют его открытым. */
uint8_t nm_avr_scientific_idle_result(uint8_t key)
{
    key &= 0x0f;
    return key == 0 || key == 5;
}

/* 0x4894–0x489F. Увеличить индекс в SRAM (смещение 53
 * относительно базы r10). Флаг сравнения сообщает вызывающему
 * коду о достижении границы. Сам индекс здесь не сбрасывается. */
bool nm_avr_adc_next_channel(uint8_t *channel)
{
    ++*channel;
    return *channel < 7;
}

/* 0x4828–0x4829 и 0x43D2–0x43E5. После вывода
 * увеличивается 16-битный индекс. Пока он меньше 2,
 * выполняется отрисовка следующего канала (0x4732). */
bool nm_avr_adc_advance_page(uint16_t *channel)
{
    ++*channel;
    return *channel < 2u;
}

/* 0x482A–0x482D. Вызов 0x49A4 с нулевым аргументом
 * обслуживает уже открытое меню. Далее действует 0x482E. */
bool nm_avr_adc_step_settings(volatile uint8_t *active, NMAdcSettingsStep step, void *context)
{
    uint8_t result = step(context,0);
    return nm_avr_adc_finish_menu(active,result);
}

/* 0x482E–0x483B. Только результат 1 сбрасывает флаг
 * меню в 0x073A до общего продолжения диспетчера 0x441E. */
bool nm_avr_adc_finish_menu(volatile uint8_t *active, uint8_t result)
{
    if (result == 1)
        *active = 0;
    return *active != 0;
}

/* 0x1CDA–0x1D13, чтение дочернего байта через 0x1D70.
 * Вызывается после завершения дочернего редактора, в том числе
 * после возврата его резервной цифры. Ограничение полей выполняется
 * следующим участком 0x1D14. */
void nm_avr_scientific_commit_digit(uint8_t parent[20], const uint8_t child[22])
{
    parent[14] = 0;
    switch (parent[9]) {
    case 1: parent[4] = child[10]; break;
    case 3: parent[5] = child[10]; break;
    case 4: parent[6] = child[10]; break;
    case 7: parent[7] = child[10]; break;
    case 8: parent[8] = child[10]; break;
    }
}

/* 0x1CD4–0x1D4F. Передать клавишу активному редактору цифры.
 * Пока он открыт, родительские цифры остаются прежними.
 * MENU восстанавливает резервное значение в 0x193A, после
 * чего родитель копирует эту цифру как при обычном выходе. */
bool nm_avr_scientific_step_digit(const NMNumericDisplay *lcd, uint8_t parent[20],
                                 uint8_t child[22], uint8_t key)
{
    NMNumericEditResult result = nm_avr_editor_adjust_word(child, key);
    if (result.redraw)
        nm_avr_editor_redraw_digit(lcd, child);
    if (result.accepted) {
        nm_avr_scientific_commit_digit(parent, child);
        nm_avr_scientific_limit(parent);
    }
    return result.accepted;
}

/* 0x1B9E–0x1BDE. Активная цифра получает клавишу первой.
 * На родительском экране 2/3 перемещают курсор, 1/4 меняют
 * знак либо открывают поле. Возврат 1 закрывает родителя. */
uint8_t nm_avr_scientific_step(const NMNumericDisplay *lcd, uint8_t *sram,
                              uint8_t parent[20], const uint8_t *flash,
                              uint8_t key, uint8_t digit,
                              NMNumericAlloc allocate, NMNumericSnapshot snapshot,
                              NMNumericRestore restore)
{
    key &= 0x0f;
    if (parent[14]) {
        uint8_t *child = sram + text_address(parent + 12);
        if (nm_avr_scientific_step_digit(lcd, parent, child, key))
            nm_avr_scientific_end_digit(lcd, sram, parent, flash, restore);
        return 0;
    }

    switch (key) {
    case 2:
    case 3:
        parent[9] = nm_avr_scientific_cursor(parent[9], key == 3);
        nm_avr_editor_redraw_scientific(lcd, parent, flash);
        lcd->write(lcd->context, 0x0e, 0);
        return 0;
    case 1:
    case 4:
        if (nm_avr_digit_selection(parent, key, &digit))
            lcd->write(lcd->context, 0x0f, 0);
        if (nm_avr_scientific_begin_digit(lcd, sram, parent, flash, digit, allocate, snapshot)) {
            /* 0x1CBA–0x1CBE: первая клавиша действует сразу,
             * после сохранения исходной цифры в резервном поле. */
            uint8_t *child = sram + text_address(parent + 12);
            nm_avr_scientific_step_digit(lcd, parent, child, key);
        }
        return 0;
    default:
        return nm_avr_scientific_idle_result(key);
    }
}

/* 0x1678–0x1681, 0x1998–0x19C9 и 0x19DE–0x19E9.
 * Родитель занимает 19 байт. Снимок принадлежит редактору,
 * а 0x0184 выбирает штатную отрисовку научной записи. */
static void scientific_init(const NMNumericDisplay *lcd, uint8_t parent[20], uint16_t saved)
{
    parent[0] = (uint8_t)saved;
    parent[1] = (uint8_t)(saved >> 8);
    parent[17] = 0x84;
    parent[18] = 1;
    lcd->write(lcd->context, 0x0e, 0);
    lcd->write(lcd->context, 0x01, 0);
    parent[10] = 3;
    parent[11] = 1;
    parent[4] = 1;
    for (uint8_t i = 5; i <= 9; ++i)
        parent[i] = 0;
    parent[14] = parent[15] = parent[16] = 0;
}

/* 0x10BE–0x10F3. Вход в калибровку по ненулевому r16.
 * Формат %9.2e сохраняет зависимость от AVR T. */
uint16_t nm_avr_calibration_open(const NM8036 *m, const NMNumericDisplay *lcd,
                                 uint8_t *sram, const uint8_t *flash, uint8_t index,
                                 bool sticky, NMNumericAlloc allocate, NMNumericSnapshot snapshot)
{
    uint16_t address = allocate(lcd->context, 19);
    uint8_t *parent = sram + address;
    scientific_init(lcd, parent, snapshot(lcd->context));
    nm_avr_calibration_bind(m, address);
    /* 0x1AF6–0x1AFD. Заголовок «Ввод значения:» во Flash. */
    parent[15] = 0x5e;
    parent[16] = 1;
    uint8_t digits[10];
    nm_avr_format_e92(digits, nm_avr_calibration_read(m, index), sticky);
    nm_avr_scientific_digits(parent, digits);
    nm_avr_editor_redraw_scientific(lcd, parent, flash);
    m->irq_restore(m->context, 0x80u);
    return address;
}

/* 0x10F4–0x111F. Результат родителя 1 сохраняет коэффициент,
 * затем 0x1682 и 0x19CA закрывают экран и освобождают память.
 * Адрес 0x067D остаётся до следующего открытия, как в оригинале. */
bool nm_avr_calibration_step(const NM8036 *m, const NMNumericDisplay *lcd,
                             uint8_t *sram, const uint8_t *flash, uint8_t index, uint8_t key,
                             NMNumericAlloc allocate, NMNumericSnapshot snapshot, NMNumericRestore restore)
{
    uint16_t address = *nm_ram(m, 0x067d) | ((uint16_t)*nm_ram(m, 0x067e) << 8);
    uint8_t *parent = sram + address;
    uint8_t result = nm_avr_scientific_step(lcd, sram, parent, flash, key,
                                              (uint8_t)(index * 4u), allocate, snapshot, restore);
    if (!nm_avr_calibration_finish(m, index, result, parent))
        return false;

    parent[17] = 0x84;
    parent[18] = 1;
    lcd->write(lcd->context, 0x0c, 0);
    restore(lcd->context, text_address(parent));
    nm_avr_heap_free(sram, address);
    return true;
}

/* 0x4848–0x4853 и 0x1EA4–0x1EAF. Обновить всю CGRAM,
 * затем опубликовать готовность экрана в SRAM 0x073F. */
void nm_avr_adc_load_glyphs(const NMNumericDisplay *lcd, const uint8_t glyphs[64],
                            volatile uint8_t *ready)
{
    lcd->write(lcd->context, 0x40, 0);
    for (uint8_t i = 0; i < 64; ++i)
        lcd->write(lcd->context, glyphs[i], 1);
    *ready = 1;
}

/* 0x1032–0x1039 и 0x48A0–0x48A7. EEPROM-адрес — 16-битная сумма двух
 * аргументов. 0x631C читает четыре байта младшим вперёд. */
uint32_t nm_avr_adc_read_operand(const NM8036 *m, uint16_t base, uint16_t offset)
{
    uint16_t address = (uint16_t)(base + offset);
    uint32_t word = 0;
    for (uint8_t i = 0; i < 4; ++i)
        word |= (uint32_t)nm_ee_read(m, (uint16_t)(address + i)) << (8u * i);
    return word;
}

static void store_word(uint8_t *p, uint32_t value)
{
    for (uint8_t i = 0; i < 4; ++i)
        p[i] = (uint8_t)(value >> (8u * i));
}

static uint32_t load_word(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

/* 0x165A–0x165F, 0x169E–0x16B1. Создать 22-байтовое поле,
 * сохранить LCD и выбрать отрисовку целого по таблице 0x0180. */
static void unit_init(const NMNumericDisplay *lcd, uint8_t *field, uint16_t saved)
{
    field[0] = (uint8_t)saved;
    field[1] = (uint8_t)(saved >> 8);
    field[20] = 0x80;
    field[21] = 1;
    lcd->write(lcd->context, 1, 0);
    nm_avr_editor_set_limits(field, 0, 100);
    field[18] = field[19] = 0;
}

/* 0x1120–0x1167. Сначала показать исходное значение EEPROM
 * без усечения, затем ограничить следующие правки диапазоном 0–6. */
void nm_avr_unit_open(const NM8036 *m, const NMNumericDisplay *lcd,
                      uint8_t *sram, const uint8_t *flash, uint8_t index,
                      NMNumericAlloc allocate, NMNumericSnapshot snapshot)
{
    uint16_t address = allocate(lcd->context, 22);
    uint8_t *field = sram + address;
    unit_init(lcd, field, snapshot(lcd->context));
    nm_avr_calibration_bind(m, address);
    field[18] = 0x6f;
    field[19] = 1;
    uint8_t value = nm_ee_read(m, 0x12u + index);
    store_word(field+10, value);
    store_word(field+14, value);
    nm_avr_editor_redraw_word(lcd, field, flash);
    m->irq_restore(m->context, 0x80u);
    nm_avr_editor_set_limits(field, 0, 6);
}

/* 0x172A–0x17FD. Ускоренный шаг сравнивается строго с границей,
 * одиночный может достичь её. Повтор MENU 0x85 лишь перерисовывает. */
static bool unit_edit(const NMNumericDisplay *lcd, uint8_t *field,
                      const uint8_t *flash, uint8_t key, uint8_t maximum)
{
    uint32_t value = load_word(field+10);
    if (key == 5) {
        store_word(field+10, load_word(field+14));
        return true;
    }
    if ((key & 15u) == 0)
        return true;

    uint32_t next = value;
    switch (key) {
    case 1: if (value < maximum) next = value + 1; break;
    case 4: if (value > 0) next = value - 1; break;
    case 2: if (value > 100) next = value - 100; break;
    /* Для верхних границ 6 и 30 шаги +100, +1000 и −1000
     * не проходят проверку. В EEPROM может лежать байт выше границы. */
    case 0x81: if (value + 10u < maximum) next = value + 10; break;
    case 0x84: if (value > 10) next = value - 10; break;
    }
    store_word(field+10, next);
    if (key != 0xff)
        nm_avr_editor_redraw_word(lcd, field, flash);
    return false;
}

/* 0x1168–0x118D. MENU сохраняет резервную цифру, ENTER —
 * текущее значение. Снимок восстанавливается после записи. */
bool nm_avr_unit_step(const NM8036 *m, const NMNumericDisplay *lcd,
                      uint8_t *sram, const uint8_t *flash, uint8_t index, uint8_t key,
                      NMNumericRestore restore)
{
    uint16_t address = *nm_ram(m, 0x067d) | ((uint16_t)*nm_ram(m, 0x067e) << 8);
    uint8_t *field = sram + address;
    if (!unit_edit(lcd, field, flash, key, 6))
        return false;
    uint8_t flags = m->irq_disable(m->context);
    nm_avr_calibration_unit_commit(m, index, field[10]);
    m->irq_restore(m->context, flags | 0x80u);
    restore(lcd->context, text_address(field));
    nm_avr_heap_free(sram, address);
    return true;
}

/* 0x1E68–0x1E85. Конечная колонка включена. После
 * колонки 255 исходный восьмибитный счётчик оборачивается. */
void nm_avr_lcd_fill_spaces(const NMNumericDisplay *lcd, uint8_t first, uint8_t last, uint8_t row)
{
    lcd->position(lcd->context, first, row);
    while (first <= last) {
        lcd->write(lcd->context, ' ', 1);
        ++first;
    }
}

/* 0x1078–0x107F. Код клавиши без флага автоповтора. */
uint8_t nm_avr_calibration_key(const NM8036 *m)
{
    return *nm_ram(m, 0x0739) & 0x0f;
}

/* 0x1044–0x104B и 0x48E6–0x48EF. Байтовое смещение
 * двухбайтового отсчёта. */
uint16_t nm_avr_adc_word_offset(uint16_t index)
{
    return (uint16_t)(index * 2u);
}

/* 0x48FE–0x490F. Нечётный элемент начинается с колонки 8,
 * номер строки берётся из младшего байта индекса, сдвинутого вправо. */
void nm_avr_adc_compact_position(const NMNumericDisplay *lcd, uint16_t index)
{
    lcd->position(lcd->context, (index & 1u) ? 8 : 0, (uint8_t)(index >> 1));
}

/* 0x4DB2–0x4DC9. Десятки дня используют только биты 4–5,
 * младшая тетрада сохраняется даже у некорректной даты. */
uint16_t nm_avr_rtc_display_day(uint8_t bcd)
{
    return 10u * ((bcd >> 4) & 3u) + (bcd & 15u);
}

static uint8_t calibration_item(const uint8_t menu[8])
{
    return (uint8_t)(menu[6] + (menu[7] & 3u));
}

/* 0x0EB2–0x0ED3, 0x10B2–0x10BD. Номер пункта состоит
 * из базы прокрутки и двух младших битов строки меню (0x2262).
 * Вычитание и сравнение в оригинале выполняются по байтам. */
NMCalibrationRoute nm_avr_calibration_route(const uint8_t menu[8])
{
    uint8_t item = calibration_item(menu);
    if (item < 3)
        return NM_CALIBRATION_PREVIEW;
    if (item < 7)
        return NM_CALIBRATION_COEFFICIENT;
    if (item < 9)
        return NM_CALIBRATION_UNIT;
    if (item < 11)
        return NM_CALIBRATION_OFFSET;
    return NM_CALIBRATION_REDRAW;
}

/* 0x0F9C–0x0FB7. Активное поле получает полный код клавиши.
 * true выбирает общий возврат 0x0F92, false — отрисовку 0x0E9A.
 * Предпросмотр и интервал обслуживаются отдельными ветвями. */
bool nm_avr_calibration_menu_step(const NM8036 *m, const NMNumericDisplay *lcd,
                                  uint8_t *sram, const uint8_t *flash, const uint8_t menu[8],
                                  NMNumericAlloc allocate, NMNumericSnapshot snapshot,
                                  NMNumericRestore restore)
{
    uint8_t item = calibration_item(menu);
    uint8_t key = *nm_ram(m, 0x0739);
    if (item >= 3 && item < 7)
        return nm_avr_calibration_step(m,lcd,sram,flash,item-3,key,allocate,snapshot,restore);
    if (item >= 7 && item < 9)
        return nm_avr_unit_step(m,lcd,sram,flash,item-7,key,restore);
    return false;
}

/* 0x0FB8–0x0FD7, 0x1012–0x1031. При стрелке изменить
 * интервал и нормализовать EEPROM. Затем вывести сырой байт
 * из 7+номер_пункта в колонку 7 второй строки. */
bool nm_avr_calibration_interval_step(const NM8036 *m, const NMNumericDisplay *lcd,
                                      const uint8_t menu[8])
{
    uint8_t key = nm_avr_calibration_key(m);
    uint8_t item = calibration_item(menu);
    if (key >= 1 && key <= 4)
        nm_avr_display_interval_key(m,(uint8_t)(item-9),key);
    lcd->position(lcd->context,7,1);
    lcd->write(lcd->context,nm_ee_read(m,7u+item),1);
    /* 0x1030 входит после CPI: проверяется Z от ANDI клавиши. */
    return nm_avr_calibration_key(m) == 0;
}

/* 0x0E7A–0x0E91 и 0x10A6–0x10B1. Снять флаг просмотра
 * перед открытием поля. Нумерация коэффициентов начинается
 * с пункта 3, а обозначений каналов — с пункта 7. */
void nm_avr_calibration_menu_open_field(const NM8036 *m, const NMNumericDisplay *lcd,
                                         uint8_t *sram, const uint8_t *flash, uint8_t menu[8],
                                         bool sticky, NMNumericAlloc allocate, NMNumericSnapshot snapshot)
{
    uint8_t item = calibration_item(menu);
    if (item >= 3 && item < 7) {
        menu[2] = 0;
        nm_avr_calibration_open(m,lcd,sram,flash,item-3,sticky,allocate,snapshot);
    } else if (item >= 7 && item < 9) {
        menu[2] = 0;
        nm_avr_unit_open(m,lcd,sram,flash,item-7,allocate,snapshot);
    }
}

/* 0x0F92–0x0F9B. Вернуться к списку с установленным флагом.
 * 0x22D2 сохраняет флаг, 0x2282 выводит две строки Flash. */
static void calibration_list_draw(const NMNumericDisplay *lcd, const uint8_t *flash,
                                  const uint8_t menu[8])
{
    uint16_t base = text_address(menu+3);
    lcd->write(lcd->context,1,0);
    for (uint8_t row = 0; row < 2; ++row) {
        lcd->position(lcd->context,0,row);
        lcd->write(lcd->context,row == (menu[7] & 3u) ? 0 : ' ',1);
        uint16_t address = (uint16_t)(base + ((uint16_t)menu[6] + row)*17u);
        text(lcd,flash+address);
    }
}

void nm_avr_calibration_menu_resume(const NMNumericDisplay *lcd, const uint8_t *flash,
                                      uint8_t menu[8])
{
    menu[2] = 1;
    calibration_list_draw(lcd,flash,menu);
}

/* 0x0E92–0x0E99, 0x1098–0x10A5. Интервал имеет
 * собственный заголовок, выводимый после очистки экрана. */
void nm_avr_calibration_interval_open(const NMNumericDisplay *lcd, const uint8_t *flash,
                                     uint8_t menu[8])
{
    lcd->write(lcd->context,1,0);
    menu[2] = 0;
    lcd->position(lcd->context,0,0);
    text(lcd,flash+0x0058);
}

/* 0x0E16–0x0E3B, 0x217C и 0x21EA. Восьмибайтовый
 * объект списка и снимок хранятся в исходной арене SRAM. */
static void numeric_menu_open(const NM8036 *m, const NMNumericDisplay *lcd,
                              uint8_t *sram, const uint8_t *flash, uint16_t slot,
                              uint16_t title_table, uint8_t rows,
                              NMNumericAlloc allocate, NMNumericSnapshot snapshot)
{
    uint16_t address = allocate(lcd->context,8);
    uint8_t *menu = sram + address;
    uint16_t saved = snapshot(lcd->context);
    menu[0] = (uint8_t)saved;
    menu[1] = (uint8_t)(saved >> 8);
    lcd->write(lcd->context,1,0);
    for (uint8_t glyph = 0; glyph < 3; ++glyph) {
        lcd->write(lcd->context,(uint8_t)(0x40 + glyph*8u),0);
        for (uint8_t row = 0; row < 8; ++row)
            lcd->write(lcd->context,flash[0x0217 + glyph*8u + row],1);
    }
    menu[6] = 0;
    menu[7] &= 0xfc;
    menu[2] = 1;
    *nm_ram(m,slot) = (uint8_t)address;
    *nm_ram(m,slot+1) = (uint8_t)(address >> 8);
    menu[3] = (uint8_t)title_table;
    menu[4] = (uint8_t)(title_table >> 8);
    menu[5] = rows;
    calibration_list_draw(lcd,flash,menu);
}

void nm_avr_calibration_menu_open(const NM8036 *m, const NMNumericDisplay *lcd,
                                   uint8_t *sram, const uint8_t *flash,
                                   NMNumericAlloc allocate, NMNumericSnapshot snapshot)
{
    numeric_menu_open(m,lcd,sram,flash,0x067b,0x00a3,11,allocate,snapshot);
}

/* 0x0E46–0x0E59 и 0x0E9E–0x0EB1. Стрелки учитывают
 * автоповтор по младшей тетраде. MENU и его повтор
 * освобождают снимок и сам список, оставляя адрес в 0x067B. */
bool nm_avr_calibration_menu_navigate(const NMNumericDisplay *lcd, uint8_t *sram,
                                       const uint8_t *flash, uint8_t menu[8],
                                       uint8_t key, NMNumericRestore restore)
{
    if (key == 5 || key == 0x85) {
        restore(lcd->context,text_address(menu));
        nm_avr_heap_free(sram,(uint16_t)(menu - sram));
        return true;
    }

    uint8_t row = menu[7] & 3u;
    switch (key & 0x0f) {
    case 1:
        if (row)
            menu[7] = (menu[7] & 0xfcu) | (row - 1u);
        else if (menu[6])
            --menu[6];
        break;
    case 4:
        if (!row)
            menu[7] |= 1u;
        else if ((int16_t)menu[6] < (int16_t)menu[5]-2)
            ++menu[6];
        break;
    default:
        return false;
    }
    calibration_list_draw(lcd,flash,menu);
    return false;
}

/* 0x0E3C–0x0EB1. Флаг +2 отличает список от активного
 * поля. Предпросмотр вызывается отдельно по маршруту 0x0ED4.
 * Возврат true означает выход из всего меню. */
bool nm_avr_calibration_menu_update(const NM8036 *m, const NMNumericDisplay *lcd,
                                     uint8_t *sram, const uint8_t *flash, bool sticky,
                                     NMNumericAlloc allocate, NMNumericSnapshot snapshot,
                                     NMNumericRestore restore)
{
    uint16_t address = *nm_ram(m,0x067b) | ((uint16_t)*nm_ram(m,0x067c) << 8);
    uint8_t *menu = sram + address;
    NMCalibrationRoute route = nm_avr_calibration_route(menu);
    if (menu[2]) {
        uint8_t key = *nm_ram(m,0x0739);
        if (key & 0x0f)
            return nm_avr_calibration_menu_navigate(lcd,sram,flash,menu,key,restore);

        switch (route) {
        case NM_CALIBRATION_PREVIEW: /* 0x0E76, 0x1098 */
            lcd->write(lcd->context,1,0);
            menu[2] = 0;
            lcd->position(lcd->context,0,0);
            break;
        case NM_CALIBRATION_COEFFICIENT:
        case NM_CALIBRATION_UNIT:
            nm_avr_calibration_menu_open_field(m,lcd,sram,flash,menu,sticky,allocate,snapshot);
            break;
        case NM_CALIBRATION_OFFSET:
            nm_avr_calibration_interval_open(lcd,flash,menu);
            break;
        case NM_CALIBRATION_REDRAW:
            break;
        }
        return false;
    }

    bool resume = false;
    switch (route) {
    case NM_CALIBRATION_PREVIEW:
        resume = nm_avr_adc_preview_sample(m,lcd,flash,calibration_item(menu));
        break;
    case NM_CALIBRATION_COEFFICIENT:
    case NM_CALIBRATION_UNIT:
        resume = nm_avr_calibration_menu_step(m,lcd,sram,flash,menu,allocate,snapshot,restore);
        break;
    case NM_CALIBRATION_OFFSET:
        resume = nm_avr_calibration_interval_step(m,lcd,menu);
        break;
    case NM_CALIBRATION_REDRAW:
        break;
    }
    if (resume)
        nm_avr_calibration_menu_resume(lcd,flash,menu);
    return false;
}

/* 0x0ED4–0x0F09 и 0x0F74–0x0F91. Сырые отсчёты двух
 * каналов лежат в 0x0677 и 0x0679. Формат Flash 0x0068
 * читает номер канала и исходное 16-битное слово как %d. */
/* 0x0F0A–0x0F27. Вольты: беззнаковый отсчёт умножается
 * на 5 и на 2^-10. Формат 0x007C принимает binary32. */
bool nm_avr_adc_preview_sample(const NM8036 *m, const NMNumericDisplay *lcd,
                                const uint8_t *flash, uint8_t mode)
{
    const uint16_t formats[] = {0x0068,0x007c,0x0091};
    for (uint8_t row = 0; row < 2; ++row) {
        volatile uint8_t *sample = nm_ram(m,0x0677u + nm_avr_adc_word_offset(row));
        uint8_t arguments[6] = {row+1u,0,sample[0],sample[1],0,0};
        if (mode) {
            /* 0x106A–0x1077. Преобразование 16-битного
             * отсчёта без знака без потери значащих битов. */
            float raw = (float)text_address(arguments+2);
            float value;
            if (mode == 1) {
                value = (raw * 5.0f) * 0x1p-10f;
            } else {
                /* 0x0F28–0x0F73: нижний и верхний пределы
                 * канала лежат по 8*row и 8*row+4 в EEPROM.
                 * Оригинал переводит сырое слово без знака. */
                uint32_t low_word = nm_avr_adc_read_operand(m,8u*row,0);
                uint32_t high_word = nm_avr_adc_read_operand(m,8u*row,4);
                float low, high;
                memcpy(&low,&low_word,sizeof low);
                memcpy(&high,&high_word,sizeof high);
                /* 0x1050–0x105B. Порядок умножений исходного AVR. */
                value = low + ((high - low) * 0x1p-10f) * raw;
            }
            uint32_t word;
            memcpy(&word,&value,sizeof word);
            store_word(arguments+2,word);
        }
        uint16_t argument = 0, count;
        lcd->position(lcd->context,0,row);
        /* 0x104C–0x104F и 0x105C–0x1069. Формат и
         * аргументы передаются в исходном порядке. */
        nm_avr_flash_format(flash,flash+formats[mode],arguments,&argument,0,
                            lcd_format_emit,(void *)lcd,&count);
    }
    uint8_t key = nm_avr_calibration_key(m);
    return key == 0 || key == 5;
}

/* 0x2B56–0x2BDB. Редактор байта EEPROM 0x45+номер.
 * В отличие от редактора единицы АЦП его верхний предел
 * равен 30. IRQ восстанавливаются после каждого вызова. */
static bool timer_field(const NM8036 *m, const NMNumericDisplay *lcd, uint8_t *sram,
                        const uint8_t *flash, uint8_t index, uint8_t key, bool opening,
                        NMNumericAlloc allocate, NMNumericSnapshot snapshot, NMNumericRestore restore)
{
    uint8_t flags = m->irq_disable(m->context);
    uint16_t ee_address = (uint16_t)(0x45u+index);
    bool complete = true;
    if (opening) {
        uint16_t address = allocate(lcd->context,22);
        uint8_t *field = sram+address;
        unit_init(lcd,field,snapshot(lcd->context));
        *nm_ram(m,0x06ac) = (uint8_t)address;
        *nm_ram(m,0x06ad) = (uint8_t)(address >> 8);
        field[18] = 0x30;
        field[19] = 4;
        uint8_t value = nm_ee_read(m,ee_address);
        store_word(field+10,value);
        store_word(field+14,value);
        nm_avr_editor_redraw_word(lcd,field,flash);
        nm_avr_editor_set_limits(field,0,30);
    } else {
        uint16_t address = *nm_ram(m,0x06ac) | ((uint16_t)*nm_ram(m,0x06ad)<<8);
        uint8_t *field = sram+address;
        complete = unit_edit(lcd,field,flash,key,30);
        if (complete) {
            nm_ee_write(m,ee_address,field[10]);
            restore(lcd->context,text_address(field));
            nm_avr_heap_free(sram,address);
        }
    }
    m->irq_restore(m->context,flags);
    return complete;
}

/* 0x2ABC–0x2B55. Список из семи параметров времени.
 * Поле +2 показывает, активен ли список. После возвращения
 * редактора список перерисовывается с прежним курсором. */
bool nm_avr_timer_menu(const NM8036 *m, const NMNumericDisplay *lcd, uint8_t *sram,
                       const uint8_t *flash, bool opening, NMNumericAlloc allocate,
                       NMNumericSnapshot snapshot, NMNumericRestore restore)
{
    if (opening) {
        numeric_menu_open(m,lcd,sram,flash,0x06aa,0x0442,7,allocate,snapshot);
        return true;
    }
    uint16_t address = *nm_ram(m,0x06aa) | ((uint16_t)*nm_ram(m,0x06ab)<<8);
    uint8_t *menu = sram+address;
    uint8_t key = *nm_ram(m,0x0739);
    if (menu[2]) {
        if (key & 0x0f)
            return nm_avr_calibration_menu_navigate(lcd,sram,flash,menu,key,restore);
        menu[2] = 0;
        timer_field(m,lcd,sram,flash,calibration_item(menu),key,true,allocate,snapshot,restore);
    } else if (timer_field(m,lcd,sram,flash,calibration_item(menu),key,false,allocate,snapshot,restore)) {
        nm_avr_calibration_menu_resume(lcd,flash,menu);
    }
    return false;
}

/* 0x2872–0x288F. Перед выводом очистить верхнюю строку
 * и вернуться в её начало. Первый аргумент оригинал
 * берёт из r24:r25 и кладёт перед остальными. */
bool nm_avr_display_caption(const NMNumericDisplay *lcd, const uint8_t *flash,
                            uint16_t address, uint8_t *arguments, uint16_t *argument)
{
    uint16_t count;
    nm_avr_lcd_fill_spaces(lcd,0,15,0);
    lcd->position(lcd->context,0,0);
    return nm_avr_flash_format(flash,flash+address,arguments,argument,0,
                               lcd_format_emit,(void *)lcd,&count);
}

/* 0x691A–0x69AF. Таблица switch хранит минимальный ключ,
 * флаги и адрес по умолчанию. Плотные таблицы индексируются,
 * разреженные кодируют положительные приращения ключа. */
uint16_t nm_avr_switch_target(const uint8_t *flash, uint16_t table, uint8_t key_bytes, uint32_t key)
{
    const uint8_t *entry = flash+table;
    uint32_t first = *entry++;
    if (key_bytes == 2)
        first = (first << 8) | *entry++;
    if (key_bytes == 4)
        for (uint8_t i = 0; i < 3; ++i)
            first = (first << 8) | *entry++;
    uint8_t flags = *entry++;
    uint16_t fallback = text_address(entry);
    entry += 2;
    uint16_t target = fallback;
    if (key < first)
        return (uint16_t)(fallback*2u);
    uint32_t offset = key-first;
    uint8_t stride = flags & 2u ? 1 : 2;
    if (!(flags & 1u)) {
        uint16_t count = text_address(entry);
        entry += 2;
        if (offset < count) {
            entry += offset*stride;
            target = stride == 1 ? (uint16_t)(fallback-*entry) : text_address(entry);
        }
    } else {
        while (offset) {
            entry += stride;
            uint32_t delta = *entry++;
            if (delta == 0xfb)
                return (uint16_t)(fallback*2u);
            uint8_t extra = delta < 0xfb ? 0 : delta == 0xff ? 1 : delta == 0xfe ? 2 : 4;
            if (extra) {
                delta = 0;
                for (uint8_t i = 0; i < extra; ++i)
                    delta = (delta << 8) | *entry++;
            }
            if (offset < delta)
                return (uint16_t)(fallback*2u);
            offset -= delta;
        }
        target = stride == 1 ? (uint16_t)(fallback-*entry) : text_address(entry);
    }
    return (uint16_t)(target*2u);
}

/* 0x49A4–0x4AB7. Список хранит свой указатель по 0x072F.
 * Таблицы 0x0C0A/0x0C26 отличаются порядком ветвей в
 * машинном коде. Их логические редакторы совпадают.
 * Значение editor=1 возвращает из подменю к списку. */
bool nm_avr_settings_menu(const NM8036 *m, const NMNumericDisplay *lcd, uint8_t *sram,
                          const uint8_t *flash, bool opening, NMNumericAlloc allocate,
                          NMNumericSnapshot snapshot, NMNumericRestore restore,
                          uint8_t (*editor)(void *, uint16_t, bool))
{
    if (opening) {
        numeric_menu_open(m,lcd,sram,flash,0x072f,0x0a18,12,allocate,snapshot);
        return true;
    }

    static const uint16_t entries[] = {
        0x4ab8,0x4e2a,0x5052,0x4e44,0x0e16,0x25aa,
        0x4f28,0x5336,0x53f4,0x4eba,0x2abc,0x4e44
    };
    uint16_t address = *nm_ram(m,0x072f) | ((uint16_t)*nm_ram(m,0x0730)<<8);
    uint8_t *menu = sram+address;
    uint8_t item = calibration_item(menu);
    uint8_t key = *nm_ram(m,0x0739);
    bool list = menu[2] != 0;
    if (list && (key & 15u)) {
        if ((key & 15u) == 5)
            key = 5; /* 0x4AA8 действует и при установленном флаге повтора. */
        return nm_avr_calibration_menu_navigate(lcd,sram,flash,menu,key,restore);
    }
    /* Пункты 0–10 имеют ветвь, 11 использует общий выход. */
    if (item >= 11)
        return false;
    uint8_t result = editor(lcd->context,entries[item],list);
    if (list)
        menu[2] = 0;
    else if (result == 1)
        nm_avr_calibration_menu_resume(lcd,flash,menu);
    return false;
}

/* 0x4EBA–0x4EC5 и 0x4EE8–0x4F27. Вход очищает LCD,
 * устанавливает 0xFE в SRAM и рисует без изменения EEPROM.
 * Последующие шаги используют прежний редактор звука. */
bool nm_avr_sound_screen_step(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t *flash, bool opening)
{
    uint8_t key = *nm_ram(m,0x0739);
    if (opening) {
        lcd->write(lcd->context,1,0);
        *nm_ram(m,0x0739) = 0xfe;
    } else if (nm_sound_editor_key(m,key)) {
        return true;
    } else if (key == 0xff) {
        return false;
    }
    lcd->position(lcd->context,0,0);
    text(lcd,flash+0x0891);
    lcd->position(lcd->context,0,1);
    text(lcd,flash+(nm_ee_read(m,0x02ec) ? 0x08a2 : 0x07bd));
    return false;
}

/* 0x43E6–0x441D. После отрисовки контролируются период
 * смены страницы, вход в настройки и повторный запуск счётчика. */
void nm_avr_home_after_draw(const NM8036 *m, uint8_t counter_limit, uint8_t pending,
                            void (*open_settings)(void *), void *context)
{
    if (*nm_ram(m,0x073b) >= counter_limit && !pending) {
        *nm_ram(m,0x073b) = 0;
        *nm_ram(m,0x073f) = 0;
        uint8_t page = *nm_ram(m,0x073c);
        *nm_ram(m,0x073c) = nm_avr_adc_next_channel(&page) ? page : 0;
    }
    if ((*nm_ram(m,0x0739) & 15u) == 5) {
        open_settings(context);
        *nm_ram(m,0x073a) = 1;
    }
    if (*nm_ram(m,0x0739) == 0)
        *nm_ram(m,0x073b) = 100;
    *nm_ram(m,0x0735) = 0;
}
