#include "nm_program_fields.h"

/* 0x3A1C–0x3A2B, 0x3A38–0x3A43.
 * Индекс из 0x06B4. Запись EEPROM занимает 21 байт;
 * r16:r17 содержит смещение, r20:r21 — адрес с 0x4C. */
uint16_t nm_avr_program_record_base(uint8_t index)
{
    return 0x4cu + 21u * index;
}

/* 0x3A4A–0x3A59. Режим периода — старшие биты
 * байта EEPROM +1, ноль соответствует флагу Z. */
uint8_t nm_avr_program_period_mode(const NM8036 *m)
{
    uint16_t address = nm_avr_program_record_base(*nm_ram(m,0x06b4));
    return nm_ee_read(m,address+1u) >> 6;
}

/* 0x3922–0x392B. Младшие шесть бит поля заменяются,
 * старшие два бита прежнего байта сохраняются. */
uint8_t nm_avr_program_merge_time(uint8_t previous, uint8_t field)
{
    return (previous & 0xc0u) | (field & 0x3fu);
}

/* 0x392C–0x3933. Указатель на редактор уже разрешён из X. */
void nm_avr_program_record_key(uint8_t editor[8], uint8_t key)
{
    editor[7] = key & 15u;
}

/* 0x3962–0x3975. Два входа пишут 0x03FF в +2 либо +4. */
void nm_avr_program_limit(uint8_t editor[6], bool upper)
{
    uint8_t offset = upper ? 4 : 2;
    editor[offset] = 0xff;
    editor[offset+1] = 3;
}

/* 0x38FC–0x3901, 0x3EEE–0x3EF1, 0x3F14–0x3F2B,
 * 0x3F48–0x3F4D, 0x3F80–0x3F8F. В зависимости от поля
 * читается один байт, слово или две пары байтов без знакового расширения. */
uint32_t nm_avr_program_eeprom_read(const NM8036 *m, uint16_t address, uint8_t width)
{
    uint32_t value = 0;
    for (uint8_t i = 0; i < width && i < 4; ++i)
        value |= (uint32_t)nm_ee_read(m,address+i) << (8u*i);
    return value;
}

/* 0x390A–0x390D, 0x3F06–0x3F0F, 0x3F2C–0x3F33.
 * Байты передаются по возрастанию адреса, начиная с младшего. */
void nm_avr_program_eeprom_write(const NM8036 *m, uint16_t address, uint32_t value, uint8_t width)
{
    for (uint8_t i = 0; i < width && i < 4; ++i) {
        nm_ee_write(m,address+i,(uint8_t)value);
        value >>= 8;
    }
}

/* 0x3A92–0x3A99, 0x3A6A–0x3A6F, 0x3A44–0x3A49.
 * Поля выбираются по индексу программы в 0x06B4. */
uint8_t nm_avr_program_selected_byte(const NM8036 *m, uint16_t offset)
{
    return nm_ee_read(m,nm_avr_program_record_base(*nm_ram(m,0x06b4))+offset);
}

/* 0x39A4–0x39A9, 0x3A5A–0x3A65, 0x3A7C–0x3A91.
 * Выбор входа сохраняется в локальном редакторе +4, +5 или +6.
 * Соседний байт EEPROM после поля +6 читается отдельной операцией. */
uint8_t nm_avr_program_editor_insert(uint8_t *editor, uint8_t offset, uint8_t code, uint8_t mask)
{
    uint8_t selected = code & mask;
    editor[offset] = selected;
    return selected;
}

/* 0x3FB8–0x3FD3. Цикл с DEC/BRMI ограничивает знак счётчика;
 * проверка итоговой маски сворачивает четыре байта через OR. */
uint8_t nm_avr_program_bit_from_mask(uint32_t mask, uint8_t shift)
{
    uint8_t count = (uint8_t)(shift - 1u);
    unsigned bit = count & 0x80u ? 0u : (unsigned)count + 1u;
    return bit < 32 && ((mask >> bit) & 1u);
}

/* 0x3EC0–0x3EC9, 0x3F9C–0x3FA7, 0x3A9A–0x3AA3.
 * Для адреса EEPROM к результату отдельно прибавляют 0x4C. */
uint16_t nm_avr_program_unbased_offset(uint8_t index, uint16_t offset)
{
    return (uint16_t)(21u*index + offset);
}

/* 0x38F6–0x38FB, 0x390E–0x3915, 0x3982–0x3987. */
uint8_t nm_avr_program_flag(const NM8036 *m, uint16_t address)
{
    return *nm_ram(m,address);
}

/* 0x395C–0x3961, 0x3976–0x397D, 0x3990–0x3997. */
void nm_avr_program_set_flag(const NM8036 *m, uint16_t address, uint8_t value)
{
    *nm_ram(m,address) = value;
}

/* 0x3934–0x3941, 0x397E–0x3981. Повтор не маскируется:
 * здесь сравнивается весь байт клавиши с выбранной константой. */
bool nm_avr_program_exact_key(uint8_t raw, uint8_t expected)
{
    return raw == expected;
}

/* 0x3942–0x3949. Вариант заполнения младших пяти бит редактора. */
uint8_t nm_avr_program_merge_source(const uint8_t *editor, uint8_t high)
{
    return high | (editor[3] & 31u);
}

/* 0x3AAC–0x3AB7, 0x3ABE–0x3ACA. Видимый номер начинается с 1. */
uint16_t nm_avr_program_number(uint8_t index)
{
    return (uint16_t)index+1u;
}

/* 0x39B4–0x39DC. Сохранение комбинированного байта EEPROM.
 * Старшие биты уже выделены вызывающей процедурой. */
void nm_avr_program_write_field(const NM8036 *m, uint16_t address, uint8_t high,
                                uint8_t low, uint8_t mask)
{
    nm_ee_write(m,address,high | (low & mask));
}

/* 0x3ED0–0x3EDB, 0x3F54–0x3F5F. Распаковка исходных
 * полей, не применяя знаковое расширение. */
uint16_t nm_avr_program_split_field(uint16_t value)
{
    return (uint16_t)((value & 15u) | ((value >> 8) << 8));
}

/* 0x3F3E–0x3F47, 0x3F4E–0x3F53, 0x3F60–0x3F6D.
 * Выбирает ровно шесть младших битов байта EEPROM. */
uint8_t nm_avr_program_six_bits(const NM8036 *m, uint16_t address)
{
    return nm_ee_read(m,address) & 0x3fu;
}

/* 0x3902–0x3909, 0x3F80–0x3F8F. Порог — четыре байта с
 * шага +17. Выбор порога сопровождается чтением флага 0x06B8. */
uint32_t nm_avr_program_threshold_word(const NM8036 *m, uint16_t address, uint8_t *flag)
{
    uint32_t value = nm_avr_program_eeprom_read(m,address,4);
    *flag = *nm_ram(m,0x06b8);
    return value;
}

/* 0x3F14–0x3F1B, 0x3F6E–0x3F7F. Канал без старшего
 * флага адресует массив отсчётов с базой 0x0747. */
uint8_t nm_avr_program_read_source(const NM8036 *m, uint16_t record, uint8_t offset)
{
    return nm_ee_read(m,record+offset) & 0x7fu;
}

/* 0x39BA–0x39DC. Применяются порядковые смещения целиком
 * в uint16_t. Возвращается новый адрес для чтения (EEPROM). */
uint16_t nm_avr_program_commit_selector(const NM8036 *m, uint16_t record,
                                         uint8_t offset, uint8_t high,
                                         uint8_t low, uint8_t mask)
{
    uint16_t address = (uint16_t)(record+offset);
    nm_avr_program_write_field(m,address,high,low,mask);
    return address;
}

/* 0x39DE–0x3A01, 0x3F22–0x3F2B, 0x3F34–0x3F39.
 * Элементы этой структуры лежат в EEPROM по постоянным смещениям,
 * но флаг и старший бит байта с +12 возвращаются отдельно. */
void nm_avr_program_load_fields(const NM8036 *m, uint16_t record, NMOriginalProgramFields *out)
{
    out->head = nm_ee_read(m,record);
    out->flag11 = nm_ee_read(m,record+11) & 1u;
    out->source12 = nm_ee_read(m,record+12);
    out->source12_low = out->source12 & 0x7fu;
    out->output5 = nm_ee_read(m,record+5);
    out->word15 = (uint16_t)nm_avr_program_eeprom_read(m,record+15,2);
}

/* 0x3A5A–0x3A65, 0x3A7C–0x3A87. Маски различаются
 * между первой парой полей и полем с пятибитным индексом. */
uint8_t nm_avr_program_transfer_sources(const NM8036 *m, uint8_t *editor,
                                        uint8_t first_offset, uint8_t second_offset)
{
    uint16_t record = nm_avr_program_record_base(*nm_ram(m,0x06b4));
    nm_avr_program_editor_insert(editor,5,nm_ee_read(m,record+first_offset),0x3f);
    nm_avr_program_editor_insert(editor,6,nm_ee_read(m,record+second_offset),0x1f);
    return nm_ee_read(m,record+4);
}
