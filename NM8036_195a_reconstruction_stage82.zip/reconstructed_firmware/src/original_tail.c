#include "nm_original_tail.h"
#include "nm_program_fields.h"
#include "nm_peripherals.h"
#include "nm_menu.h"
#include "nm_original_decimal.h"
#include "nm_original_display_routes.h"

/* 0x1090–0x1097. Параметр второй половины записи лежит
 * на 16 байт дальше базы. Смещение учитывает перенос младшего байта. */
uint16_t nm_avr_tail_delay_address(uint16_t base)
{
    return (uint16_t)(base+16u);
}

/* 0x1D60–0x1D69. Адрес дочернего редактора в +12.
 * Клавиша передаётся обработчику 0x18EE как отдельный байт. */
uint16_t nm_avr_tail_child(const uint8_t *parent)
{
    return parent[12] | (uint16_t)parent[13] << 8;
}

/* 0x1D6A–0x1D6F. Нижняя граница равна нулю. */
void nm_avr_tail_child_limits(uint8_t *ram, const uint8_t *parent, uint8_t maximum)
{
    uint8_t *field = ram+nm_avr_tail_child(parent);
    for (uint8_t i = 2; i < 10; ++i)
        field[i] = 0;
    field[6] = maximum;
}

/* 0x1D7E–0x1D8B. Курсор включён в обоих режимах. */
void nm_avr_tail_lcd_cursor(const NMNumericDisplay *lcd, bool blink)
{
    lcd->write(lcd->context,blink ? 0x0f : 0x0e,0);
}

/* 0x22DE–0x22E3. Текущее состояние списка. */
uint8_t nm_avr_tail_list_active(const uint8_t list[3])
{
    return list[2];
}

/* 0x2DCA–0x2DD1. Размер дочерней структуры календаря. */
uint16_t nm_avr_tail_allocate_calendar(const NMNumericDisplay *lcd, NMNumericAlloc allocate)
{
    return allocate(lcd->context,21);
}

/* 0x394A–0x395B. Клавиша передаётся обработчику до
 * проверки MENU, включая байт автоповтора. */
bool nm_avr_tail_calendar_key(void *context, uint16_t child, uint8_t key,
                              void (*edit)(void *, uint16_t, uint8_t))
{
    edit(context,child,key);
    return key == 5;
}

/* 0x391C–0x3921. Возвращается весь сохранённый байт. */
uint8_t nm_avr_tail_program_key(const uint8_t record[8])
{
    return record[7];
}

/* 0x3308–0x330D и 0x35FA–0x35FF: состояние 0x0735
 * открывает ветвь рисования вместо обычного шага редактора. */
uint8_t nm_avr_tail_move_program(const NM8036 *m, uint8_t redraw_page, uint8_t normal_page)
{
    return *nm_ram(m,0x0735) ? redraw_page : normal_page;
}

/* 0x39BA–0x39C7 и 0x39DA–0x39DD. Объединённый байт
 * записывается по адресу +4, затем выбирается соседнее поле. */
uint16_t nm_avr_tail_program_commit(const NM8036 *m, uint16_t address, uint16_t next,
                                    uint8_t original_flags, uint8_t selected)
{
    nm_ee_write(m,(uint16_t)(address+4u),original_flags | selected);
    return next;
}

/* 0x3A2C–0x3A31 и 0x3F90–0x3F93. Прикладной флаг
 * возвращается в исходной битовой позиции. */
uint8_t nm_avr_tail_program_flag20(const NM8036 *m, uint16_t address)
{
    return nm_ee_read(m,address) & 0x20u;
}

/* 0x3F00–0x3F05. Номер выхода занимает пять битов. */
uint8_t nm_avr_tail_program_output(const NM8036 *m, uint16_t address)
{
    return nm_ee_read(m,address) & 0x1fu;
}

/* 0x5024–0x5029. Удержание MENU считается нажатием. */
uint8_t nm_avr_tail_dallas_key(const NM8036 *m)
{
    return *nm_ram(m,0x0739) & 15u;
}

/* 0x50D4–0x50D9, 0x62E8–0x62EB. Нулевой адрес
 * пропускается, остальные обрабатываются общим освобождением. */
void nm_avr_tail_dallas_close(void *context, uint16_t cache, NMNumericRestore release)
{
    if (cache)
        release(context,cache);
}

/* 0x4D3A–0x4D43. Десятки возвращаются в старшем полубайте. */
uint8_t nm_avr_tail_rtc_hour_bits(uint8_t bcd, uint8_t *units)
{
    *units = bcd & 15u;
    return bcd & 0x70u;
}

/* 0x381C–0x382B. Сначала печатается заголовок по записи
 * с шагом 12, затем общий суффикс режима. */
void nm_avr_tail_program_period(const NMNumericDisplay *lcd,
                                const uint8_t *flash, uint8_t *ram, uint16_t index)
{
    nm_avr_status_flash_format(lcd,flash,ram,(uint16_t)(0x073du+12u*index),0);
    nm_avr_status_flash_format(lcd,flash,ram,0x06ac,0);
}

/* 0x3F6E–0x3F7F. Источник берётся из EEPROM +12,
 * затем выбирается байт по смещению 0x25 от базы 0x0747. */
uint8_t nm_avr_tail_program_compare(const NM8036 *m, uint16_t record)
{
    uint8_t source = nm_ee_read(m,record+12) & 0x7fu;
    return *nm_ram(m,0x076cu+source);
}

/* 0x5052–0x5059. Открытие запускает поиск, остальные
 * вызовы сразу передают управление общему состоянию диалога. */
bool nm_avr_tail_dallas_enter(const NM8036 *m, const NMOneWire *bus, const NMNumericDisplay *lcd,
                               const uint8_t *flash, uint8_t *ram, NMNumericAlloc allocate, bool opening)
{
    if (nm_avr_tail_menu_enter(opening))
        nm_avr_dallas_dialog_open(m,bus,lcd,flash,ram,allocate);
    return opening;
}

/* 0x5046–0x504B, 0x504C–0x5051. Оба входа используют
 * штатные выходы и общую базу состояния 0x0747 (0x5040). */
void nm_avr_tail_output_request(const NM8036 *m, uint8_t channel, bool active)
{
    nm_output_set(m,channel,active);
}

void nm_avr_tail_output_mode(const NM8036 *m, uint8_t mode)
{
    nm_outputs_force(m,mode);
}

/* 0x2FEA–0x2FED. Отдельный байт условия календаря. */
uint8_t nm_avr_tail_alarm(const NM8036 *m, uint16_t record)
{
    return nm_ee_read(m,(uint16_t)(record+7));
}

/* 0x1090–0x1097. Обновление коэффициента с использованием
 * обычного ожидания записи EEPROM в драйвере. */
void nm_avr_tail_store_coefficient(const NM8036 *m, uint16_t record, uint8_t byte)
{
    nm_ee_write(m,nm_avr_tail_delay_address(record),byte);
}

/* 0x43B8–0x43D1 и 0x5038–0x503B. После заполнения пяти
 * знаков пробела к аргументам экрана добавляется значение EEPROM. */
uint16_t nm_avr_tail_aux_display(const NM8036 *m, const NMNumericDisplay *lcd,
                                  const uint8_t *flash, uint8_t *ram, uint16_t index,
                                  uint16_t format, const uint8_t argument[6], uint16_t at)
{
    nm_avr_status_flash_format(lcd,flash,ram,0x088b,0);
    ram[at] = nm_ee_read(m,(uint16_t)(0x10u+index));
    ram[at+1] = 0;
    for (uint8_t i = 0; i < 6; ++i)
        ram[at+2+i] = argument[i];
    nm_avr_status_flash_format(lcd,flash,ram,format,at);
    return (uint16_t)(at+8);
}

/* 0x2776–0x2777, 0x2976–0x297D, 0x54A4–0x54A7.
 * Записывается новое значение и вызывается отрисовщик объекта. */
uint16_t nm_avr_tail_bar_update(const NM8036 *m, const NMNumericDisplay *lcd,
                                 const uint8_t *flash, uint8_t *ram, uint16_t scale, uint32_t word)
{
    nm_avr_display_field_set(ram+scale,word);
    nm_avr_display_redraw_bar(m,lcd,flash,ram+scale);
    return scale;
}

/* 0x39BE–0x39C7, 0x39DA–0x39DD. Входы чтения после
 * записи различаются смещением следующего адреса. */
uint8_t nm_avr_tail_program_commit_read(const NM8036 *m, uint16_t address, uint16_t next,
                                         uint8_t value, bool following)
{
    nm_ee_write(m,address,value);
    return nm_ee_read(m,(uint16_t)(next+(following ? 4u : 0u)));
}

/* 0x3988–0x398F. Повторный вход рисует текущую программу
 * с нулевым смещением и оставляет индекс в 0x06B4. */
void nm_avr_tail_program_open_zero(const NM8036 *m, const NMNumericDisplay *lcd,
                                   const uint8_t *flash, uint8_t *ram,
                                   void (*draw_row)(void *, uint8_t))
{
    lcd->write(lcd->context,0x0e,0);
    *nm_ram(m,0x06b4) &= 31u;
    nm_avr_program_select_draw(m,lcd,flash,ram,draw_row);
}

/* 0x3ECA–0x3ECF. MUL переносит два старших бита
 * в старший байт 16-битного произведения. */
uint8_t nm_avr_tail_scale_select(uint8_t mode)
{
    return mode >> 6;
}

/* 0x3ED0–0x3EDB. Байты остаются раздельными. */
uint16_t nm_avr_tail_split_option(uint8_t low, uint8_t high)
{
    return (low & 15u) | (uint16_t)high << 8;
}

/* 0x48F4–0x48FD. После вывода знака следующий аргумент
 * позиции содержит младший байт колонки и номер строки 1. */
uint8_t nm_avr_tail_setup_screen(const NMNumericDisplay *lcd, uint8_t column, uint8_t data, uint8_t byte)
{
    lcd->write(lcd->context,byte,data);
    return column;
}

/* 0x3F94–0x3F9B. Пять бит секунд передаются расчёту
 * границы с нулевыми годом и месяцем. */
uint32_t nm_avr_tail_calendar_boundary(const NM8036 *m, uint16_t address,
                                        uint8_t day,
                                        uint8_t hour, uint8_t minute)
{
    return nm_calendar_seconds(0,0,day,hour,minute,nm_avr_tail_program_output(m,address));
}

/* 0x3F14–0x3F21. Считывание пары сохраняет семь бит
 * первого байта и все восемь бит второго байта из записи +4. */
uint16_t nm_avr_tail_program_pair(const NM8036 *m, uint16_t address, uint16_t record)
{
    uint8_t first = nm_ee_read(m,address) & 0x7fu;
    return first | (uint16_t)nm_ee_read(m,record+4) << 8;
}

/* 0x3F22–0x3F2B. Значение EEPROM хранится младшим байтом вперёд. */
uint16_t nm_avr_tail_program_word13(const NM8036 *m, uint16_t record)
{
    return (uint16_t)nm_avr_program_eeprom_read(m,record+13,2);
}

/* 0x3F2C–0x3F33. Записывается только один байт поля +5. */
void nm_avr_tail_write_flags(const NM8036 *m, uint16_t record, uint8_t flags)
{
    nm_ee_write(m,record+5,flags);
}

/* 0x410E–0x4119. Номер из редактора преобразуется
 * в базовый адрес записи для следующего чтения EEPROM. */
uint16_t nm_avr_tail_program_address(uint8_t program)
{
    return nm_avr_program_record_base(program);
}

/* 0x3BB8–0x3BBF, 0x4916–0x491D. Варианты расширения
 * младшего байта и нулевого заполнения аргументов. */
uint32_t nm_avr_tail_extend_byte(uint8_t byte)
{
    return byte;
}

/* 0x4F1A–0x4F1D. После сброса содержимого LCD вызывающий
 * код заново выбирает начало первой строки. */
void nm_avr_tail_clear_home(const NMNumericDisplay *lcd)
{
    lcd->write(lcd->context,1,0);
    lcd->position(lcd->context,0,0);
}

/* 0x3A02–0x3A0D, 0x2DDA–0x2DF1, 0x4D9E–0x4DA9.
 * Два символа в адресе поля замещаются пробелами. */
void nm_avr_tail_blank_pair(uint8_t field[2])
{
    field[0] = ' ';
    field[1] = ' ';
}

/* 0x3A32–0x3A37. Байт признаков записи выбранной программы. */
uint8_t nm_avr_tail_selected_flags(const NM8036 *m)
{
    return nm_avr_program_selected_byte(m,0);
}

/* 0x3A66–0x3A69 и 0x3AD6. Первая строка, колонка ноль. */
void nm_avr_tail_first_row(const NMNumericDisplay *lcd)
{
    lcd->position(lcd->context,0,0);
}

/* 0x4728–0x4731. Нулевая строка обрабатывается
 * общим выходом, иначе сканирование начинается с канала ноль. */
bool nm_avr_tail_prepare_adc(uint8_t row, uint16_t *channel)
{
    if (!row)
        return false;
    *channel = 0;
    return true;
}

/* 0x4D82–0x4D87. Признак активного ухода экрана RTC. */
bool nm_avr_tail_rtc_redraw(const NM8036 *m)
{
    return *nm_ram(m,0x0735) != 0;
}

/* 0x52E2–0x52E7. Вывод заголовка оставляет строку 1
 * для следующей операции позиционирования. */
uint8_t nm_avr_tail_dallas_title(const NMNumericDisplay *lcd, const uint8_t *flash,
                                  uint8_t *ram, uint16_t title)
{
    nm_avr_status_flash_format(lcd,flash,ram,title,0);
    return 1;
}


/* 0x1B56–0x1B5B и 0x1B84–0x1B8D. Мантисса и порядок
 * подаются пятью словами little-endian с нулевым старшим байтом. */
void nm_avr_tail_decimal_words(const uint8_t field[20], uint8_t words[10])
{
    for (uint8_t i = 0; i < 5; ++i) {
        words[2*i] = field[4+i];
        words[2*i+1] = 0;
    }
}

/* 0x1B68–0x1B83. Поле позиции указывает координаты,
 * а нулевой указатель заголовка выбирает штатную надпись. */
uint16_t nm_avr_tail_scientific_caption(const NMNumericDisplay *lcd, const uint8_t field[20])
{
    uint16_t caption = field[15] | (uint16_t)field[16] << 8;
    if (!caption) {
        lcd->position(lcd->context,1,0);
        return 0x018a;
    }
    return caption;
}

/* 0x1B78–0x1B7B. Числа выводятся через Flash-форматтер
 * таким же способом, как и обычные подписи. */
void nm_avr_tail_scientific_digits(const NMNumericDisplay *lcd, const uint8_t *flash,
                                   const uint8_t field[20])
{
    uint8_t arguments[10];
    nm_avr_tail_decimal_words(field,arguments);
    nm_avr_status_flash_format(lcd,flash,arguments,0x0199,0);
}

/* 0x39AA–0x39B3. Длинный аргумент выводится по байтам,
 * младший расположен по меньшему адресу. */
void nm_avr_tail_store_long(uint8_t bytes[4], uint32_t value)
{
    for (unsigned i = 0; i < 4; ++i) {
        bytes[i] = (uint8_t)value;
        value >>= 8;
    }
}

/* 0x3A0E–0x3A1B. Начало записи задаётся размером 21 и
 * отдельным смещением 0x4C, оставляемым вызывающему коду. */
uint16_t nm_avr_tail_record_offset(uint16_t index, uint8_t *base)
{
    *base = 0x4c;
    return (uint16_t)(21u*index);
}

/* 0x3EDC–0x3EE1. Перенос из вычисления младшего байта
 * определяет прибавление к старшему; операция пишет один байт. */
void nm_avr_tail_commit_high(const NM8036 *m, uint16_t address, bool borrow, uint8_t value)
{
    nm_ee_write(m,(uint16_t)(address+(borrow ? 0u : 0x0100u)),value);
}

/* 0x1B7C–0x1B83 и 0x1B8E–0x1B97. Координаты
 * Sci-редактора передаются в том же порядке, что LCD API. */
void nm_avr_tail_scientific_position(const NMNumericDisplay *lcd, const uint8_t position[2])
{
    lcd->position(lcd->context,position[0],position[1]);
}

/* 0x1B98–0x1B9D, 0x503C–0x503F. Оба входа обнуляют
 * старший байт и посылают одиночный знак как данные. */
void nm_avr_tail_write_character(const NMNumericDisplay *lcd, uint8_t byte)
{
    lcd->write(lcd->context,byte,1);
}

/* 0x3BAC–0x3BB7. Текущее время приходит как пара
 * младший байт минут и старший байт секунд. */
uint32_t nm_avr_tail_current_stamp(uint8_t year, uint8_t month, uint8_t day,
                                    uint8_t hour, uint16_t minute_second)
{
    return nm_calendar_seconds(year,month,day,hour,(uint8_t)minute_second,
                               (uint8_t)(minute_second >> 8));
}

/* 0x3EF2–0x3EF9. День ограничивается пятью битами,
 * сохранённое поле из соседнего аргумента возвращается вызывающему коду. */
uint16_t nm_avr_tail_stamp_fields(const NM8036 *m, uint16_t day_address, uint8_t packed)
{
    return nm_avr_tail_program_output(m,day_address) | (uint16_t)packed << 8;
}

/* 0x3EFA–0x3EFF. Маскированные секунды включаются
 * в общую метку вместе с двумя календарными аргументами. */
uint32_t nm_avr_tail_saved_stamp(const NM8036 *m, uint16_t address,
                                  uint8_t year, uint8_t month, uint8_t day,
                                  uint8_t hour, uint8_t minute)
{
    return nm_calendar_seconds(year,month,day,hour,minute,
                               nm_avr_tail_program_output(m,address));
}

/* 0x263A–0x2645. Оба ключевых входа разрешают общий
 * указатель списка 0x06A8. При включении поле активности
 * меняется перед обновлением окна; перемещение использует шаг. */
void nm_avr_tail_output_list(const NM8036 *m, uint8_t *ram, bool move,
                              uint8_t operand, void (*redraw)(void *, uint16_t), void *context)
{
    uint16_t address = *nm_ram(m,0x06a8) | (uint16_t)*nm_ram(m,0x06a9) << 8;
    uint8_t *list = ram+address;
    if (move) {
        NMSettingsMenu menu = {list[6],list[7] & 3u};
        int8_t step = operand == 0xff ? -1 : operand == 1 ? 1 : 0;
        nm_menu_move(&menu,step,list[5]);
        list[6] = menu.first_row;
        list[7] = (list[7] & 0xfcu) | menu.cursor;
        if (operand != 0xff && operand != 0 && operand != 1)
            return;
    } else {
        list[2] = operand;
        if (!operand)
            return;
    }
    redraw(context,address);
}

/* 0x3116–0x311B. Сторожевой переход возвращает
 * номер страницы к нулю до вызова общего диспетчера. */
void nm_avr_tail_program_reset_page(const NM8036 *m)
{
    *nm_ram(m,0x06b6) = 0;
}

/* 0x3424–0x3429, 0x34DE–0x34E1 и 0x384C–0x384F.
 * Отображение зависит либо от явного первого входа,
 * либо от флага повторного обновления. */
bool nm_avr_tail_program_show_page(bool entered, uint8_t dirty)
{
    return entered || dirty != 0;
}

/* 0x52A4–0x52A5. Номер датчика выводится с единицы;
 * перед инкрементом исходный номер расширен нулём. */
uint16_t nm_avr_tail_dallas_number(uint8_t index)
{
    return (uint16_t)index+1;
}

/* 0x3916–0x391B. Прибавление к адресу буфера начато
 * вызывающим кодом. Здесь завершается старшая часть адреса. */
bool nm_avr_tail_format_program(const uint8_t *flash, uint16_t format, uint8_t *ram,
                                 uint16_t arguments, uint16_t destination,
                                 bool borrow, uint16_t *count)
{
    destination = (uint16_t)(destination+(borrow ? 0u : 0x0100u));
    return nm_avr_flash_sprintf(flash,format,ram,arguments,destination,count);
}

/* 0x53B4–0x53B9. Условия входа нескольких окон
 * проверяются по входному байту перед открытием объекта. */
bool nm_avr_tail_menu_enter(uint8_t opening)
{
    return opening != 0;
}

/* 0x4F28–0x4F2D. Вход в ручной режим очищает дисплей
 * и инициализирует выходы, обычные вызовы идут в обработку клавиши. */
bool nm_avr_tail_manual_outputs(const NM8036 *m, const NMNumericDisplay *lcd, bool opening)
{
    if (opening) {
        lcd->write(lcd->context,1,0);
        nm_manual_outputs_open(m);
        *nm_ram(m,0x0739) = 0xfe;
    }
    return nm_manual_outputs_key(m,*nm_ram(m,0x0739));
}

/* 0x2772–0x2775. Восстанавливается именно снимок LCD
 * из начала структуры, а освобождение самой структуры остаётся
 * за вызывающим кодом. */
void nm_avr_tail_restore_object(void *context, const uint8_t object[2], NMNumericRestore restore)
{
    uint16_t snapshot = object[0] | (uint16_t)object[1] << 8;
    restore(context,snapshot);
}
