#include "nm_original_decimal.h"
#include "nm_editors.h"
#include "nm_runtime.h"
#include <string.h>
#ifdef __AVR__
#include <avr/pgmspace.h>
#else
#define PROGMEM
#define memcpy_P memcpy
#define pgm_read_byte(address) (*(address))
#endif

/* [БИНАРНИК] 0x3012, вход в список с нулевым индексом. */
void nm_program_editor_open(const NM8036 *m)
{
    *nm_ram(m, 0x06b4) = 0;
    *nm_ram(m, 0x06b6) = NM_PROGRAM_LIST;
}

/* Рабочие пороги оригинала переживают выход из редактора.
 * Прямой переход 0x33FC использует их без чтения EEPROM. */
static void threshold_buffer(const NM8036 *m, NMThresholds *thresholds, bool load)
{
    volatile uint8_t *p = nm_ram(m, 0x06b0);
    for (uint8_t i = 0; i < 2; i++, p += 2) {
        if (load)
            thresholds->value[i] = (int16_t)(p[0] | ((uint16_t)p[1] << 8));
        else {
            uint16_t value = (uint16_t)thresholds->value[i];
            p[0] = (uint8_t)value;
            p[1] = value >> 8;
        }
    }
}

/* [БИНАРНИК] 0x301A..0x3040, 0x3810..0x3818. Номер
 * состояния в SRAM 0x06B6 выбирает ветвь таблицы 0x0BF0.
 * Отдельно учитываются младший полубайт клавиши и полный код. */
bool nm_program_editor_step(const NM8036 *m, NMProgramEditor *editor, uint8_t key)
{
    uint8_t saved = m->irq_disable(m->context);
    uint8_t view = *nm_ram(m, 0x06b6);
    uint8_t index = *nm_ram(m, 0x06b4);
    uint8_t action = key & 15u;
    if (view == NM_PROGRAM_LIST) {
        if (action == 5) {
            m->irq_restore(m->context, saved);
            return true;
        }
        if (action == 0)
            view = NM_PROGRAM_ENABLE;
        else
            (void)nm_program_select(m, key);
    } else if (view == NM_PROGRAM_ENABLE) {
        if (action >= 1 && action <= 4)
            nm_program_toggle(m, index);
        else if (key == 5 || (action == 0 && !nm_program_enabled(m, index)))
            view = NM_PROGRAM_LIST;
        else if (action == 0) {
            nm_program_time_load(m, index, false, &editor->time);
            view = NM_PROGRAM_START;
        }
    } else if (view == NM_PROGRAM_CONTROL) {
        if (key == 5)
            view = NM_PROGRAM_LIST;
        else if (action == 2 || action == 3)
            *nm_ram(m, 0x06b5) = (*nm_ram(m, 0x06b5) + (action == 2 ? 3u : 1u)) & 3u;
        else if (action == 1 || action == 4) {
            switch (*nm_ram(m, 0x06b5)) {
            case 0: nm_program_output_key(m, index, key); break;
            case 1: nm_program_kind_key(m, index, key); break;
            case 2: nm_program_sensor_key(m, index, key); break;
            case 3: nm_program_source_key(m, index, key); break;
            }
        } else if (key == 0) {
            uint8_t next = nm_program_control_confirm(m, index);
            if (next == 8)
                view = NM_PROGRAM_LOGIC;
            else if (next == 7) {
                editor->thresholds.analog = true;
                threshold_buffer(m, &editor->thresholds, true);
                view = NM_PROGRAM_THRESHOLDS;
            } else
                view = NM_PROGRAM_COMPARE;
        }
    } else if (view >= NM_PROGRAM_COMPARE && view <= NM_PROGRAM_PERIOD) {
        uint16_t base = 0x4cu + 21u * index;
        /* 0x3776: на экране И/ИЛИ MENU оставляет состояние 8. */
        if (key == 5 && view != NM_PROGRAM_LOGIC) {
            view = NM_PROGRAM_LIST;
        } else if (view == NM_PROGRAM_COMPARE) {
            if (action == 1 || action == 4)
                nm_program_relative_toggle(m, index);
            else if (key == 0) {
                if (nm_ee_read(m, base + 6u) & 0x20u)
                    view = NM_PROGRAM_REFERENCE;
                else {
                    nm_program_thresholds_load(m, index, &editor->thresholds);
                    threshold_buffer(m, &editor->thresholds, false);
                    view = NM_PROGRAM_THRESHOLDS;
                }
            }
        } else if (view == NM_PROGRAM_REFERENCE) {
            nm_program_reference_key(m, index, key);
            if (key == 0)
                view = NM_PROGRAM_LOGIC;
        } else if (view == NM_PROGRAM_THRESHOLDS) {
            editor->thresholds.selected = *nm_ram(m, 0x06b5) & 1u;
            nm_program_threshold_key(&editor->thresholds, key);
            threshold_buffer(m, &editor->thresholds, false);
            *nm_ram(m, 0x06b5) = editor->thresholds.selected;
            if (key == 0) {
                nm_program_thresholds_save(m, index, &editor->thresholds);
                view = NM_PROGRAM_LOGIC;
            }
        } else if (view == NM_PROGRAM_LOGIC) {
            if (action == 1 || action == 4)
                nm_program_logic_toggle(m, index);
            else if (key == 0) {
                view = NM_PROGRAM_PERIOD;
            }
        } else {
            uint8_t period = nm_program_period_key(m, index, key);
            if (!period && key == 0)
                view = NM_PROGRAM_LIST;
            else
                nm_program_period_item(m, index, period, key);
        }
    } else if (view == NM_PROGRAM_START || view == NM_PROGRAM_STOP) {
        nm_program_time_key(&editor->time, key);
        if (key == 5)
            view = NM_PROGRAM_LIST;
        else if (key == 0) {
            bool stop = view == NM_PROGRAM_STOP;
            nm_program_time_save(m, index, stop, &editor->time);
            if (stop) {
                view = NM_PROGRAM_CONTROL;
                *nm_ram(m, 0x06b5) = 0;
            } else {
                /* 0x3174..0x3198 обновляет поля того же окна, +9 остаётся. */
                uint8_t cursor = editor->time.cursor;
                nm_program_time_load(m, index, true, &editor->time);
                editor->time.cursor = cursor;
                view = NM_PROGRAM_STOP;
            }
        }
    }
    *nm_ram(m, 0x06b6) = view;
    m->irq_restore(m->context, saved);
    return false;
}

/* [БИНАРНИК] 0x306E..0x3084, шаблоны 0x0528/0x0535/0x0546. */
void nm_program_enable_screen(const NM8036 *m, uint8_t index, uint8_t screen[32])
{
    static const uint8_t title[] = {0xd8,0xc0,0xc3};
    static const uint8_t on[] = {0xc2,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
    static const uint8_t off[] = {0xc2,0xfb,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
    for (uint8_t i = 0; i < 32; i++)
        screen[i] = ' ';
    for (uint8_t i = 0; i < sizeof title; i++)
        screen[5+i] = title[i];
    uint8_t number = index + 1u;
    screen[9] = number < 10 ? ' ' : '0' + number / 10u;
    screen[10] = '0' + number % 10u;
    bool enabled = nm_program_enabled(m, index);
    const uint8_t *label = enabled ? on : off;
    uint8_t length = enabled ? sizeof on : sizeof off;
    for (uint8_t i = 0; i < length; i++)
        screen[20+i] = label[i];
}

static void lcd_two_digits(uint8_t *p, uint8_t value, bool pad)
{
    p[0] = value < 10 && !pad ? ' ' : '0' + value / 10u;
    p[1] = '0' + value % 10u;
}

/* [БИНАРНИК] 0x2D04..0x2DC8. Форматы 0x04B9 и 0x04C8
 * помещаются в правые колонки двух строк. Горизонтальное
 * перемещение курсора временно отменяет скрытие поля. */
void nm_program_calendar_screen(const NMProgramTime *time, bool stop, uint8_t index,
                                bool sqw, uint8_t key, uint8_t screen[32])
{
    static const uint8_t labels[2][5] = {
        {0xf1,0xf2,0xe0,0xf0,0xf2}, {0xf1,0xf2,0xee,0xef,' '}
    };
    static const uint8_t columns[] = {8, 11, 14, 22, 25, 30};
    for (uint8_t i = 0; i < 32; i++)
        screen[i] = ' ';
    lcd_two_digits(screen, index + 1u, false);
    screen[2] = ':';
    for (uint8_t i = 0; i < 5; i++)
        screen[3+i] = labels[stop][i];
    screen[10] = screen[13] = ':';
    screen[24] = screen[27] = '-';
    screen[28] = '2';
    screen[29] = '0';
    for (uint8_t i = 0; i < 6; i++)
        lcd_two_digits(screen + columns[i], time->field[i], i != 0 && i != 3);
    key &= 15u;
    if (!sqw && key != 2 && key != 3 && time->cursor < 6) {
        uint8_t column = columns[time->cursor];
        if (time->cursor == 5)
            screen[28] = screen[29] = ' ';
        screen[column] = screen[column+1] = ' ';
    }
}

/* [БИНАРНИК] 0x330E..0x33D8. Две строки состоят из форматов
 * 0x056D, 0x0581 и суффикса 0x0594 для источника АЦП. */
void nm_program_control_screen(const NM8036 *m, uint8_t index,
                               bool sqw, uint8_t key, uint8_t screen[32])
{
    static const uint8_t top[16] = {0xcd,0xe0,0xe3,0xf0,0xf3,0xe7,0xea,0xe0,':',' ',' ',0xd2,0xe8,0xef,':',' '};
    static const uint8_t bottom[16] = {0xc4,0xe0,0xf2,0xf7,0xe8,0xea,':',' ',' ',' ',' ',0xd2,0xe8,0xef,':','D'};
    static const uint8_t symbol[] = {1,2,0xa9,'x'};
    static const uint8_t columns[] = {9,15,23,31};
    uint16_t base = 0x4cu + 21u * index;
    for (uint8_t i = 0; i < 16; i++) {
        screen[i] = top[i];
        screen[16+i] = bottom[i];
    }
    uint8_t output = (nm_ee_read(m, base+12u) & 127u) + 1u;
    if (output < 100)
        lcd_two_digits(screen+9, output, false);
    else {
        screen[9] = '1';
        lcd_two_digits(screen+10, output-100u, true);
        for (uint8_t i = 12; i < 15; i++)
            screen[i] = top[i-1];
    }
    screen[15] = symbol[nm_ee_read(m, base) >> 6];
    lcd_two_digits(screen+23, (nm_ee_read(m, base+11u) & 31u) + 1u, true);
    if (nm_ee_read(m, base+5u) & 0x20u)
        screen[31] = 'A';
    uint8_t cursor = *nm_ram(m, 0x06b5);
    key &= 15u;
    if (!sqw && key != 2 && key != 3 && cursor < 4) {
        uint8_t column = columns[cursor];
        screen[column] = ' ';
        if (!(cursor & 1u))
            screen[column+1] = ' ';
    }
}

/* 0x36D2..0x36EA: сначала деление в binary32, затем
 * формат %.1f. Умножение мантиссы на 10 в целых сохраняет
 * разницу между точным полушагом и ближайшим float ниже него. */
static uint16_t threshold_tenths(uint16_t magnitude)
{
    if (!magnitude)
        return 0;
    float degrees = (float)magnitude / 100.0f;
    uint32_t bits;
    memcpy(&bits, &degrees, sizeof bits);
    uint8_t shift = 150u - ((bits >> 23) & 255u);
    uint32_t mantissa = (bits & UINT32_C(0x7fffff)) | UINT32_C(0x800000);
    return (uint16_t)((mantissa*10u + (UINT32_C(1) << (shift-1u))) >> shift);
}

/* [БИНАРНИК] 0x3600..0x3707. Служебные префиксы L:/H:
 * пишутся отдельно. При низкой фазе SQW поле скрыто целиком. */
void nm_program_threshold_screen(const NM8036 *m, uint8_t index,
                                 const NMThresholds *thresholds, bool sqw,
                                 uint8_t screen[32])
{
    memset(screen, ' ', 32);
    screen[0] = 'L';
    screen[16] = 'H';
    screen[1] = screen[17] = ':';
    for (uint8_t i = 0; i < 2; i++) {
        if (!sqw && thresholds->selected == i)
            continue;
        int16_t value = thresholds->value[i];
        uint8_t *line = screen + 16u*i;
        if (thresholds->analog) {
            uint16_t address = 0x4cu + 21u*index;
            uint8_t channel = nm_ee_read(m, address+11u) & 1u;
            uint8_t number[13];
            float reading = nm_adc_scale(m,channel,value);
            uint32_t word;
            memcpy(&word,&reading,sizeof word);
            nm_avr_format_threshold(number,word,nm_ee_read(m,0x10u+channel));
            /* Поле следует сразу за L:/H:, исходный пробел
             * уже включён. Нулевая единица завершает строку. */
            memcpy(line+2,number,strlen((const char *)number));
        } else {
            uint16_t magnitude = value < 0 ? (uint16_t)(-(int32_t)value) : (uint16_t)value;
            uint16_t tenths = threshold_tenths(magnitude);
            line[6] = '.';
            line[7] = '0' + tenths%10u;
            line[8] = 'C';
            uint16_t digits = tenths/10u;
            uint8_t pos = 6;
            do {
                line[--pos] = '0' + digits%10u;
                digits /= 10u;
            } while (digits);
            if (value < 0)
                line[pos-1] = '-';
        }
    }
}


/* [БИНАРНИК] 0x342A–0x3456. Бит 5 записи программы +6 выбирает
 * относительную или абсолютную уставку. Строки 0x059A–0x05CE
 * записаны в кодировке исходного дисплея. */
void nm_program_compare_screen(const NM8036 *m, uint8_t index, uint8_t screen[32])
{
    uint16_t base = 0x4cu + 21u*index;
    static const uint8_t comparison[] PROGMEM = {0xd3,0xf1,0xf2,0xe0,0xed,'.',' ',0xee,0xf2,0xed,0xee,0xf1,0xe8,0xf2,'.'};
    static const uint8_t other_sensor[] PROGMEM = {0xe4,0xf0,0xf3,0xe3,0xee,0xe3,0xee,' ',0xe4,0xe0,0xf2,0xf7,0xe8,0xea,0xe0};
    static const uint8_t absolute[] PROGMEM = {0xc0,0xe1,0xf1,0xee,0xeb,0xfe,0xf2,0xed,0xe0,0xff};
    static const uint8_t setting[] PROGMEM = {0xf3,0xf1,0xf2,0xe0,0xed,0xee,0xe2,0xea,0xe0};
    memset(screen, ' ', 32);
    if (nm_ee_read(m, base + 6u) & 0x20u) {
        memcpy_P(screen, comparison, sizeof comparison);
        memcpy_P(screen + 16, other_sensor, sizeof other_sensor);
    } else {
        memcpy_P(screen, absolute, sizeof absolute);
        memcpy_P(screen + 16, setting, sizeof setting);
    }

}

/* [БИНАРНИК] 0x34E2–0x3516. Нижний порог в этом режиме
 * содержит номер опорного датчика, а знак определяется видом
 * нагрузки. Шаблоны 0x05CF/0x05DF и 0x05EC/0x05FC. */
void nm_program_reference_screen(const NM8036 *m, uint8_t index, uint8_t screen[32])
{
    static const uint8_t heating[] PROGMEM = {0xc2,0xea,0xeb,0xfe,0xf7,0xe0,0xf2,0xfc,' ',0xed,0xe0,0xe3,0xf0,0xe5,0xe2};
    static const uint8_t cooling[] PROGMEM = {0xc2,0xea,0xeb,'.',' ',0xee,0xf5,0xeb,0xe0,0xe4,0xe8,0xf2,0xe5,0xeb,0xfc};
    static const uint8_t prefix[] PROGMEM = {0xe5,0xf1,0xeb,0xe8,' ','T'};
    uint16_t base = 0x4cu + 21u*index;
    uint8_t mode = nm_ee_read(m, base) & 0xc0u;
    char numbers[12];
    memset(screen, ' ', 32);
    if (mode != 0 && mode != 0x40)
        return;

    memcpy_P(screen, mode ? cooling : heating, sizeof heating);
    memcpy_P(screen + 16, prefix, sizeof prefix);
    /* В формате AVR оба номера выводятся без ведущих пробелов. */
    unsigned sensor = 1u + nm_ee_read(m, base + 11u);
    unsigned reference = 1u + nm_ee_read(m, base + 13u);
    uint8_t count = 0;
    unsigned values[] = {sensor, reference};
    for (uint8_t i = 0; i < 2; i++) {
        unsigned value = values[i];
        if (i) {
            numbers[count++] = mode ? '>' : '<';
            numbers[count++] = 'T';
        }
        if (value >= 100)
            numbers[count++] = '0' + value / 100u;
        if (value >= 10)
            numbers[count++] = '0' + value / 10u % 10u;
        numbers[count++] = '0' + value % 10u;
    }
    memcpy(screen + 22, numbers, count);
}


/* [БИНАРНИК] 0x37AA–0x37F9, 0x381C–0x38F5.
 * Номер режима в EEPROM +1 определяет заголовок. Позиция в 0x06B8
 * выбирает строку элемента и его бит в маске EEPROM +17..+20. */
void nm_program_period_screen(const NM8036 *m, uint8_t index, uint8_t item, uint8_t screen[32])
{
    uint16_t base = 0x4cu + 21u*index;
    static const uint8_t period[][16] PROGMEM = {
        {0xcf,0xe5,0xf0,0xe8,0xee,0xe4,0xe0,' ',0xed,0xe5,0xf2},
        {0xcf,0xee,' ',0xe4,0xed,0xff,0xec,' ',0xed,0xe5,0xe4,0xe5,0xeb,0xe8},
        {0xcf,0xee,' ',0xe4,0xed,0xff,0xec,' ',0xec,0xe5,0xf1,0xff,0xf6,0xe0},
        {0xcf,0xee,' ',0xec,0xe5,0xf1,0xff,0xf6,0xe0,0xec,':'},
    };
    static const uint8_t period_weekdays[][11] PROGMEM = {
        {0xcf,0xce,0xcd,0xc5,0xc4,0xc5,0xcb,0xdc,0xcd,0xc8,0xca},
        {0xc2,0xd2,0xce,0xd0,0xcd,0xc8,0xca,0x20,0x20,0x20,0x20},
        {0xd1,0xd0,0xc5,0xc4,0xc0,0x20,0x20,0x20,0x20,0x20,0x20},
        {0xd7,0xc5,0xd2,0xc2,0xc5,0xd0,0xc3,0x20,0x20,0x20,0x20},
        {0xcf,0xdf,0xd2,0xcd,0xc8,0xd6,0xc0,0x20,0x20,0x20,0x20},
        {0xd1,0xd3,0xc1,0xc1,0xce,0xd2,0xc0,0x20,0x20,0x20,0x20},
        {0xc2,0xce,0xd1,0xca,0xd0,0xc5,0xd1,0xc5,0xcd,0xdc,0xc5},
    };
    static const uint8_t period_months[][8] PROGMEM = {
        {0xff,0xed,0xe2,0xe0,0xf0,0xfc,0x20,0x20},
        {0xf4,0xe5,0xe2,0xf0,0xe0,0xeb,0xfc,0x20},
        {0xec,0xe0,0xf0,0xf2,0x20,0x20,0x20,0x20},
        {0xe0,0xef,0xf0,0xe5,0xeb,0xfc,0x20,0x20},
        {0xec,0xe0,0xe9,0x20,0x20,0x20,0x20,0x20},
        {0xe8,0xfe,0xed,0xfc,0x20,0x20,0x20,0x20},
        {0xe8,0xfe,0xeb,0xfc,0x20,0x20,0x20,0x20},
        {0xe0,0xe2,0xe3,0xf3,0xf1,0xf2,0x20,0x20},
        {0xf1,0xe5,0xed,0xf2,0xff,0xe1,0xf0,0xfc},
        {0xee,0xea,0xf2,0xff,0xe1,0xf0,0xfc,0x20},
        {0xed,0xee,0xff,0xe1,0xf0,0xfc,0x20,0x20},
        {0xe4,0xe5,0xea,0xe0,0xe1,0xf0,0xfc,0x20},
    };
    memset(screen, ' ', 32);
    uint8_t mode = nm_ee_read(m, base + 1u) >> 6;
    for (uint8_t i = 0; i < 16; i++) {
        uint8_t c = pgm_read_byte(&period[mode][i]);
        if (!c)
            break;
        screen[i] = c;
    }
    if (mode) {
        if (mode == 1 && item < 7)
            memcpy_P(screen + 16, period_weekdays[item], 11);
        else if (mode == 2 && item < 31) {
            static const uint8_t day[] PROGMEM = {0xc4,0xe5,0xed,0xfc};
            memcpy_P(screen + 16, day, sizeof day);
            lcd_two_digits(screen + 21, item + 1u, false);
        } else if (mode == 3 && item < 12)
            memcpy_P(screen + 16, period_months[item], 8);
        uint8_t selected = *nm_ram(m, 0x06b8);
        if (selected < 32) {
            screen[29] = '(';
            screen[30] = nm_ee_read(m, base + 17u + selected / 8u) & (1u << (selected & 7u))
                ? '+' : '-';
            screen[31] = ')';
        }
    }
}
