#include <assert.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <simavr/sim_avr.h>
#include <simavr/sim_elf.h>
#include "adc_format_vectors.h"

#define VECTOR(bits) (uint32_t)(bits),
static const uint32_t vectors[] = {FORMAT_VECTORS(VECTOR)};
#undef VECTOR

static avr_t *machine(void)
{
    avr_t *avr = avr_make_mcu_by_name("atmega32");
    assert(avr && avr_init(avr) == 0);
    avr->log = LOG_NONE;
    return avr;
}

static void step(avr_t *avr)
{
    int status = avr_run(avr);
    assert(status != cpu_Crashed && status != cpu_Done);
}

int main(int argc, char **argv)
{
    assert(argc == 3 || (argc == 4 && !strcmp(argv[3],"reconstruction")));
    bool reconstruction = argc == 4;
    uint8_t flash[28668];
    FILE *image = fopen(argv[1], "rb");
    assert(image && fread(flash, 1, sizeof flash, image) == sizeof flash);
    fclose(image);

    elf_firmware_t firmware = {0};
    assert(elf_read_firmware(argv[2], &firmware) == 0);
    avr_t *libc = machine();
    avr_load_firmware(libc, &firmware);
    while (libc->data[0x600] != 0xa5 && libc->cycle < 1000000)
        step(libc);
    assert(libc->data[0x600] == 0xa5);

    unsigned differences = 0, timeouts = 0;
    for (unsigned i = 0; i < sizeof vectors / sizeof *vectors; ++i) {
        avr_t *original = machine();
        avr_loadcode(original, flash, sizeof flash, 0);
        original->data[0x5d] = 0x5f;
        original->data[0x5e] = 0x06;
        original->data[28] = 0x20;
        original->data[29] = 0x03;
        original->data[0x320] = 'V';
        original->data[0x321] = 0;
        for (unsigned byte = 0; byte < 4; ++byte)
            original->data[16 + byte] = vectors[i] >> (8u * byte);

        /* 0x36c2 помещает число в программный стек после единицы измерения.
           0x36cc формирует полную строку по шаблону Flash 0x060f. */
        original->pc = 0x36c2;
        while (original->pc != 0x36ce && original->cycle < 2000000)
            step(original);
        if (original->pc != 0x36ce) {
            printf("%08" PRIx32 " AVR timeout PC=%04x at %" PRIu64 " cycles |%s|\n",
                   vectors[i], original->pc, (uint64_t)original->cycle,
                   (const char *)libc->data + 0x400 + 16*i);
            ++timeouts;
            uint32_t magnitude = vectors[i] & UINT32_C(0x7fffffff);
            if (reconstruction && magnitude == UINT32_C(0x7f800000)) {
                avr_t *probe = machine();
                avr_load_firmware(probe,&firmware);
                probe->data[0x601] = vectors[i] >> 31 ? 2 : 1;
                while (probe->data[0x600] != 0xa5 && probe->cycle < 2000000)
                    step(probe);
                bool agrees = probe->data[0x602] == 0x5a && probe->data[0x600] != 0xa5;
                differences += !agrees;
                printf("threshold infinity %08" PRIx32 ": %s at %" PRIu64 " cycles\n",
                       vectors[i],agrees ? "neither formatter returned" : "DIFF",(uint64_t)probe->cycle);
                avr_terminate(probe);
                free(probe);
            } else {
                ++differences;
            }
            avr_terminate(original);
            free(original);
            continue;
        }
        unsigned y = original->data[28] | (unsigned)original->data[29] << 8;
        const char *expected = (const char *)original->data + y + 6;
        assert(memchr(expected, 0, 16));
        const char *number = (const char *)libc->data + 0x400 + 16*i;
        assert(memchr(number, 0, 16));
        char actual[20];
        snprintf(actual, sizeof actual, reconstruction ? "%s" : " %9sV", number);
        bool same = strcmp(expected, actual) == 0;
        differences += !same;
        printf("%08" PRIx32 " |%s| |%s| %s\n", vectors[i], expected, actual, same ? "OK" : "DIFF");
        avr_terminate(original);
        free(original);
    }
    printf("ADC format: %zu cases, %u timeouts, %u differences\n", sizeof vectors / sizeof *vectors, timeouts, differences);
    avr_terminate(libc);
    free(libc);
    return differences ? EXIT_FAILURE : EXIT_SUCCESS;
}
