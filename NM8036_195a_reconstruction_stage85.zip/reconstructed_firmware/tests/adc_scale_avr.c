#include "nm_runtime.h"
#include "adc_scale_vectors.h"
#include <string.h>

/* Стенд запускает тот же nm_adc_scale, который входит в приложение.
 * Драйвер чтения получает байты EEPROM из текущего тестового набора. */
static uint8_t read_coefficient(void *context, uint16_t address)
{
    const uint32_t *pair = context;
    return (uint8_t)(pair[address/4] >> (8u*(address%4)));
}

int main(void)
{
    uint32_t pairs[][2] = {NM_ADC_SCALE_PAIRS};
    const int16_t counts[] = {NM_ADC_SCALE_COUNTS};
    NM8036 m = {.ee_read = read_coefficient};
    volatile uint8_t *output = (volatile uint8_t *)(uintptr_t)0x0400;
    for (unsigned i = 0; i < sizeof pairs / sizeof *pairs; ++i) {
        m.context = pairs[i];
        for (unsigned j = 0; j < sizeof counts / sizeof *counts; ++j) {
            float measured = nm_adc_scale(&m,0,counts[j]);
            uint8_t bits[4];
            memcpy(bits,&measured,sizeof bits);
            for (unsigned b = 0; b < sizeof bits; ++b)
                *output++ = bits[b];
        }
    }
    *(volatile uint8_t *)(uintptr_t)0x0600 = 0xa5;
    for (;;) {
    }
}
