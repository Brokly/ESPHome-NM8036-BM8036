/* Стенд вызывает C-форматтер, результат и завершение читает simavr. */
#include <avr/pgmspace.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "adc_format_vectors.h"
#include "nm_original_decimal.h"

#define VECTOR(bits) (uint32_t)(bits),
static const uint32_t vectors[] PROGMEM = {FORMAT_VECTORS(VECTOR)};
#undef VECTOR

int main(void)
{
    uint8_t mode = *(volatile uint8_t *)(uintptr_t)0x0601;
    if (mode) {
        uint32_t infinity = mode == 1 ? UINT32_C(0x7f800000) : UINT32_C(0xff800000);
        *(volatile uint8_t *)(uintptr_t)0x0602 = 0x5a;
        nm_avr_format_threshold((uint8_t *)(uintptr_t)0x0400,infinity,'V');
        *(volatile uint8_t *)(uintptr_t)0x0600 = 0xa5;
        for (;;) {
        }
    }
    for (uint8_t i = 0; i < sizeof vectors / sizeof *vectors; ++i) {
        uint32_t bits = pgm_read_dword(&vectors[i]);
        /* Бесконечности запускаются отдельным стендом. */
        if ((bits & UINT32_C(0x7fffffff)) == UINT32_C(0x7f800000))
            continue;
        nm_avr_format_threshold((uint8_t *)(uintptr_t)(0x400 + 16u*i),bits,'V');
    }
    *(volatile uint8_t *)(uintptr_t)0x600 = 0xa5;
    for (;;)
        ;
}
