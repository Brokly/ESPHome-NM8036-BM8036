#include "nm_original_status.h"
#include "nm_original_fragments.h"
#include "nm_original_float.h"
#include "nm_original_display_routes.h"
#include "nm_original_decimal.h"
#include "nm_program_fields.h"
#include <string.h>

/* 0x4E24–0x4E29, 0x4932–0x4939, 0x4E9C–0x4EB9.
 * Оригинал сначала округляет произведение с 5 В и затем делит
 * на 1023. Сохраняем порядок отдельных операций binary32.
 * 0x4E24 обнуляет младшее слово второго операнда. Поэтому
 * в C константы 5 и 1023 записаны полными словами binary32. */
uint32_t nm_avr_status_voltage(uint16_t raw)
{
    float input = raw;
    uint32_t word;
    memcpy(&word,&input,sizeof word);
    word = nm_avr_float_multiply(word,UINT32_C(0x40a00000));
    return nm_avr_float_divide(word,UINT32_C(0x447fc000));
}

static void voltage_arguments(uint8_t arguments[6], uint16_t integer)
{
    uint32_t word = nm_avr_status_voltage(integer);
    for (unsigned i = 0; i < 4; ++i) {
        arguments[i] = (uint8_t)word;
        word >>= 8;
    }
    arguments[4] = 0;
    arguments[5] = 0;
}

static uint16_t ram_word(const NM8036 *m, uint16_t address)
{
    return *nm_ram(m,address) | (uint16_t)*nm_ram(m,address+1) << 8;
}

/* 0x491E–0x4931. Адрес слова отсчёта начинается с 0x0677. */
uint16_t nm_avr_status_second_adc(const NM8036 *m, uint16_t index)
{
    return ram_word(m,(uint16_t)(0x0677u + 2u*index));
}

/* 0x4E44–0x4E9B. Первый формат получает float, второй получает
 * float и исходный отсчёт. Последний знак берётся из таблицы по SQW.
 * Ветка закрытия только очищает дисплей; MENU сравнивается целиком. */
bool nm_avr_status_screen(const NM8036 *m, const NMNumericDisplay *lcd,
                          bool closing, bool sqw, NMStatusFormat format)
{
    if (closing) {
        lcd->write(lcd->context,0x01,0);
        return false;
    }
    uint8_t arguments[6];
    lcd->position(lcd->context,0,0);
    voltage_arguments(arguments,ram_word(m,0x0673));
    format(lcd->context,0x0973,arguments);
    lcd->position(lcd->context,0,1);
    uint16_t raw = ram_word(m,0x0675);
    voltage_arguments(arguments,raw);
    arguments[4] = (uint8_t)raw;
    arguments[5] = (uint8_t)(raw >> 8);
    format(lcd->context,0x097e,arguments);
    format(lcd->context,sqw ? 0x098e : 0x0990,arguments);
    return *nm_ram(m,0x0739) == 5;
}

/* 0x4E2A–0x4E43. Закрытие вызывает отдельный выход редактора.
 * В рабочем режиме диспетчеру передаётся весь байт клавиши. */
bool nm_avr_program_menu(const NM8036 *m, bool closing, NMAdcSettingsStep step,
                          void (*close)(void *), void *context)
{
    if (closing) {
        close(context);
        return false;
    }
    return step(context,*nm_ram(m,0x0739)) != 0;
}

/* 0x4D3A–0x4D43, 0x4D50–0x4D63. Биты режима не являются
 * десятками часа. В 12-часовом режиме десятки задаются битом 4. */
uint8_t nm_avr_status_hour(uint8_t bcd, bool hour12, uint8_t *flags)
{
    *flags = bcd & 0x70u;
    return (uint8_t)((bcd & 15u) + 10u*((bcd >> 4) & (hour12 ? 1u : 3u)));
}

/* 0x4D94–0x4D9D. Коррекция только при переполнении DEC. */
uint8_t nm_avr_status_previous_second(uint8_t second)
{
    return second ? (uint8_t)(second - 1u) : 59;
}

/* 0x4D88–0x4D93, 0x4DCA–0x4DD9. Выделение полубайтов BCD.
 * Младшая цифра сохраняется независимо от десятков. */
uint8_t nm_avr_status_month(uint8_t bcd, uint8_t *decade)
{
    *decade = bcd >> 4;
    return bcd & 15u;
}

/* 0x4DAA–0x4DB1. Сбрасывается флаг экрана 0x0735. */
void nm_avr_status_snapshot_exit(volatile uint8_t *key)
{
    *key = 0;
}

/* 0x4168–0x4179, 0x48F0–0x48F3. Callback форматтера
 * передаёт каждый байт в LCD как данные. */
static uint16_t status_emit(void *context, uint16_t state, uint8_t byte)
{
    const NMNumericDisplay *lcd = context;
    lcd->write(lcd->context,byte,state != 0);
    return byte;
}

/* 0x4F16–0x4F19 и 0x6AE0–0x6AFD. Обычный вывод Flash-формата
 * использует состояние 0 в исходном ABI; здесь этот режим передан
 * как data=1 в интерфейсе NMNumericDisplay. */
bool nm_avr_status_flash_format(const NMNumericDisplay *lcd, const uint8_t *flash,
                                uint8_t *ram, uint16_t address, uint16_t arguments)
{
    uint16_t count;
    return nm_avr_flash_format(flash,flash+address,ram,&arguments,1,status_emit,(void *)lcd,&count);
}

/* 0x4322–0x4391. Вход родительской процедуры создаёт шкалу.
 * Слот отображается после чтения восьми байтов EEPROM и измерения.
 * Пустой ROM определяется сравнением с исходными восемью байтами
 * по 0x0667. Объект шкалы освобождается в исходном порядке. */
void nm_avr_startup_scan(const NM8036 *m, const NMOneWire *bus,
                         const NMNumericDisplay *lcd, const uint8_t *flash,
                         uint8_t *sram, NMStatusStorage storage)
{
    uint16_t scale = storage.open(lcd->context,16);
    /* open создаёт и инициализирует шкалу (0x2728). */
    nm_avr_lcd_fill_spaces(lcd,0,15,0);
    lcd->position(lcd->context,0,0);
    nm_avr_status_flash_format(lcd,flash,sram,0x07b5,0);
    for (unsigned i = 0; i < 8; ++i)
        sram[scale+2+i] = 0;
    sram[scale+6] = 32;
    nm_avr_display_field_set(sram+scale,0);

    for (uint8_t index = 0; index < 32; ++index) {
        for (uint8_t i = 0; i < 8; ++i)
            *nm_ram(m,0x0681+i) = nm_ee_read(m,0x02f0u + 8u*index + i);
        nm_avr_sample_registered(m,bus,index);
        /* 0x4368–0x437F. Выводится и номер пустого слота. */
        nm_avr_display_field_set(sram+scale,index+1u);
        nm_avr_display_redraw_bar(m,lcd,flash,sram+scale);
    }
    if (scale) {
        uint16_t snapshot = sram[scale] | (uint16_t)sram[scale+1] << 8;
        storage.restore(lcd->context,snapshot);
        storage.release(lcd->context,scale);
    }
}

/* 0x52BC–0x52C3. Первое измерение выполняется на уже выбранном
 * ROM. Ожидание PD7 остаётся блокирующим, как в оригинале. */
void nm_avr_dallas_measure_selected(const NM8036 *m, const NMOneWire *bus, int16_t *temperature)
{
    nm_dallas_configure_selected(m,bus);
    *temperature = nm_dallas_sample_selected_sync(m,bus);
}

/* 0x5052–0x50BF. Три строки выводятся до поиска. Первый поиск
 * считает ROM, затем для каждого номера повторяется поиск,
 * выполняется измерение и восемь байтов копируются в кеш.
 * Оригинал пишет по адресу, возвращённому malloc, даже при нуле. */
void nm_avr_dallas_dialog_open(const NM8036 *m, const NMOneWire *bus, const NMNumericDisplay *lcd,
                               const uint8_t *flash, uint8_t *sram, NMNumericAlloc allocate)
{
    lcd->write(lcd->context,1,0);
    lcd->position(lcd->context,1,0);
    nm_avr_status_flash_format(lcd,flash,sram,0x09a2,0);
    lcd->position(lcd->context,2,1);
    nm_avr_status_flash_format(lcd,flash,sram,0x09b1,0);

    *nm_ram(m,0x0680) = 100;
    uint8_t count = nm_dallas_search(m,bus);
    *nm_ram(m,0x0744) = count;
    uint16_t cache = allocate(lcd->context,8u*count);
    *nm_ram(m,0x0731) = (uint8_t)cache;
    *nm_ram(m,0x0732) = (uint8_t)(cache >> 8);
    *nm_ram(m,0x0680) = 0;
    while (*nm_ram(m,0x0680) < *nm_ram(m,0x0744)) {
        nm_dallas_search(m,bus);
        int16_t unused;
        nm_avr_dallas_measure_selected(m,bus,&unused);
        uint8_t index = *nm_ram(m,0x0680);
        for (uint8_t i = 0; i < 8; ++i)
            sram[cache+8u*index+i] = *nm_ram(m,0x0681u+i);
        nm_dallas_start_conversion(m,bus);
        ++*nm_ram(m,0x0680);
    }
    *nm_ram(m,0x0738) = 1;
    *nm_ram(m,0x0739) = 0xfe;
}

/* 0x4AB8–0x4AC3. При открытии редактора очищается LCD;
 * текущие данные читаются общим обработчиком следующим шагом. */
void nm_avr_rtc_menu_enter(const NMNumericDisplay *lcd, bool opening)
{
    if (opening)
        lcd->write(lcd->context,1,0);
}

/* 0x4D0C–0x4D33. Отдельно выводятся обе 16-символьные строки
 * рабочей области 34 байта. Завершение зависит от полного байта MENU. */
bool nm_avr_rtc_menu_finish(const NM8036 *m, const NMNumericDisplay *lcd, const uint8_t screen[34])
{
    lcd->position(lcd->context,0,0);
    for (const uint8_t *text = screen + 17; *text; ++text)
        lcd->write(lcd->context,*text,1);
    lcd->position(lcd->context,0,1);
    for (const uint8_t *text = screen; *text; ++text)
        lcd->write(lcd->context,*text,1);
    nm_avr_status_snapshot_exit(nm_ram(m,0x0735));
    return *nm_ram(m,0x0739) == 5;
}

/* 0x4D64–0x4D7B, 0x4DEC–0x4DFF. Десятки собираются
 * через SWAP и маску старших битов. Режим и PM сохраняются
 * в разном наборе битов при двух входах. */
uint8_t nm_avr_rtc_encode_hour(uint8_t previous, uint8_t hour, bool hour12)
{
    uint8_t high = (uint8_t)((hour/10u) << 4);
    if (hour12)
        return (previous & 0xc0u) | (high & 0x30u) | (hour%10u);
    return (previous & 0x80u) | (high & 0x70u) | (hour%10u);
}

/* 0x44FC–0x450B. При состоянии 1 запускается обработчик
 * активного меню, при прочих ненулевых байтах — общий цикл. */
uint8_t nm_avr_home_active_route(const NM8036 *m)
{
    uint8_t state = *nm_ram(m,0x073a);
    return state < 2 ? state : 2;
}

/* 0x50BE–0x50D3. 0 — пустой список, 1 — первая отрисовка
 * после поиска, 2 — последующие действия выбора. */
uint8_t nm_avr_dallas_dialog_route(const NM8036 *m)
{
    if (*nm_ram(m,0x0744))
        return 2;
    return *nm_ram(m,0x0739) == 0xfe;
}

static void rtc_argument(uint8_t *ram, uint16_t address, uint16_t value)
{
    ram[address] = (uint8_t)value;
    ram[address+1] = (uint8_t)(value >> 8);
}

/* 0x4C6C–0x4CAB, 0x4D34–0x4D39, 0x4D88–0x4D93,
 * 0x4DCA–0x4DD9, 0x4E00–0x4E23.
 * Для месяца 0x4E24 очищает аргумент перед переносом бита T
 * в разряд 0. В C маска выделяет только разряд десятков.
 * Строки строятся последовательно, поэтому более поздний фрагмент
 * заменяет терминатор предыдущего. Границы и таблицы взяты из Flash. */
void nm_avr_status_rtc_rows(const NM8036 *m, const uint8_t *flash, uint8_t *ram, uint16_t frame)
{
    uint16_t count;
    uint16_t args = frame - 6;
    uint8_t seconds = *nm_ram(m,0x0727);
    uint8_t minutes = *nm_ram(m,0x0728);
    uint8_t hours = *nm_ram(m,0x0729);
    rtc_argument(ram,args,(hours & 15u) + 10u*((hours >> 4) & 3u));
    rtc_argument(ram,args+2,(minutes & 15u) + 10u*((minutes >> 4) & 7u));
    rtc_argument(ram,args+4,(seconds & 15u) + 10u*((seconds >> 4) & 7u));
    nm_avr_flash_sprintf(flash,0x07ec,ram,args,frame+17,&count);

    uint8_t weekday = *nm_ram(m,0x072a) & 7u;
    nm_avr_flash_sprintf(flash,0x0b58u+8u*weekday,ram,args,frame+26,&count);

    uint8_t day = *nm_ram(m,0x072b);
    rtc_argument(ram,args,(day & 15u) + 10u*((day >> 4) & 3u));
    nm_avr_flash_sprintf(flash,0x07fb,ram,args,frame,&count);

    uint8_t month = *nm_ram(m,0x072c);
    nm_avr_flash_sprintf(flash,0x0aebu+9u*(10u*((month >> 4) & 1u)+(month & 15u)),
                         ram,args,frame+3,&count);

    uint8_t year = *nm_ram(m,0x072d);
    rtc_argument(ram,args,(year & 15u) + 10u*(year >> 4));
    nm_avr_flash_sprintf(flash,0x0800,ram,args,frame+11,&count);
}

/* 0x4CDA–0x4D0B. На фазе мигания поле затеняется пробелами
 * перед передачей обеих строк. Длины для дня и года различны. */
void nm_avr_status_rtc_highlight(uint8_t *ram, uint16_t frame, uint8_t field)
{
    static const uint8_t offsets[] = {17,20,23,26,0,3,12};
    static const uint8_t widths[] = {2,2,2,7,2,8,4};
    if (field < sizeof offsets)
        memset(ram+frame+offsets[field],' ',widths[field]);
}

/* 0x2CB8–0x2CCD, 0x2CEA–0x2D03 и 0x22EA–0x22FD.
 * Снимок LCD прикрепляется только после успешного выделения 10 байт.
 * Байт +9 конкретного объекта обнуляется независимо от снимка. */
uint16_t nm_avr_status_object_open(const NMNumericDisplay *lcd, uint8_t *ram,
                                    NMNumericAlloc allocate, NMNumericSnapshot snapshot)
{
    uint16_t object = allocate(lcd->context,10);
    if (object) {
        rtc_argument(ram,object,snapshot(lcd->context));
        ram[object+9] = 0;
    }
    return object;
}

/* 0x2CCE–0x2CE9, 0x22FE–0x2307, 0x62EC–0x62F7.
 * Восстановление LCD предшествует освобождению объекта. */
void nm_avr_status_object_close(const NMNumericDisplay *lcd, const uint8_t *ram,
                                 uint16_t object, NMNumericRestore restore, NMNumericRestore release)
{
    if (object) {
        uint16_t snapshot = ram[object] | (uint16_t)ram[object+1] << 8;
        restore(lcd->context,snapshot);
        release(lcd->context,object);
    }
}

/* 0x3A66–0x3A69, 0x3AD4–0x3AD9, 0x3ABE–0x3ACA.
 * Экран выбора печатает номер с единицы в начале второй строки. */
void nm_avr_program_source_line(const NMNumericDisplay *lcd, const uint8_t *flash,
                                uint8_t *ram, uint16_t format, uint8_t number)
{
    rtc_argument(ram,0,(uint16_t)number+1u);
    nm_avr_status_flash_format(lcd,flash,ram,format,0);
    lcd->position(lcd->context,0,1);
}

/* 0x30B2–0x30D9, 0x3A66–0x3A7B, 0x3AB8–0x3AD9.
 * При первом входе выводятся номер программы и надпись «старт».
 * При последующих обновлениях меняется строка включения программы. */
bool nm_avr_program_initial_screen(const NM8036 *m, const NMNumericDisplay *lcd,
                                     const uint8_t *flash, uint8_t *ram, bool opening)
{
    if (opening) {
        lcd->write(lcd->context,1,0);
        lcd->position(lcd->context,0,0);
        rtc_argument(ram,0,nm_avr_program_number(*nm_ram(m,0x06b4)));
        nm_avr_status_flash_format(lcd,flash,ram,0x0557,0);
        lcd->position(lcd->context,3,0);
        nm_avr_status_flash_format(lcd,flash,ram,0x0561,0);
    }
    lcd->position(lcd->context,0,1);
    bool enabled = (nm_avr_program_selected_byte(m,3) & 0x80u) != 0;
    if (!opening)
        nm_avr_status_flash_format(lcd,flash,ram,enabled ? 0x0535 : 0x0546,0);
    return enabled;
}

/* 0x3754–0x3775. Флаг 0x0735 разрешает единовременную
 * перерисовку, а EEPROM +12 выбирает И либо ИЛИ. */
void nm_avr_program_logic_screen(const NM8036 *m, const NMNumericDisplay *lcd,
                                  const uint8_t *flash, uint8_t *ram)
{
    if (!*nm_ram(m,0x0735))
        return;
    lcd->position(lcd->context,0,0);
    nm_avr_status_flash_format(lcd,flash,ram,0x0628,0);
    lcd->position(lcd->context,0,1);
    bool conjunction = (nm_avr_program_selected_byte(m,12) & 0x80u) != 0;
    nm_avr_status_flash_format(lcd,flash,ram,conjunction ? 0x064a : 0x0639,0);
    *nm_ram(m,0x0735) = 0;
}

/* 0x54BC–0x54D5. Для обработки кадра требуется результат 1.
 * Остальные статусы возвращают управление в приёмный цикл. */
void nm_avr_status_uart_frame(uint8_t *frame, uint8_t (*receive)(void *, uint8_t *),
                               void (*dispatch)(void *, uint8_t), void *context)
{
    if (receive(context,frame) == 1)
        dispatch(context,frame[0]);
}

/* 0x5336–0x5345, 0x53F4–0x5403, 0x53CC–0x53D9,
 * 0x547A–0x5485, 0x54A8–0x54BB. После создания шкалы
 * указатель виден диспетчеру настроек по 0x0733. Нижняя граница
 * равна 100 для контраста и 0 для подсветки, верхняя 255. */
uint16_t nm_avr_pwm_begin_display(const NMNumericDisplay *lcd, const uint8_t *flash,
                                   uint8_t *ram, bool contrast, NMNumericAlloc allocate,
                                   NMNumericSnapshot snapshot)
{
    uint16_t field = nm_avr_display_bar_open(lcd,ram,flash,allocate,snapshot);
    rtc_argument(ram,0x0733,field);
    nm_avr_lcd_fill_spaces(lcd,0,15,0);
    lcd->position(lcd->context,0,0);
    nm_avr_status_flash_format(lcd,flash,ram,contrast ? 0x0a09 : 0x09fd,0);
    nm_avr_display_field_limits(ram+field,contrast ? 100 : 0,255);
    return field;
}
