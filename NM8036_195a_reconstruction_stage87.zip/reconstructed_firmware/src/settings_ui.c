#include "nm_menu.h"
#include "nm_editors.h"
#include "nm_dallas.h"
#include "nm_peripherals.h"
#include "nm_runtime.h"

#ifdef __AVR__
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdlib.h>
#include <string.h>

/* Собственная C-обвязка для списка и восстановленных экранов.
 * Идентификаторы пунктов берутся из таблиц flash 0x0C0A/0x0C26. */
enum { SETTINGS_LIST, SETTINGS_PWM, SETTINGS_SOUND, SETTINGS_CLOCK, SETTINGS_DALLAS, SETTINGS_PROGRAM,
       SETTINGS_OUTPUT_LIST, SETTINGS_OUTPUT_VALUE, SETTINGS_MANUAL, SETTINGS_PROGRAM_ENABLE,
       SETTINGS_PROGRAM_START, SETTINGS_PROGRAM_STOP, SETTINGS_PROGRAM_CONTROL,
       SETTINGS_PROGRAM_COMPARE, SETTINGS_PROGRAM_REFERENCE, SETTINGS_PROGRAM_THRESHOLDS,
       SETTINGS_PROGRAM_LOGIC, SETTINGS_PROGRAM_PERIOD };
static NMSettingsMenu list, output_list;
static uint16_t output_seconds;
static uint8_t view;
static NMPwmSetting setting;
static uint8_t found_rom[NM_RECORDS][8], ordinal, slot, found;
static uint8_t preview[2];
static bool preview_visible;
static NMProgramEditor program_editor;

static void draw(const NM8036 *m, const uint8_t screen[32])
{
    for (uint8_t row = 0; row < 2; row++)
        nm_atmega32_lcd_text(m, row, 0, screen + 16u * row, 16);
}

/* [БИНАРНИК] Список 0x0240, 24 записи по 17 байт.
 * Заголовок ввода 0x022F. Перенос содержимого DDRAM, положение
 * числового поля уточняется при проверке LCD на оригинале. */
static void draw_output(const NM8036 *m)
{
    static const uint8_t title[] = {0xc2,0xe2,0xe5,0xe4,0xe8,0xf2,0xe5,' ',
                                    0xe2,0xf0,0xe5,0xec,0xff,'(',0xf1,')'};
    uint8_t screen[32];
    memset(screen, ' ', sizeof screen);
    if (view == SETTINGS_OUTPUT_LIST) {
        nm_output_menu_screen(&output_list, screen);
    } else {
        memcpy(screen, title, sizeof title);
        uint16_t value = output_seconds;
        uint8_t col = 23;
        do {
            screen[col--] = '0' + value % 10u;
            value /= 10u;
        } while (value);
    }
    draw(m, screen);
}

/* [БИНАРНИК] 0x5236..0x525E. Номер хранится в 0x0680,
 * копия ROM выбирает адресат Match ROM. Проба использует отдельные
 * два байта, чтобы не портить данные, доступные планировщику. */
static void select_sensor(const NM8036 *m)
{
    *nm_ram(m, 0x0680) = ordinal;
    for (uint8_t i = 0; i < 8; i++)
        *nm_ram(m, 0x0681 + i) = found_rom[ordinal][i];
    nm_dallas_start_conversion(m, &nm_atmega32_onewire);
    preview_visible = false;
}

static bool rom_registered(const NM8036 *m, const uint8_t rom[8])
{
    for (uint8_t i = 0; i < 8; i++)
        if (nm_ee_read(m, 0x02f0u + 8u * slot + i) != rom[i])
            return false;
    return true;
}

/* Строки flash 0x09BE, 0x09CB, 0x09DA, 0x09E3, 0x09F5.
 * Сохраняем кодировку LCD. Живой результат — T=%5.1f. */
static void sensor_screen(const NM8036 *m)
{
    static const uint8_t assign[] = {0xcd,0xe0,0xe7,0xed,0xe0,0xf7,0xe8,0xf2,0xfc,' ','N','o',' '};
    uint8_t screen[32];
    memset(screen, ' ', sizeof screen);
    memcpy(screen + 16, assign, sizeof assign);
    uint8_t number = slot + 1;
    if (number >= 10)
        screen[29] = '0' + number / 10;
    screen[number >= 10 ? 30 : 29] = '0' + number % 10;
    number = ordinal + 1;
    screen[10] = number < 10 ? ' ' : '0' + number / 10;
    screen[11] = '0' + number % 10;
    screen[12] = '/';
    screen[13] = '0' + found / 10;
    screen[14] = '0' + found % 10;
    screen[15] = rom_registered(m, found_rom[ordinal]) ? 'M' : '-';
    if (preview_visible) {
        int16_t raw = (int16_t)((uint16_t)preview[0] | ((uint16_t)preview[1] << 8));
        uint16_t tenths = ((uint16_t)(raw < 0 ? -(int32_t)raw : raw) + 5u) / 10u;
        screen[0] = 'T';
        screen[1] = '=';
        screen[5] = '.';
        screen[6] = '0' + tenths % 10u;
        tenths /= 10u;
        uint8_t col = 4;
        do {
            screen[col--] = '0' + tenths % 10u;
            tenths /= 10u;
        } while (tenths && col > 1);
        if (raw < 0 && col > 1)
            screen[col] = '-';
    }
    draw(m, screen);
}

/* [БИНАРНИК] 0x505A..0x50BE. Поиск и кеширование выполняются
 * при входе. Фоновый опрос приостановлен, пока диалог владеет шиной. */
static void discover_sensors(const NM8036 *m)
{
    static const uint8_t searching[] = {0xcf,0xee,0xe8,0xf1,0xea,' ',0xe4,0xe0,0xf2,0xf7,0xe8,0xea,0xee,0xe2};
    static const uint8_t waiting[] = {0xef,0xee,0xe4,0xee,0xe6,0xe4,0xe8,0xf2,0xe5,'.','.','.'};
    nm_atmega32_lcd_clear(m);
    nm_atmega32_lcd_text(m, 0, 1, searching, sizeof searching);
    nm_atmega32_lcd_text(m, 1, 2, waiting, sizeof waiting);
    *nm_ram(m, 0x0738) = 1;
    nm_atmega32_onewire.strong_pullup(nm_atmega32_onewire.context, false);
    uint8_t count = nm_dallas_discovery_count(m, &nm_atmega32_onewire);
    if (count > NM_RECORDS)
        count = NM_RECORDS;
    found = 0;
    while (found < count &&
           nm_dallas_discovery_rom(m, &nm_atmega32_onewire, found, found_rom[found])) {
        /* 0x508C вызывает настройку и блокирующую пробу.
         * Проба запускает первое измерение, результат здесь отбрасывается.
         * После кеширования ROM 0x50A0 снова запускает измерение. */
        nm_dallas_configure_selected(m, &nm_atmega32_onewire);
        (void)nm_dallas_sample_selected_sync(m, &nm_atmega32_onewire);
        nm_dallas_start_conversion(m, &nm_atmega32_onewire);
        found++;
    }
    *nm_ram(m, 0x0744) = found;
    ordinal = slot = 0;
    *nm_ram(m, 0x0743) = 0;
    if (found) {
        uint8_t match = nm_dallas_dialog_match(m, slot, found_rom, found);
        if (match != 0xff)
            ordinal = match;
        nm_atmega32_onewire.strong_pullup(nm_atmega32_onewire.context, false);
        select_sensor(m);
        sensor_screen(m);
    }
}

/* [БИНАРНИК] 0x5104..0x5157. Индекс ROM насыщается на краях,
 * номер назначения циклический. Сравнение ROM для отметки M
 * выполняется и при смене номера, до записи. */
static bool sensor_key(const NM8036 *m, uint8_t key)
{
    if (!found)
        return false;
    uint8_t previous = ordinal;
    if (key == 1 && ordinal + 1u < found)
        ordinal++;
    else if (key == 4 && ordinal)
        ordinal--;
    else if (key == 2 || key == 3) {
        slot = (uint8_t)((slot + (key == 2 ? 31u : 1u)) & 31u);
        *nm_ram(m, 0x0743) = slot;
    } else if (key == 0) {
        /* 0x5158 не проверяет CRC ROM перед записью.
         * Вариант с проверкой доступен отдельной функцией. */
        (void)nm_dallas_store_rom_raw(m, slot, found_rom[ordinal]);
    }
    if (key != 0xff) {
        uint8_t match = nm_dallas_dialog_match(m, slot, found_rom, found);
        if (match != 0xff)
            ordinal = match;
    }
    if (previous != ordinal) {
        nm_atmega32_onewire.strong_pullup(nm_atmega32_onewire.context, false);
        select_sensor(m);
    }
    return key <= 4;
}

static void draw_program_condition(const NM8036 *m, uint16_t base, uint8_t period_item)
{
    static const uint8_t logic[] PROGMEM = {0xd0,0xe5,0xe6,0xe8,0xec,' ',0xe0,0xea,0xf2,0xe8,0xe2,0xed,0xee,0xf1,0xf2,0xe8};
    uint8_t screen[32];
    memset(screen, ' ', sizeof screen);
    if (view == SETTINGS_PROGRAM_COMPARE) {
        nm_program_compare_screen(m, *nm_ram(m, 0x06b4), screen);
    } else if (view == SETTINGS_PROGRAM_REFERENCE) {
        nm_program_reference_screen(m, *nm_ram(m, 0x06b4), screen);
    } else if (view == SETTINGS_PROGRAM_THRESHOLDS) {
        nm_program_threshold_screen(m, *nm_ram(m, 0x06b4), &program_editor.thresholds,
                                    (PIND & _BV(PD2)) != 0, screen);
    } else if (view == SETTINGS_PROGRAM_LOGIC) {
        memcpy_P(screen, logic, sizeof logic);
        static const uint8_t or_text[] PROGMEM = {0xcb,0xce,0xc3,0xc8,0xd7,0xc5,0xd1,0xca,0xce,0xc5,' ','"',0xc8,0xcb,0xc8,'"'};
        static const uint8_t and_text[] PROGMEM = {' ',0xcb,0xce,0xc3,0xc8,0xd7,0xc5,0xd1,0xca,0xce,0xc5,' ','"',0xc8,'"',' '};
        memcpy_P(screen + 16, nm_ee_read(m, base + 12u) & 0x80u ? and_text : or_text, 16);
    } else {
        nm_program_period_screen(m, *nm_ram(m, 0x06b4), period_item, screen);
    }
    draw(m, screen);
}

static void draw_program(const NM8036 *m, uint8_t index, uint8_t key, uint8_t period_item)
{
    if (view >= SETTINGS_PROGRAM_COMPARE) {
        draw_program_condition(m, 0x4cu + 21u * index, period_item);
        return;
    }
    uint8_t screen[32];
    bool sqw = (PIND & _BV(PD2)) != 0;
    if (view == SETTINGS_PROGRAM)
        nm_program_overview(m, index, screen);
    else if (view == SETTINGS_PROGRAM_ENABLE)
        nm_program_enable_screen(m, index, screen);
    else if (view == SETTINGS_PROGRAM_CONTROL)
        nm_program_control_screen(m, index, sqw, key, screen);
    else
        nm_program_calendar_screen(&program_editor.time, view == SETTINGS_PROGRAM_STOP,
                                   index, sqw, key, screen);
    draw(m, screen);
}

/* Строка flash 0x0992 и знак 0 из CGRAM, 0x4FC0..0x5004. */
static void draw_manual_outputs(const NM8036 *m)
{
    uint8_t screen[32];
    nm_manual_outputs_screen(m, screen);
    draw(m, screen);
}

/* Возвращает false для ещё не восстановленного редактора.
 * Список остаётся на выбранной строке для следующей клавиши. */
bool nm_atmega32_settings_step(NM8036 *m)
{
    volatile uint8_t *visible = nm_ram(m, 0x073a);
    uint8_t key = *nm_ram(m, 0x0739);
    if (!*visible) {
        if ((key & 15u) != 5)
            return false;
        *visible = 1;
        list = (NMSettingsMenu){0};
        view = SETTINGS_LIST;
        nm_atmega32_settings_menu_glyphs(m);
        nm_atmega32_settings_menu_draw(m, &list);
        return true;
    }
    bool opening = view == SETTINGS_LIST;
    if (view >= SETTINGS_PROGRAM_START || view == SETTINGS_PROGRAM_ENABLE ||
        view == SETTINGS_PROGRAM) {
        uint8_t period_item = *nm_ram(m, 0x06b8);
        if (nm_program_editor_step(m, &program_editor, key)) {
            view = SETTINGS_LIST;
            nm_atmega32_settings_menu_draw(m, &list);
            return true;
        }
        static const uint8_t screen_for_state[] PROGMEM = {
            SETTINGS_PROGRAM, SETTINGS_PROGRAM_ENABLE, SETTINGS_PROGRAM_START,
            SETTINGS_PROGRAM_STOP, SETTINGS_PROGRAM_CONTROL, SETTINGS_PROGRAM_COMPARE,
            SETTINGS_PROGRAM_REFERENCE, SETTINGS_PROGRAM_THRESHOLDS,
            SETTINGS_PROGRAM_LOGIC, SETTINGS_PROGRAM_PERIOD,
        };
        view = pgm_read_byte(screen_for_state + *nm_ram(m, 0x06b6));
        uint8_t index = *nm_ram(m, 0x06b4);
        /* 0x381C, 0x38BC и 0x38D8 печатают название до
         * изменения номера. Знак в 0x389A читает уже новый бит. */
        if ((key & 15u) != 1 && (key & 15u) != 4)
            period_item = *nm_ram(m, 0x06b8);
        if (key != 0xff || *nm_ram(m, 0x0735))
            draw_program(m, index, key, period_item);
        *nm_ram(m, 0x0735) = 0;
        return true;
    }
    if (view == SETTINGS_MANUAL) {
        if (key != 0xff) {
            if (nm_manual_outputs_key(m, key)) {
                view = SETTINGS_LIST;
                nm_atmega32_settings_menu_draw(m, &list);
            } else
                draw_manual_outputs(m);
        }
        return true;
    }
    if (view == SETTINGS_OUTPUT_LIST || view == SETTINGS_OUTPUT_VALUE) {
        if (key == 0xff)
            return true;
        uint8_t row = nm_settings_menu_selection(&output_list);
        if (view == SETTINGS_OUTPUT_VALUE) {
            /* 0x26EE. Пока редактор возвращает 0, EEPROM не меняется. */
            if (nm_output_editor_key(row, &output_seconds, key)) {
                nm_output_save_duration(m, row, output_seconds);
                view = SETTINGS_OUTPUT_LIST;
            }
        } else {
            switch (key & 15u) {
            case 5:
                view = SETTINGS_LIST;
                nm_atmega32_settings_menu_glyphs(m);
                nm_atmega32_settings_menu_draw(m, &list);
                return true;
            case 1: case 4:
                nm_menu_move(&output_list, (key & 15u) == 1 ? -1 : 1, 24);
                break;
            case 0:
                output_seconds = nm_output_duration(m, row);
                view = SETTINGS_OUTPUT_VALUE;
                break;
            }
        }
        draw_output(m);
        return true;
    }
    if (view == SETTINGS_LIST) {
        switch (key & 15u) {
        case 5:
            *visible = 0;
            *nm_ram(m, 0x073f) = 0;
            return true;
        case 1: case 4:
            nm_settings_menu_move(&list, (key & 15u) == 1 ? -1 : 1);
            nm_atmega32_settings_menu_draw(m, &list);
            return true;
        case 0: {
            uint8_t selected = nm_settings_menu_selection(&list);
            if (selected == 7 || selected == 8) {
                setting = selected == 7 ? NM_EDIT_BACKLIGHT : NM_EDIT_CONTRAST;
                nm_pwm_editor_open(m, setting);
                view = SETTINGS_PWM;
            } else if (selected == 9) {
                view = SETTINGS_SOUND;
            } else if (selected == 0) {
                view = SETTINGS_CLOCK;
                nm_atmega32_refresh_clock(m);
            } else if (selected == 1) {
                uint8_t screen[32];
                nm_program_editor_open(m);
                view = SETTINGS_PROGRAM;
                nm_program_overview(m, 0, screen);
                draw(m, screen);
                return true;
            } else if (selected == 5) {
                view = SETTINGS_OUTPUT_LIST;
                output_list = (NMSettingsMenu){0};
                draw_output(m);
                return true;
            } else if (selected == 6) {
                view = SETTINGS_MANUAL;
                nm_manual_outputs_open(m);
                draw_manual_outputs(m);
                return true;
            } else if (selected == 2) {
                view = SETTINGS_DALLAS;
                discover_sensors(m);
                return true;
            } else {
                return false;
            }
            key = 0xff;
            break;
        }
        default:
            return true;
        }
    }

    if (!opening && key == 0xff &&
        (view != SETTINGS_DALLAS && (view != SETTINGS_CLOCK || !*nm_ram(m, 0x0735))))
        return true;
    uint8_t screen[32];
    bool done = false;
    if (view == SETTINGS_PWM) {
        done = nm_pwm_editor_key(m, setting, key) != NM_EDIT_ACTIVE;
        nm_pwm_editor_screen(m, setting, screen);
    } else if (view == SETTINGS_SOUND) {
        done = nm_sound_editor_key(m, key);
        nm_sound_editor_screen(m, screen);
    } else if (view == SETTINGS_CLOCK) {
        done = nm_clock_editor_key(m, key);
        nm_home_clock_screen(m, screen);
        /* [БИНАРНИК] 0x4CAC..0x4D0B. Гашение выбранного поля
         * на низкой фазе SQW, кроме непосредственного изменения. */
        if (!done && !(PIND & _BV(PD2)) && (key & 15u) != 1 && (key & 15u) != 4) {
            static const uint8_t start[] = {0,3,6,9,16,19,28};
            static const uint8_t width[] = {2,2,2,7,2,8,4};
            uint8_t field = *nm_ram(m, 0x0740);
            memset(screen + start[field], ' ', width[field]);
        }
        *nm_ram(m, 0x0735) = 0;
    } else {
        /* 0x50D4–0x5102: на следующем вызове пустая шина
         * завершает диалог сама. Задержка AVR составляет 1 999 994
         * тактов в цикле, без учёта двух завершающих инструкций. */
        if (!found) {
            static const uint8_t empty1[] = {0xc2,0xee,0xe7,0xec,0xee,0xe6,0xed,0xee,' ',0xf7,0xf2,0xee};
            static const uint8_t empty2[] = {0xe4,0xe0,0xf2,0xf7,0xe8,0xea,0xee,0xe2,' ',0xed,0xe5,0xf2,':','('};
            nm_atmega32_lcd_clear(m);
            nm_atmega32_lcd_text(m, 0, 0, empty1, sizeof empty1);
            nm_atmega32_lcd_text(m, 1, 0, empty2, sizeof empty2);
            __builtin_avr_delay_cycles(1999997);
        } else if (key != 5) {
            bool redraw = sensor_key(m, key);
            /* [БИНАРНИК] 0x5248..0x525E. Только валидный кадр
             * запускает следующее измерение и обновляет текст. */
            uint8_t frame[2];
            if (nm_dallas_poll_sample(m, &nm_atmega32_onewire, frame) == NM_DALLAS_SAMPLE) {
                nm_dallas_start_conversion(m, &nm_atmega32_onewire);
                memcpy(preview, frame, sizeof preview);
                preview_visible = redraw = true;
            }
            if (redraw)
                sensor_screen(m);
            return true;
        } else {
            nm_atmega32_onewire.strong_pullup(nm_atmega32_onewire.context, false);
            if (nm_dallas_load_rom(m, *nm_ram(m, 0x073e)))
                nm_dallas_start_conversion(m, &nm_atmega32_onewire);
        }
        *nm_ram(m, 0x0738) = 0;
        done = true;
    }
    if (done) {
        view = SETTINGS_LIST;
        nm_atmega32_settings_menu_draw(m, &list);
    } else {
        draw(m, screen);
    }
    return true;
}
#endif
