/* Исполняем настоящее меню AVR, пустую шину моделирует наблюдатель. */
#include "nm_runtime.h"
#include "nm_dallas.h"
#include "nm_menu.h"
#include "nm_peripherals.h"

int main(void)
{
    NM8036 device = nm_atmega32_device();
    static const uint8_t keys[] = {5, 4, 4, 0, 0xff};
    volatile uint8_t *result = nm_ram(&device, 0x0850);
    for (uint8_t i = 0; i < sizeof keys; ++i) {
        *nm_ram(&device, 0x0739) = keys[i];
        if (!nm_atmega32_settings_step(&device))
            *result = 0xee;
        if (i == 3) {
            result[1] = *nm_ram(&device, 0x0738);
            result[2] = *nm_ram(&device, 0x0744);
            result[3] = *nm_ram(&device, 0x0743);
            *result = 0x41;
        }
    }
    result[4] = *nm_ram(&device, 0x0738);
    result[5] = *nm_ram(&device, 0x0680);
    *nm_ram(&device, 0x073e) = 5;
    for (uint8_t slot = 0; slot < 32; ++slot)
        *nm_ram(&device, 0x0707 + slot) = 0x77;
    *result = 0x42;
    nm_dallas_poll_registered(&device, &nm_atmega32_onewire);
    *result = 0xa5;
    for (;;)
        ;
}
