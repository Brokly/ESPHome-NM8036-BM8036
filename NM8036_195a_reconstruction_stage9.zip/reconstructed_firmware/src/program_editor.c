#include "nm_editors.h"
#include "nm_runtime.h"
#include <string.h>
#ifdef __AVR__
#include <stdlib.h>
#else
#include <stdio.h>
#endif

/* [БИНАРНИК] 0x3012, вход в список с нулевым индексом. */
void nm_program_editor_open(const NM8036 *m)
{
    *nm_ram(m, 0x06b4) = 0;
    *nm_ram(m, 0x06b6) = NM_PROGRAM_LIST;
}

/* Рабочие пороги оригинала переживают выход из редактора.
 * Прямой переход 0x33FC использует их без чтения EEPROM. */
static void threshold_buffer(const NM8036 *m, NMThresholds *thresholds, bool load)
{
    volatile uint8_t *p = nm_ram(m, 0x06b0);
    for (uint8_t i = 0; i < 2; i++, p += 2) {
        if (load)
            thresholds->value[i] = (int16_t)(p[0] | ((uint16_t)p[1] << 8));
        else {
            uint16_t value = (uint16_t)thresholds->value[i];
            p[0] = (uint8_t)value;
            p[1] = value >> 8;
        }
    }
}

/* [БИНАРНИК] 0x301A..0x3040, 0x3810..0x3818. Номер
 * состояния в SRAM 0x06B6 выбирает ветвь таблицы 0x0BF0.
 * Отдельно учитываются младший полубайт клавиши и полный код. */
bool nm_program_editor_step(const NM8036 *m, NMProgramEditor *editor, uint8_t key)
{
    uint8_t saved = m->irq_disable(m->context);
    uint8_t view = *nm_ram(m, 0x06b6);
    uint8_t index = *nm_ram(m, 0x06b4);
    uint8_t action = key & 15u;
    if (view == NM_PROGRAM_LIST) {
        if (action == 5) {
            m->irq_restore(m->context, saved);
            return true;
        }
        if (action == 0)
            view = NM_PROGRAM_ENABLE;
        else
            (void)nm_program_select(m, key);
    } else if (view == NM_PROGRAM_ENABLE) {
        if (action >= 1 && action <= 4)
            nm_program_toggle(m, index);
        else if (key == 5 || (action == 0 && !nm_program_enabled(m, index)))
            view = NM_PROGRAM_LIST;
        else if (action == 0) {
            nm_program_time_load(m, index, false, &editor->time);
            view = NM_PROGRAM_START;
        }
    } else if (view == NM_PROGRAM_CONTROL) {
        if (key == 5)
            view = NM_PROGRAM_LIST;
        else if (action == 2 || action == 3)
            *nm_ram(m, 0x06b5) = (*nm_ram(m, 0x06b5) + (action == 2 ? 3u : 1u)) & 3u;
        else if (action == 1 || action == 4) {
            switch (*nm_ram(m, 0x06b5)) {
            case 0: nm_program_output_key(m, index, key); break;
            case 1: nm_program_kind_key(m, index, key); break;
            case 2: nm_program_sensor_key(m, index, key); break;
            case 3: nm_program_source_key(m, index, key); break;
            }
        } else if (key == 0) {
            uint8_t next = nm_program_control_confirm(m, index);
            if (next == 8)
                view = NM_PROGRAM_LOGIC;
            else if (next == 7) {
                editor->thresholds.analog = true;
                threshold_buffer(m, &editor->thresholds, true);
                view = NM_PROGRAM_THRESHOLDS;
            } else
                view = NM_PROGRAM_COMPARE;
        }
    } else if (view >= NM_PROGRAM_COMPARE && view <= NM_PROGRAM_PERIOD) {
        uint16_t base = 0x4cu + 21u * index;
        /* 0x3776: на экране И/ИЛИ MENU оставляет состояние 8. */
        if (key == 5 && view != NM_PROGRAM_LOGIC) {
            view = NM_PROGRAM_LIST;
        } else if (view == NM_PROGRAM_COMPARE) {
            if (action == 1 || action == 4)
                nm_program_relative_toggle(m, index);
            else if (key == 0) {
                if (nm_ee_read(m, base + 6u) & 0x20u)
                    view = NM_PROGRAM_REFERENCE;
                else {
                    nm_program_thresholds_load(m, index, &editor->thresholds);
                    threshold_buffer(m, &editor->thresholds, false);
                    view = NM_PROGRAM_THRESHOLDS;
                }
            }
        } else if (view == NM_PROGRAM_REFERENCE) {
            nm_program_reference_key(m, index, key);
            if (key == 0)
                view = NM_PROGRAM_LOGIC;
        } else if (view == NM_PROGRAM_THRESHOLDS) {
            editor->thresholds.selected = *nm_ram(m, 0x06b5) & 1u;
            nm_program_threshold_key(&editor->thresholds, key);
            threshold_buffer(m, &editor->thresholds, false);
            *nm_ram(m, 0x06b5) = editor->thresholds.selected;
            if (key == 0) {
                nm_program_thresholds_save(m, index, &editor->thresholds);
                view = NM_PROGRAM_LOGIC;
            }
        } else if (view == NM_PROGRAM_LOGIC) {
            if (action == 1 || action == 4)
                nm_program_logic_toggle(m, index);
            else if (key == 0) {
                view = NM_PROGRAM_PERIOD;
            }
        } else {
            uint8_t period = nm_program_period_key(m, index, key);
            if (!period && key == 0)
                view = NM_PROGRAM_LIST;
            else
                nm_program_period_item(m, index, period, key);
        }
    } else if (view == NM_PROGRAM_START || view == NM_PROGRAM_STOP) {
        nm_program_time_key(&editor->time, key);
        if (key == 5)
            view = NM_PROGRAM_LIST;
        else if (key == 0) {
            bool stop = view == NM_PROGRAM_STOP;
            nm_program_time_save(m, index, stop, &editor->time);
            if (stop) {
                view = NM_PROGRAM_CONTROL;
                *nm_ram(m, 0x06b5) = 0;
            } else {
                /* 0x3174..0x3198 обновляет поля того же окна, +9 остаётся. */
                uint8_t cursor = editor->time.cursor;
                nm_program_time_load(m, index, true, &editor->time);
                editor->time.cursor = cursor;
                view = NM_PROGRAM_STOP;
            }
        }
    }
    *nm_ram(m, 0x06b6) = view;
    m->irq_restore(m->context, saved);
    return false;
}

/* [БИНАРНИК] 0x306E..0x3084, шаблоны 0x0528/0x0535/0x0546. */
void nm_program_enable_screen(const NM8036 *m, uint8_t index, uint8_t screen[32])
{
    static const uint8_t title[] = {0xd8,0xc0,0xc3};
    static const uint8_t on[] = {0xc2,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
    static const uint8_t off[] = {0xc2,0xfb,0xea,0xeb,0xfe,0xf7,0xe5,0xed};
    for (uint8_t i = 0; i < 32; i++)
        screen[i] = ' ';
    for (uint8_t i = 0; i < sizeof title; i++)
        screen[5+i] = title[i];
    uint8_t number = index + 1u;
    screen[9] = number < 10 ? ' ' : '0' + number / 10u;
    screen[10] = '0' + number % 10u;
    bool enabled = nm_program_enabled(m, index);
    const uint8_t *label = enabled ? on : off;
    uint8_t length = enabled ? sizeof on : sizeof off;
    for (uint8_t i = 0; i < length; i++)
        screen[20+i] = label[i];
}

static void lcd_two_digits(uint8_t *p, uint8_t value, bool pad)
{
    p[0] = value < 10 && !pad ? ' ' : '0' + value / 10u;
    p[1] = '0' + value % 10u;
}

/* [БИНАРНИК] 0x2D04..0x2DC8. Форматы 0x04B9 и 0x04C8
 * помещаются в правые колонки двух строк. Горизонтальное
 * перемещение курсора временно отменяет скрытие поля. */
void nm_program_calendar_screen(const NMProgramTime *time, bool stop, uint8_t index,
                                bool sqw, uint8_t key, uint8_t screen[32])
{
    static const uint8_t labels[2][5] = {
        {0xf1,0xf2,0xe0,0xf0,0xf2}, {0xf1,0xf2,0xee,0xef,' '}
    };
    static const uint8_t columns[] = {8, 11, 14, 22, 25, 30};
    for (uint8_t i = 0; i < 32; i++)
        screen[i] = ' ';
    lcd_two_digits(screen, index + 1u, false);
    screen[2] = ':';
    for (uint8_t i = 0; i < 5; i++)
        screen[16+i] = labels[stop][i];
    screen[10] = screen[13] = ':';
    screen[24] = screen[27] = '-';
    screen[28] = '2';
    screen[29] = '0';
    for (uint8_t i = 0; i < 6; i++)
        lcd_two_digits(screen + columns[i], time->field[i], i != 0 && i != 3);
    key &= 15u;
    if (!sqw && key != 2 && key != 3 && time->cursor < 6) {
        uint8_t column = columns[time->cursor];
        if (time->cursor == 5)
            screen[28] = screen[29] = ' ';
        screen[column] = screen[column+1] = ' ';
    }
}

/* [БИНАРНИК] 0x330E..0x33D8. Две строки состоят из форматов
 * 0x056D, 0x0581 и суффикса 0x0594 для источника АЦП. */
void nm_program_control_screen(const NM8036 *m, uint8_t index,
                               bool sqw, uint8_t key, uint8_t screen[32])
{
    static const uint8_t top[16] = {0xcd,0xe0,0xe3,0xf0,0xf3,0xe7,0xea,0xe0,':',' ',' ',0xd2,0xe8,0xef,':',' '};
    static const uint8_t bottom[16] = {0xc4,0xe0,0xf2,0xf7,0xe8,0xea,':',' ',' ',' ',' ',0xd2,0xe8,0xef,':','D'};
    static const uint8_t symbol[] = {1,2,0xa9,'x'};
    static const uint8_t columns[] = {9,15,23,31};
    uint16_t base = 0x4cu + 21u * index;
    for (uint8_t i = 0; i < 16; i++) {
        screen[i] = top[i];
        screen[16+i] = bottom[i];
    }
    uint8_t output = (nm_ee_read(m, base+12u) & 127u) + 1u;
    if (output < 100)
        lcd_two_digits(screen+9, output, false);
    else {
        screen[9] = '1';
        lcd_two_digits(screen+10, output-100u, true);
        for (uint8_t i = 12; i < 15; i++)
            screen[i] = top[i-1];
    }
    screen[15] = symbol[nm_ee_read(m, base) >> 6];
    lcd_two_digits(screen+23, (nm_ee_read(m, base+11u) & 31u) + 1u, true);
    if (nm_ee_read(m, base+5u) & 0x20u)
        screen[31] = 'A';
    uint8_t cursor = *nm_ram(m, 0x06b5);
    key &= 15u;
    if (!sqw && key != 2 && key != 3 && cursor < 4) {
        uint8_t column = columns[cursor];
        screen[column] = ' ';
        if (!(cursor & 1u))
            screen[column+1] = ' ';
    }
}

/* 0x36D2..0x36EA: сначала деление в binary32, затем
 * формат %.1f. Умножение мантиссы на 10 в целых сохраняет
 * разницу между точным полушагом и ближайшим float ниже него. */
static uint16_t threshold_tenths(uint16_t magnitude)
{
    if (!magnitude)
        return 0;
    float degrees = (float)magnitude / 100.0f;
    uint32_t bits;
    memcpy(&bits, &degrees, sizeof bits);
    uint8_t shift = 150u - ((bits >> 23) & 255u);
    uint32_t mantissa = (bits & UINT32_C(0x7fffff)) | UINT32_C(0x800000);
    return (uint16_t)((mantissa*10u + (UINT32_C(1) << (shift-1u))) >> shift);
}

/* [БИНАРНИК] 0x3600..0x3707. Служебные префиксы L:/H:
 * пишутся отдельно. При низкой фазе SQW поле скрыто целиком. */
void nm_program_threshold_screen(const NM8036 *m, uint8_t index,
                                 const NMThresholds *thresholds, bool sqw,
                                 uint8_t screen[32])
{
    memset(screen, ' ', 32);
    screen[0] = 'L';
    screen[16] = 'H';
    screen[1] = screen[17] = ':';
    for (uint8_t i = 0; i < 2; i++) {
        if (!sqw && thresholds->selected == i)
            continue;
        int16_t value = thresholds->value[i];
        uint8_t *line = screen + 16u*i;
        if (thresholds->analog) {
            uint16_t address = 0x4cu + 21u*index;
            uint8_t channel = nm_ee_read(m, address+11u) & 1u;
            char number[16];
            float reading = nm_adc_scale(m, channel, value);
#ifdef __AVR__
            dtostre(reading, number, 3, 0);
#else
            snprintf(number, sizeof number, "%.3e", (double)reading);
#endif
            uint8_t length = (uint8_t)strlen(number);
            uint8_t column = length > 9 ? 3 : 12u-length;
            memcpy(line+column, number, length);
            line[column+length] = nm_ee_read(m, 0x10u+channel);
        } else {
            uint16_t magnitude = value < 0 ? (uint16_t)(-(int32_t)value) : (uint16_t)value;
            uint16_t tenths = threshold_tenths(magnitude);
            line[6] = '.';
            line[7] = '0' + tenths%10u;
            line[8] = 'C';
            uint16_t digits = tenths/10u;
            uint8_t pos = 6;
            do {
                line[--pos] = '0' + digits%10u;
                digits /= 10u;
            } while (digits);
            if (value < 0)
                line[pos-1] = '-';
        }
    }
}
